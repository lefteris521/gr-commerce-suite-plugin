/**
 * Guest payment recovery form on the classic checkout. The form is rendered hidden (after form.checkout) and revealed only when
 * WooCommerce shows the blocked-payment notice. The answer is always the generic message from the server; nothing about the address or
 * order is ever echoed.
 */
(function ($) {
    'use strict';

    var cfg = window.grcsRecovery;
    if (!cfg || !$) {
        return;
    }

    function reveal() {
        var box = document.getElementById('grcs-recovery');
        if (box) {
            box.removeAttribute('hidden');
        }
    }

    // WooCommerce passes the error HTML as the event's second argument; compare as text so entity encoding cannot hide the match.
    $(document.body).on('checkout_error', function (event, html) {
        if (html && $('<div></div>').html(String(html)).text().indexOf(cfg.blocked) !== -1) {
            reveal();
        }
    });

    $(function () {
        var form = document.getElementById('grcs-recovery-form');
        var message = document.getElementById('grcs-recovery-msg');
        if (!form || !message || !window.fetch) {
            return;
        }
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            message.textContent = cfg.i18n.sending;
            window.fetch(form.action, { method: 'POST', body: new window.FormData(form), credentials: 'same-origin' })
                .then(function (response) { return response.json(); })
                .then(function (json) { message.textContent = (json && json.message) || cfg.i18n.failed; })
                .catch(function () { message.textContent = cfg.i18n.failed; });
        });
    });
}(window.jQuery));
