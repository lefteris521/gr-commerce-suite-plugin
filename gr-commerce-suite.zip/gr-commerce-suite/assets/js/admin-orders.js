/** Warehouse actions, scoped to their order row or metabox. */
(function ($) {
    'use strict';
    $(function () {
        var config = window.grcsAdminOrders || {};
        var i18n = config.i18n || {};
        function selectPanel($box, name) {
            $box.find('[data-grcs-mb-tab]').each(function () {
                var active = $(this).data('grcs-mb-tab') === name;
                $(this).attr({ 'aria-selected': String(active), tabindex: active ? '0' : '-1' });
            });
            $box.find('[data-grcs-mb-panel]').each(function () { $(this).prop('hidden', $(this).data('grcs-mb-panel') !== name); });
        }
        $('[data-grcs-mb-tab="courier"]').each(function () {
            var $box = $(this).closest('.grcs-metabox-wrapper');
            selectPanel($box, 'courier');
            if ($box.find('.grcs-mb-alert').length) { $box.find('[data-grcs-mb-tab="risk"]').addClass('has-risk'); }
        });
        $(document).on('click', '[data-grcs-mb-tab]', function () { selectPanel($(this).closest('.grcs-metabox-wrapper'), $(this).data('grcs-mb-tab')); });
        $(document).on('keydown', '[data-grcs-mb-tab]', function (event) {
            if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(event.key) === -1) { return; }
            event.preventDefault();
            var $box = $(this).closest('.grcs-metabox-wrapper');
            var name = event.key === 'Home' ? 'courier' : event.key === 'End' ? 'risk' : $(this).data('grcs-mb-tab') === 'risk' ? 'courier' : 'risk';
            selectPanel($box, name);
            $box.find('[data-grcs-mb-tab="' + name + '"]').trigger('focus');
        });
        $(document).on('click', '.grcs-issue-voucher-btn, .grcs-save-options, .grcs-cancel-voucher-btn, .grcs-resolve-cancel-pending, .grcs-blacklist-customer', function (event) {
            event.preventDefault();
            var $button = $(this);
            if ($button.prop('disabled')) { return; }
            var $box = $button.closest('.grcs-metabox-wrapper');
            var $feedback = $box.find('.grcs-metabox-feedback');
            var value = function (name) { return $box.find('[name="' + name + '"]').val(); };
            var payload = {
                security: $box.find('#grcs_order_nonce').val() || config.nonce,
                order_id: $box.data('order-id') || $box.find('#grcs_order_id').val()
            };
            var cancel = $button.hasClass('grcs-cancel-voucher-btn');
            var resolvePending = $button.hasClass('grcs-resolve-cancel-pending');
            if (resolvePending) {
                var reason = $.trim($box.find('.grcs-cancel-pending-reason').val() || '');
                if (!reason) {
                    $feedback.text(i18n.reasonRequired || 'A reason is required.').show();
                    return;
                }
                if ($button.data('resolve') !== 'retry' && !window.confirm(i18n.confirmResolveCancel)) { return; }
                payload.action = 'grcs_resolve_cancel_pending';
                payload.voucher_id = $button.data('voucher-id');
                payload.resolve_action = $button.data('resolve');
                payload.reason = reason;
            } else if (cancel) {
                if (!window.confirm(i18n.confirmCancel)) { return; }
                payload.action = 'grcs_cancel_voucher';
                payload.voucher_id = $button.data('voucher-id');
            } else if ($button.hasClass('grcs-blacklist-customer')) {
                payload.action = 'grcs_blacklist_customer';
                payload.blocked = String($button.data('blocked'));
                payload.operation = $button.data('operation') || '';
                payload.notes = value('grcs_risk_note') || '';
            } else {
                payload.action = $button.hasClass('grcs-save-options') ? 'grcs_save_parcel_options' : 'grcs_issue_voucher';
                // Free rule: a cancelled/refunded/failed or unpaid order needs an explicit OK; the server re-checks.
                var statusConfirm = $button.attr('data-grcs-confirm');
                if (payload.action === 'grcs_issue_voucher' && statusConfirm) {
                    if (!window.confirm(statusConfirm)) { return; }
                    payload.confirm_status = $button.attr('data-grcs-confirm-status') || '';
                }
                payload.courier = value('grcs_courier');
                payload.parcels = value('grcs_parcels');
                payload.weight = value('grcs_weight');
                payload.cod_amount = value('grcs_cod_amount');
                payload.locker_id = value('grcs_boxnow_locker_id');
                ['saturday', 'rdo', 'rec'].forEach(function (key) {
                    payload['grcs_acs_' + key] = $box.find('[name="grcs_acs_' + key + '"]').prop('checked') ? 'yes' : 'no';
                });
            }
            $button.prop('disabled', true);
            $feedback.text(resolvePending ? (i18n.resolvingCancel || 'Resolving...') : i18n[cancel ? 'cancelling' : 'issuing']).show();
            $.post(config.ajaxUrl || window.ajaxurl, payload).done(function (response) {
                if (response && response.success) {
                    if (payload.action === 'grcs_save_parcel_options') {
                        $feedback.text(response.data.message);
                    } else {
                        window.location.reload();
                    }
                } else {
                    $feedback.text(response && response.data ? response.data.message : i18n.errorGeneric);
                }
            }).fail(function (xhr) {
                var response = xhr.responseJSON;
                $feedback.text(response && response.data ? response.data.message : i18n.errorGeneric);
            }).always(function () { $button.prop('disabled', false); });
        });
        $(document).on('click', '.grcs-copy-voucher', function (event) {
            event.preventDefault();
            var button = this;
            var text = button.getAttribute('data-copy') || '';
            var label = button.getAttribute('data-label') || button.textContent;
            button.setAttribute('data-label', label);
            var done = function (ok) {
                // A silent failure would leave the merchant pasting a stale number; say so.
                button.textContent = ok ? (i18n.copied || '✓') : (i18n.copyFailed || label);
                window.setTimeout(function () { button.textContent = label; }, 2000);
            };
            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(false); });
            } else {
                done(false);
            }
        });
        // Show only the chosen courier's fields; hidden inputs keep their values and are still sent.
        function toggleAcs($box) {
            var courier = $box.find('[name="grcs_courier"]').val();
            $box.find('.grcs-acs-options').prop('hidden', courier !== 'acs');
            $box.find('.grcs-boxnow-locker-field').prop('hidden', courier !== 'boxnow');
        }
        $('.grcs-metabox-wrapper').each(function () { toggleAcs($(this)); });
        $(document).on('change', '[name="grcs_courier"]', function () { toggleAcs($(this).closest('.grcs-metabox-wrapper')); });
    });
})(jQuery);
