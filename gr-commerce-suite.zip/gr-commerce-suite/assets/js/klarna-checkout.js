/**
 * Klarna Payments on the classic checkout (shortcode). Flow: session sync (server) -> Klarna.Payments.load -> on place order
 * Klarna.Payments.authorize -> authorization token in a hidden field -> WooCommerce submits -> server exchanges it for an order.
 * The browser never sees card data (Klarna's iframe collects it) and a returning success URL never marks anything paid.
 * Delegated on updated_checkout: WooCommerce replaces the payment section on every update, so the widget is re-loaded each time.
 */
(function ($) {
    'use strict';

    var cfg = window.grcsKlarna;
    if (!cfg || !$) {
        return;
    }
    var state = { token: '', categories: [], category: '', authorizing: false, timer: null, syncing: false, resume: false, pending: false };

    function selected() {
        return $('form.checkout input[name="payment_method"]:checked').val() === cfg.gateway;
    }

    function field(name) {
        return $.trim($('form.checkout [name="' + name + '"]').val() || '');
    }

    function billing() {
        var map = {
            given_name: 'billing_first_name', family_name: 'billing_last_name', email: 'billing_email', phone: 'billing_phone',
            street_address: 'billing_address_1', street_address2: 'billing_address_2', postal_code: 'billing_postcode',
            city: 'billing_city', region: 'billing_state', country: 'billing_country'
        };
        var address = {};
        Object.keys(map).forEach(function (key) {
            var value = field(map[key]);
            if (value) {
                address[key] = value;
            }
        });
        return address;
    }

    function notice(message) {
        $('.woocommerce-NoticeGroup-checkout').remove();
        var list = $('<ul class="woocommerce-error" role="alert"></ul>').append($('<li></li>').text(message));
        $('form.checkout').prepend($('<div class="woocommerce-NoticeGroup woocommerce-NoticeGroup-checkout"></div>').append(list));
        $('html, body').animate({ scrollTop: $('form.checkout').offset().top - 100 }, 300);
    }

    function setToken(value) {
        state.token = value || '';
        $('#grcs-klarna-token').val(state.token);
    }

    function unavailable() {
        $('#grcs-klarna-container').empty().append($('<p class="grcs-klarna-unavailable"></p>').text(cfg.i18n.unavailable));
    }

    function inform(message, resume, url) {
        // No Klarna session, widget or authorisation is created: the server told us the order is already held (resume) or that an
        // earlier payment is still being verified (pending). Both are re-decided by the server on every checkout update.
        state.resume = resume;
        state.pending = !resume;
        var paragraph = $('<p class="grcs-klarna-' + (resume ? 'resume' : 'pending') + '"></p>').text(message);
        if (url) {
            paragraph.append(document.createTextNode(' ')).append($('<a></a>').attr('href', url).text(cfg.i18n.status));
        }
        $('#grcs-klarna-container').empty().append(paragraph);
    }

    function render(data) {
        state.resume = false;
        state.pending = false;
        var container = $('#grcs-klarna-container').empty();
        if (!window.Klarna || !window.Klarna.Payments || !data.client_token || !data.categories || !data.categories.length) {
            return unavailable();
        }
        try {
            window.Klarna.Payments.init({ client_token: data.client_token });
        } catch (error) {
            return unavailable();
        }
        state.categories = data.categories;
        var known = data.categories.some(function (category) { return category.identifier === state.category; });
        state.category = known ? state.category : data.categories[0].identifier;
        data.categories.forEach(function (category) {
            var id = 'grcs-klarna-cat-' + category.identifier;
            var row = $('<div class="grcs-klarna-category"></div>');
            if (data.categories.length > 1) {
                var radio = $('<input type="radio" name="grcs_klarna_cat" />').val(category.identifier).prop('checked', category.identifier === state.category);
                row.append($('<label></label>').append(radio).append(document.createTextNode(' ' + category.name)));
            }
            row.append($('<div></div>').attr('id', id));
            container.append(row);
            try {
                window.Klarna.Payments.load({ container: '#' + id, payment_method_category: category.identifier }, {}, function (response) {
                    if (response && response.show_form === false) {
                        $('#' + id).empty();
                    }
                });
            } catch (error) {
                unavailable();
            }
        });
    }

    function sync() {
        if (!selected() || state.syncing) {
            return;
        }
        state.syncing = true;
        $.post(cfg.sessionUrl, { nonce: cfg.nonce })
            .done(function (response) {
                if (response && response.success && response.data && response.data.resume === true) {
                    setToken('');
                    inform(cfg.i18n.resume, true);
                } else if (response && response.success && response.data && response.data.pending_verification === true) {
                    setToken('');
                    inform(cfg.i18n.pending, false, response.data.url);
                } else if (response && response.success) {
                    render(response.data);
                } else {
                    state.resume = false;
                    state.pending = false;
                    unavailable();
                }
            })
            .fail(function () { state.resume = false; state.pending = false; unavailable(); })
            .always(function () { state.syncing = false; });
    }

    function schedule() {
        window.clearTimeout(state.timer);
        state.timer = window.setTimeout(sync, 150);
    }

    function authorize(done) {
        if (!window.Klarna || !window.Klarna.Payments || !state.category) {
            return notice(cfg.i18n.unavailable);
        }
        state.authorizing = true;
        try {
            window.Klarna.Payments.authorize({ payment_method_category: state.category }, { billing_address: billing() }, function (response) {
                state.authorizing = false;
                if (response && response.approved && response.authorization_token) {
                    setToken(response.authorization_token);
                    done();
                } else if (!response || response.show_form !== true) {
                    // show_form === true means Klarna keeps the form open for the customer to correct details.
                    setToken('');
                    notice(cfg.i18n.declined);
                }
            });
        } catch (error) {
            state.authorizing = false;
            notice(cfg.i18n.unavailable);
        }
    }

    $(function () {
        // triggerHandler does not bubble: bind to the form itself (it is not replaced by updated_checkout).
        $('form.checkout').on('checkout_place_order_' + cfg.gateway, function () {
            if (state.pending) {
                notice(cfg.i18n.pending);
                return false;
            }
            if (state.token || state.resume) {
                // resume: the server resumes the order Klarna already holds; asking Klarna for another authorisation would only leave
                // an unused one open. If the server disagrees it refuses with a notice and the next update re-decides.
                return true;
            }
            if (!state.authorizing) {
                authorize(function () { $('form.checkout').trigger('submit'); });
            }
            return false;
        });
        $('form.checkout').on('change', 'input[name="grcs_klarna_cat"]', function () {
            state.category = $(this).val();
            setToken('');
        });
        $(document.body)
            .on('updated_checkout payment_method_selected', function () { setToken(''); state.resume = false; state.pending = false; schedule(); })
            .on('checkout_error', function () { setToken(''); state.resume = false; state.pending = false; schedule(); });
        schedule();
    });
}(window.jQuery));
