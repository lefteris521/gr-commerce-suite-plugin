(function ($) {
    'use strict';
    $(document).on('click', '.grcs-test-connection', function () {
        var $button = $(this), $panel = $button.closest('.grcs-connection-tests');
        var courier = $button.data('courier'), credentials = {};
        $('[id^="grcs_' + courier + '_"]').each(function () {
            if (this.tagName === 'INPUT' || this.tagName === 'SELECT') {
                var key = this.id.replace('grcs_' + courier + '_', '');
                if (courier === 'geniki') {
                    key = ({ default_service: 'default_service_code', cod_service: 'cod_service_code' })[key] || key;
                }
                credentials[key] = $(this).val();
            }
        });
        var data = { action: 'grcs_test_courier_connection', security: $panel.data('nonce'), courier: courier, credentials: credentials };
        var $sandbox = $('#grcs_sandbox_mode');
        if ($sandbox.length) { data.sandbox_mode = $sandbox.is(':checked') ? 'yes' : 'no'; }
        var $result = $button.siblings('.grcs-connection-result').empty();
        $button.prop('disabled', true).attr('aria-busy', 'true');
        function show(response) {
            $result.css('color', response && response.success ? '#008a20' : '#b32d2e')
                .text(response && response.data && response.data.message ? response.data.message : window.grcsConnection.i18n.failed);
        }
        $.post($panel.data('url'), data).done(show).fail(function (xhr) { show(xhr.responseJSON); })
            .always(function () { $button.prop('disabled', false).removeAttr('aria-busy'); });
    });
})(jQuery);
