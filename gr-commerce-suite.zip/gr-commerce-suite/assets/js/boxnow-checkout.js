/* Official BOX NOW v5 popup, enhanced native Checkout Fields, and Classic checkout. */
(function () {
    'use strict';
    var config = window.grcsBoxNowCheckout || {}, fieldId = 'grcs/boxnow-locker-id';
    var active = false, selection = '', generation = 0, summary = '', failure = '', pending = false, attempted = false;
    var widgetPromise, trigger, map, fallbackOpen = false, lastValidation, previousRates = null, scheduled = false;
    // The last confirmed locker, offered again (and re-verified) if the customer returns to BOX NOW.
    var remembered = '';
    function blocks() { return !!document.querySelector('.wc-block-checkout'); }
    function fields() {
        var store = window.wp && wp.data && wp.data.select('wc/store/checkout');
        return (store && store.getAdditionalFields ? store.getAdditionalFields() : {}) || {};
    }
    function input() {
        return document.querySelector('#grcs_boxnow_locker_id, [id$="grcs-boxnow-locker-id"], [id$="grcs/boxnow-locker-id"], [name="grcs/boxnow-locker-id"]');
    }
    function value() { var el = input(); return blocks() ? (fields()[fieldId] || '') : (el ? el.value : ''); }
    function setValue(id) {
        var el = input();
        if (blocks() && window.wp && wp.data) {
            var data = fields(), actions = wp.data.dispatch('wc/store/checkout');
            if (actions && actions.setAdditionalFields && data[fieldId] !== id) {
                actions.setAdditionalFields(Object.assign({}, data, { [fieldId]: id }));
            }
        } else if (el && el.value !== id) {
            el.value = id;
            el.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }
    function selectedRates() {
        if (!blocks()) {
            return Array.from(document.querySelectorAll('input[name^="shipping_method"]')).filter(function (el) {
                return el.checked || el.type === 'hidden';
            }).map(function (el) { return el.value; });
        }
        var store = window.wp && wp.data && wp.data.select('wc/store/cart');
        var cart = store && store.getCartData ? store.getCartData() : {};
        var ids = [];
        ((cart || {}).shippingRates || (cart || {}).shipping_rates || []).forEach(function (parcel) {
            (parcel.shipping_rates || parcel.shippingRates || []).forEach(function (rate) {
                if (rate.selected) { ids.push(rate.rate_id || rate.rateId); }
            });
        });
        return ids;
    }
    function isBoxNow(id) {
        if (typeof id !== 'string') { return false; }
        var method = id.split(':')[0];
        function mapped(list) { return (list || []).indexOf(id) !== -1 || (list || []).indexOf(method) !== -1; }
        if (method === 'grcs_boxnow') { return true; }
        if (method === 'grcs_acs' || mapped(config.acsMethods)) { return false; }
        return mapped(config.methods) || /^(boxnow|box_now|box-now)$/.test(method);
    }
    function validation() {
        var message = active && (!selection || pending || failure) ? (failure || config.required) : '';
        if (lastValidation === message) { return; }
        lastValidation = message;
        if (blocks() && window.wp && wp.data) {
            var actions = wp.data.dispatch('wc/store/validation');
            if (actions && actions.setValidationErrors && actions.clearValidationError) {
                if (message) { actions.setValidationErrors({ 'grcs-boxnow-locker': { message: message, hidden: false } }); }
                else { actions.clearValidationError('grcs-boxnow-locker'); }
            }
        }
    }
    function status() {
        var hasSelection = !!selection && !pending && !failure && !!summary;
        // After a blocked order attempt the missing locker is shown as an error, not a neutral hint.
        var state = failure ? 'error' : (pending ? 'loading' : (hasSelection ? 'selected' : (attempted && active ? 'error' : 'required')));
        if (hasSelection) { attempted = false; }
        document.querySelectorAll('.grcs-boxnow-control-ready').forEach(function (el) {
            el.setAttribute('data-state', state);
        });
        document.querySelectorAll('.grcs-boxnow-change').forEach(function (el) {
            el.hidden = !hasSelection;
        });
        document.querySelectorAll('.grcs-boxnow-status').forEach(function (el) {
            var text = failure || (pending ? config.loading : summary || config.required);
            if (el.textContent !== text) { el.textContent = text; }
            el.setAttribute('data-state', state);
        });
        validation();
    }
    function choose(id, widget) {
        if (!active || !/^[a-zA-Z0-9_-]{1,64}$/.test(String(id))) { return; }
        var ticket = ++generation;
        selection = ''; summary = ''; failure = ''; pending = true; setValue(''); status();
        var controller = typeof AbortController === 'function' ? new AbortController() : null;
        var timeout = window.setTimeout(function () {
            if (ticket !== generation || !active) { return; }
            ++generation; pending = false; failure = config.unavailable; status();
            if (controller) { controller.abort(); }
        }, 20000);
        var params = { action: 'grcs_boxnow_validate_locker', security: config.nonce, locker: String(id) };
        if (config.sandbox && widget) {
            // Sandbox cannot verify live lockers, so the server records the widget's description as test data.
            params.name = String(widget.boxnowLockerName || '');
            params.address = String(widget.boxnowLockerAddressLine1 || '');
            params.postcode = String(widget.boxnowLockerPostalCode || '');
        }
        return fetch(config.ajaxUrl, { method: 'POST', credentials: 'same-origin', signal: controller ? controller.signal : undefined,
            body: new URLSearchParams(params)
        }).then(function (response) { return response.json(); }).then(function (response) {
            if (ticket !== generation || !active) { return; }
            if (!response.success || !response.data || String(response.data.id) !== String(id)) { throw new Error(); }
            var details = response.data;
            selection = String(details.id);
            var address = [details.address, details.postcode, details.city].filter(Boolean).join(', ');
            summary = 'Θυρίδα: ' + (details.name || selection) + (address ? ' — ' + address : '');
            pending = false; setValue(selection); status();
        }).catch(function () {
            if (ticket !== generation || !active) { return; }
            pending = false; failure = config.unavailable; setValue(''); status();
        }).finally(function () { window.clearTimeout(timeout); });
    }
    function setFallback(open) {
        fallbackOpen = open;
        document.querySelectorAll('.grcs-boxnow-fallback').forEach(function (el) { el.hidden = !open; });
        document.querySelectorAll('.grcs-boxnow-fallback-toggle').forEach(function (el) {
            el.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }
    function mapFailed() {
        failure = config.unavailable;
        if (config.sandbox) { setFallback(true); }
        status();
    }
    function loadWidget() {
        if (widgetPromise) { return widgetPromise; }
        map = document.createElement('div'); map.id = 'grcs-boxnow-map'; map.style.position = 'fixed'; map.style.zIndex = '2147483000';
        map.style.inset = '0'; map.style.width = '100%'; map.style.height = '100%'; map.style.pointerEvents = 'none';
        trigger = document.createElement('button'); trigger.type = 'button'; trigger.hidden = true; trigger.id = 'grcs-boxnow-map-trigger';
        document.body.appendChild(map); document.body.appendChild(trigger);
        // Production and Sandbox both use the official map; 123 is BOX NOW's public demo partner.
        window._bn_map_widget_config = {
            parentElement: '#grcs-boxnow-map', buttonSelector: '#grcs-boxnow-map-trigger',
            partnerId: config.partnerId || 123,
            type: 'popup', gps: true, autoclose: true, autoselect: false,
            afterSelect: function (selected) {
                if (selected && selected.boxnowLockerId && active) { choose(selected.boxnowLockerId, selected); }
            }
        };
        widgetPromise = new Promise(function (resolve, reject) {
            var script = document.createElement('script');
            var timeout = window.setTimeout(function () { script.remove(); reject(new Error()); }, 20000);
            script.src = 'https://widget-cdn.boxnow.gr/map-widget/client/v5.js'; script.async = true;
            script.onload = function () { window.clearTimeout(timeout); resolve(); };
            script.onerror = function () { window.clearTimeout(timeout); script.remove(); reject(new Error()); };
            document.head.appendChild(script);
        }).catch(function (error) { widgetPromise = null; trigger.remove(); map.remove(); throw error; });
        return widgetPromise;
    }
    function openMap() {
        failure = ''; status();
        loadWidget().then(function () {
            if (!active) { return; }
            map.querySelectorAll('iframe').forEach(function (frame) { frame.remove(); });
            trigger.click();
            var frame = map.querySelector('iframe');
            if (frame) {
                frame.title = 'BOX NOW locker selection map';
                var timeout = window.setTimeout(mapFailed, 20000);
                frame.addEventListener('load', function () { window.clearTimeout(timeout); });
                frame.addEventListener('error', function () { window.clearTimeout(timeout); mapFailed(); });
            }
        }).catch(mapFailed);
    }
    function controls(wrapper) {
        if (wrapper.querySelector('.grcs-boxnow-control-ready')) { return; }
        var root = document.createElement('div'); root.className = 'grcs-boxnow-control-ready grcs-checkout-wrap grcs-boxnow-picker';
        var button = document.createElement('button'); button.type = 'button'; button.className = 'button grcs-boxnow-open'; button.textContent = config.select;
        root.appendChild(button);
        var message = document.createElement('p'); message.id = 'grcs-boxnow-locker-status'; message.className = 'grcs-boxnow-status'; message.setAttribute('role', 'status'); message.setAttribute('aria-live', 'polite');
        var change = document.createElement('button'); change.type = 'button'; change.className = 'button grcs-boxnow-open grcs-boxnow-change'; change.textContent = 'Αλλαγή'; change.hidden = true;
        root.appendChild(message); root.appendChild(change);
        if (config.sandbox) {
            // Secondary offline path for sandbox tests without internet or with the widget CDN blocked.
            var toggle = document.createElement('button'); toggle.type = 'button'; toggle.className = 'grcs-boxnow-fallback-toggle';
            toggle.textContent = config.fallback; toggle.setAttribute('aria-controls', 'grcs-boxnow-fallback');
            toggle.setAttribute('aria-expanded', fallbackOpen ? 'true' : 'false');
            toggle.addEventListener('click', function () { setFallback(!fallbackOpen); });
            var fallback = document.createElement('div'); fallback.id = 'grcs-boxnow-fallback'; fallback.className = 'grcs-boxnow-fallback'; fallback.hidden = !fallbackOpen;
            var label = document.createElement('label'); label.textContent = config.simulation;
            label.setAttribute('for', 'grcs-boxnow-sandbox-locker');
            var select = document.createElement('select'); select.id = 'grcs-boxnow-sandbox-locker';
            select.setAttribute('aria-label', config.select);
            select.setAttribute('aria-describedby', 'grcs-boxnow-locker-status');
            var blank = document.createElement('option'); blank.value = ''; blank.textContent = config.select; select.appendChild(blank);
            Object.keys(config.mockLockers || {}).forEach(function (id) {
                var option = document.createElement('option'); option.value = id; option.textContent = config.mockLockers[id]; select.appendChild(option);
            });
            select.value = value();
            fallback.appendChild(label); fallback.appendChild(select);
            root.appendChild(toggle); root.appendChild(fallback);
        }
        wrapper.appendChild(root);
    }
    function update() {
        var rates = selectedRates(), signature = JSON.stringify(rates);
        var show = rates.some(isBoxNow), el = input();
        if (previousRates !== null && previousRates !== signature) {
            if (selection && !pending && !failure) { remembered = selection; }
            ++generation; selection = ''; summary = ''; failure = ''; pending = false; setValue('');
            if (map) { map.querySelectorAll('iframe').forEach(function (frame) { frame.remove(); }); }
        }
        previousRates = signature;
        if (active !== show) {
            active = show;
            if (!show) {
                ++generation; selection = ''; summary = ''; failure = ''; pending = false; setValue('');
                if (map) { map.querySelectorAll('iframe').forEach(function (frame) { frame.remove(); }); }
            }
        }
        var wrapper = el && (blocks() ? el.closest('.wc-block-components-text-input') : document.querySelector('#grcs-boxnow-locker-checkout-field'));
        if (wrapper) {
            wrapper.setAttribute('data-grcs-boxnow-picker', '');
            wrapper.hidden = !show;
            if (show) {
                controls(wrapper);
                var simulated = wrapper.querySelector('select');
                if (config.sandbox && simulated && !pending) { simulated.value = value(); }
            }
        }
        if (!show && value()) { setValue(''); }
        if (show && selection && !pending && !failure && !value()) { setValue(selection); }
        // Restored draft values must be verified in the current environment too.
        if (show && value() && !selection && !pending && !failure) { choose(value()); }
        else if (show && remembered && !value() && !selection && !pending && !failure) {
            var again = remembered; remembered = ''; choose(again);
        }
        status();
    }
    function schedule() {
        if (scheduled) { return; } scheduled = true;
        window.requestAnimationFrame(function () { scheduled = false; update(); });
    }
    if (window.wp && wp.data) { wp.data.subscribe(schedule); }
    document.body.addEventListener('click', function (event) {
        if (event.target.closest('.grcs-boxnow-open')) { event.preventDefault(); openMap(); }
    });
    document.body.addEventListener('change', function (event) {
        var el = event.target;
        if (el.id === 'grcs-boxnow-sandbox-locker' && config.sandbox) {
            if (el.value) { choose(el.value); }
            else { ++generation; selection = ''; summary = ''; failure = ''; pending = false; setValue(''); status(); }
        }
        schedule();
    });
    document.body.addEventListener('submit', function (event) {
        if (active && (!selection || pending || failure)) { event.preventDefault(); attempted = true; status(); }
    }, true);
    if (window.jQuery) {
        window.jQuery(document.body).on('updated_checkout', schedule);
        // WooCommerce calls $form.triggerHandler('checkout_place_order'), which never bubbles to a delegated body handler.
        window.jQuery(function ($) {
            $('form.checkout').on('checkout_place_order', function () {
                if (!active || (!!selection && !pending && !failure)) { return true; }
                attempted = true; status();
                var wrapper = document.querySelector('#grcs-boxnow-locker-checkout-field');
                if (wrapper && wrapper.scrollIntoView) { wrapper.scrollIntoView({ block: 'center' }); }
                var open = wrapper && wrapper.querySelector('.grcs-boxnow-open:not([hidden])');
                if (open && open.focus) { open.focus({ preventScroll: true }); }
                return false;
            });
        });
    }
    new MutationObserver(schedule).observe(document.documentElement, { childList: true, subtree: true });
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', schedule); } else { schedule(); }
})();
