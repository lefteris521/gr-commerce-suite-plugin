/* Classic toggle and progressive enhancement of WooCommerce's native Blocks fields. */
(function () {
    'use strict';
    var config = window.grcsInvoice || {};
    var automaticVat = '';
    var rejectedFields = {};
    function markRejected(input) {
        var row = input && document.getElementById(input.id + '_field');
        if (row && isInvoice()) {
            row.classList.remove('woocommerce-validated');
            row.classList.add('woocommerce-invalid');
            input.setAttribute('aria-invalid', 'true');
        }
    }
    function field(key) {
        var block = key.replace(/_/g, '-');
        return document.querySelector('#grcs_' + key + ', [id$="grcs-' + block + '"], [id$="grcs/' + block + '"], [name="grcs/' + block + '"]');
    }
    function isInvoice() {
        var radio = document.querySelector('[name="grcs_document_type"]:checked');
        var select = field('document_type');
        return (radio ? radio.value : select ? select.value : 'receipt') === 'invoice';
    }
    function setValue(input, value) {
        if (!input) { return; }
        // Native setter plus an input event allows React to update its controlled field state.
        var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
        setter.call(input, value);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
    }
    var autofilled = {};
    function populate(details, replaceTyped) {
        // Registry details belong to the invoice. Billing may also be the delivery address;
        // only the customer may change either address through WooCommerce's address fields.
        // An automatic lookup never replaces what the customer typed; the lookup button may.
        [['company_name', details.company || details.company_name || ''], ['doy', details.doy || ''],
            ['profession', details.profession || '']].forEach(function (pair) {
            var input = field(pair[0]);
            if (!input) { return; }
            var current = input.value.trim();
            if (replaceTyped || current === '' || current === autofilled[pair[0]]) {
                setValue(input, pair[1]);
                autofilled[pair[0]] = pair[1];
            }
        });
    }
    function sync() {
        var invoice = isInvoice();
        if (!invoice) { rejectedFields = {}; }
        var fieldset = document.querySelector('#grcs-invoice-checkout');
        if (fieldset && fieldset.classList) { fieldset.classList.add('grcs-checkout-wrap'); }
        var documentType = field('document_type');
        if (documentType && document.querySelector('.wc-block-checkout')) {
            var documentWrapper = documentType.closest('.wc-blocks-components-select, .wc-block-components-select, .wc-block-components-combobox');
            if (documentWrapper) { documentWrapper.classList.add('grcs-document-block-field'); }
        }
        var classic = document.querySelector('.grcs-invoice-fields');
        if (classic) {
            classic.hidden = !invoice;
            classic.querySelectorAll('input').forEach(function (input) {
                input.required = invoice;
                input.setAttribute('aria-required', invoice ? 'true' : 'false');
                var row = input.closest('.form-row');
                if (row) {
                    row.classList.toggle('validate-required', invoice);
                    if (!invoice) {
                        row.classList.remove('woocommerce-invalid', 'woocommerce-invalid-required-field', 'woocommerce-validated');
                        input.removeAttribute('aria-invalid');
                    }
                }
            });
        }
        ['vat_number', 'company_name', 'doy', 'profession'].forEach(function (key) {
            var input = field(key);
            if (!input) { return; }
            // Supports WooCommerce 9.6–9.8, before native conditional field visibility.
            if (!classic || !classic.contains(input)) {
                var wrapper = input.closest('.wc-block-components-text-input');
                if (wrapper) { wrapper.classList.add('grcs-invoice-block-field'); wrapper.hidden = !invoice; }
                input.required = invoice;
            }
        });
        var vat = field('vat_number');
        if (!vat || !invoice || vat.parentNode.querySelector('.grcs-invoice-lookup')) { return; }
        var button = document.createElement('button');
        button.type = 'button';
        button.className = 'button grcs-invoice-lookup';
        button.textContent = config.lookup || '🔍 Αναζήτηση ΑΑΔΕ';
        var feedback = document.createElement('span');
        feedback.className = 'grcs-invoice-feedback';
        feedback.setAttribute('role', 'status');
        feedback.setAttribute('aria-live', 'polite');
        var busy = false;
        var lastAttempt = '';
        var debounce;
        var confirmationTimer;
        function show(message, state) {
            window.clearTimeout(confirmationTimer);
            feedback.textContent = message;
            feedback.setAttribute('data-state', state || '');
        }
        function lookup(force) {
            var requestedVat = vat.value.trim();
            if (busy || !isInvoice() || (!force && (lastAttempt === requestedVat || automaticVat === requestedVat))) { return; }
            if (!/^[0-9]{9}$/.test(requestedVat)) { if (force) { vat.reportValidity(); } return; }
            busy = true;
            lastAttempt = requestedVat;
            automaticVat = requestedVat;
            button.disabled = true;
            button.setAttribute('data-loading', 'true');
            feedback.setAttribute('aria-busy', 'true');
            show(config.loading, 'loading');
            var body = new URLSearchParams({ action: 'grcs_lookup_afm', security: config.nonce, afm: requestedVat });
            fetch(config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body }).then(function (response) {
                return response.json();
            }).then(function (response) {
                var currentVat = field('vat_number');
                if (!currentVat || currentVat.value.trim() !== requestedVat || !isInvoice()) { return; }
                if (response.success && response.data.details) {
                    populate(response.data.details, force === true);
                    show(response.data.simulated ? config.simulation : config.success, 'success');
                    confirmationTimer = window.setTimeout(function () { show('', ''); }, 7000);
                } else {
                    show(response.data && response.data.message ? response.data.message : config.fallback, 'error');
                }
            }).catch(function () {
                if (vat.value.trim() === requestedVat && isInvoice()) { show(config.fallback, 'error'); }
            }).finally(function () {
                busy = false;
                button.disabled = false;
                button.setAttribute('data-loading', 'false');
                feedback.setAttribute('aria-busy', 'false');
                if (vat.value.trim() !== requestedVat) { lookup(false); }
                if (!isInvoice()) { show('', ''); }
            });
        }
        button.addEventListener('click', function () { lookup(true); });
        vat.addEventListener('input', function () {
            window.clearTimeout(debounce);
            show('', '');
            lastAttempt = '';
            automaticVat = '';
            debounce = window.setTimeout(function () { lookup(false); }, 350);
        });
        vat.addEventListener('blur', function () { lookup(false); });
        vat.parentNode.appendChild(button);
        vat.parentNode.appendChild(feedback);
        // Also covers a prefilled AFM when switching from receipt to invoice.
        lookup(false);
    }
    document.addEventListener('change', sync);
    if (window.jQuery) {
        window.jQuery(document.body).on('updated_checkout.grcsInvoice', sync)
            .on('checkout_error.grcsInvoice', function () {
                rejectedFields = {};
                // WooCommerce notices supply data-id; checksum errors need this even on non-empty inputs.
                document.querySelectorAll('.woocommerce-error [data-id], .wc-block-components-notice-banner.is-error [data-id]').forEach(function (notice) {
                    var id = notice.getAttribute('data-id');
                    if (!/^grcs_(vat_number|company_name|doy|profession)$/.test(id)) { return; }
                    var input = document.getElementById(id);
                    if (input && isInvoice()) {
                        rejectedFields[id] = input.value;
                        markRejected(input);
                    }
                });
            }).on('validate.grcsInvoice blur.grcsInvoice',
                '#grcs_vat_number, #grcs_company_name, #grcs_doy, #grcs_profession', function () {
                    // A non-empty AFM can still fail its checksum. Keep the server rejection
                    // through WooCommerce's later blur validation until the value changes.
                    if (rejectedFields[this.id] === this.value) { markRejected(this); }
                });
    }
    document.addEventListener('input', function (event) {
        var input = event.target;
        if (input && /^grcs_(vat_number|company_name|doy|profession)$/.test(input.id)) {
            delete rejectedFields[input.id];
            input.removeAttribute('aria-invalid');
            var row = input.closest('.form-row');
            if (row) { row.classList.remove('woocommerce-invalid', 'woocommerce-invalid-required-field'); }
        }
    });
    var scheduled = false;
    var observer = new MutationObserver(function () {
        if (!scheduled) {
            scheduled = true;
            window.requestAnimationFrame(function () { scheduled = false; sync(); });
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    sync();
})();
