/** Klarna settings screen: "Test connection" buttons (one AJAX call; the server tests the saved credentials). */
(function ($) {
    'use strict';

    var cfg = window.grcsKlarnaAdmin;
    if (!cfg || !$) {
        return;
    }
    $(document).on('click', '[data-grcs-klarna-test]', function () {
        var button = $(this);
        var result = $('#grcs-klarna-test-result').removeClass('is-ok is-error').text(cfg.i18n.testing);
        button.prop('disabled', true);
        $.post(cfg.ajaxUrl, { action: cfg.action, nonce: cfg.nonce, environment: button.attr('data-grcs-klarna-test') })
            .done(function (response) {
                var ok = !!(response && response.success);
                var message = response && response.data && response.data.message ? response.data.message : cfg.i18n.failed;
                result.addClass(ok ? 'is-ok' : 'is-error').css('color', ok ? '#1a7f37' : '#b32d2e').text(message);
            })
            .fail(function (xhr) {
                var data = xhr && xhr.responseJSON && xhr.responseJSON.data;
                result.addClass('is-error').css('color', '#b32d2e').text(data && data.message ? data.message : cfg.i18n.failed);
            })
            .always(function () { button.prop('disabled', false); });
    });
}(window.jQuery));
