/* Classic Checkout: reflect only GRCS's server-rejected delivery postcode and courier phone. */
(function ($) {
    'use strict';
    var rejected = {};
    function describe(input, id, add) {
        var ids = (input.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
        ids = ids.filter(function (value) { return value !== id; });
        if (add) { ids.push(id); }
        if (ids.length) { input.setAttribute('aria-describedby', ids.join(' ')); }
        else { input.removeAttribute('aria-describedby'); }
    }
    function clear(id) {
        var state = rejected[id];
        if (!state) { return; }
        state.row.classList.remove('woocommerce-invalid-postcode');
        // Do not clear another validator's required/email/etc. failure.
        if (!/\bwoocommerce-invalid-/.test(state.row.className)) {
            state.row.classList.remove('woocommerce-invalid');
            state.input.removeAttribute('aria-invalid');
            // Recent WooCommerce adds its inline message after checkout_error fires.
            var inline = document.getElementById(id + '_description');
            if (inline && inline.classList.contains('checkout-inline-error-message')
                && inline.textContent.trim() === state.notice.textContent.trim()) {
                describe(state.input, inline.id, false);
                inline.remove();
            }
        }
        describe(state.input, state.notice.id, false);
        delete rejected[id];
    }
    function mark(state) {
        state.row.classList.remove('woocommerce-validated');
        state.row.classList.add('woocommerce-invalid', 'woocommerce-invalid-postcode');
        state.input.setAttribute('aria-invalid', 'true');
        describe(state.input, state.notice.id, true);
    }
    $(document.body).on('checkout_error.grcsPostcode', function () {
        Object.keys(rejected).forEach(clear);
        document.querySelectorAll('form.checkout [data-grcs-postcode][data-id], form.checkout [data-grcs-field][data-id]').forEach(function (notice) {
            var id = notice.getAttribute('data-id');
            var allowed = notice.getAttribute('data-grcs-postcode')
                ? ['billing_postcode', 'shipping_postcode'] : ['billing_phone', 'shipping_phone'];
            if (allowed.indexOf(id) < 0) { return; }
            var input = document.getElementById(id);
            var row = document.getElementById(id + '_field');
            if (!input || !row) { return; }
            notice.id = 'grcs-' + id + '-error';
            rejected[id] = { input: input, row: row, notice: notice, value: input.value };
            mark(rejected[id]);
        });
    }).on('input.grcsPostcode change.grcsPostcode validate.grcsPostcode focusout.grcsPostcode',
        'form.checkout #billing_postcode, form.checkout #shipping_postcode, form.checkout #billing_phone, form.checkout #shipping_phone', function () {
            var state = rejected[this.id];
            if (!state) { return; }
            // Follow native checkout feedback: edits clear the rejection; submission revalidates.
            if (this.value !== state.value) { clear(this.id); }
            else { mark(state); }
        }).on('change.grcsPostcode',
        'form.checkout #billing_country, form.checkout #shipping_country, form.checkout #ship-to-different-address-checkbox, form.checkout [name^="shipping_method"]',
        function () { Object.keys(rejected).forEach(clear); });

    // A courier needs the customer's phone. The billing field is not re-rendered when the
    // shipping method changes, so mirror the server's requirement on its "(optional)" label.
    $(document.body).on('updated_checkout.grcsPhone', function () {
        var marker = document.querySelector('[data-grcs-phone-required]');
        var row = document.getElementById('billing_phone_field');
        var input = document.getElementById('billing_phone');
        var label = row && row.querySelector('label');
        var optional = label && label.querySelector('.optional');
        if (!marker || !row || !input || !optional) { return; } // Natively required or absent.
        var required = marker.getAttribute('data-grcs-phone-required') === 'yes';
        var star = label.querySelector('.grcs-phone-required');
        optional.hidden = required;
        if (required && !star) {
            star = document.createElement('span');
            star.className = 'required grcs-phone-required';
            star.setAttribute('aria-hidden', 'true');
            star.textContent = '*';
            label.appendChild(star);
        } else if (!required && star) {
            star.remove();
        }
        row.classList.toggle('validate-required', required);
        if (required) { input.setAttribute('aria-required', 'true'); } else { input.removeAttribute('aria-required'); }
    });
})(jQuery);
