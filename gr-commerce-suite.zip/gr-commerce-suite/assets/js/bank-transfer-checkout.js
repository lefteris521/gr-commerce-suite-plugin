/* Bank selector inside the Direct Bank Transfer (bacs) payment box; WooCommerce re-renders it on every update_checkout. */
(function ($) {
    'use strict';
    var config = window.grcsBankTransfer || {};
    // WooCommerce shows server rejections only in the top notice group; mirror validateCheckout() on the fields.
    var invalid = { account: false, ack: false };
    function mark() {
        $('[data-grcs-bank-transfer]').each(function () {
            var box = $(this);
            box.find('.grcs-bank-options').toggleClass('woocommerce-invalid', invalid.account)
                .attr('aria-invalid', invalid.account ? 'true' : 'false');
            box.find('.grcs-bank-ack').toggleClass('woocommerce-invalid', invalid.ack);
            box.find('input[name="grcs_bank_fee_ack"]').attr('aria-invalid', invalid.ack ? 'true' : 'false');
        });
    }
    function validate() {
        var box = $('[data-grcs-bank-transfer]');
        var bacs = box.length > 0 && $('input[name="payment_method"]:checked').val() === 'bacs';
        var ack = box.find('input[name="grcs_bank_fee_ack"]');
        invalid.account = bacs && box.find('input[name="grcs_bank_account"]:checked').length === 0;
        invalid.ack = bacs && ack.length > 0 && !ack.is(':checked');
        mark();
    }
    function revalidate() {
        // Only clears or keeps marks after a rejected submit; never flags fields before one.
        if (invalid.account || invalid.ack) { validate(); }
    }
    function sync() {
        $('[data-grcs-bank-transfer]').each(function () {
            var box = $(this);
            var selected = box.find('input[name="grcs_bank_account"]:checked').val() || '';
            box.find('.grcs-bank-details').each(function () { this.hidden = this.getAttribute('data-bank') !== selected; });
            box.find('.grcs-bank-option').each(function () {
                $(this).toggleClass('is-selected', $(this).find('input').val() === selected);
            });
        });
        revalidate();
    }
    function fallbackCopy(text) {
        // gr-shop style HTTP stores have no async Clipboard API outside a secure context.
        var area = document.createElement('textarea');
        area.value = text;
        area.setAttribute('readonly', '');
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        var copied = false;
        try { copied = document.execCommand('copy'); } catch (error) { copied = false; }
        document.body.removeChild(area);
        return copied;
    }
    function announce(message) {
        // Button text changes are not reliably read out; one polite live region serves every copy button.
        var region = document.getElementById('grcs-copy-status');
        if (!region) {
            region = document.createElement('span');
            region.id = 'grcs-copy-status';
            region.className = 'screen-reader-text';
            region.setAttribute('role', 'status');
            region.setAttribute('aria-live', 'polite');
            document.body.appendChild(region);
        }
        region.textContent = '';
        window.setTimeout(function () { region.textContent = message; }, 50);
    }
    function selectSource(button) {
        // When copying is blocked, select the visible value so the customer can copy it by hand.
        var source = $(button).siblings('.grcs-copy-source, code').get(0);
        if (!source || !window.getSelection || !document.createRange) { return; }
        var range = document.createRange();
        range.selectNodeContents(source);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
    }
    function copied(button, success) {
        if (!button.getAttribute('data-label')) { button.setAttribute('data-label', button.textContent); }
        var message = success ? (button.getAttribute('data-copied') || config.copied || '✓') : (config.copyFailed || '');
        button.textContent = success ? (config.copied || '✓') : (config.selected || '…');
        announce(message);
        if (!success) { selectSource(button); }
        window.clearTimeout(button.grcsTimer);
        button.grcsTimer = window.setTimeout(function () { button.textContent = button.getAttribute('data-label'); }, 2000);
    }
    $(document.body).on('change', 'input[name="grcs_bank_account"]', sync);
    $(document.body).on('change', 'input[name="grcs_bank_fee_ack"]', revalidate);
    function linkNotices() {
        // WooCommerce links only list-style notices to their field; a single block-theme banner stays plain text.
        if (typeof document === 'undefined' || !document.querySelectorAll) { return; }
        Array.prototype.forEach.call(document.querySelectorAll('.woocommerce-NoticeGroup-checkout [data-id^="grcs_bank_"]'), function (notice) {
            var target = notice.getAttribute('data-id');
            if (!document.getElementById(target) || notice.querySelector('a[href="#' + target + '"]')) { return; }
            var content = notice.querySelector('.wc-block-components-notice-banner__content') || notice;
            var link = document.createElement('a');
            link.href = '#' + target;
            link.className = 'grcs-notice-link';
            while (content.firstChild) { link.appendChild(content.firstChild); }
            content.appendChild(link);
        });
    }
    $(document.body).on('click', 'a.grcs-notice-link, .woocommerce-NoticeGroup-checkout a[href^="#grcs_bank_"]', function (event) {
        var field = document.getElementById(this.getAttribute('href').slice(1));
        if (!field) { return; }
        event.preventDefault();
        field.scrollIntoView({ block: 'center' });
        field.focus({ preventScroll: true });
    });
    $(document.body).on('checkout_error', function () { validate(); linkNotices(); });
    $(document.body).on('click', '.grcs-copy-iban, .grcs-copy', function (event) {
        event.preventDefault();
        var button = this;
        var text = button.getAttribute('data-copy') || button.getAttribute('data-iban') || '';
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(function () { copied(button, true); }, function () { copied(button, fallbackCopy(text)); });
        } else {
            copied(button, fallbackCopy(text));
        }
    });
    $(document.body).on('updated_checkout', sync);
    sync();
})(jQuery);
