(function ($) {
    'use strict';

    function toggleField(field, scope, visible) {
        var row = field.closest('tr');
        if (row.length) {
            row.toggle(visible);
        } else {
            // Current WooCommerce replaces tables with labels + fieldsets in the modal.
            field.closest('fieldset').toggle(visible);
            scope.find('label[for="' + field.attr('id') + '"]').toggle(visible);
        }
    }

    function refresh() {
        $('.grcs-pricing-mode').each(function () {
            var mode = $(this), scope = mode.closest('.grcs-pricing-settings'), dynamic = mode.val() === 'dynamic';
            scope.find('.grcs-pricing-dynamic').each(function () { toggleField($(this), scope, dynamic); });
            scope.find('.grcs-pricing-fixed').each(function () { toggleField($(this), scope, !dynamic); });
            // Hide containers only: disabled inputs are omitted by WooCommerce's modal serializer.
            var missing = false;
            scope.find('[data-grcs-pricing-required]').each(function () {
                var empty = dynamic && !String($(this).val() || '').trim();
                $(this).attr('aria-invalid', empty ? 'true' : 'false');
                missing = missing || empty;
            });
            var notice = scope.find('.grcs-pricing-required-error');
            if (!notice.length) {
                notice = $('<div class="notice notice-error grcs-pricing-required-error" role="alert"><p></p></div>');
                notice.find('p').text(grcsPricingSettings.required);
                scope.prepend(notice);
            }
            notice.toggle(dynamic && missing);
            scope.find('.grcs-pricing-configuration-errors').toggle(dynamic);
        });
    }

    $(refresh);
    $(document.body).on('change.grcsPricing input.grcsPricing',
        '.grcs-pricing-mode, [data-grcs-pricing-required]', refresh);
    // WooCommerce inserts fresh settings markup each time a method is opened/reopened.
    $(document.body).on('wc_backbone_modal_loaded.grcsPricing', function (event, target) {
        if (target === 'wc-modal-shipping-method-settings') { refresh(); }
    });
})(jQuery);
