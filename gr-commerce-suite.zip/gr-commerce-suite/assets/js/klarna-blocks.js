/**
 * Klarna Payments for the WooCommerce Checkout Block (registered via the Blocks payment-method registry).
 * The Store API cart extension (namespace grcs-klarna) creates/updates the Klarna session server side and returns only the
 * browser-side client_token; authorize() runs when the shopper places the order and its token travels as payment data.
 */
(function () {
    'use strict';

    var registry = window.wc && window.wc.wcBlocksRegistry;
    var settingsApi = window.wc && window.wc.wcSettings;
    if (!registry || !settingsApi || !window.wp || !window.wp.element) {
        return;
    }
    var el = window.wp.element;
    var data = settingsApi.getSetting('grcs_klarna_data', {});
    var NAMESPACE = data.namespace || 'grcs-klarna';
    var TOKEN_FIELD = data.tokenField || 'grcs_klarna_token';
    var i18n = data.i18n || {};

    function address(billing) {
        var source = (billing && billing.billingAddress) || {};
        var map = {
            given_name: 'first_name', family_name: 'last_name', email: 'email', phone: 'phone', street_address: 'address_1',
            street_address2: 'address_2', postal_code: 'postcode', city: 'city', region: 'state', country: 'country'
        };
        var result = {};
        Object.keys(map).forEach(function (key) {
            if (source[map[key]]) {
                result[key] = source[map[key]];
            }
        });
        return result;
    }

    function extensionData(select) {
        var cart = select('wc/store/cart');
        var extensions = cart && cart.getCartData ? (cart.getCartData().extensions || {}) : {};
        return extensions[NAMESPACE] || {};
    }

    var Content = function (props) {
        var ext = window.wp.data.useSelect(function (select) { return extensionData(select); }, []);
        var chosen = el.useState('');
        var category = chosen[0];
        var setCategory = chosen[1];
        var categories = ext.categories || [];
        var total = props.billing && props.billing.cartTotal ? props.billing.cartTotal.value : 0;
        var country = props.billing && props.billing.billingAddress ? props.billing.billingAddress.country : '';

        function syncSession() {
            if (window.wc.blocksCheckout && window.wc.blocksCheckout.extensionCartUpdate) {
                window.wc.blocksCheckout.extensionCartUpdate({ namespace: NAMESPACE, data: { sync: Date.now() } }).catch(function () {});
            }
        }

        // Create/update the session whenever the amount or country changes.
        el.useEffect(syncSession, [total, country]);

        // After a failed checkout the server dropped the session: open a fresh one before the next attempt.
        el.useEffect(function () {
            var failed = props.eventRegistration.onCheckoutFail || props.eventRegistration.onCheckoutAfterProcessingWithError;
            if (!failed) {
                return undefined;
            }
            return failed(function () { syncSession(); return undefined; });
        }, [props.eventRegistration]);

        // (Re)load the Klarna widgets for the current client token.
        el.useEffect(function () {
            if (!ext.client_token || !categories.length || !window.Klarna || !window.Klarna.Payments) {
                return;
            }
            try {
                window.Klarna.Payments.init({ client_token: ext.client_token });
                if (!category) {
                    setCategory(categories[0].identifier);
                }
                categories.forEach(function (item) {
                    window.Klarna.Payments.load({ container: '#grcs-klarna-cat-' + item.identifier, payment_method_category: item.identifier }, {}, function () {});
                });
            } catch (error) {
                // The unavailable message is shown below when no widget could be loaded.
            }
        }, [ext.client_token]);

        // Place order: authorise with Klarna, then hand the token to the server as payment data.
        var register = props.eventRegistration;
        var types = props.emitResponse.responseTypes;
        el.useEffect(function () {
            var unsubscribe = register.onPaymentSetup(function () {
                return new Promise(function (resolve) {
                    var selectedCategory = category || (categories[0] && categories[0].identifier);
                    if (!window.Klarna || !window.Klarna.Payments || !selectedCategory) {
                        return resolve({ type: types.ERROR, message: i18n.unavailable });
                    }
                    try {
                        window.Klarna.Payments.authorize({ payment_method_category: selectedCategory }, { billing_address: address(props.billing) }, function (response) {
                            if (response && response.approved && response.authorization_token) {
                                var paymentData = {};
                                paymentData[TOKEN_FIELD] = response.authorization_token;
                                resolve({ type: types.SUCCESS, meta: { paymentMethodData: paymentData } });
                            } else {
                                resolve({ type: types.ERROR, message: i18n.declined });
                            }
                        });
                    } catch (error) {
                        resolve({ type: types.ERROR, message: i18n.unavailable });
                    }
                });
            });
            return unsubscribe;
        }, [register.onPaymentSetup, category, ext.client_token, props.billing]);

        var children = [];
        if (data.description) {
            children.push(el.createElement('p', { key: 'd' }, data.description));
        }
        if (!ext.client_token || !categories.length) {
            children.push(el.createElement('p', { key: 'u', className: 'grcs-klarna-unavailable' }, i18n.unavailable));
        }
        categories.forEach(function (item) {
            var row = [];
            if (categories.length > 1) {
                row.push(el.createElement('label', { key: 'l' },
                    el.createElement('input', {
                        type: 'radio', name: 'grcs_klarna_cat', value: item.identifier, checked: category === item.identifier,
                        onChange: function () { setCategory(item.identifier); }
                    }), ' ' + item.name));
            }
            row.push(el.createElement('div', { key: 'c', id: 'grcs-klarna-cat-' + item.identifier }));
            children.push(el.createElement('div', { key: item.identifier, className: 'grcs-klarna-category' }, row));
        });
        return el.createElement('div', { className: 'grcs-klarna-blocks' }, children);
    };

    var label = el.createElement('span', null, data.title || 'Klarna');
    registry.registerPaymentMethod({
        name: 'grcs_klarna',
        label: label,
        ariaLabel: data.title || 'Klarna',
        content: el.createElement(Content, null),
        edit: el.createElement('div', null, data.title || 'Klarna'),
        canMakePayment: function () { return true; },
        supports: { features: data.supports || ['products'] }
    });
}());
