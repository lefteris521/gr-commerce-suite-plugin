(function (factory) {
    'use strict';
    var feature = factory();
    if (typeof module === 'object' && module.exports) {
        module.exports = feature;
    } else if (typeof jQuery !== 'undefined') {
        jQuery(function () { feature.init(jQuery, document, window.grcsCharacterWarnings || {}); });
    }
}(function () {
    'use strict';
    var words, marks, scripts;
    try {
        // Construct dynamically so browsers without Unicode property escapes fail open.
        words = new RegExp('[\\p{L}\\p{M}]+', 'gu');
        marks = new RegExp('\\p{M}', 'gu');
        scripts = ['Latin', 'Greek', 'Cyrillic'].map(function (script) {
            return new RegExp('\\p{Script=' + script + '}', 'u');
        });
    } catch (error) { /* Checkout remains available without this optional advisory. */ }

    function hasMixedWord(value) {
        // Bound work and never truncate or normalize the actual field value.
        if (!scripts || typeof value !== 'string' || value.length > 4096) { return false; }
        var tokens = value.match(words) || [];
        return tokens.some(function (token) {
            var letters = token.replace(marks, '');
            return scripts.filter(function (script) { return script.test(letters); }).length > 1;
        });
    }

    function init($, doc, config) {
        if (!scripts || !config.message) { return; }
        var ids = [];
        ['billing', 'shipping'].forEach(function (prefix) {
            ['first_name', 'last_name', 'address_1', 'address_2', 'city'].forEach(function (field) {
                ids.push(prefix + '_' + field);
            });
        });
        var selector = ids.map(function (id) { return 'form.checkout #' + id; }).join(',');
        var composing = new WeakSet();

        function describe(input, id, enabled) {
            var descriptions = (input.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean)
                .filter(function (existing) { return existing !== id; });
            if (enabled) { descriptions.push(id); }
            if (descriptions.length) { input.setAttribute('aria-describedby', descriptions.join(' ')); }
            else { input.removeAttribute('aria-describedby'); }
        }

        function inspect(input) {
            var id = 'grcs-' + input.id + '-character-warning';
            var warning = doc.getElementById(id);
            var different = doc.getElementById('ship-to-different-address-checkbox');
            var active = !input.disabled && $(input).is(':visible')
                && (input.id.indexOf('shipping_') !== 0 || (different && different.checked));
            var show = active && !composing.has(input) && hasMixedWord(input.value);
            if (!warning) {
                warning = doc.createElement('span');
                warning.id = id;
                warning.className = 'grcs-character-warning';
                warning.setAttribute('role', 'status');
                warning.setAttribute('aria-live', 'polite');
                warning.setAttribute('aria-atomic', 'true');
                input.insertAdjacentElement('afterend', warning);
            }
            if (warning) {
                var message = show ? config.message : '';
                // No repeated live announcements on blur or repeated checkout refreshes.
                if (warning.textContent !== message) { warning.textContent = message; }
            }
            describe(input, id, show);
        }

        function refresh() { $(selector).each(function () { inspect(this); }); }
        $(doc.body)
            .on('input.grcsCharacters change.grcsCharacters focusout.grcsCharacters', selector, function (event) {
                if (!(event.originalEvent && event.originalEvent.isComposing)) { inspect(this); }
            })
            .on('compositionstart.grcsCharacters', selector, function () { composing.add(this); inspect(this); })
            .on('compositionend.grcsCharacters', selector, function () { composing.delete(this); inspect(this); })
            .on('updated_checkout.grcsCharacters', refresh)
            .on('checkout_error.grcsCharacters', function () {
                // WooCommerce may replace aria-describedby while adding native inline errors.
                setTimeout(refresh, 0);
            })
            .on('change.grcsCharacters', '#ship-to-different-address-checkbox, #billing_country, #shipping_country', refresh);
        refresh();
    }
    return { hasMixedWord: hasMixedWord, init: init };
}));
