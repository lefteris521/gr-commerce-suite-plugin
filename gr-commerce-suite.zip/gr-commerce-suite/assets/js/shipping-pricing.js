/* Sync only rating inputs. The Store API returns WooCommerce's recalculated cart. */
(function () {
    'use strict';
    var timer, inFlight = false, sent = null, pending = null;
    function flush() {
        if (inFlight || pending === null || pending === sent) { return; }
        var snapshot = pending, api = window.wc && window.wc.blocksCheckout;
        if (!api || !api.extensionCartUpdate) { return; }
        inFlight = true;
        api.extensionCartUpdate({ namespace: 'grcs-shipping-pricing', data: JSON.parse(snapshot) }).then(function () {
            sent = snapshot;
            inFlight = false;
            flush(); // Serialize requests so a slow response cannot restore an old locker.
        }).catch(function (error) {
            inFlight = false;
            // A failed response may follow a successful server mutation; its state is unknown.
            sent = null;
            if (window.wc.wcBlocksData && window.wc.wcBlocksData.processErrorResponse) {
                window.wc.wcBlocksData.processErrorResponse(error);
            } else if (window.wp && wp.data && wp.data.dispatch) {
                var notices = wp.data.dispatch('core/notices');
                if (notices && notices.createErrorNotice) {
                    notices.createErrorNotice(error.message || window.grcsShippingPricing.error,
                        { id: 'grcs-shipping-pricing', isDismissible: true });
                }
            }
            // Retry only after another input change; avoid a request loop during an outage.
            if (pending !== snapshot) { flush(); }
        });
    }
    function sync() {
        if (!document.querySelector('.wc-block-checkout') || !window.wp || !wp.data) { return; }
        var checkout = wp.data.select('wc/store/checkout');
        if (!checkout || !checkout.getAdditionalFields) { return; }
        var fields = checkout.getAdditionalFields() || {};
        var payment = wp.data.select('wc/store/payment');
        var method = payment && payment.getActivePaymentMethod ? payment.getActivePaymentMethod() : '';
        var next = JSON.stringify({ locker: fields['grcs/boxnow-locker-id'] || '', payment_method: method || '' });
        if (next === pending) { return; }
        pending = next;
        clearTimeout(timer);
        timer = setTimeout(flush, 150);
    }
    var refreshTimer;
    function refreshCheckout() {
        window.clearTimeout(refreshTimer);
        refreshTimer = window.setTimeout(function () {
            window.jQuery(document.body).trigger('update_checkout');
        }, 400);
    }
    if (window.jQuery) {
        window.jQuery(document.body).on('change.grcsCheckout blur.grcsCheckout',
            '#billing_phone, #billing_email, #billing_postcode, [name="grcs_document_type"]', refreshCheckout);
    }
    document.body.addEventListener('change', function (event) {
        var field = event.target;
        if (field && (field.name === 'grcs_boxnow_locker_id' || field.name === 'payment_method')) {
            if (window.jQuery) { window.jQuery(document.body).trigger('update_checkout'); }
        }
    });
    if (window.wp && wp.data) { wp.data.subscribe(sync); }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', sync); }
    else { sync(); }
})();
