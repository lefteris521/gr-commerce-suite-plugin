/**
 * Order-received page of a Klarna order Klarna has not confirmed yet. Asks the server (which asks Klarna) for the real state every
 * 10 seconds for a few minutes, and on demand. Nothing is ever shown as paid from this script: it only reloads the page once the
 * server reports a final state, and the page itself is rendered from the order.
 */
(function () {
    'use strict';

    var cfg = window.grcsKlarnaStatus;
    var box = document.getElementById('grcs-klarna-status');
    if (!cfg || !box || !window.fetch) {
        return;
    }
    var attempts = 0;
    var MAX_ATTEMPTS = 18;
    var timer = null;
    var message = document.createElement('span');
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'button grcs-klarna-check';
    button.textContent = cfg.i18n.check;
    box.appendChild(message);
    box.appendChild(document.createTextNode(' '));
    box.appendChild(button);

    function check() {
        window.clearTimeout(timer);
        attempts += 1;
        message.textContent = cfg.i18n.checking;
        var body = new URLSearchParams();
        body.set('order', String(cfg.order));
        body.set('key', cfg.key);
        window.fetch(cfg.url, { method: 'POST', credentials: 'same-origin', body: body })
            .then(function (response) { return response.json(); })
            .then(function (payload) {
                var data = payload && payload.data ? payload.data : null;
                if (!data) {
                    message.textContent = '';
                    return;
                }
                message.textContent = data.message || '';
                if (data.state === 'confirmed' || data.state === 'failed') {
                    window.setTimeout(function () { window.location.reload(); }, 1500);
                } else if (attempts < MAX_ATTEMPTS) {
                    timer = window.setTimeout(check, 10000);
                }
            })
            .catch(function () {
                message.textContent = '';
                if (attempts < MAX_ATTEMPTS) {
                    timer = window.setTimeout(check, 15000);
                }
            });
    }

    button.addEventListener('click', check);
    timer = window.setTimeout(check, 10000);
}());
