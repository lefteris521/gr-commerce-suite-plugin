/**
 * GR Commerce Suite — Admin UI behaviour.
 *
 * Progressive enhancement only: every feature degrades to plain links / visible content
 * when JavaScript is unavailable, and no form field names, nonces or actions are touched.
 *
 *  1. Instant tab switching on WooCommerce → COD Reconciliation (`[data-grcs-tab]`).
 *  2. "Copy URL" buttons (`[data-grcs-copy]`).
 *  3. Settings sub-navigation filtering on the GR Commerce Suite settings tab.
 *  4. Show the developer-only "Simulate Post-Transmission Timeout" row only in Sandbox Mode.
 */
(function ($) {
    'use strict';
    $(function () {
        $('.grcs-ui .woocommerce-help-tip, #grcs_courier_shipping_metabox .woocommerce-help-tip').each(function () {
            // WooCommerce's tipTip may already have consumed data-tip; keep its aria-label then.
            var tip = $(this).attr('data-tip') || $(this).attr('aria-label') || $(this).attr('title') || '';
            $(this).attr({ 'aria-label': tip.replace(/<[^>]*>/g, ''), 'data-tip': tip.replace(/<[^>]*>/g, ''), tabindex: '0' }).removeAttr('title');
        });
        if (new URL(window.location.href).searchParams.get('pickup_show') === '1'
            && $('[data-grcs-panel="pickup"]:not([hidden]) .grcs-manifest:not([data-grcs-empty])').length) {
            $('.grcs-print-manifest').trigger('click');
        }
    });
    $(document).on('click', '.grcs-print-manifest', function () {
        document.body.classList.add('grcs-printing-manifest');
        window.print();
        document.body.classList.remove('grcs-printing-manifest');
    });

    var config = window.grcsAdminUi || {};
    var i18n = config.i18n || {};
    // Search the server registry, including customers outside the 200 visible rows.
    $(function () {
        $('[data-grcs-registry]').each(function () {
            var $registry = $(this);
            var $form = $registry.find('.grcs-filter-bar');
            var $results = $registry.find('[data-grcs-registry-results]');
            var $feedback = $registry.find('[data-grcs-registry-feedback]');
            var request = null;
            var timer = null;
            var revision = 0;

            function search(delay) {
                var current = ++revision;
                window.clearTimeout(timer);
                if (request) { request.abort(); }
                $results.attr('aria-busy', 'true').find('button').prop('disabled', true);
                $feedback.text($feedback.attr('data-loading'));
                timer = window.setTimeout(function () {
                    var url = new URL($form.attr('action') || window.location.pathname, window.location.href);
                    url.search = $form.serialize();
                    request = $.ajax({ url: url.toString(), dataType: 'html' }).done(function (html) {
                        if (current !== revision) { return; }
                        var document = new DOMParser().parseFromString(html, 'text/html');
                        var replacement = document.querySelector('[data-grcs-registry-results]');
                        if (!replacement) {
                            $feedback.text($feedback.attr('data-error'));
                            return;
                        }
                        $results.html(replacement.innerHTML);
                        $feedback.text('');
                        // Row POST actions and reloads keep the successful lookup filters.
                        url.searchParams.delete('_grcs_cod_nonce');
                        window.history.replaceState(null, '', url.toString());
                    }).fail(function (xhr, status) {
                        if (current === revision && status !== 'abort') { $feedback.text($feedback.attr('data-error')); }
                    }).always(function () {
                        if (current === revision) {
                            $results.attr('aria-busy', 'false').find('button').prop('disabled', false);
                        }
                    });
                }, delay);
            }

            $form.on('input', 'input[type="search"]', function () { search(300); });
            $form.on('change', 'select', function () { search(0); });
            $form.on('submit', function (event) {
                var button = event.originalEvent && event.originalEvent.submitter;
                if (button && button.value === 'grcs_cod_export_blacklist') { return; }
                event.preventDefault();
                search(0);
            });
        });
    });
    $(document).on('change', '[data-grcs-log-level], [data-grcs-log-context]', function () {
        var level = $('[data-grcs-log-level]').val();
        var context = $('[data-grcs-log-context]').val();
        $('[data-grcs-log-row]').each(function () {
            $(this).prop('hidden', !!((level && $(this).data('level') !== level) || (context && $(this).data('context') !== context)));
        });
    });

    /* ------------------------------------------------------------------ */
    /* 1. Tabs                                                             */
    /* ------------------------------------------------------------------ */
    function activateTab(name, updateUrl, focus) {
        var $tabs = $('[data-grcs-tab]');
        var $target = $tabs.filter('[data-grcs-tab="' + name + '"]');
        if (!$target.length) {
            return false;
        }
        if ($target.is('[data-grcs-load-page]') && updateUrl) {
            window.location.assign($target.attr('href') + (focus ? '#grcs-tab-' + name : ''));
            return true;
        }

        $tabs.removeClass('is-active').attr({ 'aria-selected': 'false', tabindex: '-1' });
        $target.addClass('is-active').attr({ 'aria-selected': 'true', tabindex: '0' });

        $('[data-grcs-panel]').each(function () {
            var $panel = $(this);
            $panel.prop('hidden', $panel.data('grcs-panel') !== name);
        });
        $('[data-grcs-sidebar-tab]').each(function () {
            $(this).prop('hidden', $(this).data('grcs-sidebar-tab') !== name);
        });
        $('[data-grcs-hub-tab]').each(function () {
            if ($(this).data('grcs-hub-tab') === name) {
                $(this).attr('aria-current', 'page');
            } else {
                $(this).removeAttr('aria-current');
            }
        });

        if (updateUrl && window.history && window.history.pushState && window.URL) {
            try {
                var url = new URL(window.location.href);
                url.searchParams.set('tab', name);
                if (/^#grcs-tab-[a-z]+$/.test(url.hash)) {
                    url.hash = '';
                }
                if (url.toString() !== window.location.href) {
                    window.history.pushState(null, '', url.toString());
                }
            } catch (e) { /* Older browsers keep the server-rendered URL. */ }
        }

        return true;
    }

    var initialTab = $('[data-grcs-tab][aria-selected="true"]').data('grcs-tab');
    $(window).on('popstate', function () {
        if (initialTab && window.URL) {
            activateTab(new URL(window.location.href).searchParams.get('tab') || initialTab, false);
        }
    });
    $(function () {
        // Diagnostics needs a server request; restore keyboard focus after that navigation.
        if (/^#grcs-tab-[a-z]+$/.test(window.location.hash)) {
            $(window.location.hash).filter('[data-grcs-tab][aria-selected="true"]').trigger('focus');
        }
    });

    $(document).on('click', '[data-grcs-tab]', function (event) {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.button === 1) {
            return; // Allow "open in new tab".
        }
        if (activateTab(String($(this).data('grcs-tab')), true, event.detail === 0)) {
            event.preventDefault();
        }
    });

    // Hub links to a tab of the current page switch it in place, like the tab itself.
    $(document).on('click', '[data-grcs-hub-tab]', function (event) {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.button === 1) {
            return;
        }
        if (activateTab(String($(this).data('grcs-hub-tab')), true, false)) {
            event.preventDefault();
        }
    });

    $(document).on('keydown', '[data-grcs-tab]', function (event) {
        var key = event.key;
        if (key !== 'ArrowRight' && key !== 'ArrowLeft' && key !== 'Home' && key !== 'End') {
            return;
        }
        var $tabs = $('[data-grcs-tab]');
        var index = $tabs.index(this);
        var next = key === 'Home' ? 0
            : key === 'End' ? $tabs.length - 1
            : (index + (key === 'ArrowRight' ? 1 : -1) + $tabs.length) % $tabs.length;
        var $next = $tabs.eq(next);
        activateTab(String($next.data('grcs-tab')), true, true);
        $next.trigger('focus');
        event.preventDefault();
    });

    /* ------------------------------------------------------------------ */
    /* 2. Copy-to-clipboard                                                */
    /* ------------------------------------------------------------------ */
    function flash($button, text) {
        var original = $button.data('grcs-label') || $button.text();
        $button.data('grcs-label', original).text(text);
        window.setTimeout(function () { $button.text(original); }, 1800);
    }

    $(document).on('click', '[data-grcs-copy]', function (event) {
        event.preventDefault();
        var $button = $(this);
        var $input = $($button.data('grcs-copy'));
        if (!$input.length) {
            return;
        }
        var value = String($input.val());

        function legacyCopy() {
            $input.trigger('focus').trigger('select');
            var ok = false;
            try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
            flash($button, ok ? i18n.copied : i18n.copyFailed);
        }

        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(value).then(function () {
                flash($button, i18n.copied);
            }, legacyCopy);
        } else {
            legacyCopy();
        }
    });

    $(document).on('focus click', '.grcs-copy-field input[readonly]', function () {
        $(this).trigger('select');
    });

    // Native focus scrolling can leave part of a table action behind the scroll edge.
    $(document).on('focusin', '.grcs-ui .grcs-table-wrap a, .grcs-ui .grcs-table-wrap button, .grcs-ui .grcs-table-wrap input, .grcs-ui .grcs-table-wrap select', function () {
        if (typeof this.scrollIntoView === 'function') {
            this.scrollIntoView({ block: 'nearest', inline: 'nearest' });
        }
    });

    /* ------------------------------------------------------------------ */
    /* 3. Settings sub-navigation filtering                               */
    /* ------------------------------------------------------------------ */
    function sectionFromHref(href) {
        try {
            var url = new URL(href, window.location.href);
            if (url.searchParams.get('tab') !== 'gr_commerce_suite') {
                return null;
            }
            return url.searchParams.get('section') || '';
        } catch (e) {
            return null;
        }
    }

    function filterSettings(section) {
        var $root = $('.grcs-settings-ui');
        var $sections = $root.find('[data-grcs-section]');

        $sections.each(function () {
            var $s = $(this);
            $s.prop('hidden', section !== '' && $s.data('grcs-section') !== section);
        });

        $root.find('[data-grcs-sections]').each(function () {
            var $block = $(this);
            var list = String($block.data('grcs-sections')).split(' ');
            var visible = section === '' || list.indexOf(section) !== -1;
            $block.prop('hidden', !visible);
            // Inside the connection-test card only show the courier being edited.
            $block.find('[data-grcs-courier-row]').each(function () {
                var courier = $(this).data('grcs-courier-row');
                $(this).prop('hidden', section === 'acs' || section === 'boxnow' ? courier !== section : false);
            });
        });

        $('.subsubsub a').each(function () {
            var $a = $(this);
            var s = sectionFromHref($a.attr('href') || '');
            if (s !== null) {
                $a.toggleClass('current', s === section);
                if (s === section) {
                    $a.attr('aria-current', 'page');
                } else {
                    $a.removeAttr('aria-current');
                }
            }
        });
    }

    function initSettings() {
        var $root = $('.grcs-settings-ui');
        if (!$root.length) {
            return;
        }

        // Only the "All Settings" view contains every section; specific views use normal links.
        var available = {};
        $root.find('[data-grcs-section]').each(function () {
            available[$(this).data('grcs-section')] = true;
        });
        var isAllView = Object.keys(available).length > 1;

        if (isAllView) {
            $(document).on('click', '.subsubsub a', function (event) {
                if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button === 1) {
                    return;
                }
                var section = sectionFromHref($(this).attr('href') || '');
                if (section === null || (section !== '' && !available[section])) {
                    return;
                }
                event.preventDefault();
                filterSettings(section);
                if (window.history && window.history.pushState && window.URL) {
                    // Retain the all-settings POST scope while recording each filtered view.
                    var url = new URL(window.location.href);
                    url.hash = section === '' ? '' : 'grcs-' + section;
                    if (url.toString() !== window.location.href) {
                        window.history.pushState(null, '', url.toString());
                    }
                }
            });

            var restoreSection = function () {
                var match = /^#grcs-([a-z]+)$/.exec(window.location.hash || '');
                filterSettings(match && available[match[1]] ? match[1] : '');
            };
            $(window).on('popstate', restoreSection);
            restoreSection();
        } else {
            filterSettings($root.attr('data-grcs-current-section') || '');
        }

        // Duplicate read-only license field (browsers without :has() support).
        $('#grcs_license_status').closest('tr').addClass('grcs-row-hidden');

        // 4. Sandbox timeout row visibility.
        var $sandbox = $('#grcs_sandbox_mode');
        var $timeoutRow = $('#grcs_sandbox_simulate_timeout').closest('tr');
        if ($sandbox.length && $timeoutRow.length) {
            $timeoutRow.addClass('grcs-sandbox-timeout-row');
            var sync = function () {
                $timeoutRow.toggleClass('grcs-row-hidden', !$sandbox.is(':checked'));
            };
            $sandbox.on('change', sync);
            sync();
        }
    }

    function updateConfiguration() {
        var write = function (key, value) { $('[data-grcs-summary="' + key + '"]').text(value); };
        var $strategy = $('#grcs-rule-strategy');
        if ($strategy.length) { write('strategy', $strategy.find(':selected').text()); }
        ['min_failures', 'expiry_days'].forEach(function (key) {
            var $input = $('#grcs-rule-' + key);
            if ($input.length) { write(key, $input.val()); }
        });
    }
    // The setup-status widget reflects saved settings only, so it is not rewritten while typing.
    $(document).on('input change', '.grcs-cod-blacklist input, .grcs-cod-blacklist select', updateConfiguration);
    $(document).on('keydown', '.grcs-import-drawer', function (event) {
        if (event.key === 'Escape') { $(this).prop('open', false).find('summary').trigger('focus'); }
    });
    $(function () { initSettings(); updateConfiguration(); });
})(jQuery);

// Modules screen: suspend BestPrice while Skroutz is off, retaining the merchant's checked preference for re-enable.
(function () {
    document.addEventListener('change', function (event) {
        var skroutz = document.getElementById('grcs-module-skroutz');
        var bestPrice = document.getElementById('grcs-module-bestprice');
        if (!skroutz || !bestPrice || event.target !== skroutz) { return; }
        bestPrice.disabled = !skroutz.checked;
        var fallback = document.getElementById('grcs-module-bestprice-fallback');
        if (fallback) { fallback.value = bestPrice.disabled && bestPrice.checked ? '1' : '0'; }
    });
})();
