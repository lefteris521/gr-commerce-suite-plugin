<?php
//============================================================+
// File name   : tcpdf_autoconfig.php
// Version     : 1.1.1
// Begin       : 2013-05-16
// Last Update : 2025-04-18
// Authors     : Nicola Asuni - Tecnick.com LTD - www.tecnick.com - info@tecnick.com
// License     : GNU-LGPL v3 (https://www.gnu.org/copyleft/lesser.html)
// -------------------------------------------------------------------
// Copyright (C) 2011-2026 Nicola Asuni - Tecnick.com LTD
//
// This file is part of GRCS_Vendor_TCPDF software library.
//
// GRCS_Vendor_TCPDF is free software: you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as
// published by the Free Software Foundation, either version 3 of the
// License, or (at your option) any later version.
//
// GRCS_Vendor_TCPDF is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
// See the GNU Lesser General Public License for more details.
//
// You should have received a copy of the License
// along with GRCS_Vendor_TCPDF. If not, see
// <http://www.tecnick.com/pagefiles/tcpdf/LICENSE.TXT>.
//
// See LICENSE.TXT file for more information.
// -------------------------------------------------------------------
//
// Description : Try to automatically configure some GRCS_Vendor_TCPDF
//               constants if not defined.
//
//============================================================+

/**
 * @file
 * Try to automatically configure some GRCS_Vendor_TCPDF constants if not defined.
 * @package com.tecnick.tcpdf
 * @version 1.2.1
 */

// Disable phar stream wrapper globally.
// if (in_array('phar', stream_get_wrappers(), true)) {
//     stream_wrapper_unregister('phar');
// }

// DOCUMENT_ROOT fix for IIS Webserver
if ((!isset($_SERVER['DOCUMENT_ROOT'])) OR (empty($_SERVER['DOCUMENT_ROOT']))) {
	if(isset($_SERVER['SCRIPT_FILENAME'])) {
		$_SERVER['DOCUMENT_ROOT'] = str_replace( '\\', '/', substr($_SERVER['SCRIPT_FILENAME'], 0, 0-strlen($_SERVER['PHP_SELF'])));
	} elseif(isset($_SERVER['PATH_TRANSLATED'])) {
		$_SERVER['DOCUMENT_ROOT'] = str_replace( '\\', '/', substr(str_replace('\\\\', '\\', $_SERVER['PATH_TRANSLATED']), 0, 0-strlen($_SERVER['PHP_SELF'])));
	} else {
		// define here your DOCUMENT_ROOT path if the previous fails (e.g. '/var/www')
		$_SERVER['DOCUMENT_ROOT'] = '/';
	}
}
$_SERVER['DOCUMENT_ROOT'] = str_replace('//', '/', $_SERVER['DOCUMENT_ROOT']);
if (substr($_SERVER['DOCUMENT_ROOT'], -1) != '/') {
	$_SERVER['DOCUMENT_ROOT'] .= '/';
}

// Load main configuration file only if the K_TCPDF_EXTERNAL_CONFIG constant is set to false.
if (!defined('GRCS_VENDOR_K_TCPDF_EXTERNAL_CONFIG') OR !GRCS_VENDOR_K_TCPDF_EXTERNAL_CONFIG) {
	// define a list of default config files in order of priority
	$tcpdf_config_files = array(dirname(__FILE__).'/config/tcpdf_config.php', '/etc/php-tcpdf/tcpdf_config.php', '/etc/tcpdf/tcpdf_config.php', '/etc/tcpdf_config.php');
	foreach ($tcpdf_config_files as $tcpdf_config) {
		if (@file_exists($tcpdf_config) AND is_readable($tcpdf_config)) {
			require_once($tcpdf_config);
			break;
		}
	}
}

if (!defined('GRCS_VENDOR_K_PATH_MAIN')) {
	define ('GRCS_VENDOR_K_PATH_MAIN', dirname(__FILE__).'/');
}

if (!defined('GRCS_VENDOR_K_PATH_FONTS')) {
	define ('GRCS_VENDOR_K_PATH_FONTS', GRCS_VENDOR_K_PATH_MAIN.'fonts/');
}

if (!defined('GRCS_VENDOR_K_PATH_URL')) {
	$k_path_url = GRCS_VENDOR_K_PATH_MAIN; // default value for console mode
	if (isset($_SERVER['HTTP_HOST']) AND (!empty($_SERVER['HTTP_HOST']))) {
		if(isset($_SERVER['HTTPS']) AND (!empty($_SERVER['HTTPS'])) AND (strtolower($_SERVER['HTTPS']) != 'off')) {
			$k_path_url = 'https://';
		} else {
			$k_path_url = 'http://';
		}
		$k_path_url .= $_SERVER['HTTP_HOST'];
		$k_path_url .= str_replace( '\\', '/', substr(GRCS_VENDOR_K_PATH_MAIN, (strlen($_SERVER['DOCUMENT_ROOT']) - 1)));
	}
	define ('GRCS_VENDOR_K_PATH_URL', $k_path_url);
}

if (!defined('GRCS_VENDOR_K_PATH_IMAGES')) {
	$tcpdf_images_dirs = array(GRCS_VENDOR_K_PATH_MAIN.'examples/images/', GRCS_VENDOR_K_PATH_MAIN.'images/', '/usr/share/doc/php-tcpdf/examples/images/', '/usr/share/doc/tcpdf/examples/images/', '/usr/share/doc/php/tcpdf/examples/images/', '/var/www/tcpdf/images/', '/var/www/html/tcpdf/images/', '/usr/local/apache2/htdocs/tcpdf/images/', GRCS_VENDOR_K_PATH_MAIN);
	foreach ($tcpdf_images_dirs as $tcpdf_images_path) {
		if (@file_exists($tcpdf_images_path)) {
			define ('GRCS_VENDOR_K_PATH_IMAGES', $tcpdf_images_path);
			break;
		}
	}
}

if (!defined('GRCS_VENDOR_PDF_HEADER_LOGO')) {
	$tcpdf_header_logo = '';
	if (@file_exists(GRCS_VENDOR_K_PATH_IMAGES.'tcpdf_logo.jpg')) {
		$tcpdf_header_logo = 'tcpdf_logo.jpg';
	}
	define ('GRCS_VENDOR_PDF_HEADER_LOGO', $tcpdf_header_logo);
}

if (!defined('GRCS_VENDOR_PDF_HEADER_LOGO_WIDTH')) {
	if (!empty($tcpdf_header_logo)) {
		define ('GRCS_VENDOR_PDF_HEADER_LOGO_WIDTH', 30);
	} else {
		define ('GRCS_VENDOR_PDF_HEADER_LOGO_WIDTH', 0);
	}
}

if (!defined('GRCS_VENDOR_K_PATH_CACHE')) {
	$GRCS_VENDOR_K_PATH_CACHE = ini_get('upload_tmp_dir') ? ini_get('upload_tmp_dir') : sys_get_temp_dir();
	if (substr($GRCS_VENDOR_K_PATH_CACHE, -1) != '/') {
		$GRCS_VENDOR_K_PATH_CACHE .= '/';
	}
	define ('GRCS_VENDOR_K_PATH_CACHE', $GRCS_VENDOR_K_PATH_CACHE);
}

if (!defined('GRCS_VENDOR_K_BLANK_IMAGE')) {
	define ('GRCS_VENDOR_K_BLANK_IMAGE', '_blank.png');
}

if (!defined('GRCS_VENDOR_PDF_PAGE_FORMAT')) {
	define ('GRCS_VENDOR_PDF_PAGE_FORMAT', 'A4');
}

if (!defined('GRCS_VENDOR_PDF_PAGE_ORIENTATION')) {
	define ('GRCS_VENDOR_PDF_PAGE_ORIENTATION', 'P');
}

if (!defined('GRCS_VENDOR_PDF_CREATOR')) {
	define ('GRCS_VENDOR_PDF_CREATOR', 'GRCS_Vendor_TCPDF');
}

if (!defined('GRCS_VENDOR_PDF_AUTHOR')) {
	define ('GRCS_VENDOR_PDF_AUTHOR', 'GRCS_Vendor_TCPDF');
}

if (!defined('GRCS_VENDOR_PDF_HEADER_TITLE')) {
	define ('GRCS_VENDOR_PDF_HEADER_TITLE', 'GRCS_Vendor_TCPDF Example');
}

if (!defined('GRCS_VENDOR_PDF_HEADER_STRING')) {
	define ('GRCS_VENDOR_PDF_HEADER_STRING', "by2026 Nicola Asuni - Tecnick.com\nwww.tcpdf.org");
}

if (!defined('GRCS_VENDOR_PDF_UNIT')) {
	define ('GRCS_VENDOR_PDF_UNIT', 'mm');
}

if (!defined('GRCS_VENDOR_PDF_MARGIN_HEADER')) {
	define ('GRCS_VENDOR_PDF_MARGIN_HEADER', 5);
}

if (!defined('GRCS_VENDOR_PDF_MARGIN_FOOTER')) {
	define ('GRCS_VENDOR_PDF_MARGIN_FOOTER', 10);
}

if (!defined('GRCS_VENDOR_PDF_MARGIN_TOP')) {
	define ('GRCS_VENDOR_PDF_MARGIN_TOP', 27);
}

if (!defined('GRCS_VENDOR_PDF_MARGIN_BOTTOM')) {
	define ('GRCS_VENDOR_PDF_MARGIN_BOTTOM', 25);
}

if (!defined('GRCS_VENDOR_PDF_MARGIN_LEFT')) {
	define ('GRCS_VENDOR_PDF_MARGIN_LEFT', 15);
}

if (!defined('GRCS_VENDOR_PDF_MARGIN_RIGHT')) {
	define ('GRCS_VENDOR_PDF_MARGIN_RIGHT', 15);
}

if (!defined('GRCS_VENDOR_PDF_FONT_NAME_MAIN')) {
	define ('GRCS_VENDOR_PDF_FONT_NAME_MAIN', 'helvetica');
}

if (!defined('GRCS_VENDOR_PDF_FONT_SIZE_MAIN')) {
	define ('GRCS_VENDOR_PDF_FONT_SIZE_MAIN', 10);
}

if (!defined('GRCS_VENDOR_PDF_FONT_NAME_DATA')) {
	define ('GRCS_VENDOR_PDF_FONT_NAME_DATA', 'helvetica');
}

if (!defined('GRCS_VENDOR_PDF_FONT_SIZE_DATA')) {
	define ('GRCS_VENDOR_PDF_FONT_SIZE_DATA', 8);
}

if (!defined('GRCS_VENDOR_PDF_FONT_MONOSPACED')) {
	define ('GRCS_VENDOR_PDF_FONT_MONOSPACED', 'courier');
}

if (!defined('GRCS_VENDOR_PDF_IMAGE_SCALE_RATIO')) {
	define ('GRCS_VENDOR_PDF_IMAGE_SCALE_RATIO', 96/72);
}

if (!defined('GRCS_VENDOR_HEAD_MAGNIFICATION')) {
	define('GRCS_VENDOR_HEAD_MAGNIFICATION', 1.1);
}

if (!defined('GRCS_VENDOR_K_CELL_HEIGHT_RATIO')) {
	define('GRCS_VENDOR_K_CELL_HEIGHT_RATIO', 1.25);
}

if (!defined('GRCS_VENDOR_K_TITLE_MAGNIFICATION')) {
	define('GRCS_VENDOR_K_TITLE_MAGNIFICATION', 1.3);
}

if (!defined('GRCS_VENDOR_K_SMALL_RATIO')) {
	define('GRCS_VENDOR_K_SMALL_RATIO', 2/3);
}

if (!defined('GRCS_VENDOR_K_THAI_TOPCHARS')) {
	define('GRCS_VENDOR_K_THAI_TOPCHARS', true);
}

if (!defined('GRCS_VENDOR_K_TCPDF_CALLS_IN_HTML')) {
	define('GRCS_VENDOR_K_TCPDF_CALLS_IN_HTML', false);
}

if (!defined('GRCS_VENDOR_K_ALLOWED_TCPDF_TAGS')) {
	define('GRCS_VENDOR_K_ALLOWED_TCPDF_TAGS', '');
}

if (!defined('GRCS_VENDOR_K_TCPDF_THROW_EXCEPTION_ERROR')) {
	define('GRCS_VENDOR_K_TCPDF_THROW_EXCEPTION_ERROR', false);
}

if (!defined('GRCS_VENDOR_K_TIMEZONE')) {
	define('GRCS_VENDOR_K_TIMEZONE', @date_default_timezone_get());
}

// Custom cURL options for curl_setopt_array.
if (!defined('GRCS_VENDOR_K_CURLOPTS')) {
	define('GRCS_VENDOR_K_CURLOPTS', array());
}

//============================================================+
// END OF FILE
//============================================================+
