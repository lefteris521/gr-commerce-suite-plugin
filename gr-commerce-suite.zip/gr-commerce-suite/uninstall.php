<?php

declare(strict_types=1);

defined('WP_UNINSTALL_PLUGIN') || exit;

// Uninstall must work even if WooCommerce is inactive. Never remove financial history or credentials: vouchers and the whole payment-attempt
// ledger (Schema::deletionEligibleTableNames() is empty) survive uninstall and network uninstall; no table is dropped here.
require_once __DIR__ . '/src/Database/PreparedQuery.php';
require_once __DIR__ . '/src/Database/Repositories/SchedulerRepository.php';
require_once __DIR__ . '/src/Jobs/JobDispatcher.php';

if (class_exists(\GRCommerceSuite\Jobs\JobDispatcher::class)) {
    \GRCommerceSuite\Jobs\JobDispatcher::unscheduleAll(function_exists('is_multisite') && is_multisite());
}

$cleanSite = static function (): void {
    if (function_exists('wp_unschedule_hook')) {
        wp_unschedule_hook('grcs_payment_recovery_send');
        wp_unschedule_hook('grcs_payment_recovery_purge');
        wp_unschedule_hook('grcs_network_install_batch');
    } elseif (function_exists('wp_clear_scheduled_hook')) {
        wp_clear_scheduled_hook('grcs_payment_recovery_send');
        wp_clear_scheduled_hook('grcs_payment_recovery_purge');
        wp_clear_scheduled_hook('grcs_network_install_batch');
    }

    // COD notification markers are per-voucher delivery bookkeeping, not financial history.
    global $wpdb;
    if ($wpdb instanceof \wpdb) {
        $notified_options = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                $wpdb->esc_like('grcs_cod_notified_') . '%'
            )
        );
        if (is_array($notified_options)) {
            foreach ($notified_options as $notified_option) {
                if (function_exists('delete_option')) {
                    delete_option((string) $notified_option);
                }
            }
        }

        $recovery_options = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
                $wpdb->esc_like('grcs_pay_rec_') . '%'
            )
        );
        if (is_array($recovery_options)) {
            foreach ($recovery_options as $recovery_option) {
                if (function_exists('delete_option')) {
                    delete_option((string) $recovery_option);
                }
            }
        }
    }
};

if (function_exists('is_multisite') && is_multisite()) {
    if (function_exists('wp_unschedule_hook')) {
        wp_unschedule_hook('grcs_network_install_batch');
    } elseif (function_exists('wp_clear_scheduled_hook')) {
        wp_clear_scheduled_hook('grcs_network_install_batch');
    }
    if (function_exists('delete_site_option')) {
        delete_site_option('grcs_network_install_cursor');
    }

    $offset = 0;
    do {
        $sites = function_exists('get_sites') ? get_sites(['fields' => 'ids', 'number' => 100, 'offset' => $offset]) : [];
        $sites = is_array($sites) ? $sites : [];
        foreach ($sites as $siteId) {
            if (function_exists('switch_to_blog')) {
                switch_to_blog((int) $siteId);
            }
            try {
                $cleanSite();
            } finally {
                if (function_exists('restore_current_blog')) {
                    restore_current_blog();
                }
            }
        }
        $offset += 100;
    } while (count($sites) === 100);
} else {
    $cleanSite();
}
