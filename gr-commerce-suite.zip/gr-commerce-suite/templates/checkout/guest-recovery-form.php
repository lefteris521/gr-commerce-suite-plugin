<?php
/**
 * Guest payment recovery form (classic checkout, guests). Rendered by GuestRecovery::renderForm() AFTER the checkout form (forms cannot
 * nest) and revealed by assets/js/guest-recovery.js when the blocked-payment notice appears.
 *
 * @var string $action AJAX endpoint of grcs_payment_recovery_request
 * @var string $nonce  nonce for that action
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}
?>
<div id="grcs-recovery" class="grcs-recovery" hidden>
    <h3><?php echo esc_html__('Already paid or started a payment?', 'gr-commerce-suite'); // customer-facing ?></h3>
    <p><?php echo esc_html__('Enter the billing email of your earlier order. If it matches an order with a payment in progress, we will email you a link to confirm access.', 'gr-commerce-suite'); // customer-facing ?></p>
    <form id="grcs-recovery-form" method="post" action="<?php echo esc_url($action); ?>">
        <p>
            <label for="grcs-recovery-email"><?php echo esc_html__('Billing email', 'gr-commerce-suite'); // customer-facing ?></label>
            <input type="email" id="grcs-recovery-email" name="billing_email" autocomplete="email" required>
        </p>
        <p>
            <label for="grcs-recovery-ref"><?php echo esc_html__('Order number (optional)', 'gr-commerce-suite'); // customer-facing ?></label>
            <input type="text" id="grcs-recovery-ref" name="grcs_order_ref" autocomplete="off" maxlength="40">
        </p>
        <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>">
        <button type="submit" class="button"><?php echo esc_html__('Email me a confirmation link', 'gr-commerce-suite'); // customer-facing ?></button>
        <p id="grcs-recovery-msg" role="status" aria-live="polite"></p>
    </form>
</div>
