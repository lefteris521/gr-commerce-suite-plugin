<?php
/**
 * Settings Page
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CC_Settings {

    /**
     * Constructor
     */
    public function __construct() {
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_filter( 'option_page_capability_cc_wc_settings', array( $this, 'settings_capability' ) );
        add_action( 'wp_ajax_cc_test_and_autofill', array( $this, 'ajax_test_and_autofill' ) );
        add_action( 'wp_ajax_cc_autofill_pickup_point', array( $this, 'ajax_autofill_pickup_point' ) );
        add_action( 'wp_ajax_cc_clear_settings',    array( $this, 'ajax_clear_settings' ) );
    }

    /**
     * Η σελίδα ρυθμίσεων είναι ορατή με manage_woocommerce — το ίδιο δικαίωμα
     * χρειάζεται και η αποθήκευση μέσω options.php (default: manage_options).
     */
    public function settings_capability( $capability ) {
        return 'manage_woocommerce';
    }

    /**
     * Register settings
     */
    public function register_settings() {
        // API Credentials section
        add_settings_section(
            'cc_wc_api_section',
            'API Credentials',
            array( $this, 'api_section_callback' ),
            'courier-center'
        );

        // UserAlias
        register_setting( 'cc_wc_settings', 'cc_wc_user_alias', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        add_settings_field(
            'cc_wc_user_alias',
            'User Alias',
            array( $this, 'text_field_callback' ),
            'courier-center',
            'cc_wc_api_section',
            array( 'label_for' => 'cc_wc_user_alias' )
        );

        // CredentialValue
        register_setting( 'cc_wc_settings', 'cc_wc_credential_value', array(
            'type'              => 'string',
            'sanitize_callback' => array( $this, 'sanitize_credential_value' ),
        ) );
        add_settings_field(
            'cc_wc_credential_value',
            'Credential Value',
            array( $this, 'password_field_callback' ),
            'courier-center',
            'cc_wc_api_section',
            array( 'label_for' => 'cc_wc_credential_value' )
        );

        // ApiKey
        register_setting( 'cc_wc_settings', 'cc_wc_api_key', array(
            'type'              => 'string',
            'sanitize_callback' => array( $this, 'sanitize_api_key' ),
        ) );
        add_settings_field(
            'cc_wc_api_key',
            'API Key',
            array( $this, 'password_field_callback' ),
            'courier-center',
            'cc_wc_api_section',
            array( 'label_for' => 'cc_wc_api_key' )
        );

        // CarrierBillingAccount
        register_setting( 'cc_wc_settings', 'cc_wc_billing_account', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        add_settings_field(
            'cc_wc_billing_account',
            'Κεντρικός κωδικός (Carrier Billing Account)',
            array( $this, 'text_field_callback' ),
            'courier-center',
            'cc_wc_api_section',
            array( 'label_for' => 'cc_wc_billing_account' )
        );

        // ── Autofill section (button between API and Shipper sections) ──────
        add_settings_section(
            'cc_wc_autofill_section',
            '',
            array( $this, 'autofill_section_callback' ),
            'courier-center'
        );

        // Shipper Details section
        add_settings_section(
            'cc_wc_shipper_section',
            'Στοιχεία Αποστολέα',
            array( $this, 'shipper_section_callback' ),
            'courier-center'
        );

        // Shipper Name
        register_setting( 'cc_wc_settings', 'cc_wc_shipper_name', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        add_settings_field(
            'cc_wc_shipper_name',
            'Επωνυμία',
            array( $this, 'text_field_callback' ),
            'courier-center',
            'cc_wc_shipper_section',
            array( 'label_for' => 'cc_wc_shipper_name' )
        );

        // Shipper Address
        register_setting( 'cc_wc_settings', 'cc_wc_shipper_address', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        add_settings_field(
            'cc_wc_shipper_address',
            'Διεύθυνση',
            array( $this, 'text_field_callback' ),
            'courier-center',
            'cc_wc_shipper_section',
            array( 'label_for' => 'cc_wc_shipper_address' )
        );

        // Shipper Postal Code
        register_setting( 'cc_wc_settings', 'cc_wc_shipper_postal_code', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        add_settings_field(
            'cc_wc_shipper_postal_code',
            'Ταχυδρομικός Κώδικας',
            array( $this, 'text_field_callback' ),
            'courier-center',
            'cc_wc_shipper_section',
            array( 'label_for' => 'cc_wc_shipper_postal_code' )
        );

        // Shipper City
        register_setting( 'cc_wc_settings', 'cc_wc_shipper_city', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        add_settings_field(
            'cc_wc_shipper_city',
            'Πόλη',
            array( $this, 'text_field_callback' ),
            'courier-center',
            'cc_wc_shipper_section',
            array( 'label_for' => 'cc_wc_shipper_city' )
        );

        // Shipper Phone
        register_setting( 'cc_wc_settings', 'cc_wc_shipper_phone', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        add_settings_field(
            'cc_wc_shipper_phone',
            'Τηλέφωνο',
            array( $this, 'text_field_callback' ),
            'courier-center',
            'cc_wc_shipper_section',
            array( 'label_for' => 'cc_wc_shipper_phone' )
        );

        // ── Σημεία αποστολής (υποκωδικοί) ─────────────────────────────────────
        add_settings_section(
            'cc_wc_pickup_section',
            '📍 Σημεία αποστολής (υποκωδικοί)',
            array( $this, 'pickup_section_callback' ),
            'courier-center'
        );

        register_setting( 'cc_wc_settings', CC_Pickup_Points::OPTION, array(
            'type'              => 'array',
            'sanitize_callback' => array( $this, 'sanitize_pickup_points' ),
            'default'           => array(),
        ) );
        add_settings_field(
            CC_Pickup_Points::OPTION,
            'Υποκωδικοί',
            array( $this, 'pickup_points_field_callback' ),
            'courier-center',
            'cc_wc_pickup_section'
        );

        register_setting( 'cc_wc_settings', CC_Pickup_Points::DEFAULT_OPTION, array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ) );
        add_settings_field(
            CC_Pickup_Points::DEFAULT_OPTION,
            'Προεπιλεγμένο σημείο',
            array( $this, 'default_pickup_point_field_callback' ),
            'courier-center',
            'cc_wc_pickup_section',
            array( 'label_for' => CC_Pickup_Points::DEFAULT_OPTION )
        );

        // ── Στοιχεία παραλήπτη ────────────────────────────────────────────────
        add_settings_section(
            'cc_wc_consignee_section',
            '📍 Στοιχεία Παραλήπτη',
            array( $this, 'consignee_section_callback' ),
            'courier-center'
        );

        register_setting( 'cc_wc_settings', 'cc_wc_street_number_field', array(
            'type'              => 'string',
            'sanitize_callback' => array( $this, 'sanitize_street_number_field' ),
            'default'           => '',
        ) );
        add_settings_field(
            'cc_wc_street_number_field',
            'Πεδίο αριθμού διεύθυνσης',
            array( $this, 'street_number_field_callback' ),
            'courier-center',
            'cc_wc_consignee_section',
            array( 'label_for' => 'cc_wc_street_number_field' )
        );

        // Tracking section
        add_settings_section(
            'cc_wc_tracking_section',
            'Tracking & Emails',
            array( $this, 'tracking_section_callback' ),
            'courier-center'
        );

        // Tracking URL — custom sanitize to preserve {{tracking}} placeholder
        register_setting( 'cc_wc_settings', 'cc_wc_tracking_url', array(
            'type'              => 'string',
            'sanitize_callback' => array( $this, 'sanitize_tracking_url' ),
            'default'           => 'https://www.courier.gr/track/result?tracknr={{tracking}}',
        ) );
        add_settings_field(
            'cc_wc_tracking_url',
            'Tracking URL',
            array( $this, 'tracking_url_field_callback' ),
            'courier-center',
            'cc_wc_tracking_section',
            array( 'label_for' => 'cc_wc_tracking_url' )
        );

        // Include tracking in customer emails
        register_setting( 'cc_wc_settings', 'cc_wc_email_tracking_enabled', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '1',
        ) );
        add_settings_field(
            'cc_wc_email_tracking_enabled',
            'Ενημέρωση πελάτη',
            array( $this, 'email_tracking_field_callback' ),
            'courier-center',
            'cc_wc_tracking_section',
            array( 'label_for' => 'cc_wc_email_tracking_enabled' )
        );

        // Print settings section
        add_settings_section(
            'cc_wc_print_section',
            'Ρυθμίσεις Εκτύπωσης',
            array( $this, 'print_section_callback' ),
            'courier-center'
        );

        // Print template for normal vouchers
        register_setting( 'cc_wc_settings', 'cc_wc_print_template', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => 'pdf',
        ) );
        add_settings_field(
            'cc_wc_print_template',
            'Εκτύπωση Courier Center Voucher',
            array( $this, 'print_template_field_callback' ),
            'courier-center',
            'cc_wc_print_section',
            array( 'label_for' => 'cc_wc_print_template' )
        );

        // Print template for BOX NOW vouchers
        register_setting( 'cc_wc_settings', 'cc_wc_print_template_boxnow', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => 'singlepdf_100x150_4up',
        ) );
        add_settings_field(
            'cc_wc_print_template_boxnow',
            'Εκτύπωση BOX NOW Voucher',
            array( $this, 'print_template_boxnow_field_callback' ),
            'courier-center',
            'cc_wc_print_section',
            array( 'label_for' => 'cc_wc_print_template_boxnow' )
        );

        // ── BOX NOW Widget section ────────────────────────────────────────────
        add_settings_section(
            'cc_wc_boxnow_section',
            '📦 BOX NOW Widget (Checkout)',
            array( $this, 'boxnow_section_callback' ),
            'courier-center'
        );

        register_setting( 'cc_wc_settings', 'cc_wc_boxnow_enabled', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '0',
        ) );
        add_settings_field(
            'cc_wc_boxnow_enabled',
            __( 'Ενεργοποίηση BOX NOW', 'courier-center-woocommerce' ),
            array( $this, 'boxnow_enabled_field_callback' ),
            'courier-center',
            'cc_wc_boxnow_section',
            array( 'label_for' => 'cc_wc_boxnow_enabled' )
        );

        register_setting( 'cc_wc_settings', 'cc_wc_boxnow_shipping_methods', array(
            'type'              => 'array',
            'sanitize_callback' => array( $this, 'sanitize_boxnow_shipping_methods' ),
            'default'           => array(),
        ) );
        add_settings_field(
            'cc_wc_boxnow_shipping_methods',
            __( 'Μέθοδος αποστολής "Courier Center"', 'courier-center-woocommerce' ),
            array( $this, 'boxnow_shipping_methods_field_callback' ),
            'courier-center',
            'cc_wc_boxnow_section',
            array( 'label_for' => 'cc_wc_boxnow_shipping_methods' )
        );

        register_setting( 'cc_wc_settings', 'cc_wc_boxnow_default_selected', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '0',
        ) );
        add_settings_field(
            'cc_wc_boxnow_default_selected',
            __( 'Προεπιλεγμένη επιλογή BOX NOW', 'courier-center-woocommerce' ),
            array( $this, 'boxnow_default_selected_field_callback' ),
            'courier-center',
            'cc_wc_boxnow_section',
            array( 'label_for' => 'cc_wc_boxnow_default_selected' )
        );

        // ── Auto-create voucher section ───────────────────────────────────────
        add_settings_section(
            'cc_wc_auto_create_section',
            __( '🤖 Αυτόματη Δημιουργία Voucher', 'courier-center-woocommerce' ),
            array( $this, 'auto_create_section_callback' ),
            'courier-center'
        );

        register_setting( 'cc_wc_settings', 'cc_wc_auto_create_enabled', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '0',
        ) );
        add_settings_field(
            'cc_wc_auto_create_enabled',
            __( 'Ενεργοποίηση', 'courier-center-woocommerce' ),
            array( $this, 'auto_create_enabled_field_callback' ),
            'courier-center',
            'cc_wc_auto_create_section',
            array( 'label_for' => 'cc_wc_auto_create_enabled' )
        );

        register_setting( 'cc_wc_settings', 'cc_wc_auto_create_status', array(
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ) );
        add_settings_field(
            'cc_wc_auto_create_status',
            __( 'Κατάσταση που πυροδοτεί τη δημιουργία', 'courier-center-woocommerce' ),
            array( $this, 'auto_create_status_field_callback' ),
            'courier-center',
            'cc_wc_auto_create_section',
            array( 'label_for' => 'cc_wc_auto_create_status' )
        );

        // ── Διαχειρίσιμες μέθοδοι αποστολής ────────────────────────────────────
        add_settings_section(
            'cc_wc_handled_section',
            __( '🚚 Μέθοδοι αποστολής που διαχειρίζεται το plugin', 'courier-center-woocommerce' ),
            array( $this, 'handled_section_callback' ),
            'courier-center'
        );

        register_setting( 'cc_wc_settings', 'cc_wc_handled_shipping_methods', array(
            'type'              => 'array',
            'sanitize_callback' => array( $this, 'sanitize_handled_shipping_methods' ),
            'default'           => array(),
        ) );
        add_settings_field(
            'cc_wc_handled_shipping_methods',
            __( 'Διαχειρίσιμες μέθοδοι', 'courier-center-woocommerce' ),
            array( $this, 'handled_shipping_methods_field_callback' ),
            'courier-center',
            'cc_wc_handled_section',
            array( 'label_for' => 'cc_wc_handled_shipping_methods' )
        );
    }

    /**
     * Section callbacks
     */
    public function api_section_callback() {
        echo '<p>Τα credentials που σας έχει δώσει η Courier Center για πρόσβαση στο API.</p>';
    }

    public function shipper_section_callback() {
        echo '<p>Τα στοιχεία του αποστολέα που θα εμφανίζονται στα vouchers.</p>';
    }

    // ── Σημεία αποστολής callbacks ───────────────────────────────────────────

    public function pickup_section_callback() {
        echo '<p>Αν έχετε περισσότερα σημεία παραλαβής, το καθένα είναι υποκωδικός κάτω από τον κεντρικό κωδικό σας. Προσθέστε τους εδώ και πατήστε <strong>Test &amp; Auto-fill</strong> σε κάθε γραμμή. Χωρίς υποκωδικούς, όλα τα vouchers βγαίνουν από την Έδρα όπως πάντα. Το Test &amp; Auto-fill των υποκωδικών χρησιμοποιεί τα <strong>αποθηκευμένα</strong> credentials — αποθηκεύστε πρώτα τα API Credentials.</p>';
    }

    /**
     * Ο έλεγχος «ίδιος με τον κεντρικό» γίνεται με τον κεντρικό κωδικό της ΙΔΙΑΣ
     * υποβολής, γιατί μπορεί να αλλάζει μαζί με τους υποκωδικούς.
     */
    public function sanitize_pickup_points( $value ) {
        $main_code = isset( $_POST['cc_wc_billing_account'] )
            ? sanitize_text_field( wp_unslash( $_POST['cc_wc_billing_account'] ) )
            : (string) get_option( 'cc_wc_billing_account', '' );

        $result = CC_Pickup_Points::sanitize_rows( $value, $main_code );

        foreach ( $result['errors'] as $i => $message ) {
            add_settings_error( CC_Pickup_Points::OPTION, 'cc_pickup_point_' . $i, $message, 'error' );
        }

        return $result['rows'];
    }

    public function pickup_points_field_callback() {
        $rows  = get_option( CC_Pickup_Points::OPTION, array() );
        $rows  = is_array( $rows ) ? array_values( $rows ) : array();
        $nonce = wp_create_nonce( 'cc_autofill_nonce' );
        ?>
        <table class="widefat striped" id="cc-pickup-points" style="max-width: 980px;">
            <thead>
                <tr>
                    <th>Υποκωδικός</th>
                    <th>Όνομα σημείου</th>
                    <th>Χρέωση</th>
                    <th>Στοιχεία αποστολέα (από Auto-fill)</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $rows as $i => $row ) { $this->render_pickup_point_row( $i, $row ); } ?>
            </tbody>
        </table>
        <script type="text/html" id="cc-pickup-point-template"><?php $this->render_pickup_point_row( '__i__', array() ); ?></script>
        <p><button type="button" class="button" id="cc-pickup-add">+ Προσθήκη υποκωδικού</button></p>
        <p class="description">Ο υποκωδικός ορίζει από ποιο σημείο παραλαμβάνει η Courier Center. «Χρέωση στον κεντρικό κωδικό»: η αποστολή βγαίνει από το σημείο αλλά χρεώνεται στον κεντρικό κωδικό.</p>

        <script>
        jQuery(function($) {
            var $tbody = $('#cc-pickup-points tbody');
            var fields = ['name', 'address', 'postal', 'city', 'phone'];
            var ccNextRow = 0;

            $('#cc-pickup-add').on('click', function() {
                var html = $('#cc-pickup-point-template').html().replace(/__i__/g, 'n' + Date.now() + '_' + (ccNextRow++));
                $tbody.append(html);
            });

            $tbody.on('click', '.cc-pp-remove', function() {
                $(this).closest('tr').remove();
            });

            // Νέος κωδικός → τα στοιχεία του προηγούμενου δεν ισχύουν πια
            $tbody.on('change', '.cc-pp-code', function() {
                var $row = $(this).closest('tr');
                $.each(fields, function(_, f) { $row.find('.cc-pp-' + f).val(''); });
                $row.find('.cc-pp-summary').text('—');
                $row.find('.cc-pp-status').css('color', '#8a6d00').text('Κάνε Test & Auto-fill για τον νέο κωδικό.');
            });

            $tbody.on('click', '.cc-pp-autofill', function() {
                var $btn  = $(this);
                var $row  = $btn.closest('tr');
                var $st   = $row.find('.cc-pp-status');
                var code  = $.trim($row.find('.cc-pp-code').val());

                if (!code) {
                    $st.css('color', '#b32d2e').text('Συμπλήρωσε πρώτα τον υποκωδικό.');
                    return;
                }

                $btn.prop('disabled', true);
                $st.css('color', '#666').text('⏳ Test αποστολή...');

                $.post(ajaxurl, {
                    action: 'cc_autofill_pickup_point',
                    nonce:  '<?php echo esc_js( $nonce ); ?>',
                    code:   code
                }, function(response) {
                    $btn.prop('disabled', false);
                    if (!response.success) {
                        $st.css('color', '#b32d2e').text('❌ ' + (response.data && response.data.message ? response.data.message : 'Άγνωστο σφάλμα'));
                        return;
                    }
                    var d = response.data;
                    $.each(fields, function(_, f) { $row.find('.cc-pp-' + f).val(d[f] || ''); });
                    $row.find('.cc-pp-summary').text(d.name + ' — ' + d.address + ', ' + d.postal + ' ' + d.city);
                    $st.css('color', '#1e6823').text('✅ Σταθμός: ' + (d.station_name || '—') + ' — πάτα «Αποθήκευση Ρυθμίσεων».');
                }).fail(function(xhr, status, error) {
                    $btn.prop('disabled', false);
                    $st.css('color', '#b32d2e').text('❌ AJAX error: ' + error);
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Μία γραμμή του πίνακα υποκωδικών ($i = '__i__' για το template).
     */
    private function render_pickup_point_row( $i, array $row ) {
        $row  = wp_parse_args( $row, array(
            'code' => '', 'label' => '', 'bill_to' => 'self',
            'name' => '', 'address' => '', 'postal' => '', 'city' => '', 'phone' => '',
        ) );
        $base    = CC_Pickup_Points::OPTION . '[' . $i . ']';
        $summary = '' !== $row['name']
            ? $row['name'] . ' — ' . $row['address'] . ', ' . $row['postal'] . ' ' . $row['city']
            : '—';
        ?>
        <tr class="cc-pickup-row">
            <td>
                <input type="text" class="cc-pp-code" style="width: 140px;" placeholder="100-0120-0001"
                       name="<?php echo esc_attr( $base . '[code]' ); ?>" value="<?php echo esc_attr( $row['code'] ); ?>">
            </td>
            <td>
                <input type="text" style="width: 140px;" placeholder="π.χ. Κηφισός"
                       name="<?php echo esc_attr( $base . '[label]' ); ?>" value="<?php echo esc_attr( $row['label'] ); ?>">
            </td>
            <td>
                <select name="<?php echo esc_attr( $base . '[bill_to]' ); ?>">
                    <option value="self" <?php selected( $row['bill_to'], 'self' ); ?>>Στον υποκωδικό</option>
                    <option value="main" <?php selected( $row['bill_to'], 'main' ); ?>>Στον κεντρικό κωδικό</option>
                </select>
            </td>
            <td>
                <span class="cc-pp-summary"><?php echo esc_html( $summary ); ?></span>
                <?php foreach ( array( 'name', 'address', 'postal', 'city', 'phone' ) as $field ) : ?>
                    <input type="hidden" class="cc-pp-<?php echo esc_attr( $field ); ?>"
                           name="<?php echo esc_attr( $base . '[' . $field . ']' ); ?>" value="<?php echo esc_attr( $row[ $field ] ); ?>">
                <?php endforeach; ?>
                <br><span class="cc-pp-status" style="font-style: italic;"></span>
            </td>
            <td style="white-space: nowrap;">
                <button type="button" class="button cc-pp-autofill">🔍 Test &amp; Auto-fill</button>
                <button type="button" class="button cc-pp-remove" style="color: #b32d2e;" title="Διαγραφή">🗑</button>
            </td>
        </tr>
        <?php
    }

    public function default_pickup_point_field_callback( $args ) {
        $current = (string) get_option( CC_Pickup_Points::DEFAULT_OPTION, '' );

        printf( '<select id="%1$s" name="%1$s">', esc_attr( $args['label_for'] ) );
        printf( '<option value="">%s</option>', esc_html( 'Έδρα (κεντρικός κωδικός)' ) );
        foreach ( CC_Pickup_Points::get_sub_points() as $point ) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr( $point['code'] ),
                selected( $current, $point['code'], false ),
                esc_html( CC_Pickup_Points::display_label( $point ) )
            );
        }
        echo '</select>';
        echo '<p class="description">Από αυτό το σημείο βγαίνουν η αυτόματη δημιουργία και η απλή μαζική ενέργεια· είναι και η προεπιλογή στο κουμπί της παραγγελίας. Νέοι υποκωδικοί εμφανίζονται εδώ μετά την αποθήκευση.</p>';
    }

    // ── Στοιχεία παραλήπτη callbacks ─────────────────────────────────────────

    public function consignee_section_callback() {
        echo '<p>' . esc_html__( 'Το voucher χρησιμοποιεί τη διεύθυνση αποστολής του πελάτη· όποιο πεδίο λείπει (π.χ. τηλέφωνο) συμπληρώνεται από τα στοιχεία χρέωσης.', 'courier-center-woocommerce' ) . '</p>';
    }

    /**
     * Χειροκίνητο meta key (αν δόθηκε) υπερισχύει της επιλογής στο dropdown.
     */
    public function sanitize_street_number_field( $value ) {
        $manual = isset( $_POST['cc_wc_street_number_field_manual'] )
            ? trim( sanitize_text_field( wp_unslash( $_POST['cc_wc_street_number_field_manual'] ) ) )
            : '';

        if ( '' !== $manual ) {
            return $manual;
        }

        return trim( sanitize_text_field( $value ) );
    }

    public function street_number_field_callback( $args ) {
        $current    = trim( (string) get_option( 'cc_wc_street_number_field', '' ) );
        $candidates = $this->discover_street_number_fields();

        // Η αποθηκευμένη τιμή εμφανίζεται πάντα, ακόμα κι αν δεν βρέθηκε στο σκανάρισμα
        if ( '' !== $current && ! isset( $candidates[ $current ] ) ) {
            $candidates = array( $current => '' ) + $candidates;
        }

        printf( '<select id="%1$s" name="%1$s">', esc_attr( $args['label_for'] ) );
        printf(
            '<option value="">%s</option>',
            esc_html__( '— Κανένα: ο αριθμός είναι ήδη μέσα στη «Διεύθυνση» —', 'courier-center-woocommerce' )
        );
        foreach ( $candidates as $key => $sample ) {
            printf(
                '<option value="%s" %s>%s%s</option>',
                esc_attr( $key ),
                selected( $current, $key, false ),
                esc_html( $key ),
                '' !== $sample ? esc_html( ' (π.χ. «' . $sample . '»)' ) : ''
            );
        }
        echo '</select>';

        printf(
            '<p style="margin-top:6px;"><input type="text" class="regular-text" name="cc_wc_street_number_field_manual" value="" placeholder="%s"></p>',
            esc_attr__( 'ή γράψτε το meta key χειροκίνητα', 'courier-center-woocommerce' )
        );

        echo '<p class="description">';
        esc_html_e( 'Μόνο για καταστήματα όπου το checkout έχει ξεχωριστό πεδίο «Αριθμός» εκτός της Διεύθυνσης. Η λίστα δείχνει πεδία που βρέθηκαν στις τελευταίες παραγγελίες, με δείγμα τιμής. Ο αριθμός θα προστίθεται στο τέλος της διεύθυνσης στο voucher.', 'courier-center-woocommerce' );
        echo '</p>';
    }

    /**
     * Σκανάρει τα custom meta των τελευταίων παραγγελιών για πιθανά πεδία
     * αριθμού οδού: σύντομες τιμές (≤6 χαρακτήρες) που περιέχουν ψηφίο.
     * Τα δείγματα βοηθούν τον merchant να διαλέξει το σωστό πεδίο.
     */
    private function discover_street_number_fields() {
        if ( ! function_exists( 'wc_get_orders' ) ) {
            return array();
        }

        $orders = wc_get_orders( array(
            'limit'   => 30,
            'orderby' => 'date',
            'order'   => 'DESC',
        ) );

        $found = array();
        foreach ( $orders as $order ) {
            foreach ( $order->get_meta_data() as $meta ) {
                $data  = $meta->get_data();
                $key   = (string) $data['key'];
                $value = $data['value'];

                if ( isset( $found[ $key ] ) || ! is_scalar( $value ) ) {
                    continue;
                }
                $value = trim( (string) $value );
                if ( '' === $value || mb_strlen( $value ) > 6 || ! preg_match( '/\d/u', $value ) ) {
                    continue;
                }
                // Εσωτερικά πεδία του plugin δεν είναι υποψήφια
                if ( preg_match( '/^_?(cc_|boxnow)/', $key ) ) {
                    continue;
                }
                $found[ $key ] = $value;
            }
        }

        ksort( $found );
        return array_slice( $found, 0, 20, true );
    }

    /**
     * Autofill button — rendered as a standalone section between API and Shipper
     */
    public function autofill_section_callback() {
        $nonce = wp_create_nonce( 'cc_autofill_nonce' );
        ?>
        <div style="padding: 12px 0 4px;">
            <button type="button" id="cc-autofill-btn" class="button button-primary">
                🔍 Test &amp; Auto-fill στοιχεία
            </button>
            <button type="button" id="cc-clear-btn" class="button" style="margin-left: 8px; color: #b32d2e; border-color: #b32d2e;">
                🗑️ Εκκαθάριση
            </button>
            <span id="cc-autofill-status" style="margin-left: 12px; font-style: italic;"></span>

            <div id="cc-autofill-notice" style="display:none; margin-top: 12px; padding: 10px 14px; background: #e7f5e9; border-left: 4px solid #46b450; border-radius: 3px; font-size: 13px;">
                ✅ <strong>Στοιχεία από Courier Center API</strong> — τα πεδία συμπληρώθηκαν αυτόματα και αποθηκεύτηκαν.
                Επικοινωνήστε με τον διαχειριστή για αλλαγές.
            </div>
        </div>

        <script>
        console.log('CC Settings JS loaded');
        console.log('ajaxurl:', typeof ajaxurl !== 'undefined' ? ajaxurl : 'NOT DEFINED');

        jQuery(document).ready(function($) {
            console.log('jQuery ready');
            console.log('Test button exists:', $('#cc-autofill-btn').length);
            console.log('Clear button exists:', $('#cc-clear-btn').length);

            $('#cc-autofill-btn').on('click', function() {
                var $btn    = $(this);
                var $status = $('#cc-autofill-status');
                var $notice = $('#cc-autofill-notice');

                $btn.prop('disabled', true).text('⏳ Παρακαλώ περιμένετε...');
                $status.css('color', '#666').text('Βήμα 1/3: Δημιουργία test αποστολής...');
                $notice.hide();

                var postData = {
                    action:           'cc_test_and_autofill',
                    nonce:            '<?php echo esc_js( $nonce ); ?>',
                    user_alias:       $('#cc_wc_user_alias').val(),
                    credential_value: $('#cc_wc_credential_value').val(),
                    api_key:          $('#cc_wc_api_key').val(),
                    billing_account:  $('#cc_wc_billing_account').val(),
                };
                console.log('CC Autofill POST data:', {
                    user_alias:       postData.user_alias      || '(empty)',
                    credential_value: postData.credential_value ? '(set, length=' + postData.credential_value.length + ')' : '(empty)',
                    api_key:          postData.api_key          ? '(set, length=' + postData.api_key.length + ')' : '(empty)',
                    billing_account:  postData.billing_account  || '(empty)',
                });

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: postData,
                    success: function(response) {
                        $btn.prop('disabled', false).text('🔍 Test & Auto-fill στοιχεία');
                        console.log('CC Autofill response:', response);

                        if (!response.success) {
                            $status.css('color', '#b32d2e').text('❌ ' + (response.data && response.data.message ? response.data.message : 'Άγνωστο σφάλμα'));
                            return;
                        }

                        var d = response.data;
                        console.log('CC Autofill data:', d);

                        // Γεμίζουμε τα πεδία με name=
                        if (d.shipper_name)         $('input[name="cc_wc_shipper_name"]').val(d.shipper_name).prop('readonly', true);
                        if (d.shipper_address)       $('input[name="cc_wc_shipper_address"]').val(d.shipper_address).prop('readonly', true);
                        if (d.shipper_postal_code)   $('input[name="cc_wc_shipper_postal_code"]').val(d.shipper_postal_code).prop('readonly', true);
                        if (d.shipper_city)          $('input[name="cc_wc_shipper_city"]').val(d.shipper_city).prop('readonly', true);
                        if (d.shipper_phone)         $('input[name="cc_wc_shipper_phone"]').val(d.shipper_phone).prop('readonly', true);

                        // Στυλ για readonly πεδία
                        $('input[name^="cc_wc_shipper_"]').filter('[readonly]').css({
                            'background-color': '#f6f7f7',
                            'color': '#444',
                            'cursor': 'not-allowed'
                        });

                        $status.text('');
                        $notice.show();
                    },
                    error: function(xhr, status, error) {
                        $btn.prop('disabled', false).text('🔍 Test & Auto-fill στοιχεία');
                        $status.css('color', '#b32d2e').text('❌ AJAX error: ' + error);
                    }
                });
            });

            $('#cc-clear-btn').on('click', function() {
                if ( ! confirm('Είστε σίγουροι ότι θέλετε να διαγράψετε όλες τις ρυθμίσεις;') ) {
                    return;
                }
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'cc_clear_settings',
                        nonce:  '<?php echo esc_js( wp_create_nonce( 'cc_clear_settings_nonce' ) ); ?>',
                    },
                    success: function() {
                        location.reload();
                    },
                    error: function(xhr, status, error) {
                        alert('❌ AJAX error: ' + error);
                    }
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Field callbacks
     */
    public function text_field_callback( $args ) {
        $option = get_option( $args['label_for'] );
        printf(
            '<input type="text" id="%s" name="%s" value="%s" class="regular-text">',
            esc_attr( $args['label_for'] ),
            esc_attr( $args['label_for'] ),
            esc_attr( $option )
        );
    }

    public function password_field_callback( $args ) {
        $option = get_option( $args['label_for'] );
        $display_value = $option ? str_repeat( '•', 20 ) : '';
        printf(
            '<input type="password" id="%s" name="%s" value="" class="regular-text" placeholder="%s" autocomplete="new-password">',
            esc_attr( $args['label_for'] ),
            esc_attr( $args['label_for'] ),
            esc_attr( $display_value )
        );
        if ( $option ) {
            echo '<p class="description">Αποθηκευμένο — άφησε κενό για να μην αλλάξει</p>';
        }
    }

    public function sanitize_credential_value( $value ) {
        return $this->keep_secret_if_empty( $value, 'cc_wc_credential_value' );
    }

    public function sanitize_api_key( $value ) {
        return $this->keep_secret_if_empty( $value, 'cc_wc_api_key' );
    }

    /**
     * Τα password πεδία εμφανίζονται κενά — κενή υποβολή σημαίνει «μην αλλάξεις».
     */
    private function keep_secret_if_empty( $value, $option ) {
        $value = sanitize_text_field( (string) $value );
        return '' === $value ? (string) get_option( $option, '' ) : $value;
    }

    /**
     * Sanitize tracking URL — preserves {{tracking}} placeholder, rejects values without it
     */
    public function sanitize_tracking_url( $value ) {
        // wp_kses με κενό array αφαιρεί HTML αλλά διατηρεί τα {{ και }}
        $value = wp_kses( trim( $value ), array() );

        if ( strpos( $value, '{{tracking}}' ) === false ) {
            add_settings_error(
                'cc_wc_tracking_url',
                'missing_placeholder',
                'Tracking URL: πρέπει να περιέχει <code>{{tracking}}</code> ως placeholder. Επαναφέρθηκε η προεπιλεγμένη τιμή.',
                'error'
            );
            // Επιστρέφει πάντα την hardcoded default (και για χαλασμένες αποθηκευμένες τιμές)
            return 'https://www.courier.gr/track/result?tracknr={{tracking}}';
        }

        return $value;
    }

    /**
     * Render settings page
     */
    public function render_page() {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

            <?php settings_errors(); ?>

            <form method="post" action="options.php">
                <?php
                settings_fields( 'cc_wc_settings' );
                do_settings_sections( 'courier-center' );
                submit_button( 'Αποθήκευση Ρυθμίσεων' );
                ?>
            </form>

            <?php
            $next_cron     = wp_next_scheduled( 'cc_status_tracking_cron' );
            $last_run      = get_option( 'cc_wc_cron_last_run', '' );
            $all_schedules = wp_get_schedules();
            $has_custom    = isset( $all_schedules['cc_every_two_hours'] );
            $cron_disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
            ?>
            <div style="background:#f0f6fc; border-left:4px solid #2271b1; padding:12px 16px; margin-top:20px; max-width:700px; border-radius:3px;">
                <strong>Αυτόματη Ενημέρωση Status</strong><br>
                <small>
                    Επόμενη εκτέλεση: <strong><?php
                        if ( $next_cron ) {
                            echo human_time_diff( time(), $next_cron ) . ' από τώρα (' . date( 'H:i', $next_cron + (get_option('gmt_offset', 0) * 3600) ) . ')';
                        } else {
                            echo '❌ Δεν είναι προγραμματισμένο!';
                        }
                    ?></strong><br>
                    Τελευταία εκτέλεση: <strong><?php echo esc_html( $last_run ? (string) $last_run : 'Δεν έχει τρέξει ακόμα' ); ?></strong>
                </small>
                <br><br>
                <small style="color: #666;">
                    <strong>Debug Info:</strong><br>
                    - Schedule 'cc_every_two_hours' registered: <strong><?php echo $has_custom ? 'YES' : 'NO'; ?></strong><br>
                    - wp_next_scheduled raw value: <strong><?php echo $next_cron ? $next_cron . ' (' . date('Y-m-d H:i:s', $next_cron) . ' UTC)' : 'FALSE'; ?></strong><br>
                    - WP Cron: <strong><?php echo $cron_disabled ? 'DISABLED (DISABLE_WP_CRON = true)' : 'ENABLED'; ?></strong><br>
                    - Server time (UTC): <strong><?php echo date('Y-m-d H:i:s'); ?></strong>
                </small>
            </div>
        </div>
        <?php
    }

    /**
     * AJAX: Δημιούργησε test αποστολή → GetShipmentDetails → Void → επέστρεψε στοιχεία αποστολέα
     */
    public function ajax_test_and_autofill() {
        check_ajax_referer( 'cc_autofill_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => 'Unauthorized' ) );
        }

        $user_alias       = sanitize_text_field( $_POST['user_alias']       ?? '' );
        $credential_value = sanitize_text_field( $_POST['credential_value'] ?? '' );
        $api_key          = sanitize_text_field( $_POST['api_key']          ?? '' );
        $billing_account  = sanitize_text_field( $_POST['billing_account']  ?? '' );

        // Αν τα password fields ήρθαν κενά (browser δεν στέλνει masked τιμές), fallback στη βάση
        if ( empty( $credential_value ) ) {
            $credential_value = get_option( 'cc_wc_credential_value', '' );
        }
        if ( empty( $api_key ) ) {
            $api_key = get_option( 'cc_wc_api_key', '' );
        }
        if ( empty( $user_alias ) ) {
            $user_alias = get_option( 'cc_wc_user_alias', '' );
        }
        if ( empty( $billing_account ) ) {
            $billing_account = get_option( 'cc_wc_billing_account', '' );
        }

        // ── Βήμα 0: Αποθήκευσε credentials πρώτα ───────────────────────────
        update_option( 'cc_wc_user_alias',       $user_alias );
        update_option( 'cc_wc_credential_value', $credential_value );
        update_option( 'cc_wc_api_key',          $api_key );
        update_option( 'cc_wc_billing_account',  $billing_account );

        $context = array(
            'UserAlias'       => $user_alias,
            'CredentialValue' => $credential_value,
            'ApiKey'          => $api_key,
        );

        $details = $this->fetch_account_details( $billing_account, $context );
        if ( is_wp_error( $details ) ) {
            wp_send_json_error( array( 'message' => $details->get_error_message() ) );
        }

        // ── Αποθήκευση στοιχείων αποστολέα ──────────────────────────────────
        update_option( 'cc_wc_shipper_name',        $details['name'] );
        update_option( 'cc_wc_shipper_address',     $details['address'] );
        update_option( 'cc_wc_shipper_postal_code', $details['postal'] );
        update_option( 'cc_wc_shipper_city',        $details['city'] );
        update_option( 'cc_wc_shipper_phone',       $details['phone'] );
        update_option( 'cc_wc_shipper_station',     $details['station'] );

        wp_send_json_success( array(
            'shipper_name'         => $details['name'],
            'shipper_address'      => $details['address'],
            'shipper_postal_code'  => $details['postal'],
            'shipper_city'         => $details['city'],
            'shipper_phone'        => $details['phone'],
            'shipper_station'      => $details['station'],
        ) );
    }

    /**
     * Test αποστολή → GetShipmentDetails → Void: τα στοιχεία αποστολέα και ο σταθμός
     * ενός κωδικού όπως τα έχει η Courier Center. Το API αγνοεί τη διεύθυνση που
     * στέλνουμε και βάζει αυτή του κωδικού — γι' αυτό τα στοιχεία είναι ψεύτικα.
     *
     * @param string     $account Κεντρικός ή υποκωδικός.
     * @param array|null $context Credentials· null = τα αποθηκευμένα.
     * @return array|WP_Error
     */
    public function fetch_account_details( $account, $context = null ) {
        if ( null === $context ) {
            $context = array(
                'UserAlias'       => get_option( 'cc_wc_user_alias', '' ),
                'CredentialValue' => get_option( 'cc_wc_credential_value', '' ),
                'ApiKey'          => get_option( 'cc_wc_api_key', '' ),
            );
        }

        $api = new CC_API();

        // ── Βήμα 1: Δημιουργία test αποστολής ──────────────────────────────
        $payload = array(
            'Context'      => $context,
            'shipmentDate' => date( 'Y-m-d' ),
            'comments'     => 'TEST AUTOFILL - DELETE',
            'Requestor'    => array( 'CarrierBillingAccount' => $account ),
            'Shipper'      => array(
                'CarrierBillingAccount' => $account,
                'CompanyName'           => 'TEST',
                'Address'               => 'TEST',
                'ZipCode'               => '10431',
                'City'                  => 'ΑΘΗΝΑ',
                'Phones'                => '2101234567',
                'Country'               => 'GREECE',
                'CountryCode'           => 'GR',
            ),
            'Consignee'    => array(
                'CompanyName' => 'TEST',
                'ContactName' => 'TEST',
                'Address'     => 'ΑΘΗΝΑ',
                'City'        => 'ΑΘΗΝΑ',
                'Area'        => 'ΑΘΗΝΑ',
                'ZipCode'     => '10431',
                'Country'     => 'GR',
                'Mobile1'     => '2101234567',
            ),
            'BillTo'       => 'Requestor',
            'BasicService' => '211',
            'Reference1'   => 'TEST-AUTOFILL',
            'Items'        => array(
                array(
                    'GoodsType'        => 'NoDocs',
                    'Content'          => 'TEST',
                    'IsDangerousGoods' => false,
                    'IsDryIce'         => false,
                    'IsFragile'        => false,
                    'Weight'           => array( 'Unit' => 'kg', 'Value' => 1.0 ),
                ),
            ),
        );

        $create_result = $api->create_shipment( $payload );

        if ( is_wp_error( $create_result ) ) {
            return new WP_Error( 'autofill_create', 'Βήμα 1 — Αποτυχία δημιουργίας test αποστολής: ' . $create_result->get_error_message() );
        }

        $awb = $create_result['ShipmentNumber'] ?? '';

        if ( empty( $awb ) ) {
            return new WP_Error( 'autofill_no_awb', 'Βήμα 1 — Το API δεν επέστρεψε ShipmentNumber. Response: ' . wp_json_encode( $create_result ) );
        }

        // ── Βήμα 2: GetShipmentDetails → εξαγωγή στοιχείων αποστολέα ───────
        $details = $api->get_shipment_details( $awb );

        if ( is_wp_error( $details ) ) {
            $void = $api->void_shipment( $awb );
            $note = is_wp_error( $void )
                ? sprintf( ' (η test αποστολή %s ΔΕΝ ακυρώθηκε — ακυρώστε την χειροκίνητα)', $awb )
                : sprintf( ' (η test αποστολή %s ακυρώθηκε)', $awb );
            return new WP_Error( 'autofill_details', 'Βήμα 2 — Αποτυχία GetShipmentDetails: ' . $details->get_error_message() . $note );
        }

        // Ανακτούμε στοιχεία από ShipmentDetails[0]['ShipmentInfo']
        $info    = $details['ShipmentDetails'][0]['ShipmentInfo'] ?? array();
        $shipper = $info['Shipper'] ?? array();

        // ── Βήμα 3: Void αποστολής ──────────────────────────────────────────
        $void = $api->void_shipment( $awb );
        if ( is_wp_error( $void ) ) {
            return new WP_Error(
                'autofill_void',
                sprintf( 'Βήμα 3 — Η test αποστολή %s δεν ακυρώθηκε (%s). Ακυρώστε την χειροκίνητα.', $awb, $void->get_error_message() )
            );
        }

        return array(
            'name'         => (string) ( $shipper['CompanyName'] ?? '' ),
            'address'      => (string) ( $shipper['Address'] ?? '' ),
            'postal'       => (string) ( $shipper['ZipCode'] ?? '' ),
            'city'         => (string) ( $shipper['City'] ?? '' ),
            'phone'        => (string) ( $shipper['Phones'] ?? '' ),
            'station'      => (string) ( $info['PickupStation']['Prefix'] ?? '' ),
            'station_name' => (string) ( $info['PickupStation']['Name'] ?? '' ),
        );
    }

    /**
     * AJAX: Test & Auto-fill μίας γραμμής υποκωδικού. Επιστρέφει τα στοιχεία —
     * δεν γράφει options· αποθηκεύονται με τη φόρμα.
     */
    public function ajax_autofill_pickup_point() {
        check_ajax_referer( 'cc_autofill_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => 'Unauthorized' ) );
        }

        $code = isset( $_POST['code'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['code'] ) ) ) : '';
        if ( '' === $code ) {
            wp_send_json_error( array( 'message' => 'Συμπλήρωσε τον υποκωδικό.' ) );
        }

        $details = $this->fetch_account_details( $code );
        if ( is_wp_error( $details ) ) {
            wp_send_json_error( array( 'message' => $details->get_error_message() ) );
        }

        wp_send_json_success( $details );
    }

    /**
     * Tracking section description
     */
    public function tracking_section_callback() {
        echo '<p>Ρυθμίσεις για τα emails που στέλνονται στους πελάτες με τα στοιχεία αποστολής.</p>';
    }

    /**
     * Tracking URL field with help text
     */
    public function tracking_url_field_callback( $args ) {
        $value = get_option( $args['label_for'], 'https://www.courier.gr/track/result?tracknr={{tracking}}' );
        printf(
            '<input type="text" id="%s" name="%s" value="%s" class="regular-text" style="width: 500px;">',
            esc_attr( $args['label_for'] ),
            esc_attr( $args['label_for'] ),
            esc_attr( $value )
        );
        echo '<p class="description">';
        echo 'Το URL όπου ο πελάτης μπορεί να παρακολουθήσει την αποστολή του.<br>';
        echo 'Χρησιμοποιήστε <code>{{tracking}}</code> ως placeholder για το tracking number.<br>';
        echo '<strong>Προεπιλογή:</strong> <code>https://www.courier.gr/track/result?tracknr={{tracking}}</code>';
        echo '</p>';
    }

    /**
     * Email tracking enabled checkbox
     */
    public function email_tracking_field_callback( $args ) {
        $value = get_option( $args['label_for'], '1' );
        printf(
            '<label><input type="checkbox" id="%s" name="%s" value="1" %s> %s</label>',
            esc_attr( $args['label_for'] ),
            esc_attr( $args['label_for'] ),
            checked( $value, '1', false ),
            'Προσθήκη στοιχείων αποστολής στα emails του WooCommerce'
        );
        echo '<p class="description">';
        echo 'Όταν είναι ενεργό, τα WooCommerce emails που στέλνονται στον πελάτη (Processing, Completed κλπ) θα περιλαμβάνουν το AWB και link για παρακολούθηση της αποστολής.';
        echo '</p>';
    }

    /**
     * Print section description
     */
    public function print_section_callback() {
        echo '<p>Επιλέξτε το format εκτύπωσης για τα vouchers ανάλογα με τον εκτυπωτή σας.</p>';
    }

    /**
     * Print template dropdown for normal (non-BOX NOW) vouchers
     */
    public function print_template_field_callback( $args ) {
        $value = get_option( $args['label_for'], 'pdf' );
        $options = array(
            'pdf'                    => 'A4 - 3 θέσεις μη προεκτυπωμένο',
            'clean'                  => 'A4 - 3 θέσεις προεκτυπωμένο',
            'singlepdf_100x150_4up'  => 'A4 - 4 θέσεις 100x150mm (custom - FPDI)',
            'singlepdf'              => 'Θερμικός 205x100mm μη προεκτυπωμένο',
            'singleclean'            => 'Θερμικός 205x100mm προεκτυπωμένο',
            'singlepdf_100x150'      => 'Θερμικός 100x150mm',
            'singlepdf_100x170'      => 'Θερμικός 100x170mm',
        );
        printf( '<select id="%s" name="%s">', esc_attr( $args['label_for'] ), esc_attr( $args['label_for'] ) );
        foreach ( $options as $key => $label ) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr( $key ),
                selected( $value, $key, false ),
                esc_html( $label )
            );
        }
        echo '</select>';
    }

    /**
     * Print template dropdown for BOX NOW vouchers
     */
    public function print_template_boxnow_field_callback( $args ) {
        $value = get_option( $args['label_for'], 'singlepdf_100x150_4up' );
        $options = array(
            'singlepdf_100x150_4up' => 'A4 - 4 θέσεις 100x150mm (default)',
            'singlepdf_100x150'     => 'Θερμικός 100x150mm',
        );
        printf( '<select id="%s" name="%s">', esc_attr( $args['label_for'] ), esc_attr( $args['label_for'] ) );
        foreach ( $options as $key => $label ) {
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr( $key ),
                selected( $value, $key, false ),
                esc_html( $label )
            );
        }
        echo '</select>';
    }

    // ── BOX NOW Widget callbacks ──────────────────────────────────────────────

    public function boxnow_section_callback() {
        echo '<p>Ρυθμίσεις για το BOX NOW Locker addon στο checkout.</p>';

        $enabled = get_option( 'cc_wc_boxnow_enabled', '0' );
        $methods = get_option( 'cc_wc_boxnow_shipping_methods', array() );

        if ( $enabled === '1' && empty( $methods ) ) {
            echo '<div class="notice notice-warning inline"><p>';
            esc_html_e( 'Το BOX NOW είναι ενεργό αλλά δεν έχει οριστεί ποια μέθοδος αποστολής αντιστοιχεί στο "Courier Center" παρακάτω. Μέχρι να το ρυθμίσετε, το widget BOX NOW δεν θα εμφανίζεται στο checkout.', 'courier-center-woocommerce' );
            echo '</p></div>';
        }
    }

    public function boxnow_enabled_field_callback( $args ) {
        $value = get_option( $args['label_for'], '0' );
        printf(
            '<label><input type="checkbox" id="%s" name="%s" value="1" %s> %s</label>',
            esc_attr( $args['label_for'] ),
            esc_attr( $args['label_for'] ),
            checked( $value, '1', false ),
            esc_html__( 'Εμφάνιση επιλογής BOX NOW Locker στο checkout (κάτω από τα shipping methods)', 'courier-center-woocommerce' )
        );
    }

    /**
     * Sanitize: array of shipping method instance IDs
     */
    public function sanitize_boxnow_shipping_methods( $value ) {
        if ( ! is_array( $value ) ) {
            return array();
        }
        return array_map( 'absint', $value );
    }

    /**
     * Checkbox list: ποιες shipping methods (από όλες τις zones) αντιστοιχούν στο "Courier Center"
     */
    public function boxnow_shipping_methods_field_callback( $args ) {
        $selected = array_map( 'absint', (array) get_option( $args['label_for'], array() ) );

        $zones   = \WC_Shipping_Zones::get_zones();
        $zones[] = array(
            'zone_id'   => 0,
            'zone_name' => __( 'Υπόλοιπος Κόσμος', 'courier-center-woocommerce' ),
        );

        $found_any = false;

        foreach ( $zones as $zone_data ) {
            $zone    = new \WC_Shipping_Zone( $zone_data['zone_id'] );
            $methods = $zone->get_shipping_methods();

            if ( empty( $methods ) ) {
                continue;
            }

            foreach ( $methods as $method ) {
                $found_any = true;
                printf(
                    '<label style="display:block;margin-bottom:4px;"><input type="checkbox" name="%s[]" value="%d" %s> %s &mdash; <em>%s</em></label>',
                    esc_attr( $args['label_for'] ),
                    esc_attr( $method->instance_id ),
                    checked( in_array( $method->instance_id, $selected, true ), true, false ),
                    esc_html( $method->get_title() ),
                    esc_html( $zone_data['zone_name'] )
                );
            }
        }

        if ( ! $found_any ) {
            echo '<p class="description">' . esc_html__( 'Δεν βρέθηκαν shipping methods. Ρυθμίστε πρώτα τις ζώνες αποστολής στο WooCommerce.', 'courier-center-woocommerce' ) . '</p>';
        }

        echo '<p class="description">';
        esc_html_e( 'Επιλέξτε ποια μέθοδο/μεθόδους αποστολής αντιστοιχούν στο "Courier Center". Το widget BOX NOW θα εμφανίζεται στο checkout μόνο όταν ο πελάτης επιλέξει μία από αυτές.', 'courier-center-woocommerce' );
        echo '</p>';
    }

    public function boxnow_default_selected_field_callback( $args ) {
        $value = get_option( $args['label_for'], '0' );
        printf(
            '<label><input type="checkbox" id="%s" name="%s" value="1" %s> %s</label>',
            esc_attr( $args['label_for'] ),
            esc_attr( $args['label_for'] ),
            checked( $value, '1', false ),
            esc_html__( 'Να εμφανίζεται ήδη τσεκαρισμένο και κλειδωμένο όταν ο πελάτης επιλέξει μέθοδο "Courier Center". Για να το αφαιρέσει, ο πελάτης επιλέγει άλλη μέθοδο αποστολής.', 'courier-center-woocommerce' )
        );
    }

    // ── Διαχειρίσιμες μέθοδοι αποστολής callbacks ─────────────────────────────

    public function handled_section_callback() {
        echo '<p>' . esc_html__( 'Επιλέξτε ποιες μεθόδους αποστολής διαχειρίζεται το plugin. Voucher Courier Center (αυτόματα, μαζικά ή χειροκίνητα) δημιουργείται μόνο για παραγγελίες με αυτές τις μεθόδους — οι υπόλοιπες (π.χ. άλλος courier) αγνοούνται.', 'courier-center-woocommerce' ) . '</p>';

        $methods = get_option( 'cc_wc_handled_shipping_methods', array() );
        if ( empty( $methods ) ) {
            echo '<div class="notice notice-warning inline"><p>';
            esc_html_e( 'Δεν έχει επιλεγεί καμία μέθοδος αποστολής. Μέχρι να επιλέξετε τουλάχιστον μία, το plugin θεωρεί ότι διαχειρίζεται ΟΛΕΣ τις παραγγελίες.', 'courier-center-woocommerce' );
            echo '</p></div>';
        }
    }

    /**
     * Sanitize + save-time validation: απαιτείται τουλάχιστον 1 μέθοδος.
     */
    public function sanitize_handled_shipping_methods( $value ) {
        $clean = is_array( $value ) ? array_values( array_filter( array_map( 'absint', $value ) ) ) : array();

        if ( empty( $clean ) ) {
            add_settings_error(
                'cc_wc_handled_shipping_methods',
                'cc_wc_handled_empty',
                __( 'Δεν έχει επιλεγεί καμία μέθοδος αποστολής στο πεδίο «Μέθοδοι αποστολής που διαχειρίζεται το plugin». Επιλέξτε τουλάχιστον μία.', 'courier-center-woocommerce' ),
                'error'
            );
            // Κράτα την προηγούμενη αποθηκευμένη τιμή αντί να αποθηκεύσεις κενό
            return array_map( 'absint', (array) get_option( 'cc_wc_handled_shipping_methods', array() ) );
        }

        return $clean;
    }

    public function handled_shipping_methods_field_callback( $args ) {
        $selected = array_map( 'absint', (array) get_option( $args['label_for'], array() ) );
        $this->render_shipping_methods_checklist( $args['label_for'], $selected );

        echo '<p class="description">';
        esc_html_e( 'Μόνο παραγγελίες με τις επιλεγμένες μεθόδους δημιουργούν voucher αυτόματα/μαζικά. Στη χειροκίνητη δημιουργία, ο διαχειριστής μπορεί να παρακάμψει με επιβεβαίωση.', 'courier-center-woocommerce' );
        echo '</p>';
    }

    /**
     * Render checkbox-λίστας όλων των shipping methods όλων των zones.
     */
    private function render_shipping_methods_checklist( $name, array $selected ) {
        $zones   = \WC_Shipping_Zones::get_zones();
        $zones[] = array(
            'zone_id'   => 0,
            'zone_name' => __( 'Υπόλοιπος Κόσμος', 'courier-center-woocommerce' ),
        );

        $found_any = false;

        foreach ( $zones as $zone_data ) {
            $zone    = new \WC_Shipping_Zone( $zone_data['zone_id'] );
            $methods = $zone->get_shipping_methods();

            if ( empty( $methods ) ) {
                continue;
            }

            foreach ( $methods as $method ) {
                $found_any = true;
                printf(
                    '<label style="display:block;margin-bottom:4px;"><input type="checkbox" name="%s[]" value="%d" %s> %s &mdash; <em>%s</em></label>',
                    esc_attr( $name ),
                    esc_attr( $method->instance_id ),
                    checked( in_array( $method->instance_id, $selected, true ), true, false ),
                    esc_html( $method->get_title() ),
                    esc_html( $zone_data['zone_name'] )
                );
            }
        }

        if ( ! $found_any ) {
            echo '<p class="description">' . esc_html__( 'Δεν βρέθηκαν shipping methods. Ρυθμίστε πρώτα τις ζώνες αποστολής στο WooCommerce.', 'courier-center-woocommerce' ) . '</p>';
        }
    }

    // ── Auto-create voucher callbacks ─────────────────────────────────────────

    public function auto_create_section_callback() {
        echo '<p>Δημιουργία voucher αποστολής αυτόματα (Επόμενη Μέρα), μόλις μια παραγγελία περάσει στην παρακάτω επιλεγμένη κατάσταση — χωρίς να χρειάζεται καμία χειροκίνητη ενέργεια. Δεν δημιουργείται διπλό voucher αν υπάρχει ήδη ενεργό για την παραγγελία.</p>';
    }

    public function auto_create_enabled_field_callback( $args ) {
        $value = get_option( $args['label_for'], '0' );
        printf(
            '<label><input type="checkbox" id="%s" name="%s" value="1" %s> %s</label>',
            esc_attr( $args['label_for'] ),
            esc_attr( $args['label_for'] ),
            checked( $value, '1', false ),
            esc_html__( 'Αυτόματη δημιουργία voucher όταν μια παραγγελία περάσει στην επιλεγμένη κατάσταση', 'courier-center-woocommerce' )
        );
    }

    public function auto_create_status_field_callback( $args ) {
        $value    = get_option( $args['label_for'], '' );
        $statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();

        printf( '<select id="%s" name="%s">', esc_attr( $args['label_for'] ), esc_attr( $args['label_for'] ) );
        echo '<option value="">— Επιλέξτε κατάσταση —</option>';
        foreach ( $statuses as $key => $label ) {
            $slug = preg_replace( '/^wc-/', '', $key );
            printf(
                '<option value="%s" %s>%s</option>',
                esc_attr( $slug ),
                selected( $value, $slug, false ),
                esc_html( $label )
            );
        }
        echo '</select>';
        echo '<p class="description">Μόλις μια παραγγελία περάσει σε αυτή την κατάσταση, θα δημιουργείται αυτόματα voucher (Επόμενη Μέρα, με αυτόματο εντοπισμό BOX NOW όπου χρειάζεται).</p>';
    }

    /**
     * Όλα τα options του plugin — όσα σβήνει η «Εκκαθάριση».
     *
     * @return string[]
     */
    public static function plugin_option_names() {
        return array_merge( array(
            'cc_wc_user_alias',
            'cc_wc_credential_value',
            'cc_wc_api_key',
            'cc_wc_billing_account',
            'cc_wc_shipper_name',
            'cc_wc_shipper_address',
            'cc_wc_shipper_postal_code',
            'cc_wc_shipper_city',
            'cc_wc_shipper_phone',
            'cc_wc_shipper_station',
            'cc_wc_pickup_points',
            'cc_wc_default_pickup_point',
            'cc_wc_tracking_url',
            'cc_wc_email_tracking_enabled',
            'cc_wc_print_template',
            'cc_wc_print_template_boxnow',
            'cc_wc_boxnow_enabled',
            'cc_wc_boxnow_shipping_methods',
            'cc_wc_boxnow_default_selected',
            'cc_wc_auto_create_enabled',
            'cc_wc_auto_create_status',
            'cc_wc_handled_shipping_methods',
        ), CC_Returns_Settings::option_names() );
    }

    /**
     * AJAX: Διαγραφή όλων των plugin options
     */
    public function ajax_clear_settings() {
        check_ajax_referer( 'cc_clear_settings_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_send_json_error( array( 'message' => 'Unauthorized' ) );
        }

        foreach ( self::plugin_option_names() as $option ) {
            delete_option( $option );
        }

        wp_send_json_success();
    }
}
