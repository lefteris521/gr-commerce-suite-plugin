<?php
/**
 * Bulk Actions & Custom Columns for WooCommerce Orders List
 *
 * - Στήλη "CC Voucher" με AWB
 * - Στήλη "CC Status" με τρέχον status
 * - Bulk action: Δημιουργία Vouchers (Επόμενη Μέρα)
 * - Bulk action: Ενημέρωση Status
 * - Bulk action: Μαζική Εκτύπωση Vouchers
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class CC_Bulk_Actions {

    /** Μαζική δημιουργία από συγκεκριμένο σημείο: cc_create_vouchers__<κωδικός>. */
    const CREATE_FROM_POINT_PREFIX = 'cc_create_vouchers__';

    public function __construct() {
        // === BULK ACTIONS ===
        add_filter( 'bulk_actions-woocommerce_page_wc-orders', array( $this, 'register_bulk_actions' ) );
        add_filter( 'bulk_actions-edit-shop_order', array( $this, 'register_bulk_actions' ) );

        add_filter( 'handle_bulk_actions-woocommerce_page_wc-orders', array( $this, 'handle_bulk_action' ), 10, 3 );
        add_filter( 'handle_bulk_actions-edit-shop_order', array( $this, 'handle_bulk_action' ), 10, 3 );

        add_action( 'admin_notices', array( $this, 'show_bulk_result_notice' ) );

        // === MASS PRINT HANDLER ===
        add_action( 'admin_post_cc_mass_print_vouchers',        array( $this, 'handle_mass_print' ) );
        add_action( 'admin_post_cc_mass_print_boxnow_vouchers', array( $this, 'handle_mass_print' ) );

        // === CUSTOM COLUMNS (HPOS) ===
        add_filter( 'manage_woocommerce_page_wc-orders_columns', array( $this, 'add_custom_columns' ) );
        add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( $this, 'render_custom_columns' ), 10, 2 );

        // === CUSTOM COLUMNS (Legacy) ===
        add_filter( 'manage_edit-shop_order_columns', array( $this, 'add_custom_columns' ) );
        add_action( 'manage_shop_order_posts_custom_column', array( $this, 'render_custom_columns_legacy' ), 10, 2 );

        // === COLUMN STYLES ===
        add_action( 'admin_head', array( $this, 'column_styles' ) );
        add_action( 'admin_footer', array( $this, 'checkbox_click_fix' ) );
    }

    // =========================================================================
    // CUSTOM COLUMNS
    // =========================================================================

    public function add_custom_columns( $columns ) {
        $new_columns = array();
        foreach ( $columns as $key => $label ) {
            $new_columns[ $key ] = $label;
            if ( $key === 'order_status' ) {
                $new_columns['cc_voucher']  = 'CC Voucher';
                $new_columns['cc_type']     = 'Τύπος';
                $new_columns['cc_status']   = 'CC Status';
            }
        }
        if ( ! isset( $new_columns['cc_voucher'] ) ) {
            $new_columns['cc_voucher'] = 'CC Voucher';
            $new_columns['cc_type']    = 'Τύπος';
            $new_columns['cc_status']  = 'CC Status';
        }
        return $new_columns;
    }

    public function render_custom_columns( $column_name, $order ) {
        if ( is_numeric( $order ) ) {
            $order = wc_get_order( $order );
        }
        if ( ! $order ) { echo '—'; return; }
        $this->render_column_content( $column_name, $order );
    }

    public function render_custom_columns_legacy( $column_name, $post_id ) {
        $order = wc_get_order( $post_id );
        if ( ! $order ) { echo '—'; return; }
        $this->render_column_content( $column_name, $order );
    }

    private function render_column_content( $column_name, $order ) {
        if ( $column_name === 'cc_voucher' ) {
            $voucher   = $order->get_meta( '_cc_voucher_number' );
            $is_voided = $order->get_meta( '_cc_voided' ) === '1';

            if ( empty( $voucher ) ) {
                echo '<span style="color: #999;">—</span>';
            } elseif ( $is_voided ) {
                echo '<span style="color: #b32d2e; text-decoration: line-through;" title="Ακυρωμένη">' . esc_html( $voucher ) . '</span>';
            } else {
                echo '<span style="color: #2271b1; font-weight: 500;">' . esc_html( $voucher ) . '</span>';
            }
        }

        if ( $column_name === 'cc_type' ) {
            $voucher   = $order->get_meta( '_cc_voucher_number' );
            $is_voided = $order->get_meta( '_cc_voided' ) === '1';
            $is_boxnow = $order->get_meta( '_cc_boxnow' ) === '1';

            if ( empty( $voucher ) || $is_voided ) {
                echo '<span style="color:#999;">—</span>';
            } elseif ( $is_boxnow ) {
                echo '<span class="cc-col-badge cc-col-boxnow">📦 BOX NOW</span>';
            } else {
                echo '<span class="cc-col-badge cc-col-normal">🚚 Κανονική</span>';
            }
        }

        if ( $column_name === 'cc_status' ) {
            $voucher     = $order->get_meta( '_cc_voucher_number' );
            $is_voided   = $order->get_meta( '_cc_voided' ) === '1';
            $status_desc = $order->get_meta( '_cc_shipment_status_desc' );
            $status_code = $order->get_meta( '_cc_shipment_status' );

            if ( empty( $voucher ) ) {
                echo '<span style="color: #999;">—</span>';
            } elseif ( $is_voided ) {
                echo '<span class="cc-col-badge cc-col-cancelled">Ακυρωμένη</span>';
            } elseif ( ! empty( $status_desc ) && $status_desc !== 'None' ) {
                $badge_class = 'cc-col-active';
                if ( in_array( $status_code, array( '29', '87' ), true ) ) {
                    $badge_class = 'cc-col-delivered';
                } elseif ( in_array( $status_code, array( '25', '99', '14', '95' ), true ) ) {
                    $badge_class = 'cc-col-cancelled';
                } elseif ( in_array( $status_code, array( '28', '30' ), true ) ) {
                    $badge_class = 'cc-col-failed';
                }
                echo '<span class="cc-col-badge ' . esc_attr( $badge_class ) . '" title="Code: ' . esc_attr( $status_code ) . '">';
                echo esc_html( $this->shorten_status( $status_desc ) );
                echo '</span>';
            } else {
                echo '<span class="cc-col-badge cc-col-new">Νέα</span>';
            }
        }
    }

    private function shorten_status( $desc ) {
        $map = array(
            'ShipmentCreated'               => 'Δημιουργήθηκε',
            'ShipmentPickedUp'              => 'Παραλήφθηκε',
            'ShipmentInTransit'             => 'Σε μεταφορά',
            'ShipmentArriveAtFinalStation'   => 'Στον σταθμό',
            'ShipmentOutForDelivery'        => 'Σε διανομή',
            'ShipmentDelivered'             => 'Παραδόθηκε',
            'ShipmentDeliveryFailed'        => 'Αποτυχία',
            'ShipmentReturnedToSender'      => 'Επιστράφηκε',
            'ShipmentCancelled'             => 'Ακυρωμένη',
        );
        return $map[ $desc ] ?? $desc;
    }

    public function column_styles() {
        $screen = get_current_screen();
        if ( ! $screen ) { return; }
        if ( strpos( $screen->id, 'wc-orders' ) === false && $screen->post_type !== 'shop_order' ) { return; }

        echo '<style>
            .column-cc_voucher { width: 130px; }
            .column-cc_type   { width: 110px; }
            .column-cc_status { width: 120px; }
            .cc-col-badge {
                display: inline-block;
                padding: 3px 8px;
                border-radius: 3px;
                font-size: 11px;
                font-weight: 500;
                line-height: 1.4;
                white-space: nowrap;
            }
            .cc-col-new { background: #f0f6fc; color: #2271b1; }
            .cc-col-active { background: #e7f0ff; color: #1d4ed8; }
            .cc-col-delivered { background: #e7f5e9; color: #1e6823; }
            .cc-col-failed { background: #fff3cd; color: #856404; }
            .cc-col-cancelled { background: #fce8e6; color: #8b0000; }
            .cc-col-boxnow    { background: #fff3e0; color: #e65100; }
            .cc-col-normal    { background: #f1f1f1; color: #555; }
        </style>';
    }

    /**
     * Από WordPress 7 το κελί του checkbox είναι <td>, οπότε το row-click του
     * WooCommerce (wc-orders.js) ανοίγει την παραγγελία όταν πατηθεί το checkbox.
     * Η κλάση no-link είναι η εξαίρεση που ήδη αναγνωρίζει το WooCommerce.
     */
    public function checkbox_click_fix() {
        $screen = get_current_screen();
        if ( ! $screen ) { return; }
        if ( strpos( $screen->id, 'wc-orders' ) === false && $screen->post_type !== 'shop_order' ) { return; }

        echo '<script>jQuery( function( $ ) { $( ".wp-list-table tbody td.check-column" ).addClass( "no-link" ); } );</script>';
    }

    // =========================================================================
    // BULK ACTIONS
    // =========================================================================

    public function register_bulk_actions( $actions ) {
        $actions['cc_create_vouchers']  = '🚚 CC — Δημιουργία Vouchers (Επόμενη Μέρα)';
        if ( CC_Pickup_Points::has_sub_points() ) {
            foreach ( CC_Pickup_Points::get_points() as $point ) {
                $actions[ self::CREATE_FROM_POINT_PREFIX . $point['code'] ] =
                    '🚚 CC — Vouchers από: ' . esc_html( CC_Pickup_Points::display_label( $point ) );
            }
        }
        $actions['cc_update_statuses']  = '🔄 CC — Ενημέρωση Status';
        $actions['cc_mass_print']       = '🖨️ CC — Μαζική Εκτύπωση Vouchers';
        $actions['cc_mass_print_boxnow'] = '🟡 CC — Μαζική Εκτύπωση BOX NOW';
        return $actions;
    }

    public function handle_bulk_action( $redirect_to, $action, $order_ids ) {
        if ( 0 === strpos( (string) $action, self::CREATE_FROM_POINT_PREFIX ) ) {
            $code = substr( $action, strlen( self::CREATE_FROM_POINT_PREFIX ) );
            if ( ! CC_Pickup_Points::get_point( $code ) ) {
                // Οι ρυθμίσεις άλλαξαν μετά τη φόρτωση της λίστας
                return $this->redirect_with_result( $redirect_to, array(
                    'type'    => 'create',
                    'success' => 0,
                    'failed'  => count( $order_ids ),
                    'skipped' => 0,
                    'errors'  => array( sprintf( 'Το σημείο αποστολής %s δεν υπάρχει πια στις ρυθμίσεις — ανανέωσε τη σελίδα και ξαναδοκίμασε.', $code ) ),
                    'total'   => count( $order_ids ),
                ) );
            }
            return $this->bulk_create_vouchers( $redirect_to, $order_ids, $code );
        }
        if ( $action === 'cc_create_vouchers' ) {
            return $this->bulk_create_vouchers( $redirect_to, $order_ids );
        }
        if ( $action === 'cc_update_statuses' ) {
            return $this->bulk_update_statuses( $redirect_to, $order_ids );
        }
        if ( $action === 'cc_mass_print' ) {
            return $this->bulk_mass_print( $redirect_to, $order_ids );
        }
        if ( $action === 'cc_mass_print_boxnow' ) {
            return $this->bulk_mass_print_boxnow( $redirect_to, $order_ids );
        }
        return $redirect_to;
    }

    // =========================================================================
    // MASS PRINT
    // =========================================================================

    /**
     * Bulk mass print - store AWBs in transient and redirect to print handler
     */
    private function bulk_mass_print( $redirect_to, $order_ids ) {
        if ( empty( $order_ids ) ) {
            return $redirect_to;
        }

        $awbs        = array();
        $boxnow_awbs = array();
        $skipped     = 0;

        foreach ( $order_ids as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) { continue; }

            $awb        = $order->get_meta( '_cc_voucher_number' );
            $return_awb = $order->get_meta( '_cc_return_awb' );
            $is_voided  = $order->get_meta( '_cc_voided' ) === '1';
            $is_boxnow  = $order->get_meta( '_cc_boxnow' ) === '1';

            if ( empty( $awb ) || $is_voided ) {
                $skipped++;
                continue;
            }

            if ( $is_boxnow ) {
                $boxnow_awbs[] = $awb;
                if ( ! empty( $return_awb ) ) {
                    $boxnow_awbs[] = $return_awb;
                }
            } else {
                $awbs[] = $awb;
                if ( ! empty( $return_awb ) ) {
                    $awbs[] = $return_awb;
                }
            }
        }

        if ( empty( $awbs ) && empty( $boxnow_awbs ) ) {
            return $this->redirect_with_result( $redirect_to, array(
                'type' => 'print', 'success' => 0, 'failed' => 0,
                'skipped' => $skipped, 'errors' => array( 'Δεν βρέθηκαν ενεργά vouchers' ),
                'total' => count( $order_ids ),
            ) );
        }

        // Κανονικά και BOX NOW έχουν διαφορετικό template εκτύπωσης, οπότε κάθε
        // ομάδα βγαίνει σε δικό της PDF (το BOX NOW όπως η ενέργεια cc_mass_print_boxnow).
        // Με δύο ομάδες μοιράζεται το όριο του cc_pd ώστε το URL του notice να μη μεγαλώνει.
        $is_mixed    = ! empty( $awbs ) && ! empty( $boxnow_awbs );
        $max_encoded = $is_mixed ? 3000 : 6000;
        $print_links = array();

        if ( ! empty( $awbs ) ) {
            // Store AWBs in transient (fallback για μεγάλα batches / sites χωρίς cache lag)
            $print_key  = 'cc_mass_print_' . get_current_user_id() . '_' . time();
            $print_data = array(
                'awbs'        => $awbs,
                'boxnow_awbs' => array(),
            );
            set_transient( $print_key, $print_data, 300 ); // 5 minutes expiry

            // Τα δεδομένα περνάνε ΚΑΙ κωδικοποιημένα μέσα στο URL (base64) ώστε να
            // δουλεύει ακόμα κι αν persistent object cache (SiteGround Optimizer κ.λπ.)
            // καθυστερήσει να κάνει replicate το transient στο νέο request/tab.
            $print_links[] = array(
                'url'    => $this->build_print_url( 'cc_mass_print_vouchers', $print_key, $print_data, $max_encoded ),
                'count'  => count( $awbs ),
                'boxnow' => false,
            );
        }

        if ( ! empty( $boxnow_awbs ) ) {
            $print_key  = 'cc_mass_print_boxnow_' . get_current_user_id() . '_' . time();
            $print_data = array(
                'awbs'        => $boxnow_awbs,
                'boxnow_awbs' => array(),
                'template'    => get_option( 'cc_wc_print_template_boxnow', 'singlepdf_100x150_4up' ),
            );
            set_transient( $print_key, $print_data, 300 );

            $print_links[] = array(
                'url'    => $this->build_print_url( 'cc_mass_print_boxnow_vouchers', $print_key, $print_data, $max_encoded ),
                'count'  => count( $boxnow_awbs ),
                'boxnow' => true,
            );
        }

        // Store the print URL so we can show it in the notice
        $result = array(
            'type'      => 'print',
            'success'   => count( $awbs ) + count( $boxnow_awbs ),
            'failed'    => 0,
            'skipped'   => $skipped,
            'errors'    => array(),
            'total'     => count( $order_ids ),
            'print_url' => $print_links[0]['url'],
        );
        if ( $is_mixed ) {
            $result['print_links'] = $print_links;
        }

        return $this->redirect_with_result( $redirect_to, $result );
    }

    /**
     * BOX NOW mass print - εκτυπώνει μόνο BOX NOW vouchers με template singlepdf_100x150
     */
    private function bulk_mass_print_boxnow( $redirect_to, $order_ids ) {
        if ( empty( $order_ids ) ) {
            return $redirect_to;
        }

        $awbs    = array();
        $skipped = 0;

        foreach ( $order_ids as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) { continue; }

            $awb        = $order->get_meta( '_cc_voucher_number' );
            $is_voided  = $order->get_meta( '_cc_voided' ) === '1';
            $is_boxnow  = $order->get_meta( '_cc_boxnow' ) === '1';

            if ( empty( $awb ) || $is_voided || ! $is_boxnow ) {
                $skipped++;
                continue;
            }

            $awbs[] = $awb;
        }

        if ( empty( $awbs ) ) {
            return $this->redirect_with_result( $redirect_to, array(
                'type'    => 'print',
                'success' => 0,
                'failed'  => 0,
                'skipped' => $skipped,
                'errors'  => array( 'Καμία από τις επιλεγμένες παραγγελίες δεν είναι BOX NOW' ),
                'total'   => count( $order_ids ),
            ) );
        }

        $print_key  = 'cc_mass_print_boxnow_' . get_current_user_id() . '_' . time();
        $print_data = array(
            'awbs'        => $awbs,
            'boxnow_awbs' => array(),
            'template'    => get_option( 'cc_wc_print_template_boxnow', 'singlepdf_100x150_4up' ),
        );
        set_transient( $print_key, $print_data, 300 );

        $print_url = $this->build_print_url( 'cc_mass_print_boxnow_vouchers', $print_key, $print_data );

        return $this->redirect_with_result( $redirect_to, array(
            'type'      => 'print',
            'success'   => count( $awbs ),
            'failed'    => 0,
            'skipped'   => $skipped,
            'errors'    => array(),
            'total'     => count( $order_ids ),
            'print_url' => $print_url,
        ) );
    }

    /**
     * Handle mass print - fetch combined PDF from API, scale it down, serve directly
     */
    public function handle_mass_print() {
        if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( $_GET['_wpnonce'], 'cc_mass_print' ) ) {
            wp_die( 'Invalid request' );
        }

        if ( ! current_user_can( 'edit_shop_orders' ) ) {
            wp_die( 'Unauthorized' );
        }

        $print_key = isset( $_GET['print_key'] ) ? sanitize_text_field( $_GET['print_key'] ) : '';
        $data      = get_transient( $print_key );

        // Fallback: αν το transient δεν είναι ορατό ακόμα λόγω persistent object cache lag
        // (π.χ. SiteGround Optimizer), διάβασε τα δεδομένα από το URL — ίδιος μηχανισμός
        // με το cc_bulk_r στο result notice.
        if ( ! $data && isset( $_GET['cc_pd'] ) ) {
            $data = $this->decode_bulk_result( wp_unslash( $_GET['cc_pd'] ) );
        }

        if ( ! $data ) {
            wp_die( 'Τα δεδομένα εκτύπωσης έληξαν. Δοκιμάστε ξανά.' );
        }

        delete_transient( $print_key );

        $awbs        = $data['awbs'] ?? array();
        $boxnow_awbs = $data['boxnow_awbs'] ?? array();

        // Κάθε PDF έχει μία ομάδα: regular AWBs, ή (αν λείπουν) BOX NOW με το δικό τους template
        $is_boxnow_batch = empty( $awbs ) && ! empty( $boxnow_awbs );
        $print_awbs      = $is_boxnow_batch ? $boxnow_awbs : $awbs;
        $template = $data['template'] ?? (
            $is_boxnow_batch
                ? get_option( 'cc_wc_print_template_boxnow', 'singlepdf_100x150_4up' )
                : get_option( 'cc_wc_print_template', 'pdf' )
        );

        if ( empty( $print_awbs ) ) {
            wp_die( 'Δεν βρέθηκαν vouchers' );
        }

        // singlepdf_100x150_4up είναι custom — στέλνουμε singlepdf_100x150 στο API
        // αλλά μετά κάνουμε arrange_4up() με FPDI
        $raw_template = $template;
        $use_4up      = ( $raw_template === 'singlepdf_100x150_4up' );
        $api_template = $use_4up ? 'singlepdf_100x150' : $raw_template;

        $api = new CC_API();
        $pdf = $api->get_voucher_pdf( $print_awbs, $api_template );

        if ( is_wp_error( $pdf ) ) {
            wp_die( 'Σφάλμα λήψης vouchers: ' . esc_html( $pdf->get_error_message() ) );
        }

        // Αν είναι 4up layout, κάνε arrange με FPDI
        if ( $use_4up ) {
            $arranged = CC_PDF_Scaler::arrange_4up( $pdf );
            if ( ! is_wp_error( $arranged ) ) {
                $pdf = $arranged;
            }
        }

        // Scale για κανονικά (pdf / clean)
        if ( in_array( $api_template, array( 'pdf', 'clean' ), true ) ) {
            $scaled = CC_PDF_Scaler::scale_pdf( $pdf, 0.95 );
            if ( ! is_wp_error( $scaled ) ) {
                $pdf = $scaled;
            }
        }

        $scaled_pdf = $pdf;

        // Σερβίρισε το scaled PDF απευθείας στον browser
        nocache_headers();
        header( 'Content-Type: application/pdf' );
        header( 'Content-Disposition: inline; filename="vouchers-' . date( 'Y-m-d-His' ) . '.pdf"' );
        header( 'Content-Length: ' . strlen( $scaled_pdf ) );
        echo $scaled_pdf;
        exit;
    }
    // =========================================================================
    // BULK CREATE VOUCHERS
    // =========================================================================

    private function bulk_create_vouchers( $redirect_to, $order_ids, $point_code = null ) {
        if ( empty( $order_ids ) ) { return $redirect_to; }
        if ( null === $point_code ) {
            $point_code = CC_Pickup_Points::get_default_code();
        }

        // Επέκταση χρόνου εκτέλεσης για μαζικές δημιουργίες (αποφυγή 504)
        @set_time_limit( 300 );
        ignore_user_abort( true );

        $success = 0; $failed = 0; $skipped = 0; $errors = array();
        $api = new CC_API();
        $locked_id = 0;

        foreach ( $order_ids as $order_id ) {
            // Ξεκλείδωμα της προηγούμενης παραγγελίας (κάθε διαδρομή του βρόχου καταλήγει εδώ ή μετά τον βρόχο)
            if ( $locked_id ) {
                CC_Shipment_Builder::release_voucher_lock( $locked_id );
                $locked_id = 0;
            }

            $order = wc_get_order( $order_id );
            if ( ! $order ) { $failed++; $errors[] = "#$order_id: Δεν βρέθηκε"; continue; }

            // Κλείδωμα ώστε ταυτόχρονη δημιουργία (κουμπί / αυτόματη) να μη φτιάξει δεύτερο AWB
            if ( ! CC_Shipment_Builder::acquire_voucher_lock( $order_id ) ) {
                $skipped++;
                $errors[] = "#$order_id: Δημιουργείται ήδη voucher (ταυτόχρονη ενέργεια)";
                continue;
            }
            $locked_id = (int) $order_id;
            $order->read_meta_data( true );

            $existing  = $order->get_meta( '_cc_voucher_number' );
            $is_voided = $order->get_meta( '_cc_voided' ) === '1';
            if ( $existing && ! $is_voided ) { $skipped++; continue; }

            // Μόνο για μεθόδους αποστολής που διαχειρίζεται το plugin
            if ( ! CC_Shipment_Builder::is_handled_order( $order ) ) {
                $skipped++;
                $errors[] = "#$order_id: Μη διαχειρίσιμη μέθοδος αποστολής";
                continue;
            }

            $builder = new CC_Shipment_Builder( $order );
            $check = $builder->use_pickup_point( $point_code );
            if ( is_wp_error( $check ) ) { $failed++; $errors[] = "#$order_id: " . $check->get_error_message(); continue; }
            $check = $builder->validate_settings();
            if ( is_wp_error( $check ) ) { $failed++; $errors[] = "#$order_id: " . $check->get_error_message(); continue; }
            $check = $builder->validate_order();
            if ( is_wp_error( $check ) ) { $failed++; $errors[] = "#$order_id: " . $check->get_error_message(); continue; }

            $is_boxnow_order = ! empty( $order->get_meta( '_boxnow_locker_id' ) )
                               || $order->get_meta( '_boxnow_delivery_mode' ) === 'auto';
            $payload = $builder->build_payload( 'next_day', $is_boxnow_order );
            $result  = $api->create_shipment( $payload );

            if ( is_wp_error( $result ) ) {
                $failed++; $errors[] = "#$order_id: " . $result->get_error_message();
                $order->add_order_note( '❌ Bulk: ' . $result->get_error_message() );
                continue;
            }

            $voucher_number  = $result['ShipmentNumber'] ?? '';
            $tracking_number = isset( $result['TrackingNumbers'][0] ) ? $result['TrackingNumbers'][0] : $voucher_number;
            if ( empty( $voucher_number ) ) { $failed++; $errors[] = "#$order_id: Δεν επιστράφηκε AWB"; continue; }

            if ( $is_voided ) {
                $order->delete_meta_data( '_cc_voided' );
                $order->delete_meta_data( '_cc_voided_at' );
                $order->delete_meta_data( '_cc_shipment_status' );
                $order->delete_meta_data( '_cc_shipment_status_desc' );
                $order->delete_meta_data( '_cc_shipment_action_code' );
                $order->delete_meta_data( '_cc_status_updated_at' );

                // Υπολείμματα του ακυρωμένου voucher — αλλιώς εμφανίζονται ως δεδομένα του νέου
                $order->delete_meta_data( '_cc_return_awb' );
                $order->delete_meta_data( '_cc_boxnow_fallback' );
                $order->delete_meta_data( '_cc_boxnow_assigned_locker' );
                $order->delete_meta_data( '_cc_boxnow_outbound' );
            }

            $builder->save_pickup_point_meta();
            $order->update_meta_data( '_cc_voucher_number', $voucher_number );
            $order->update_meta_data( '_cc_tracking_number', $tracking_number );
            $order->update_meta_data( '_cc_service_type', 'next_day' );
            $order->update_meta_data( '_cc_boxnow', $is_boxnow_order ? '1' : '0' );
            $order->update_meta_data( '_cc_created_at', current_time( 'mysql' ) );

            // BOX NOW Parcel ID — επιστρέφεται μόνο σε αποστολές BOX NOW
            if ( ! empty( $result['OutboundShipmentNumber'] ) ) {
                $order->update_meta_data( '_cc_boxnow_outbound', sanitize_text_field( $result['OutboundShipmentNumber'] ) );
            }

            $order->save();

            $order->add_order_note( '✅ CC voucher (Bulk): ' . $voucher_number . ' | Επόμενη Μέρα' . $builder->pickup_point_note() );
            $success++;
            usleep( 100000 ); // 100ms αντί 300ms για αποφυγή timeout
        }

        if ( $locked_id ) {
            CC_Shipment_Builder::release_voucher_lock( $locked_id );
        }

        return $this->redirect_with_result( $redirect_to, array(
            'type' => 'create', 'success' => $success, 'failed' => $failed,
            'skipped' => $skipped, 'errors' => $errors, 'total' => count( $order_ids ),
        ) );
    }

    // =========================================================================
    // BULK UPDATE STATUSES
    // =========================================================================

    private function bulk_update_statuses( $redirect_to, $order_ids ) {
        if ( empty( $order_ids ) ) { return $redirect_to; }

        @set_time_limit( 300 );
        ignore_user_abort( true );

        $updated = 0; $skipped = 0; $failed = 0; $errors = array();
        $api = new CC_API();

        foreach ( $order_ids as $order_id ) {
            $order = wc_get_order( $order_id );
            if ( ! $order ) { $failed++; continue; }

            $awb       = $order->get_meta( '_cc_voucher_number' );
            $is_voided = $order->get_meta( '_cc_voided' ) === '1';
            if ( empty( $awb ) || $is_voided ) { $skipped++; continue; }

            // Έλεγχος rate limit
            $rate_check = CC_Status_Tracker::check_rate_limit( $order );
            if ( ! $rate_check['allowed'] ) {
                $skipped++;
                $errors[] = sprintf(
                    '#%d (%s): Ενημερώθηκε %s, διαθέσιμο σε %d λεπτά',
                    $order_id,
                    $awb,
                    $rate_check['last_updated_human'],
                    $rate_check['minutes_remaining']
                );
                continue;
            }

            $result = $api->get_shipment_details( $awb );
            if ( is_wp_error( $result ) ) { $failed++; $errors[] = "#$order_id ($awb): " . $result->get_error_message(); continue; }

            $status_code = ''; $status_desc = ''; $action_code = '';
            $info = CC_API::pick_shipment_info( $result, $awb );
            if ( null !== $info ) {
                $status_code = (string) ( $info['ShipmentStatus'] ?? '' );
                $status_desc = $info['ShipmentStatusDesc'] ?? '';
                $action_code = $info['CollectionStatus'] ?? '';
            }
            if ( empty( $status_code ) && empty( $status_desc ) ) { $failed++; $errors[] = "#$order_id ($awb): Δεν βρέθηκε status"; continue; }

            CC_Status_Tracker::apply_status( $order, $status_code, $status_desc, $action_code, 'bulk' );

            CC_Status_Tracker::mark_check_now( $order );

            $updated++;
            usleep( 500000 );
        }

        return $this->redirect_with_result( $redirect_to, array(
            'type' => 'status', 'success' => $updated, 'failed' => $failed,
            'skipped' => $skipped, 'errors' => $errors, 'total' => count( $order_ids ),
        ) );
    }

    // =========================================================================
    // RESULT PASSING (URL-encoded — ανεξάρτητο από object cache / transients)
    // =========================================================================

    /**
     * Φτιάχνει το URL για τον print handler, περνώντας τα AWBs ΚΑΙ κωδικοποιημένα
     * μέσα στο URL (base64 url-safe) — ώστε να δουλεύει ακόμα κι αν persistent
     * object cache καθυστερήσει να κάνει replicate το transient στο νέο request/tab.
     * Για πολύ μεγάλα batches (encoded > 6000 chars) παραλείπει το cc_pd και
     * βασίζεται μόνο στο transient (αποφυγή 414 Request-URI Too Large).
     * Όταν το notice έχει δύο links, ο caller περνά μικρότερο $max_encoded.
     */
    private function build_print_url( $action, $print_key, array $print_data, $max_encoded = 6000 ) {
        $args = array(
            'action'    => $action,
            'print_key' => $print_key,
        );

        $encoded = $this->encode_bulk_result( $print_data );
        if ( $encoded && strlen( $encoded ) < $max_encoded ) {
            $args['cc_pd'] = $encoded;
        }

        return wp_nonce_url( add_query_arg( $args, admin_url( 'admin-post.php' ) ), 'cc_mass_print' );
    }

    /**
     * Αποθηκεύει τα αποτελέσματα ενός bulk action και επιστρέφει το redirect URL.
     *
     * Σε sites με persistent object cache (π.χ. SiteGround Optimizer + Memcached/Redis,
     * "Dynamic Caching") το set_transient() μπορεί να μην είναι ορατό ακόμα στο request
     * που ακολουθεί το redirect — με αποτέλεσμα το notice να μην εμφανίζεται ΚΑΘΟΛΟΥ.
     *
     * Για να είμαστε ανεξάρτητοι από αυτό, κωδικοποιούμε τα αποτελέσματα απευθείας
     * μέσα στο URL του redirect (base64 url-safe). Κρατάμε ΚΑΙ το transient ως
     * fallback (π.χ. αν κάποιο plugin/proxy αφαιρέσει το query param).
     */
    private function redirect_with_result( $redirect_to, array $result_data ) {
        set_transient( 'cc_bulk_result_' . get_current_user_id(), $result_data, 60 );

        return add_query_arg(
            array(
                'cc_bulk_done' => '1',
                'cc_bulk_r'    => $this->encode_bulk_result( $result_data ),
            ),
            $redirect_to
        );
    }

    /**
     * Κωδικοποιεί ένα array αποτελεσμάτων σε url-safe base64 string.
     * Περιορίζει τα errors σε 15 ώστε να μη "φουσκώνει" υπερβολικά το URL.
     */
    private function encode_bulk_result( array $data ) {
        if ( ! empty( $data['errors'] ) && is_array( $data['errors'] ) && count( $data['errors'] ) > 15 ) {
            $total_errors     = count( $data['errors'] );
            $data['errors']   = array_slice( $data['errors'], 0, 15 );
            $data['errors'][] = sprintf( '… και %d ακόμα σφάλματα', $total_errors - 15 );
        }

        $json = wp_json_encode( $data );
        if ( false === $json ) { return ''; }

        return strtr( base64_encode( $json ), '+/', '-_' );
    }

    /**
     * Αποκωδικοποιεί το string που παράχθηκε από encode_bulk_result().
     */
    private function decode_bulk_result( $encoded ) {
        $b64  = strtr( (string) $encoded, '-_', '+/' );
        $json = base64_decode( $b64, true );
        if ( false === $json ) { return null; }

        $data = json_decode( $json, true );
        return is_array( $data ) ? $data : null;
    }

    // =========================================================================
    // RESULTS NOTICE
    // =========================================================================

    public function show_bulk_result_notice() {
        if ( ! isset( $_GET['cc_bulk_done'] ) ) { return; }

        $result = null;

        // Πρωτεύουσα πηγή: δεδομένα κωδικοποιημένα μέσα στο ίδιο το URL —
        // λειτουργεί πάντα, ανεξάρτητα από caching/object cache του site.
        if ( isset( $_GET['cc_bulk_r'] ) ) {
            $result = $this->decode_bulk_result( wp_unslash( $_GET['cc_bulk_r'] ) );
        }

        // Fallback: transient (καλύπτει edge cases όπου το query param αφαιρέθηκε)
        if ( ! $result ) {
            $result = get_transient( 'cc_bulk_result_' . get_current_user_id() );
        }

        if ( ! $result ) { return; }
        delete_transient( 'cc_bulk_result_' . get_current_user_id() );

        $type    = $result['type']    ?? 'create';
        $success = $result['success'] ?? 0;
        $failed  = $result['failed']  ?? 0;
        $skipped = $result['skipped'] ?? 0;
        $errors  = $result['errors']  ?? array();
        $total   = $result['total']   ?? 0;

        // Special handling for print action - show link to open PDF
        if ( $type === 'print' && ! empty( $result['print_url'] ) ) {
            // Ανάμικτη επιλογή: ένα PDF για τα κανονικά και ένα για τα BOX NOW
            $links = ( ! empty( $result['print_links'] ) && is_array( $result['print_links'] ) )
                ? $result['print_links']
                : array( array( 'url' => $result['print_url'] ) );
            $is_split = count( $links ) > 1;

            echo '<div class="notice notice-info is-dismissible">';
            echo '<p><strong>🖨️ Courier Center — Μαζική Εκτύπωση</strong></p>';
            echo '<p>' . esc_html( $success ) . ' vouchers έτοιμα για εκτύπωση.';
            if ( $is_split ) {
                $regular_count = 0;
                $boxnow_count  = 0;
                foreach ( $links as $link ) {
                    if ( ! empty( $link['boxnow'] ) ) {
                        $boxnow_count += (int) ( $link['count'] ?? 0 );
                    } else {
                        $regular_count += (int) ( $link['count'] ?? 0 );
                    }
                }
                echo ' (' . esc_html( $regular_count ) . ' κανονικά, ' . esc_html( $boxnow_count ) . ' BOX NOW — σε ξεχωριστά PDF)';
            }
            if ( $skipped > 0 ) {
                echo ' (' . esc_html( $skipped ) . ' παραλείφθηκαν — χωρίς ενεργό voucher)';
            }
            echo '</p>';
            echo '<p>';
            foreach ( $links as $link ) {
                if ( ! $is_split ) {
                    $label = '📄 Άνοιγμα PDF για εκτύπωση';
                } elseif ( ! empty( $link['boxnow'] ) ) {
                    $label = '🟡 Άνοιγμα PDF BOX NOW (' . (int) ( $link['count'] ?? 0 ) . ')';
                } else {
                    $label = '📄 Άνοιγμα PDF κανονικών (' . (int) ( $link['count'] ?? 0 ) . ')';
                }
                echo '<a href="' . esc_url( $link['url'] ) . '" target="_blank" class="button button-primary">' . esc_html( $label ) . '</a> ';
            }
            echo '</p>';
            echo '</div>';

            // Auto-open in new tab via JS — decode HTML entities (&amp; → &) so the URL is valid inside a JS string
            foreach ( $links as $link ) {
                $js_url = html_entity_decode( $link['url'], ENT_QUOTES, 'UTF-8' );
                echo '<script>window.open(' . wp_json_encode( $js_url ) . ', "_blank");</script>';
            }
            return;
        }

        $notice_type = 'success';
        if ( $failed > 0 && $success === 0 ) { $notice_type = 'error'; }
        elseif ( $failed > 0 ) { $notice_type = 'warning'; }

        $titles = array(
            'create' => '🚚 Courier Center — Bulk Voucher Creation',
            'status' => '🔄 Courier Center — Bulk Status Update',
            'print'  => '🖨️ Courier Center — Μαζική Εκτύπωση',
        );
        $title = $titles[ $type ] ?? $titles['create'];

        $success_labels = array( 'create' => 'Δημιουργήθηκαν', 'status' => 'Ενημερώθηκαν', 'print' => 'Εκτυπώθηκαν' );
        $skip_labels    = array( 'create' => 'Ήδη έχουν voucher', 'status' => 'Χωρίς voucher', 'print' => 'Χωρίς voucher' );

        echo '<div class="notice notice-' . esc_attr( $notice_type ) . ' is-dismissible">';
        echo '<p><strong>' . esc_html( $title ) . '</strong></p>';
        echo '<p>Σύνολο: ' . esc_html( $total ) . ' | ✅ ' . esc_html( $success_labels[ $type ] ?? 'OK' ) . ': ' . esc_html( $success );
        if ( $skipped > 0 ) { echo ' | ⏭️ ' . esc_html( $skip_labels[ $type ] ?? 'Παράλειψη' ) . ': ' . esc_html( $skipped ); }
        if ( $failed > 0 ) { echo ' | ❌ Απέτυχαν: ' . esc_html( $failed ); }
        echo '</p>';

        if ( ! empty( $errors ) ) {
            echo '<details style="margin-top: 5px;"><summary style="cursor: pointer; color: #b32d2e;">Λεπτομέρειες σφαλμάτων</summary><ul style="margin-top: 5px;">';
            foreach ( $errors as $error ) { echo '<li>' . esc_html( $error ) . '</li>'; }
            echo '</ul></details>';
        }
        echo '</div>';
    }
}