<?php

/**
 * Plugin Name:          GR Commerce Suite
 * Description:          Greek courier vouchers (ACS, BOX NOW, Geniki Taxydromiki), COD reconciliation and Skroutz/BestPrice XML feeds for WooCommerce.
 * Version:              1.0.1
 * Requires at least:    6.2
 * Requires PHP:         8.2
 * Requires Plugins:     woocommerce
 * WC requires at least: 8.0
 * WC tested up to:      10.3
 * Author:               GR Commerce Suite
 * License:              GPL-2.0-or-later
 * License URI:          https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:          gr-commerce-suite
 * Domain Path:          /languages
 *
 * Bootstrap contract (SPEC.md §5):
 *  - This file MUST stay parseable by PHP 7.4 so that a host that downgraded PHP after activation
 *    gets an admin notice instead of a fatal error. No PHP 8.x syntax is allowed in this file.
 *  - Everything runs inside a single IIFE: no global variables and no named functions are declared,
 *    so two copies of the plugin can never trigger "Cannot redeclare" fatals.
 *  - No translation function is called before `init` (WP 6.7+ just-in-time textdomain rules):
 *    notice messages are passed as callables and resolved at render time.
 *
 * @package GRCommerceSuite
 */

declare(strict_types=1);

namespace GRCommerceSuite;

use Automattic\WooCommerce\Utilities\FeaturesUtil;
use GRCommerceSuite\Database\Schema;

defined('ABSPATH') || exit;

(static function (): void {
    /**
     * Queue an admin error notice. The message is a callable so translation happens at render time.
     *
     * @param callable():string $message
     */
    $admin_notice = static function (callable $message): void {
        add_action(
            'admin_notices',
            static function () use ($message): void {
                if (!current_user_can('activate_plugins')) {
                    return;
                }
                printf(
                    '<div class="notice notice-error"><p><strong>%1$s</strong> %2$s</p></div>',
                    esc_html__('GR Commerce Suite:', 'gr-commerce-suite'),
                    esc_html(class_exists('GRCommerceSuite\\I18n\\AdminLocale')
                        ? \GRCommerceSuite\I18n\AdminLocale::display((string) $message())
                        : (string) $message())
                );
            }
        );
    };

    // 0. Duplicate-copy guard (e.g. "gr-commerce-suite" and "gr-commerce-suite-old" both active).
    if (defined('GRCS_VERSION')) {
        $admin_notice(static function (): string {
            return __(
                'another copy of the plugin is already active. Deactivate the duplicate copy.',
                'gr-commerce-suite'
            );
        });
        return;
    }

    define('GRCS_VERSION', '1.0.1');
    define('GRCS_PLUGIN_FILE', __FILE__);
    define('GRCS_PLUGIN_DIR', plugin_dir_path(__FILE__));
    define('GRCS_PLUGIN_URL', plugin_dir_url(__FILE__));
    define('GRCS_PLUGIN_BASENAME', plugin_basename(__FILE__));
    define('GRCS_MIN_PHP', '8.2.0');
    define('GRCS_MIN_WC', '8.0');
    define('GRCS_AS_GROUP', 'gr-commerce-suite');
    define('GRCS_JOB_CHUNK_SIZE', 100);

    // Translations (commercial plugin: not served by translate.wordpress.org). Must run on `init` or later.
    add_action(
        'init',
        static function (): void {
            load_plugin_textdomain('gr-commerce-suite', false, dirname(GRCS_PLUGIN_BASENAME) . '/languages');
            $locale = determine_locale();
            if (in_array($locale, ['el', 'en_US'], true)) {
                load_textdomain('gr-commerce-suite', GRCS_PLUGIN_DIR . 'languages/gr-commerce-suite-' . $locale . '.mo');
            }
        }
    );

    // 1. PHP version gate. Nothing below this line may be loaded on an unsupported runtime.
    if (version_compare(PHP_VERSION, GRCS_MIN_PHP, '<')) {
        $admin_notice(static function (): string {
            return sprintf(
                /* translators: 1: required PHP version, 2: current PHP version. */
                __(
                    'requires PHP %1$s or newer (running %2$s). The plugin is inactive until PHP is upgraded.',
                    'gr-commerce-suite'
                ),
                GRCS_MIN_PHP,
                PHP_VERSION
            );
        });
        return;
    }

    // 2. Autoloading: Composer PSR-4 (GRCommerceSuite\ => src/) + Strauss-prefixed third-party packages.
    $autoloader = __DIR__ . '/vendor/autoload.php';
    if (!is_readable($autoloader)) {
        $admin_notice(static function (): string {
            return __(
                'the Composer autoloader is missing. Re-install the plugin from the official release package.',
                'gr-commerce-suite'
            );
        });
        return;
    }
    require_once $autoloader;

    \GRCommerceSuite\Modules\EmbeddedIntegrations::register();

    $prefixed_autoloader = __DIR__ . '/vendor-prefixed/autoload.php';
    if (is_readable($prefixed_autoloader)) {
        require_once $prefixed_autoloader;
    }

    // 3. WooCommerce feature compatibility: HPOS (custom order tables) and Cart/Checkout Blocks.
    add_action(
        'before_woocommerce_init',
        static function (): void {
            if (!class_exists(FeaturesUtil::class)) {
                return;
            }
            FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
            FeaturesUtil::declare_compatibility('cart_checkout_blocks', __FILE__, false);
            if (GRCS_PLUGIN_BASENAME !== 'gr-commerce-suite/gr-commerce-suite.php') {
                FeaturesUtil::declare_compatibility(
                    'custom_order_tables',
                    'gr-commerce-suite/gr-commerce-suite.php',
                    true
                );
                FeaturesUtil::declare_compatibility(
                    'cart_checkout_blocks',
                    'gr-commerce-suite/gr-commerce-suite.php',
                    false
                );
            }
        }
    );

    // 4. Activation: create/upgrade the custom table for the current site and flag recurring jobs for (re)registration.
    register_activation_hook(
        __FILE__,
        static function (bool $networkWide = false): void {
            if (!class_exists('WooCommerce')) {
                wp_die(
                    esc_html__(
                        'GR Commerce Suite requires WooCommerce to be installed and active.',
                        'gr-commerce-suite'
                    ),
                    esc_html__('Plugin activation failed', 'gr-commerce-suite'),
                    ['back_link' => true]
                );
            }

            // Must be read before the schema/activation rows below are written. Any doubt counts as existing history.
            $hadHistory = true;
            try {
                $hadHistory = \GRCommerceSuite\Feed\FeedSafetyDefaults::hadInstallHistory();
            } catch (\Throwable $e) {
                $hadHistory = true;
            }

            try {
                Schema::fromGlobals()->install();
            } catch (\Throwable $e) {
                wp_die(
                    esc_html(
                        sprintf(
                            /* translators: %s: database error message. */
                            __('GR Commerce Suite could not create its database table: %s', 'gr-commerce-suite'),
                            $e->getMessage()
                        )
                    ),
                    esc_html__('Plugin activation failed', 'gr-commerce-suite'),
                    ['back_link' => true]
                );
            }

            add_option('grcs_activated_at', gmdate('Y-m-d H:i:s'), '', false);
            // Network activation installs this site only; the rest run in resumable batches (maybeUpgrade() stays the safety net).
            if ($networkWide && is_multisite()) {
                try {
                    \GRCommerceSuite\Database\NetworkInstaller::start();
                } catch (\Throwable $e) {
                    // Never block activation; sites self-install on their first admin request.
                }
            }
            // Owner-approved D9/D10 policy: only a site with no GR Commerce Suite history starts with the safety exclusions ON.
            try {
                \GRCommerceSuite\Feed\FeedSafetyDefaults::seedForNewInstall($hadHistory);
            } catch (\Throwable $e) {
                // Leaving the defaults OFF is the safe fallback for existing listings; never block activation.
            }
            \GRCommerceSuite\Jobs\JobDispatcher::unscheduleAll($networkWide);
            // The kernel re-registers recurring Action Scheduler jobs when this option != GRCS_VERSION.
            delete_option('grcs_recurring_jobs_version');
        }
    );

    // 5. Deactivation: stop background work. Voucher/COD financial history is always retained.
    register_deactivation_hook(
        __FILE__,
        static function (bool $networkWide = false): void {
            \GRCommerceSuite\Jobs\JobDispatcher::unscheduleAll($networkWide);
        }
    );

    // 6. Multisite: provision new sites when network-active; on site deletion the plugin tables are RETAINED (financial history).
    if (is_multisite()) {
        \GRCommerceSuite\Database\NetworkInstaller::register();
        add_action(
            'wp_initialize_site',
            static function (\WP_Site $site): void {
                if (!function_exists('is_plugin_active_for_network')) {
                    require_once ABSPATH . 'wp-admin/includes/plugin.php';
                }
                if (!is_plugin_active_for_network(GRCS_PLUGIN_BASENAME)) {
                    return;
                }
                switch_to_blog((int) $site->blog_id);
                try {
                    $hadHistory = true;
                    try {
                        $hadHistory = \GRCommerceSuite\Feed\FeedSafetyDefaults::hadInstallHistory();
                    } catch (\Throwable $e) {
                        $hadHistory = true;
                    }
                    try {
                        Schema::fromGlobals()->install();
                    } catch (\Throwable $e) {
                        // The version stays unbumped, so maybeUpgrade() retries on the new site's first admin request; reason code only.
                        error_log('GR Commerce Suite: schema install failed for new site ' . (int) $site->blog_id . ': ' . get_class($e)); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- support diagnosis, no message text
                        return;
                    }
                    try {
                        \GRCommerceSuite\Feed\FeedSafetyDefaults::seedForNewInstall($hadHistory);
                    } catch (\Throwable $e) {
                        // Safe fallback: defaults stay OFF.
                    }
                } finally {
                    restore_current_blog();
                }
            },
            200 // After core (priority 10) has created the site's tables.
        );
    }

    // Site deletion (wpmu_drop_tables only fires on multisite) drops ordinary site tables only. Voucher/COD history and the whole
    // payment-attempt ledger are financial evidence and are retained (owner decision, D1 v4): strip every retained plugin table from the
    // list, whatever other callbacks added.
    add_filter('wpmu_drop_tables', [Schema::class, 'retainFinancialHistory'], PHP_INT_MAX);

    // 7. Runtime boot. Plugins load alphabetically, so WooCommerce is only guaranteed after plugins_loaded.
    add_action(
        'plugins_loaded',
        static function () use ($admin_notice): void {
            if (!class_exists('WooCommerce')) {
                $admin_notice(static function (): string {
                    return __('requires WooCommerce to be installed and active.', 'gr-commerce-suite');
                });
                return;
            }

            if (defined('WC_VERSION') && version_compare((string) WC_VERSION, GRCS_MIN_WC, '<')) {
                $admin_notice(static function (): string {
                    return sprintf(
                        /* translators: 1: required WooCommerce version, 2: installed WooCommerce version. */
                        __('requires WooCommerce %1$s or newer (installed: %2$s).', 'gr-commerce-suite'),
                        GRCS_MIN_WC,
                        (string) WC_VERSION
                    );
                });
                return;
            }

            // Fail closed for the plugin, fail open for the store: a plugin fault must never break checkout.
            try {
                Plugin::boot(__FILE__);
            } catch (\Throwable $e) {
                if (function_exists('wc_get_logger')) {
                    wc_get_logger()->critical(
                        'Boot aborted: ' . $e->getMessage(),
                        ['source' => 'gr-commerce-suite', 'exception' => get_class($e)]
                    );
                }
                $admin_notice(static function (): string {
                    return __(
                        'failed to start and has been paused. See WooCommerce > Status > Logs ' .
                            '(source: gr-commerce-suite).',
                        'gr-commerce-suite'
                    );
                });
            }
        },
        20
    );
})();
