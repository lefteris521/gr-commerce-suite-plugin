<?php

declare(strict_types=1);

namespace GRCommerceSuite\Utils;

use InvalidArgumentException;

/**
 * High-performance, self-contained normalization and sanitization utility for Greek e-commerce.
 *
 * Handles:
 * 1. Greek Phone Numbers: Normalizes and validates 10-digit mobile (69XXXXXXXX) and landline (2XXXXXXXXX).
 * 2. Greek Postal Codes (Τ.Κ.): Normalizes 5-digit postal codes (10000–85999) and detects island/remote courier surcharge zones.
 * 3. Thermal ZPL/PDF Courier Label Names & Addresses: Strips Greek diacritics/tonos/dialytika and converts to clean uppercase.
 * 4. Skroutz & BestPrice XML Feeds: Strips invalid XML 1.0 control characters and HTML tags, decodes entities, and escapes CDATA.
 * 5. Decimal Formatting: Handles European comma/period decimals, rounds to 2 decimal places, and enforces ACS REST API minimum weight (0.50 kg).
 */
final class GreekDataNormalizer
{
    /**
     * Map of Greek accented and special characters to their plain uppercase base equivalents.
     * Thermal label printers (ZPL/EPL) and PDF courier generators fail or print question marks
     * when presented with Greek vowels containing tonos or dialytika.
     *
     * @var array<string, string>
     */
    private const GREEK_ACCENTS_MAP = [
        // Lowercase with tonos
        'ά' => 'Α',
        'έ' => 'Ε',
        'ή' => 'Η',
        'ί' => 'Ι',
        'ό' => 'Ο',
        'ύ' => 'Υ',
        'ώ' => 'Ω',
        // Lowercase with dialytika
        'ϊ' => 'Ι',
        'ϋ' => 'Υ',
        // Lowercase with dialytika and tonos
        'ΐ' => 'Ι',
        'ΰ' => 'Υ',
        // Final sigma
        'ς' => 'Σ',
        // Uppercase with tonos
        'Ά' => 'Α',
        'Έ' => 'Ε',
        'Ή' => 'Η',
        'Ί' => 'Ι',
        'Ό' => 'Ο',
        'Ύ' => 'Υ',
        'Ώ' => 'Ω',
        // Uppercase with dialytika
        'Ϊ' => 'Ι',
        'Ϋ' => 'Υ',
    ];

    /**
     * 2-digit Greek postal code prefixes for Island destinations (Νησιωτικοί Προορισμοί).
     * Used by Greek couriers (ACS, Geniki Taxydromiki, Speedex) to assess island delivery surcharges.
     *
     * 28: Cephalonia & Ithaca (Ionian)
     * 29: Zakynthos (Ionian)
     * 31: Lefkada & Meganisi (Ionian)
     * 49: Corfu & Paxoi (Ionian)
     * 70, 71, 72, 73, 74: Crete (Heraklion, Lasithi, Chania, Rethymno)
     * 80: Kythira & Antikythira (80100)
     * 81: Lesvos, Lemnos, Agios Efstratios (North Aegean)
     * 82: Chios, Oinousses, Psara (North Aegean)
     * 83: Samos, Ikaria, Fournoi (North Aegean)
     * 84: Cyclades (Syros, Mykonos, Santorini, Naxos, Paros, Milos, Tinos, Andros, etc.)
     * 85: Dodecanese (Rhodes, Kos, Kalymnos, Karpathos, Leros, Patmos, Symi, etc.)
     *
     * @var list<string>
     */
    public const ISLAND_PREFIXES_2DIGIT = [
        '28', '29', '31', '49',
        '70', '71', '72', '73', '74',
        '80', '81', '82', '83', '84', '85',
    ];

    /**
     * Specific 5-digit Greek postal codes belonging to islands outside the standard 2-digit island prefixes
     * (e.g. Saronic islands under Attica, Sporades under Magnesia, Thassos, Samothraki, Skyros).
     *
     * @var list<string>
     */
    public const SPECIFIC_ISLAND_POSTAL_CODES = [
        // Saronic Gulf Islands (under Attica postcodes)
        '18010', // Aegina
        '18020', // Poros
        '18030', // Methana / Galatas
        '18040', // Hydra
        '18050', // Spetses
        '18055', // Agistri
        '18900', // Salamina
        '18901', // Salamina
        '18902', // Salamina
        '18903', // Salamina
        '18950', // Salamina
        // Evia island enclave
        '34007', // Skyros
        // Northern Sporades (under Magnesia)
        '37002', // Skiathos
        '37003', // Skopelos
        '37004', // Glossa Skopelou
        '37005', // Alonnisos
        // Chalkidiki island/monastery
        '63075', // Ammouliani
        '63086', // Mount Athos (Karyes)
        '63087', // Mount Athos (Dafni)
        // North-Eastern Aegean island enclaves under mainland prefectures
        '64002', // Thassos (Limenaria)
        '64004', // Thassos (Prinos)
        '64010', // Thassos (Limenas)
        '68002', // Samothraki
    ];

    /**
     * 2-digit Greek postal code prefixes for remote mountainous mainland areas (Δυσπρόσιτες Περιοχές - ΔΠ).
     *
     * 36: Evrytania (Karpenisi and surrounding mountainous areas)
     * 51: Grevena (Pindus mountainous region)
     *
     * @var list<string>
     */
    public const REMOTE_MAINLAND_PREFIXES_2DIGIT = [
        '36',
        '51',
    ];

    /**
     * Private constructor to prevent direct instantiation.
     */
    private function __construct()
    {
    }

    /**
     * Normalizes and validates a Greek telephone number:
     * - Strips spaces, dashes, dots, parentheses, brackets, and slashes.
     * - Strips country prefixes: +30, 0030, or leading 30 (when followed by 10 digits).
     * - Validates that the resulting string is a valid 10-digit Greek mobile (69XXXXXXXX)
     *   or landline (2XXXXXXXXX) number.
     *
     * @param string $rawPhone Raw phone string from WooCommerce billing/shipping or courier payloads.
     * @return string Clean 10-digit Greek telephone number.
     * @throws InvalidArgumentException When the input cannot be resolved to a valid 10-digit Greek phone.
     */
    public static function normalizeGreekPhone(string $rawPhone): string
    {
        // Strip common whitespace, dashes, dots, parentheses, brackets, and slashes
        $cleaned = preg_replace('/[\s\-\.\(\)\[\]\/]+/', '', trim($rawPhone)) ?? '';

        // Strip country prefixes (+30, 0030, or leading 30 if followed by 10 national digits)
        if (str_starts_with($cleaned, '+30')) {
            $cleaned = substr($cleaned, 3);
        } elseif (str_starts_with($cleaned, '0030')) {
            $cleaned = substr($cleaned, 4);
        } elseif (
            str_starts_with($cleaned, '30')
            && strlen($cleaned) === 12
            && (str_starts_with(substr($cleaned, 2), '69') || str_starts_with(substr($cleaned, 2), '2'))
        ) {
            $cleaned = substr($cleaned, 2);
        }

        // Validate: must be exactly 10 digits starting with 69 (mobile) or 2 (landline)
        if (!preg_match('/^(69\d{8}|2\d{9})$/', $cleaned)) {
            throw new InvalidArgumentException(sprintf(
                __('Invalid Greek telephone number "%s". Expected a 10-digit Greek mobile ' .
                    '(69XXXXXXXX) or landline (2XXXXXXXXX) number. / Μη έγκυρος ' .
                    'ελληνικός αριθμός τηλεφώνου.', 'gr-commerce-suite'),
                $rawPhone
            ));
        }

        return $cleaned;
    }

    /**
     * Checks if a raw phone string is a valid Greek mobile number (69XXXXXXXX).
     *
     * @param string $rawPhone
     * @return bool
     */
    public static function isGreekMobile(string $rawPhone): bool
    {
        try {
            $normalized = self::normalizeGreekPhone($rawPhone);
            return str_starts_with($normalized, '69');
        } catch (InvalidArgumentException) {
            return false;
        }
    }

    /**
     * Checks if a raw phone string is a valid Greek landline number (2XXXXXXXXX).
     *
     * @param string $rawPhone
     * @return bool
     */
    public static function isGreekLandline(string $rawPhone): bool
    {
        try {
            $normalized = self::normalizeGreekPhone($rawPhone);
            return str_starts_with($normalized, '2');
        } catch (InvalidArgumentException) {
            return false;
        }
    }

    /**
     * Normalizes a Greek phone number to international E.164 format (+30XXXXXXXXXX).
     *
     * @param string $rawPhone
     * @return string E.164 formatted string (e.g. +306912345678).
     * @throws InvalidArgumentException When the input is not a valid Greek telephone number.
     */
    public static function toE164(string $rawPhone): string
    {
        return '+30' . self::normalizeGreekPhone($rawPhone);
    }

    /**
     * Normalizes and validates a Greek Postal Code (Τ.Κ.):
     * - Strips spaces and non-digits.
     * - Validates that the postal code is exactly 5 digits and falls within valid
     *   Greek postal ranges (10000 to 85999).
     * - Detects remote / island prefixes for courier surcharge estimation (optionally
     *   populating $isRemoteOrIsland by reference).
     *
     * @param string $rawTk Raw postal code (e.g. "115 27", "GR-11527", "84100").
     * @param bool|null $isRemoteOrIsland Optional output parameter populated with true if destination is remote/island.
     * @param-out bool $isRemoteOrIsland
     * @return string Normalized 5-digit Greek postal code.
     * @throws InvalidArgumentException When the postal code is not a valid 5-digit Greek postal code between 10000 and 85999.
     */
    public static function normalizePostalCode(string $rawTk, ?bool &$isRemoteOrIsland = null): string
    {
        $cleaned = preg_replace('/\D+/', '', $rawTk) ?? '';

        if (strlen($cleaned) !== 5 || (int) $cleaned < 10000 || (int) $cleaned > 85999) {
            throw new InvalidArgumentException(sprintf(
                __('Invalid Greek postal code (Τ.Κ.) "%s". Expected exactly 5 digits between ' .
                    '10000 and 85999. / Μη έγκυρος ελληνικός ' .
                    'ταχυδρομικός κώδικας.', 'gr-commerce-suite'),
                $rawTk
            ));
        }

        $isRemoteOrIsland = self::isIslandPostalCode($cleaned) || self::isRemotePostalCode($cleaned);

        return $cleaned;
    }

    /**
     * Checks whether a Greek postal code belongs to an island destination (courier island surcharge zone).
     *
     * @param string $rawTk
     * @return bool
     */
    public static function isIslandPostalCode(string $rawTk): bool
    {
        $cleaned = preg_replace('/\D+/', '', $rawTk) ?? '';
        if (strlen($cleaned) !== 5) {
            return false;
        }

        $prefix2 = substr($cleaned, 0, 2);
        if (in_array($prefix2, self::ISLAND_PREFIXES_2DIGIT, true)) {
            return true;
        }

        return in_array($cleaned, self::SPECIFIC_ISLAND_POSTAL_CODES, true);
    }

    /**
     * Checks whether a Greek postal code is classified as remote or inaccessible (Δυσπρόσιτη Περιοχή - ΔΠ).
     * In Greek courier rate cards, all island non-capital areas and remote mountainous regions incur surcharge.
     *
     * @param string $rawTk
     * @return bool
     */
    public static function isRemotePostalCode(string $rawTk): bool
    {
        $cleaned = preg_replace('/\D+/', '', $rawTk) ?? '';
        if (strlen($cleaned) !== 5) {
            return false;
        }

        $prefix2 = substr($cleaned, 0, 2);
        if (in_array($prefix2, self::REMOTE_MAINLAND_PREFIXES_2DIGIT, true)) {
            return true;
        }

        return self::isIslandPostalCode($cleaned);
    }

    /**
     * Retrieves geographical destination classification for courier surcharge calculation.
     *
     * @param string $rawTk
     * @return array{postal_code: string, is_island: bool, is_remote: bool, destination_zone: string}
     * @throws InvalidArgumentException When postal code is invalid.
     */
    public static function getPostalCodeRegionInfo(string $rawTk): array
    {
        $normalized = self::normalizePostalCode($rawTk);
        $isIsland = self::isIslandPostalCode($normalized);
        $isRemote = self::isRemotePostalCode($normalized);

        $zone = match (true) {
            $isIsland => 'island',
            $isRemote => 'remote',
            default   => 'mainland',
        };

        return [
            'postal_code'      => $normalized,
            'is_island'        => $isIsland,
            'is_remote'        => $isRemote,
            'destination_zone' => $zone,
        ];
    }

    /**
     * Converts Greek text to uppercase and strips all diacritics/tonos/dialytika
     * (ά->Α, έ->Ε, ή->Η, ί->Ι, ό->Ο, ύ->Υ, ώ->Ω, ϊ->Ι, ϋ->Υ, ΐ->Ι, ΰ->Υ, ς->Σ)
     * so thermal ZPL/PDF courier shipping labels never print garbled or corrupted characters.
     *
     * @param string $text Raw input string (recipient name, address, city, etc.).
     * @return string Normalized uppercase string without accents or diacritics.
     */
    public static function stripGreekAccentsUpper(string $text): string
    {
        if ($text === '') {
            return '';
        }

        // Decompose Unicode if intl Normalizer is available (handles polytonic/decomposed forms)
        if (class_exists(\Normalizer::class)) {
            $decomposed = \Normalizer::normalize($text, \Normalizer::FORM_D);
            if ($decomposed !== false) {
                $text = $decomposed;
            }
        }

        // Map known Greek accented vowels and final sigma to plain uppercase equivalents
        $text = strtr($text, self::GREEK_ACCENTS_MAP);

        // Convert full string to uppercase using UTF-8
        $text = mb_strtoupper($text, 'UTF-8');

        // Second pass in case mb_strtoupper formed uppercase accented vowels (e.g. Ά, Έ)
        $text = strtr($text, self::GREEK_ACCENTS_MAP);

        // Strip any remaining combining diacritical marks (U+0300 to U+036F)
        $text = preg_replace('/[\x{0300}-\x{036F}]/u', '', $text) ?? $text;

        // Strip standalone Greek tonos, dialytika, and grave marks
        return strtr($text, [
            '΄' => '', // Greek Tonos U+0384
            '¨' => '', // Spacing Diaeresis U+00A8
            '΅' => '', // Greek Dialytika Tonos U+0385
            '`' => '',
            '´' => '',
        ]);
    }

    /**
     * Sanitizes strings for safe output in Skroutz and BestPrice XML feeds:
     * - Strips invalid XML 1.0 control characters that crash XML parsers
     *   (allows only \x09, \x0A, \x0D, \x20-\xD7FF, \xE000-\xFFFD).
     * - Strips HTML tags (including contents of <script> and <style> tags).
     * - Decodes HTML entities back to clean UTF-8 characters.
     * - Prepares text for safe XMLWriter::writeCData() output (escapes ']]>').
     *
     * @param string $input Raw product title, description, or attribute value.
     * @return string Clean, valid UTF-8 string safe for XML CDATA nodes.
     */
    public static function sanitizeXmlString(string $input): string
    {
        if ($input === '') {
            return '';
        }

        // Ensure valid UTF-8 byte sequence (replaces invalid byte sequences)
        $text = mb_convert_encoding($input, 'UTF-8', 'UTF-8');

        // Remove <script> and <style> elements along with their contents
        $text = preg_replace('/<(script|style)\b[^>]*>(.*?)<\/\1>/is', '', $text) ?? $text;

        // Strip all remaining HTML tags
        $text = strip_tags($text);

        // Decode HTML entities back to clean UTF-8 characters
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Strip invalid XML 1.0 control characters
        // Allowed: Tab (\x09), Line Feed (\x0A), Carriage Return (\x0D), \x20-\xD7FF, \xE000-\xFFFD
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text) ?? '';
        $text = preg_replace('/[^\x{0009}\x{000A}\x{000D}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u', '', $text) ?? '';

        // Prevent premature closure of XML CDATA blocks (XMLWriter::writeCData)
        $text = str_replace(']]>', ']] >', $text);

        return trim($text);
    }

    /**
     * Ensures decimals (weight, COD amount, VAT rate) use a period separator rounded to 2 decimal places,
     * enforcing the ACS REST API minimum weight of 0.50 kg when input weight is zero or empty.
     *
     * Handles:
     * - Floats and integers.
     * - Strings with European comma decimals ("12,50", "1.250,50") or US decimals ("1,250.50").
     * - Strings with currency symbols (" 12,50 € ") or percentages ("24.00%").
     * - Empty strings or zero values (falls back to $minIfZero, default 0.50).
     *
     * @param float|string $value Numeric float or string representation.
     * @param float $minIfZero Minimum fallback value when input is zero, empty, or negative (default: 0.50 kg).
     * @return float Rounded float with 2 decimal places.
     */
    public static function formatDecimal(float|string $value, float $minIfZero = 0.50): float
    {
        if (is_float($value)) {
            $floatVal = (float) $value;
        } else {
            $trimmed = trim($value);
            if ($trimmed === '') {
                return round($minIfZero, 2);
            }

            // Remove currency symbols, percentage signs, and non-numeric whitespace
            $cleaned = str_replace(['€', 'EUR', 'eur', '%', ' '], '', $trimmed);

            // Handle decimal and thousand separators
            if (str_contains($cleaned, ',') && str_contains($cleaned, '.')) {
                $lastComma = strrpos($cleaned, ',');
                $lastDot = strrpos($cleaned, '.');
                if ($lastComma !== false && $lastDot !== false && $lastComma > $lastDot) {
                    // European format: 1.250,50 -> 1250.50
                    $cleaned = str_replace('.', '', $cleaned);
                    $cleaned = str_replace(',', '.', $cleaned);
                } else {
                    // US format: 1,250.50 -> 1250.50
                    $cleaned = str_replace(',', '', $cleaned);
                }
            } elseif (str_contains($cleaned, ',')) {
                // Single comma used as decimal separator: 12,50 -> 12.50
                $cleaned = str_replace(',', '.', $cleaned);
            }

            $floatVal = is_numeric($cleaned) ? (float) $cleaned : 0.0;
        }

        // Enforce minimum when input is zero, empty, or negative
        if ($floatVal <= 0.0) {
            return round($minIfZero, 2);
        }

        return round($floatVal, 2);
    }

    /**
     * Formats a decimal into a clean 2-decimal place string with a period separator (e.g. "0.50", "12.50").
     *
     * @param float|string $value
     * @param float $minIfZero
     * @return string Formatted string suitable for courier REST JSON/XML payloads.
     */
    public static function formatDecimalString(float|string $value, float $minIfZero = 0.50): string
    {
        return number_format(self::formatDecimal($value, $minIfZero), 2, '.', '');
    }
}
