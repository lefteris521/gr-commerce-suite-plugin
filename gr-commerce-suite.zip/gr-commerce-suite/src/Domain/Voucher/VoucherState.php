<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Voucher;

/**
 * Voucher lifecycle state machine values (SPEC.md §6.3, §8.3).
 */
enum VoucherState: string
{
    case Reserved = 'reserved';
    case Created = 'created';
    case Unknown = 'unknown';
    case Failed = 'failed';
    case Cancelled = 'cancelled';

    public function isLive(): bool
    {
        return match ($this) {
            self::Reserved, self::Created, self::Unknown => true,
            self::Failed, self::Cancelled => false,
        };
    }

    public function isTerminal(): bool
    {
        return match ($this) {
            self::Failed, self::Cancelled => true,
            self::Reserved, self::Created, self::Unknown => false,
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return match ($this) {
            self::Reserved => in_array($target, [self::Reserved, self::Created, self::Failed, self::Unknown], true),
            self::Unknown => in_array($target, [self::Created, self::Failed], true),
            self::Created => $target === self::Cancelled,
            self::Failed, self::Cancelled => false,
        };
    }
}
