<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Voucher;

/**
 * Supported label print formats (SPEC.md §8.3).
 */
enum PrintFormat: string
{
    case A4 = 'a4';
    case A6 = 'a6';
    case Thermal = 'thermal';
}
