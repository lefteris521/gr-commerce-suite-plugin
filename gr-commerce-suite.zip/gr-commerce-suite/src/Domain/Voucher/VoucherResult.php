<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Voucher;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use InvalidArgumentException;

/**
 * Immutable result returned by CourierProviderInterface::createVoucher() (SPEC.md §8.3).
 */
final readonly class VoucherResult
{
    /**
     * @param array<string, mixed> $rawResponse Redacted courier response payload.
     */
    public function __construct(
        public string $voucherNo,
        public CourierSlug $courier,
        public int $codAmountCents,
        public int $parcelCount = 1,
        public ?string $trackingUrl = null,
        public ?string $lockerId = null,
        public array $rawResponse = [],
    ) {
        if (trim($this->voucherNo) === '') {
            throw new InvalidArgumentException(__('Voucher number cannot be empty.', 'gr-commerce-suite'));
        }

        if ($this->codAmountCents < 0) {
            throw new InvalidArgumentException(__('COD amount in cents cannot be negative.', 'gr-commerce-suite'));
        }

        if ($this->parcelCount < 1) {
            throw new InvalidArgumentException(__('Parcel count must be at least 1.', 'gr-commerce-suite'));
        }
    }
}
