<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Cod;

use DateTimeImmutable;
use InvalidArgumentException;

/**
 * COD collection and remittance facts reported by a courier for one voucher (SPEC.md §8.3).
 */
final readonly class CodReconciliationResult
{
    /**
     * @param array<string, mixed> $rawResponse Redacted courier response payload.
     */
    public function __construct(
        public string $voucherNo,
        public CodSettlementStatus $status,
        public ?int $collectedAmountCents,
        public ?string $settlementRef,
        public ?DateTimeImmutable $settledAt,
        public array $rawResponse = [],
    ) {
        if (trim($this->voucherNo) === '') {
            throw new InvalidArgumentException(__('Voucher number cannot be empty.', 'gr-commerce-suite'));
        }

        if ($this->collectedAmountCents !== null && $this->collectedAmountCents < 0) {
            throw new InvalidArgumentException(__('Collected COD amount in cents cannot be negative.', 'gr-commerce-suite'));
        }
    }
}
