<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Cod;

/**
 * Courier-reported Cash-On-Delivery settlement states (SPEC.md §8.3, §10).
 */
enum CodSettlementStatus: string
{
    case Settled = 'settled';
    case CollectedNotSettled = 'collected_not_settled';
    case NotCollected = 'not_collected';
    case NotFound = 'not_found';
}
