<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Shared;

/**
 * Supported courier identifiers (SPEC.md §8.3).
 */
enum CourierSlug: string
{
    case Acs = 'acs';
    case BoxNow = 'boxnow';
    case Geniki = 'geniki';

    public function label(): string
    {
        return match ($this) {
            self::Acs => 'ACS Courier',
            self::BoxNow => 'BOX NOW',
            self::Geniki => 'Geniki Taxydromiki',
        };
    }
}
