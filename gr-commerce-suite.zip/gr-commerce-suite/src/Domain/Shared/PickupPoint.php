<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Shared;

use InvalidArgumentException;

/**
 * Represents an APM locker or courier pickup location (SPEC.md §8.6).
 */
final readonly class PickupPoint
{
    /**
     * @param array<string, mixed> $rawResponse
     */
    public function __construct(
        public string $id,
        public CourierSlug $courier,
        public string $name,
        public string $address,
        public string $postcode,
        public string $city,
        public ?float $latitude = null,
        public ?float $longitude = null,
        public array $rawResponse = [],
    ) {
        if (trim($this->id) === '') {
            throw new InvalidArgumentException(__('Pickup point ID cannot be empty.', 'gr-commerce-suite'));
        }
    }
}
