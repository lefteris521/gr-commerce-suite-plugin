<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Tracking;

use DateTimeImmutable;

/**
 * Single checkpoint in a parcel's tracking history (SPEC.md §8.3).
 */
final readonly class TrackingEvent
{
    public function __construct(
        public DateTimeImmutable $occurredAt,
        public string $courierCode,
        public string $label,
        public ?string $location = null,
    ) {
    }
}
