<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Tracking;

use DateTimeImmutable;
use InvalidArgumentException;

/**
 * Normalised tracking result for a single voucher (SPEC.md §8.3).
 */
final readonly class TrackingResult
{
    /**
     * @param list<TrackingEvent>  $events
     * @param array<string, mixed> $rawResponse Redacted courier response payload.
     */
    public function __construct(
        public string $voucherNo,
        public TrackingStatus $status,
        public string $courierStatusCode,
        public string $courierStatusLabel,
        public ?DateTimeImmutable $lastEventAt,
        public array $events = [],
        public array $rawResponse = [],
    ) {
        if (trim($this->voucherNo) === '') {
            throw new InvalidArgumentException(__('Voucher number cannot be empty.', 'gr-commerce-suite'));
        }
    }

    public function isTerminal(): bool
    {
        return $this->status->isTerminal();
    }
}
