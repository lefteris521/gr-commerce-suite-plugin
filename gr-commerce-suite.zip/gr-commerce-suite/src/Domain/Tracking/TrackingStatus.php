<?php

declare(strict_types=1);

namespace GRCommerceSuite\Domain\Tracking;

/**
 * Normalised parcel tracking statuses across all couriers (SPEC.md §11.1).
 */
enum TrackingStatus: string
{
    case Pending = 'pending';
    case PickedUp = 'picked_up';
    case InTransit = 'in_transit';
    case OutForDelivery = 'out_for_delivery';
    case ReadyForPickup = 'ready_for_pickup';
    case Delivered = 'delivered';
    case DeliveryFailed = 'delivery_failed';
    case Returning = 'returning';
    case Returned = 'returned';
    case Cancelled = 'cancelled';
    case Exception = 'exception';
    case Unknown = 'unknown';

    /**
     * The courier has not reported the parcel moving yet, so the voucher can still be cancelled.
     * Unrecognised stored values count as not moving: refusing a cancel is worse than one the courier rejects.
     */
    public static function notYetShipped(string $status): bool
    {
        return in_array(self::tryFrom($status) ?? self::Unknown, [self::Pending, self::Unknown, self::Exception], true);
    }

    public function isTerminal(): bool
    {
        return match ($this) {
            self::Delivered, self::Returned, self::Cancelled => true,
            default => false,
        };
    }
}
