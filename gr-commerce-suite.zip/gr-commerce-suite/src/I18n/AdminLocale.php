<?php

declare(strict_types=1);

namespace GRCommerceSuite\I18n;

/**
 * Presentation-only WordPress gettext adapter. Never switches the request locale.
 * Private MO instances also isolate emails sent synchronously from an admin action.
 */
final class AdminLocale
{
    public const OPTION = 'grcs_admin_language';
    private const DOMAIN = 'gr-commerce-suite';

    public static function sanitize(mixed $value): string
    {
        return in_array($value, ['auto', 'el', 'en_US'], true) ? $value : 'auto';
    }

    public static function locale(): string
    {
        if (!function_exists('get_option')) {
            return 'en_US';
        }
        $language = self::sanitize(get_option(self::OPTION, 'auto'));
        if ($language === 'auto') {
            $language = function_exists('get_user_locale') ? get_user_locale() : 'en_US';
        }
        return $language === 'el' ? 'el' : 'en_US';
    }

    private static function domain(string $locale): string
    {
        global $l10n;
        // Outside a full WordPress runtime, retain native identity gettext.
        if (!function_exists('get_translations_for_domain')) {
            return self::DOMAIN;
        }
        $domain = self::DOMAIN . '-admin-' . $locale;
        if (!isset($l10n[$domain])) {
            // POMO ships with every supported WordPress version. Its isolated MO object
            // avoids load_textdomain($locale) changing WP's translation controller locale.
            if (!class_exists(\MO::class)) {
                require_once ABSPATH . (defined('WPINC') ? WPINC : 'wp-includes') . '/pomo/mo.php';
            }
            $catalog = new \MO();
            $root = dirname(__DIR__, 2) . '/languages/';
            $file = $root . self::DOMAIN . '-' . $locale . '.mo';
            if (is_readable($file)) {
                $catalog->import_from_file($file);
            }
            $l10n[$domain] = $catalog;
        }
        return $domain;
    }

    private static function messageDomain(string $key): string
    {
        if (!function_exists('get_translations_for_domain')) {
            return self::DOMAIN;
        }
        global $l10n;
        $selected = self::domain(self::locale());
        $catalog = $l10n[$selected] ?? null;
        $entry = $catalog instanceof \MO ? ($catalog->entries[$key] ?? null) : null;
        // Equality to the source is a valid translation (brands and Greek source strings).
        if ($entry !== null && $entry->translations !== [] && !in_array('', $entry->translations, true)) {
            return $selected;
        }
        return self::domain('en_US');
    }

    public static function __(string $text, string $domain = self::DOMAIN): string
    {
        return \__($text, $domain === self::DOMAIN ? self::messageDomain($text) : $domain);
    }

    public static function esc_html__(string $text, string $domain = self::DOMAIN): string
    {
        return esc_html(self::__($text, $domain));
    }

    public static function esc_attr__(string $text, string $domain = self::DOMAIN): string
    {
        return esc_attr(self::__($text, $domain));
    }

    public static function _e(string $text, string $domain = self::DOMAIN): void
    {
        echo self::__($text, $domain);
    }

    public static function esc_html_e(string $text, string $domain = self::DOMAIN): void
    {
        echo self::esc_html__($text, $domain);
    }

    public static function esc_attr_e(string $text, string $domain = self::DOMAIN): void
    {
        echo self::esc_attr__($text, $domain);
    }

    public static function _n(string $single, string $plural, int $number, string $domain = self::DOMAIN): string
    {
        return \_n($single, $plural, $number, $domain === self::DOMAIN ? self::messageDomain($single) : $domain);
    }

    public static function _x(string $text, string $context, string $domain = self::DOMAIN): string
    {
        return \_x($text, $context, $domain === self::DOMAIN ? self::messageDomain($context . "\x04" . $text) : $domain);
    }

    /** Display labels only; machine-readable status values must never be changed. */
    public static function status(string $status): string
    {
        static $byLocale = [];
        $locale = self::locale();
        if (isset($byLocale[$locale])) {
            return $byLocale[$locale][$status] ?? $status;
        }
        $labels = [
            'reserved' => self::__('Reserved', 'gr-commerce-suite'),
            'created' => self::__('Created', 'gr-commerce-suite'),
            'unknown' => self::__('Unknown', 'gr-commerce-suite'),
            'failed' => self::__('Failed', 'gr-commerce-suite'),
            'cancelled' => self::__('Cancelled', 'gr-commerce-suite'),
            'pending' => self::__('Pending', 'gr-commerce-suite'),
            'picked_up' => self::__('Picked up', 'gr-commerce-suite'),
            'in_transit' => self::__('In transit', 'gr-commerce-suite'),
            'out_for_delivery' => self::__('Out for delivery', 'gr-commerce-suite'),
            'ready_for_pickup' => self::__('Ready for pickup', 'gr-commerce-suite'),
            'delivered' => self::__('Delivered', 'gr-commerce-suite'),
            'delivery_failed' => self::__('Delivery failed', 'gr-commerce-suite'),
            'returning' => self::__('Returning', 'gr-commerce-suite'),
            'returned' => self::__('Returned', 'gr-commerce-suite'),
            'exception' => self::__('Exception', 'gr-commerce-suite'),
            'unissued' => self::__('Not issued', 'gr-commerce-suite'),
            'yes' => self::__('Yes', 'gr-commerce-suite'),
            'no' => self::__('No', 'gr-commerce-suite'),
            'refused' => self::__('Refused', 'gr-commerce-suite'),
            'processing' => self::__('Processing', 'gr-commerce-suite'),
            'completed' => self::__('Completed', 'gr-commerce-suite'),
            'on-hold' => self::__('On hold', 'gr-commerce-suite'),
            'refunded' => self::__('Refunded', 'gr-commerce-suite'),
        ];
        $byLocale[$locale] = $labels;
        // Unknown extension/carrier statuses are technical identifiers.
        return $labels[$status] ?? $status;
    }

    public static function orderStatus(string $status): string
    {
        $label = self::status($status);
        return $label !== $status ? $label : wc_get_order_status_name($status);
    }

    /**
     * Stable diagnostic keys are translated only when displayed, never before comparisons.
     *
     * @return array<string, string>
     */
    private static function diagnosticLabels(): array
    {
        static $labels = [];
        $locale = self::locale();
        if (isset($labels[$locale])) {
            return $labels[$locale];
        }
        return $labels[$locale] = [
            'Environment' => self::__('Environment', 'gr-commerce-suite'),
            'Required Extensions' => self::__('Required Extensions', 'gr-commerce-suite'),
            'WooCommerce & HPOS' => self::__('WooCommerce & HPOS', 'gr-commerce-suite'),
            'Checkout Shipping' => self::__('Checkout Shipping', 'gr-commerce-suite'),
            'Plugin Conflicts' => self::__('Plugin Conflicts', 'gr-commerce-suite'),
            'Live Handshake Ping' => self::__('Live Handshake Ping', 'gr-commerce-suite'),
            'Database Integrity' => self::__('Database Integrity', 'gr-commerce-suite'),
            'Recent Error Logs' => self::__('Recent Error Logs', 'gr-commerce-suite'),
            'PHP security status' => self::__('PHP security status', 'gr-commerce-suite'),
            'PHP security details' => self::__('PHP security details', 'gr-commerce-suite'),
            'PHP security warning' => self::__('PHP security warning', 'gr-commerce-suite'),
            'Web Server' => self::__('Web Server', 'gr-commerce-suite'),
            'Unavailable' => self::__('Unavailable', 'gr-commerce-suite'),
            'Available' => self::__('Available', 'gr-commerce-suite'),
            'Available (native)' => self::__('Available (native)', 'gr-commerce-suite'),
            'Available (sodium_compat)' => self::__('Available (sodium_compat)', 'gr-commerce-suite'),
            'Missing' => self::__('Missing', 'gr-commerce-suite'),
            'Patched' => self::__('Patched', 'gr-commerce-suite'),
            'Update recommended' => self::__('Update recommended', 'gr-commerce-suite'),
            'The PHP branch or patch status cannot be determined reliably from the reported version. Contact your hosting provider to confirm security patches.' => self::__('The PHP branch or patch status cannot be determined reliably from the reported version. Contact your hosting provider to confirm security patches.', 'gr-commerce-suite'),
            'The reported PHP version meets the official PHP2Shell security patch threshold (%s).' => self::__('The reported PHP version meets the official PHP2Shell security patch threshold (%s).', 'gr-commerce-suite'),
            'The reported PHP version is below the official PHP2Shell security patch threshold (%s) and may be vulnerable. Hosting providers may backport security fixes without changing the reported PHP version.' => self::__('The reported PHP version is below the official PHP2Shell security patch threshold (%s) and may be vulnerable. Hosting providers may backport security fixes without changing the reported PHP version.', 'gr-commerce-suite'),
            'Your hosting environment may be affected by known PHP security vulnerabilities (CVE-2026-109618 and CVE-2026-109619). Contact your hosting provider to confirm the security patches are installed.' => self::__('Your hosting environment may be affected by known PHP security vulnerabilities (CVE-2026-109618 and CVE-2026-109619). Contact your hosting provider to confirm the security patches are installed.', 'gr-commerce-suite'),
            'Uploads writable' => self::__('Uploads writable', 'gr-commerce-suite'),
            'License' => self::__('License', 'gr-commerce-suite'),
            'Inactive' => self::__('Inactive', 'gr-commerce-suite'),
            'Block Checkout' => self::__('Block Checkout', 'gr-commerce-suite'),
            'Classic Checkout ([woocommerce_checkout])' => self::__('Classic Checkout ([woocommerce_checkout])', 'gr-commerce-suite'),
            'Unrecognized checkout content' => self::__('Unrecognized checkout content', 'gr-commerce-suite'),
            'Active theme' => self::__('Active theme', 'gr-commerce-suite'),
            'Pending orders sync count' => self::__('Pending orders sync count', 'gr-commerce-suite'),
            'Checkout template overrides' => self::__('Checkout template overrides', 'gr-commerce-suite'),
            'Authoritative orders storage' => self::__('Authoritative orders storage', 'gr-commerce-suite'),
            'Compatibility sync' => self::__('Compatibility sync', 'gr-commerce-suite'),
            'Action Scheduler' => self::__('Action Scheduler', 'gr-commerce-suite'),
            'Credential encryption is unavailable. Enable PHP Sodium or a compatible sodium_compat implementation before saving credentials.' => self::__('Credential encryption is unavailable. Enable PHP Sodium or a compatible sodium_compat implementation before saving credentials.', 'gr-commerce-suite'),
            'Destination and locker data' => self::__('Destination and locker data', 'gr-commerce-suite'),
            'Courier pricing rules' => self::__('Courier pricing rules', 'gr-commerce-suite'),
            'Required for Dynamic pricing. Enter schema version 1 JSON.' => self::__('Required for Dynamic pricing. Enter schema version 1 JSON.', 'gr-commerce-suite'),
            'Add verified destination records.' => self::__('Add verified destination records.', 'gr-commerce-suite'),
            'Select a supported option.' => self::__('Select a supported option.', 'gr-commerce-suite'),
            'Enter a cost greater than zero.' => self::__('Enter a cost greater than zero.', 'gr-commerce-suite'),
            'Άρνηση Παραλαβής' => self::__('Άρνηση Παραλαβής', 'gr-commerce-suite'),
            'Λάθος Διεύθυνση' => self::__('Λάθος Διεύθυνση', 'gr-commerce-suite'),
            'Δεν Βρέθηκε' => self::__('Δεν Βρέθηκε', 'gr-commerce-suite'),
            'Επιστροφή' => self::__('Επιστροφή', 'gr-commerce-suite'),
            'Αποτυχία Παράδοσης' => self::__('Αποτυχία Παράδοσης', 'gr-commerce-suite'),
            'AFM (Greek VAT Number)' => self::__('AFM (Greek VAT Number)', 'gr-commerce-suite'),
            'Company Name' => self::__('Company Name', 'gr-commerce-suite'),
            'Tax Office' => self::__('Tax Office', 'gr-commerce-suite'),
            'Business Activity' => self::__('Business Activity', 'gr-commerce-suite'),
            'Syntax error' => self::__('Syntax error', 'gr-commerce-suite'),
            'Maximum stack depth exceeded' => self::__('Maximum stack depth exceeded', 'gr-commerce-suite'),
            'Malformed UTF-8 characters, possibly incorrectly encoded' => self::__('Malformed UTF-8 characters, possibly incorrectly encoded', 'gr-commerce-suite'),
            'Underflow or the modes mismatch' => self::__('Underflow or the modes mismatch', 'gr-commerce-suite'),
            'Control character error, possibly incorrectly encoded' => self::__('Control character error, possibly incorrectly encoded', 'gr-commerce-suite'),
            'Manual' => self::__('Manual', 'gr-commerce-suite'),
            'Courier and customer risk' => self::__('Courier and customer risk', 'gr-commerce-suite'),
            'Copy this generated URL into your Skroutz Merchants or BestPrice partner dashboard.' => self::__('Copy this generated URL into your Skroutz Merchants or BestPrice partner dashboard.', 'gr-commerce-suite'),
            'INFO' => self::__('INFO', 'gr-commerce-suite'),
            'WARNING' => self::__('WARNING', 'gr-commerce-suite'),
            'WARN' => self::__('WARN', 'gr-commerce-suite'),
            'ERROR' => self::__('ERROR', 'gr-commerce-suite'),
            'CRITICAL' => self::__('CRITICAL', 'gr-commerce-suite'),
            'BLACKLIST' => self::__('BLACKLIST', 'gr-commerce-suite'),
            'RECONCILIATION' => self::__('RECONCILIATION', 'gr-commerce-suite'),
            'INVOICE' => self::__('INVOICE', 'gr-commerce-suite'),
            'LICENSE' => self::__('LICENSE', 'gr-commerce-suite'),
            'SYSTEM' => self::__('SYSTEM', 'gr-commerce-suite'),
            'Voucher created.' => self::__('Voucher created.', 'gr-commerce-suite'),
            'Voucher cancelled.' => self::__('Voucher cancelled.', 'gr-commerce-suite'),
            'Validation failed.' => self::__('Validation failed.', 'gr-commerce-suite'),
            'Remote request failed.' => self::__('Remote request failed.', 'gr-commerce-suite'),
            'Remote request completed.' => self::__('Remote request completed.', 'gr-commerce-suite'),
            'License transport failed.' => self::__('License transport failed.', 'gr-commerce-suite'),
            'License request completed.' => self::__('License request completed.', 'gr-commerce-suite'),
            'License check succeeded.' => self::__('License check succeeded.', 'gr-commerce-suite'),
            'License check failed.' => self::__('License check failed.', 'gr-commerce-suite'),
            'COD CSV headers could not be matched.' => self::__('COD CSV headers could not be matched.', 'gr-commerce-suite'),
            'Simulated AADE registry lookup.' => self::__('Simulated AADE registry lookup.', 'gr-commerce-suite'),
            'Registry response could not be validated.' => self::__('Registry response could not be validated.', 'gr-commerce-suite'),
            'Blacklist check completed.' => self::__('Blacklist check completed.', 'gr-commerce-suite'),
            'COD CSV reconciliation completed.' => self::__('COD CSV reconciliation completed.', 'gr-commerce-suite'),
            'COD CSV row skipped: invalid collected amount.' => self::__('COD CSV row skipped: invalid collected amount.', 'gr-commerce-suite'),
            'Request failed' => self::__('Request failed', 'gr-commerce-suite'),
            'Diagnostic event.' => self::__('Diagnostic event.', 'gr-commerce-suite'),
            'XML feed generation started.' => self::__('XML feed generation started.', 'gr-commerce-suite'),
            'Feed publication failed.' => self::__('Feed publication failed.', 'gr-commerce-suite'),
            'XML and verified ZIP feed published.' => self::__('XML and verified ZIP feed published.', 'gr-commerce-suite'),
            'Could not atomically publish the XML feed; the previous feed was retained.' => self::__('Could not atomically publish the XML feed; the previous feed was retained.', 'gr-commerce-suite'),
            'ACS COD amount exceeds configured cash transaction warning threshold.' => self::__('ACS COD amount exceeds configured cash transaction warning threshold.', 'gr-commerce-suite'),
            'BOX NOW COD amount exceeds configured cash transaction warning threshold.' => self::__('BOX NOW COD amount exceeds configured cash transaction warning threshold.', 'gr-commerce-suite'),
            'Unmapped ACS tracking status code encountered; mapped to TrackingStatus::Unknown.' => self::__('Unmapped ACS tracking status code encountered; mapped to TrackingStatus::Unknown.', 'gr-commerce-suite'),
            'Unmapped BOX NOW tracking state encountered; mapped to TrackingStatus::Unknown.' => self::__('Unmapped BOX NOW tracking state encountered; mapped to TrackingStatus::Unknown.', 'gr-commerce-suite'),
        ];
    }

    /**
     * Translate known service messages only at their administrative display boundary.
     * Match catalog format strings, never arbitrary fragments or provider/customer data.
     * This preserves values already interpolated by shared service exceptions.
     */
    private static function resolveMessage(string $message): ?string
    {
        global $l10n;
        static $exact = null;
        static $formats = [];
        $placeholder = '/%%|%(?:(\d+)\$)?[-+0 \x27#]*\d*(?:\.\d+)?[bcdeEfFgGosuxX]/';
        if ($exact === null) {
            $exact = [];
            foreach (['en_US', 'el'] as $locale) {
                $catalog = $l10n[self::domain($locale)] ?? null;
                if (!$catalog instanceof \MO) {
                    continue;
                }
                foreach ($catalog->entries as $entry) {
                    if ($entry->context !== null || $entry->is_plural) {
                        continue;
                    }
                    foreach (array_unique(array_merge([$entry->singular], $entry->translations)) as $template) {
                        $exact[$template] = $entry->singular;
                        if (strlen(preg_replace($placeholder, '', $template) ?? '') < 8
                            || preg_match_all($placeholder, $template, $parts, PREG_OFFSET_CAPTURE) === 0) {
                            continue;
                        }
                        $pattern = '';
                        $offset = 0;
                        $slots = [];
                        $next = 1;
                        foreach ($parts[0] as [$token, $position]) {
                            $pattern .= preg_quote(substr($template, $offset, $position - $offset), '~');
                            if ($token === '%%') {
                                $pattern .= '%';
                            } else {
                                preg_match('/^%(\d+)\$/', $token, $number);
                                $slots[] = isset($number[1]) ? (int) $number[1] : $next++;
                                $pattern .= '(.*?)';
                            }
                            $offset = $position + strlen($token);
                        }
                        if ($slots !== []) {
                            $pattern .= preg_quote(substr($template, $offset), '~');
                            $formats[] = ['~\A' . $pattern . '\z~sD', $slots, $entry->singular];
                        }
                    }
                }
            }
        }
        if (isset($exact[$message])) {
            return self::__($exact[$message]);
        }
        foreach ($formats as [$pattern, $slots, $source]) {
            if (preg_match($pattern, $message, $matches) !== 1) {
                continue;
            }
            $arguments = [];
            foreach ($slots as $index => $slot) {
                $arguments[$slot] = $matches[$index + 1];
            }
            $next = 1;
            return preg_replace_callback($placeholder, static function (array $token) use ($arguments, &$next): string {
                if ($token[0] === '%%') {
                    return '%';
                }
                $slot = isset($token[1]) ? (int) $token[1] : $next++;
                return $arguments[$slot] ?? $token[0];
            }, self::__($source));
        }
        return null;
    }

    public static function error(string $message): string
    {
        if (!function_exists('get_translations_for_domain')) {
            return $message;
        }
        return self::resolveMessage($message) ?? self::__(
            'The operation could not be completed. Please try again or contact support.',
            'gr-commerce-suite'
        );
    }

    /** Exact known diagnostic labels; arbitrary logs/provider payloads remain technical data. */
    public static function display(string $text): string
    {
        return self::diagnosticLabels()[$text] ?? self::resolveMessage($text) ?? $text;
    }
}
