<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Geniki;

use GRCommerceSuite\I18n\AdminLocale;

/**
 * Settings configuration and schema for Geniki Taxydromiki module.
 */
final class GenikiSettings
{
    public const SECTION = 'geniki';

    public const OPTION_USERNAME = 'grcs_geniki_username';
    public const OPTION_PASSWORD = 'grcs_geniki_password';
    public const OPTION_APP_KEY = 'grcs_geniki_application_key';
    public const OPTION_ENVIRONMENT = 'grcs_geniki_environment';
    public const OPTION_DEFAULT_SERVICE = 'grcs_geniki_default_service';
    public const OPTION_COD_SERVICE = 'grcs_geniki_cod_service';
    public const OPTION_CASH_LIMIT = 'grcs_geniki_cod_cash_limit_cents';

    /**
     * Return array of credential keys mapped to WordPress option names for CredentialVault.
     *
     * @return array<string, string>
     */
    public static function vaultOptionMap(): array
    {
        return [
            'username' => self::OPTION_USERNAME,
            'password' => self::OPTION_PASSWORD,
            'application_key' => self::OPTION_APP_KEY,
            'environment' => self::OPTION_ENVIRONMENT,
            'default_service_code' => self::OPTION_DEFAULT_SERVICE,
            'cod_service_code' => self::OPTION_COD_SERVICE,
            'cod_cash_limit_cents' => self::OPTION_CASH_LIMIT,
        ];
    }

    /**
     * Return WooCommerce settings fields for the Geniki settings tab/section.
     *
     * @return list<array<string, mixed>>
     */
    public static function fields(): array
    {
        return [
            [
                'title' => AdminLocale::__('Geniki Taxydromiki API Settings', 'gr-commerce-suite'),
                'type' => 'title',
                'desc' => AdminLocale::__('Configure your Geniki Taxydromiki Web API V2 credentials and options.', 'gr-commerce-suite'),
                'id' => 'grcs_geniki_section_title',
            ],
            [
                'title' => AdminLocale::__('Username', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Your Geniki Taxydromiki Web API username (sUsrName).', 'gr-commerce-suite'),
                'id' => self::OPTION_USERNAME,
                'type' => 'text',
                'css' => 'min-width:300px;',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Password', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Your Geniki Taxydromiki Web API password (sUsrPwd).', 'gr-commerce-suite'),
                'id' => self::OPTION_PASSWORD,
                'type' => 'password',
                'css' => 'min-width:300px;',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Application Key', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Your Geniki Taxydromiki Web API application key (applicationKey).', 'gr-commerce-suite'),
                'id' => self::OPTION_APP_KEY,
                'type' => 'password',
                'css' => 'min-width:300px;',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Environment', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Choose Production or Sandbox (testvoucher.taxydromiki.gr).', 'gr-commerce-suite'),
                'id' => self::OPTION_ENVIRONMENT,
                'type' => 'select',
                'default' => 'live',
                'options' => [
                    'live' => AdminLocale::__('Live / Production', 'gr-commerce-suite'),
                    'sandbox' => AdminLocale::__('Sandbox / Test', 'gr-commerce-suite'),
                ],
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('COD Service Code', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Service code passed to Geniki Taxydromiki for cash-on-delivery (default: αμ for cash; αν for cheque).', 'gr-commerce-suite'),
                'id' => self::OPTION_COD_SERVICE,
                'type' => 'text',
                'default' => 'αμ',
                'css' => 'width:80px;',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Default Service Code', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Optional additional service code passed to all vouchers.', 'gr-commerce-suite'),
                'id' => self::OPTION_DEFAULT_SERVICE,
                'type' => 'text',
                'default' => '',
                'css' => 'width:120px;',
                'desc_tip' => true,
            ],
            [
                'type' => 'sectionend',
                'id' => 'grcs_geniki_section_end',
            ],
        ];
    }
}
