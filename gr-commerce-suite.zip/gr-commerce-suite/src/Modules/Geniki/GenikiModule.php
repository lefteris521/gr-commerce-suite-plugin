<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Geniki;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Modules\ModuleRegistry;

/**
 * Geniki Taxydromiki Module (Module A) specification and activation rules.
 *
 * In accordance with owner architectural principles (2026-10-29):
 *  - OFF by default: absent from `grcs_modules` option evaluates to inactive ('no').
 *  - Preserves historical vouchers, orders, zone instances and decrypted credentials when disabled.
 *  - Isolates provider-specific logic from shared core.
 */
final class GenikiModule
{
    public const KEY = 'geniki';

    /**
     * Determine whether the Geniki Taxydromiki module is effectively enabled.
     *
     * Invariant: Defaults to FALSE (OFF) unless explicitly enabled in `grcs_modules`.
     */
    public static function isEnabled(): bool
    {
        // If ModuleRegistry already knows GENIKI, delegate to it
        if (defined(ModuleRegistry::class . '::GENIKI')) {
            /** @var string $genikiConst */
            $genikiConst = constant(ModuleRegistry::class . '::GENIKI');
            return ModuleRegistry::isEnabled($genikiConst);
        }

        $stored = function_exists('get_option') ? get_option(ModuleRegistry::OPTION, []) : [];
        if (!is_array($stored)) {
            return false;
        }

        // OFF by default: absent key evaluates to 'no'
        return ($stored[self::KEY] ?? 'no') === 'yes';
    }

    /**
     * Determine saved merchant preference (before dependency gating).
     */
    public static function isRequested(): bool
    {
        if (defined(ModuleRegistry::class . '::GENIKI')) {
            /** @var string $genikiConst */
            $genikiConst = constant(ModuleRegistry::class . '::GENIKI');
            return ModuleRegistry::isRequested($genikiConst);
        }

        $stored = function_exists('get_option') ? get_option(ModuleRegistry::OPTION, []) : [];
        if (!is_array($stored)) {
            return false;
        }

        return ($stored[self::KEY] ?? 'no') === 'yes';
    }

    /**
     * Return CourierSlug associated with this module.
     */
    public static function slug(): CourierSlug
    {
        return CourierSlug::Geniki;
    }

    /**
     * Return module card definition for ModuleRegistry and SettingsPage.
     *
     * @return array{label: string, description: string, off: string}
     */
    public static function definition(): array
    {
        return [
            'label' => AdminLocale::__('Geniki Taxydromiki', 'gr-commerce-suite'),
            'description' => AdminLocale::__('Vouchers, tracking and shipping rates for Geniki Taxydromiki.', 'gr-commerce-suite'),
            'off' => AdminLocale::__('No new Geniki Taxydromiki vouchers or shipping rates at checkout, and no Geniki tracking or connection tests. Existing vouchers, orders and credentials stay.', 'gr-commerce-suite'),
        ];
    }
}
