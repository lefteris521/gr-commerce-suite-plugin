<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Geniki;

use DateTimeImmutable;
use DateTimeZone;
use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Couriers\GenikiProvider;
use GRCommerceSuite\Database\Repositories\OptionLockRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Security\CredentialVault;
use GRCommerceSuite\Services\LicenseManager;
use InvalidArgumentException;
use RuntimeException;
use Throwable;
use wpdb;

/** Explicit account-wide closing, also available for historical jobs while the module is OFF. */
final class MerchantFinalization implements HookSubscriberInterface
{
    public const ACTION = 'grcs_geniki_finalize';
    public const ACTION_RELEASE = 'grcs_geniki_release_lock';
    public const PAGE = 'grcs-geniki-finalization';
    public const OPTION_SUCCESS = 'grcs_geniki_finalization_success';
    public const OPTION_LOCK_RELEASES = 'grcs_geniki_closing_lock_releases';

    /** Lock TTL for stale (no dispatch) locks: 15 minutes. */
    private const STALE_LOCK_TTL_SECONDS = 900;

    public function __construct(private readonly CourierRegistry $registry, private readonly CredentialVault $vault)
    {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'menu']);
        add_action('admin_post_' . self::ACTION, [$this, 'handle']);
        add_action('admin_post_' . self::ACTION_RELEASE, [$this, 'handleRelease']);
    }

    public static function url(): string
    {
        return admin_url('admin.php?page=' . self::PAGE);
    }

    public function menu(): void
    {
        add_submenu_page('', AdminLocale::__('Geniki finalization', 'gr-commerce-suite'),
            AdminLocale::__('Geniki finalization', 'gr-commerce-suite'),
            current_user_can('manage_woocommerce') ? 'manage_woocommerce' : 'grcs_manage_vouchers', self::PAGE, [$this, 'render']);
    }

    private function authorize(): void
    {
        LicenseManager::assertLicensed();
        if (!current_user_can('manage_woocommerce') && !current_user_can('grcs_manage_vouchers')) {
            throw new RuntimeException('Permission denied.');
        }
    }

    /** Bind a form and successful cursor to the site, effective endpoint and carrier account. */
    public function scope(): string
    {
        $credentials = $this->vault->getForCourier(CourierSlug::Geniki);
        $environment = $this->environment($credentials);
        return hash_hmac('sha256', (string) wp_json_encode([
            get_current_blog_id(), $environment, $credentials['endpoint_url'] ?? '',
            $credentials['username'] ?? '', $credentials['application_key'] ?? '',
        ]), wp_salt('auth'));
    }

    /** @param array<string, string> $credentials */
    private function environment(array $credentials): string
    {
        return in_array(strtolower(trim($credentials['environment'] ?? '')), ['sandbox', 'test'], true)
            || (new LicenseManager())->isSandboxEnabled() ? 'sandbox' : 'live';
    }

    /** Carrier-account exclusion is shared across sites; credentials/forms/cursors remain site local. */
    private function accountLockKey(): string
    {
        $credentials = $this->vault->getForCourier(CourierSlug::Geniki);
        $endpoint = trim($credentials['endpoint_url'] ?? '');
        if ($endpoint === '') {
            $endpoint = $this->environment($credentials) === 'sandbox'
                ? GenikiProvider::SANDBOX_ENDPOINT : GenikiProvider::PRODUCTION_ENDPOINT;
        }
        $host = parse_url($endpoint, PHP_URL_HOST);
        if (!is_string($host) || $host === '') {
            throw new InvalidArgumentException('Invalid Geniki endpoint.');
        }
        // Password/application-key rotation and per-site salts must not bypass an in-flight account lock.
        return 'grcs_geniki_closing_account_' . hash('sha256', (string) wp_json_encode([
            strtolower($host), strtolower(trim($credentials['username'] ?? '')),
        ]));
    }

    /** @return array{0: DateTimeImmutable, 1: DateTimeImmutable} */
    public static function range(string $mode, string $from, string $to, ?DateTimeImmutable $now = null): array
    {
        $zone = new DateTimeZone('Europe/Athens');
        $today = ($now ?? new DateTimeImmutable('now', $zone))->setTimezone($zone)->format('Y-m-d');
        if ($mode === 'today') {
            $from = $to = $today;
        } elseif ($mode !== 'range') {
            throw new InvalidArgumentException('Choose today or an explicit date range.');
        }
        $parse = static function (string $value) use ($zone): DateTimeImmutable {
            $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, $zone);
            if ($date === false || $date->format('Y-m-d') !== $value) {
                throw new InvalidArgumentException('Invalid finalization date.');
            }
            return $date;
        };
        $start = $parse($from);
        $end = $parse($to)->setTime(23, 59, 59);
        if ($start > $end || $to > $today) {
            throw new InvalidArgumentException('Invalid finalization date range.');
        }
        return [$start, $end];
    }

    public function render(): void
    {
        try {
            $this->authorize();
        } catch (Throwable) {
            wp_die(esc_html(AdminLocale::__('Permission denied.', 'gr-commerce-suite')), '', ['response' => 403]);
            return; // @phpstan-ignore deadCode.unreachable (Custom WordPress die handlers may return.)
        }
        $credentials = $this->vault->getForCourier(CourierSlug::Geniki);
        $scope = $this->scope();
        $today = (new DateTimeImmutable('now', new DateTimeZone('Europe/Athens')))->format('Y-m-d');
        echo '<div class="wrap"><h1>' . AdminLocale::esc_html__('Geniki finalization', 'gr-commerce-suite') . '</h1>';
        echo '<p>' . AdminLocale::esc_html__('Closing affects ALL pending jobs in this Geniki account, including jobs created outside WooCommerce. Today excludes older jobs. Use a date range for older jobs. Dates use Europe/Athens. Nothing closes automatically.', 'gr-commerce-suite') . '</p>';
        echo '<p>' . esc_html(($credentials['username'] ?? '') . ' / ' . $this->environment($credentials)) . '</p>';
        $records = get_option(self::OPTION_SUCCESS, []);
        $last = is_array($records) ? ($records[$scope] ?? null) : null;
        if (is_array($last)) {
            echo '<p>' . AdminLocale::esc_html__('Last confirmed closing:', 'gr-commerce-suite') . ' '
                . esc_html((string) ($last['at_utc'] ?? '') . ' UTC / ' . (string) ($last['from'] ?? '') . ' – ' . (string) ($last['to'] ?? '')) . '</p>';
        }
        // Show current lock status if held.
        $lockKey = $this->accountLockKey();
        $lockValue = OptionLockRepository::get($lockKey, true);
        if ($lockValue !== null) {
            $lockData = json_decode($lockValue, true);
            $age = 'unknown';
            $outcome = 'not_sent';
            if (is_array($lockData)) {
                if (isset($lockData['acquired_at_utc'])) {
                    $acquired = strtotime($lockData['acquired_at_utc']);
                    if ($acquired !== false) {
                        $age = sprintf(AdminLocale::__('%d minutes', 'gr-commerce-suite'), max(1, (time() - $acquired) / 60));
                    }
                }
                $outcome = $lockData['outcome'] ?? 'not_sent';
            }
            echo '<div class="grcs-card grcs-card--warning"><h2>' . AdminLocale::esc_html__('Active closing lock', 'gr-commerce-suite') . '</h2>';
            echo '<p>' . AdminLocale::esc_html__('A closing operation is currently in progress or was left in an uncertain state.', 'gr-commerce-suite') . '</p>';
            echo '<p><strong>' . AdminLocale::esc_html__('Lock age:', 'gr-commerce-suite') . '</strong> ' . esc_html($age) . '</p>';
            echo '<p><strong>' . AdminLocale::esc_html__('Last known outcome:', 'gr-commerce-suite') . '</strong> ' . esc_html($outcome) . '</p>';
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
            wp_nonce_field(self::ACTION_RELEASE);
            echo '<input type="hidden" name="action" value="' . esc_attr(self::ACTION_RELEASE) . '">';
            echo '<input type="hidden" name="scope" value="' . esc_attr($scope) . '">';
            echo '<p><label>' . AdminLocale::esc_html__('Reason for manual release (required):', 'gr-commerce-suite') . ' '
                . '<input type="text" name="reason" required style="width: 80%;"></label></p>';
            echo '<p><label><input type="checkbox" name="confirm" value="yes" required> '
                . AdminLocale::esc_html__('I understand this will allow a new closing attempt for this carrier account. The previous operation may have already closed jobs at the carrier.', 'gr-commerce-suite') . '</label></p>';
            submit_button(AdminLocale::__('Release closing lock', 'gr-commerce-suite'), 'delete');
            echo '</form></div>';
        }
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field(self::ACTION);
        echo '<input type="hidden" name="action" value="' . esc_attr(self::ACTION) . '">'
            . '<input type="hidden" name="scope" value="' . esc_attr($scope) . '">'
            . '<input type="hidden" name="request_id" value="' . esc_attr(wp_generate_uuid4()) . '">';
        echo '<p><label><select name="mode"><option value="today">' . AdminLocale::esc_html__('Today', 'gr-commerce-suite')
            . '</option><option value="range">' . AdminLocale::esc_html__('Date range', 'gr-commerce-suite') . '</option></select></label></p>';
        echo '<p><label>' . AdminLocale::esc_html__('From', 'gr-commerce-suite') . ' <input type="date" name="from" value="' . esc_attr($today) . '"></label> '
            . '<label>' . AdminLocale::esc_html__('To', 'gr-commerce-suite') . ' <input type="date" name="to" value="' . esc_attr($today) . '"></label></p>';
        echo '<p><label><input type="checkbox" name="confirm" value="yes" required> '
            . AdminLocale::esc_html__('I confirm closing all pending jobs in this carrier account and selected period.', 'gr-commerce-suite') . '</label></p>';
        submit_button(AdminLocale::__('Finalize Geniki jobs', 'gr-commerce-suite'));
        echo '</form></div>';
    }

    public function handle(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            wp_die(esc_html(AdminLocale::__('Explicit POST confirmation required.', 'gr-commerce-suite')), '', ['response' => 405]);
            return; // @phpstan-ignore deadCode.unreachable
        }
        try {
            $this->authorize();
        } catch (Throwable) {
            wp_die(esc_html(AdminLocale::__('Permission denied.', 'gr-commerce-suite')), '', ['response' => 403]);
            return; // @phpstan-ignore deadCode.unreachable
        }
        check_admin_referer(self::ACTION);
        $input = [];
        foreach (['scope', 'request_id', 'mode', 'from', 'to', 'confirm'] as $key) {
            $input[$key] = is_string($_POST[$key] ?? null) ? wp_unslash($_POST[$key]) : '';
        }
        try {
            $this->finalize($input);
        } catch (Throwable) {
            // Never expose carrier faults or credentials, or retry an ambiguous closing.
            wp_die(esc_html(AdminLocale::__('Closing was not confirmed. The last successful record is unchanged. Check the carrier account before deliberately trying again; this request will not be replayed.', 'gr-commerce-suite')), '', ['response' => 409, 'back_link' => true]);
            return; // @phpstan-ignore deadCode.unreachable
        }
        wp_safe_redirect(self::url());
        exit;
    }

    public function handleRelease(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            wp_die(esc_html(AdminLocale::__('Explicit POST confirmation required.', 'gr-commerce-suite')), '', ['response' => 405]);
            return; // @phpstan-ignore deadCode.unreachable
        }
        try {
            $this->authorize();
        } catch (Throwable) {
            wp_die(esc_html(AdminLocale::__('Permission denied.', 'gr-commerce-suite')), '', ['response' => 403]);
            return; // @phpstan-ignore deadCode.unreachable
        }
        check_admin_referer(self::ACTION_RELEASE);
        $scope = is_string($_POST['scope'] ?? null) ? wp_unslash($_POST['scope']) : '';
        $reason = is_string($_POST['reason'] ?? null) ? trim(wp_unslash($_POST['reason'])) : '';
        $confirm = is_string($_POST['confirm'] ?? null) ? wp_unslash($_POST['confirm']) : '';
        if ($scope === '' || $confirm !== 'yes' || $reason === '') {
            wp_die(esc_html(AdminLocale::__('Scope, confirmation and a non-empty reason are required to release a closing lock.', 'gr-commerce-suite')), '', ['response' => 400, 'back_link' => true]);
            return; // @phpstan-ignore deadCode.unreachable
        }
        try {
            $this->releaseLock($scope, $reason, true);
        } catch (InvalidArgumentException $error) {
            wp_die(esc_html($error->getMessage()), '', ['response' => 400, 'back_link' => true]);
            return; // @phpstan-ignore deadCode.unreachable
        } catch (RuntimeException $error) {
            wp_die(esc_html($error->getMessage()), '', ['response' => 409, 'back_link' => true]);
            return; // @phpstan-ignore deadCode.unreachable
        }
        wp_safe_redirect(self::url());
        exit;
    }

    /**
     * Operator release of a closing lock: requires scope, explicit confirmation and a non-empty reason,
     * releases only if the exact value is still held (CAS) and writes the capped audit trail.
     */
    public function releaseLock(string $scope, string $reason, bool $confirmed): void
    {
        $reason = trim($reason);
        if (!$confirmed || $reason === '') {
            throw new InvalidArgumentException(AdminLocale::__('Scope, confirmation and a non-empty reason are required to release a closing lock.', 'gr-commerce-suite'));
        }
        if (!hash_equals($this->scope(), $scope)) {
            throw new InvalidArgumentException(AdminLocale::__('Invalid scope for lock release.', 'gr-commerce-suite'));
        }
        $lockKey = $this->accountLockKey();
        $lockValue = OptionLockRepository::get($lockKey, true);
        if ($lockValue === null) {
            throw new RuntimeException(AdminLocale::__('No closing lock is currently held.', 'gr-commerce-suite'));
        }
        // CAS release: delete only if the value still matches.
        if (!OptionLockRepository::replace($lockKey, $lockValue, null, true)) {
            throw new RuntimeException(AdminLocale::__('Lock was modified by another process; please retry.', 'gr-commerce-suite'));
        }
        // Audit log entry.
        $releases = get_option(self::OPTION_LOCK_RELEASES, []);
        $releases = is_array($releases) ? $releases : [];
        $data = json_decode($lockValue, true);
        $releases[] = [
            'at_utc' => gmdate('c'),
            'user_id' => get_current_user_id(),
            'reason' => $reason,
            'lock_age_seconds' => $this->lockAgeSeconds($lockValue),
            'lock_outcome' => is_array($data) ? ($data['outcome'] ?? 'unknown') : 'legacy',
        ];
        // Cap audit log to last 100 entries.
        if (count($releases) > 100) {
            $releases = array_slice($releases, -100);
        }
        update_option(self::OPTION_LOCK_RELEASES, $releases, true);
    }

    /** @param array<string, string> $input */
    public function finalize(array $input): void
    {
        $this->authorize();
        $scope = $this->scope();
        if (($input['confirm'] ?? '') !== 'yes' || !hash_equals($scope, $input['scope'] ?? '')
            || preg_match('/^[a-f0-9-]{32,36}$/Di', $input['request_id'] ?? '') !== 1) {
            throw new InvalidArgumentException('Explicit confirmation and current account scope required.');
        }
        $mode = $input['mode'] ?? '';
        [$from, $to] = self::range($mode, $input['from'] ?? '', $input['to'] ?? '');
        $lockKey = $this->accountLockKey();
        $owner = bin2hex(random_bytes(16));
        $acquiredAt = gmdate('c');
        // Build initial lock value JSON.
        $lockValue = (string) wp_json_encode([
            'owner' => $owner,
            'acquired_at_utc' => $acquiredAt,
            'dispatch_sent' => false,
            'outcome' => 'not_sent',
            'scope' => $scope,
            'request_id' => $input['request_id'],
        ]);
        // Attempt to acquire the lock.
        $inserted = OptionLockRepository::insert($lockKey, $lockValue, true);
        if (!$inserted) {
            // Check if existing lock is a stale "no-dispatch" lock eligible for auto-recovery.
            $existing = OptionLockRepository::get($lockKey, true);
            $staleRecovered = false;
            if ($existing !== null) {
                $data = json_decode($existing, true);
                $isLegacy = !is_array($data);
                $isStaleNoDispatch = !$isLegacy
                    && isset($data['dispatch_sent']) && $data['dispatch_sent'] === false
                    && isset($data['acquired_at_utc']) && strtotime($data['acquired_at_utc']) !== false
                    && (time() - strtotime($data['acquired_at_utc'])) > self::STALE_LOCK_TTL_SECONDS;
                if ($isStaleNoDispatch) {
                    // Attempt CAS delete of the stale lock.
                    if (OptionLockRepository::replace($lockKey, $existing, null, true)) {
                        $staleRecovered = true;
                        // Retry insert.
                        $inserted = OptionLockRepository::insert($lockKey, $lockValue, true);
                    }
                }
            }
            if (!$inserted) {
                // Prepare message with lock age and outcome.
                $age = 'unknown';
                $outcome = 'unknown';
                if ($existing !== null) {
                    $age = $this->lockAgeSeconds($existing) > 0
                        ? sprintf(AdminLocale::__('%d minutes', 'gr-commerce-suite'), max(1, $this->lockAgeSeconds($existing) / 60))
                        : AdminLocale::__('unknown', 'gr-commerce-suite');
                    $data = json_decode($existing, true);
                    $outcome = is_array($data) ? ($data['outcome'] ?? 'legacy') : 'legacy';
                }
                throw new RuntimeException(sprintf(
                    AdminLocale::__('A closing is already running (held for %1$s; last outcome: %2$s). Check the carrier before clearing an interrupted operation.', 'gr-commerce-suite'),
                    $age,
                    $outcome
                ));
            }
        }
        $dispatchSent = false;
        try {
            // Record replay ledger.
            $request = 'grcs_geniki_close_request_' . hash('sha256', $scope . $input['request_id']);
            if (!OptionLockRepository::insert($request, gmdate('c'))) {
                throw new RuntimeException('This request has already been attempted.');
            }
            $provider = $this->registry->get(CourierSlug::Geniki);
            if (!$provider instanceof GenikiProvider) {
                throw new RuntimeException('Geniki provider unavailable.');
            }
            // Update lock to mark dispatch sent (before the carrier call).
            $dispatchValue = (string) wp_json_encode([
                'owner' => $owner,
                'acquired_at_utc' => $acquiredAt,
                'dispatch_sent' => true,
                'dispatch_at_utc' => gmdate('c'),
                'outcome' => 'dispatched',
                'scope' => $scope,
                'request_id' => $input['request_id'],
            ]);
            if (!OptionLockRepository::replace($lockKey, $lockValue, $dispatchValue, true)) {
                throw new RuntimeException('Lock was lost before dispatch; carrier state is unknown.');
            }
            $lockValue = $dispatchValue;
            $dispatchSent = true;
            $result = $mode === 'today' ? $provider->closePendingJobs() : $provider->closePendingJobsByDate($from, $to);
            if ($result !== 0) {
                // Carrier reported an error; mark lock as ambiguous and do NOT release.
                $ambiguousValue = (string) wp_json_encode([
                    'owner' => $owner,
                    'acquired_at_utc' => $acquiredAt,
                    'dispatch_sent' => true,
                    'dispatch_at_utc' => gmdate('c'),
                    'outcome' => 'ambiguous',
                    'last_error_code' => $result,
                    'scope' => $scope,
                    'request_id' => $input['request_id'],
                ]);
                OptionLockRepository::replace($lockKey, $lockValue, $ambiguousValue, true);
                throw new RuntimeException('Closing was not confirmed.');
            }
            // Carrier success: record cursor.
            $records = get_option(self::OPTION_SUCCESS, []);
            $records = is_array($records) ? $records : [];
            $records[$scope] = ['at_utc' => gmdate('c'), 'mode' => $mode, 'from' => $from->format('c'), 'to' => $to->format('c')];
            if (!update_option(self::OPTION_SUCCESS, $records, false) && get_option(self::OPTION_SUCCESS) !== $records) {
                // Carrier succeeded but local cursor failed: log but do NOT release lock (ambiguous local state).
                $ambiguousValue = (string) wp_json_encode([
                    'owner' => $owner,
                    'acquired_at_utc' => $acquiredAt,
                    'dispatch_sent' => true,
                    'dispatch_at_utc' => gmdate('c'),
                    'outcome' => 'cursor_save_failed',
                    'scope' => $scope,
                    'request_id' => $input['request_id'],
                ]);
                OptionLockRepository::replace($lockKey, $lockValue, $ambiguousValue, true);
                throw new RuntimeException('Carrier closing succeeded but its local record could not be saved. Check the carrier; do not replay.');
            }
            // Confirmed success: release the lock.
            OptionLockRepository::replace($lockKey, $lockValue, null, true);
        } catch (Throwable $e) {
            // Never release once the carrier call may have run: a timeout/5xx can leave jobs closed.
            if (!$dispatchSent) {
                // Exception before dispatch (provider unavailable, replay-ledger collision, lost lock):
                // CAS-release our own not_sent lock so the next closing is not blocked for the whole TTL.
                OptionLockRepository::replace($lockKey, $lockValue, null, true);
            }
            throw $e;
        }
    }

    private function lockAgeSeconds(string $lockValue): int
    {
        $data = json_decode($lockValue, true);
        if (!is_array($data) || !isset($data['acquired_at_utc'])) {
            return -1;
        }
        $acquired = strtotime($data['acquired_at_utc']);
        if ($acquired === false) {
            return -1;
        }
        return time() - $acquired;
    }
}