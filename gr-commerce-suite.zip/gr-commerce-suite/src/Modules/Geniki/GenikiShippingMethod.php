<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Geniki;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Shipping\ConfiguredShippingMethod;
use GRCommerceSuite\Shipping\Pricing\Rules;
use GRCommerceSuite\Support\Money;
use InvalidArgumentException;
use WC_Shipping_Method;

/**
 * Geniki Taxydromiki Shipping Method (`grcs_geniki`).
 *
 * Provides zone-specific fixed delivery prices in WooCommerce checkout.
 * Restricts pricing to fixed merchant rules; avoids BOX NOW dynamic compartment/locker inheritance.
 */
final class GenikiShippingMethod extends ConfiguredShippingMethod
{
    public const METHOD_ID = 'grcs_geniki';

    public function __construct(int $instance_id = 0)
    {
        // Invoke WC_Shipping_Method constructor directly to avoid ConfiguredShippingMethod's BOX NOW dynamic settings initialization
        WC_Shipping_Method::__construct($instance_id);

        $this->id = $this->methodId();
        $this->method_title = AdminLocale::display($this->defaultTitle());
        $this->method_description = AdminLocale::__('Merchant fixed delivery prices for this zone. No live courier quotes.', 'gr-commerce-suite');
        $this->supports = ['shipping-zones', 'instance-settings', 'instance-settings-modal'];

        // Restrict Geniki strictly to fixed pricing; do not inherit BOX NOW dynamic/compartment/locker fields
        $this->instance_form_fields = [
            'enabled' => [
                'title' => AdminLocale::__('Enable/Disable', 'gr-commerce-suite'),
                'type' => 'checkbox',
                'label' => AdminLocale::__('Enable this shipping method', 'gr-commerce-suite'),
                'default' => 'yes',
            ],
            'title' => [
                'title' => AdminLocale::__('Title', 'gr-commerce-suite'),
                'type' => 'text',
                'default' => $this->defaultTitle(),
            ],
            'cost' => [
                'title' => AdminLocale::__('Shipping cost', 'gr-commerce-suite'),
                'type' => 'price',
                'class' => 'grcs-pricing-fixed',
                'description' => AdminLocale::__('Cost in store currency, excluding tax. Enter 0 for free delivery. A blank cost offers no rate.', 'gr-commerce-suite'),
                'default' => '',
            ],
            'free_threshold' => [
                'title' => AdminLocale::__('Free delivery threshold', 'gr-commerce-suite'),
                'type' => 'price',
                'class' => 'grcs-pricing-fixed',
                'description' => AdminLocale::__('Cart total in store currency at which shipping becomes free. Leave blank to disable.', 'gr-commerce-suite'),
                'default' => '',
            ],
            'tax_status' => [
                'title' => AdminLocale::__('Tax status', 'gr-commerce-suite'),
                'type' => 'select',
                'default' => 'taxable',
                'options' => [
                    'taxable' => AdminLocale::__('Taxable', 'gr-commerce-suite'),
                    'none' => AdminLocale::__('None', 'gr-commerce-suite'),
                ],
            ],
        ];

        $this->init_instance_settings();
        $this->enabled = (string) $this->get_option('enabled', 'yes');
        $this->title = (string) $this->get_option('title', $this->defaultTitle());
        $this->tax_status = $this->get_option('tax_status', 'taxable') === 'none' ? 'none' : 'taxable';

        if (function_exists('add_action')) {
            add_action('woocommerce_update_options_shipping_' . $this->id, function (): void {
                $this->process_admin_options();
            });
        }
    }

    protected function methodId(): string
    {
        return self::METHOD_ID;
    }

    protected function defaultTitle(): string
    {
        return AdminLocale::__('Geniki Taxydromiki', 'gr-commerce-suite');
    }

    /**
     * Calculate fixed shipping rate for the package without requiring locker context or compartment rules.
     *
     * @param array<string, mixed> $package
     */
    public function calculate_shipping($package = []): void
    {
        if (!GenikiModule::isEnabled() || $this->instance_id <= 0 || !$this->is_enabled()) {
            return;
        }

        $this->init_instance_settings();
        if ($this->get_option('enabled', 'yes') !== 'yes') {
            return;
        }

        $raw = $this->get_option('cost', '');
        $cost = is_string($raw) || is_int($raw) || is_float($raw) ? (string) $raw : null;

        try {
            if ($cost === null || trim($cost) === '' || Money::fromDecimalString($cost)->cents() < 0) {
                return;
            }

            if (Rules::qualifiesForFreeShipping(is_array($package) ? $package : [], $this->get_option('free_threshold', ''))) {
                $cost = Money::zero()->toDecimalString();
            }
        } catch (InvalidArgumentException) {
            return;
        }

        $this->title = (string) $this->get_option('title', $this->defaultTitle());
        $this->tax_status = $this->get_option('tax_status', 'taxable') === 'none' ? 'none' : 'taxable';

        $this->add_rate([
            'id' => $this->get_rate_id(),
            'label' => $this->get_title(),
            'cost' => $cost,
            'package' => $package,
        ]);
    }
}
