<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Geniki;

use GRCommerceSuite\Contracts\HookSubscriberInterface;

/**
 * Hooks subscriber for Geniki Taxydromiki module.
 *
 * Implements HookSubscriberInterface to dynamically register checkout shipping methods
 * only when the Geniki Taxydromiki module is enabled.
 */
final class GenikiSubscriber implements HookSubscriberInterface
{
    public function register(): void
    {
        add_filter('woocommerce_shipping_methods', [$this, 'filterShippingMethods']);
    }

    /**
     * Register Geniki Taxydromiki shipping method if module is active.
     *
     * @param array<string, mixed> $methods
     * @return array<string, mixed>
     */
    public function filterShippingMethods(array $methods): array
    {
        if (GenikiModule::isEnabled()) {
            $methods[GenikiShippingMethod::METHOD_ID] = GenikiShippingMethod::class;
        }

        return $methods;
    }
}
