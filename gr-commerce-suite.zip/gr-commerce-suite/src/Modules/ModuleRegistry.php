<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Feed\SkroutzXmlGenerator;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Jobs\JobDispatcher;

/**
 * Which optional integrations are active. One option, `grcs_modules` (`key => 'yes'|'no'`).
 *
 * Rules that keep upgrades and history safe:
 *  - The five original integrations default ON; later native integrations and external-plugin setup default OFF. Nothing seeds it; it is written only by
 *    {@see save()} from the Modules form (FeedSafetyDefaults treats any grcs_* row as install history).
 *  - A disabled module stops work from STARTING (schedules, webhook route, checkout picker and assets, shipping method,
 *    new-voucher choices, connection test, settings clutter). Courier providers stay registered: they are lazy, so a
 *    registered but unused provider does nothing, and explicit actions on existing vouchers keep working.
 *  - Credentials, vouchers, orders, feed files and every other option are never deleted or changed by a toggle.
 *  - Independent of the D9/D10 marketplace safety policies and of `grcs_skroutz_feed_enabled`.
 */
final class ModuleRegistry
{
    public const OPTION = 'grcs_modules';

    public const ACS = 'acs';
    public const BOXNOW = 'boxnow';
    public const SKROUTZ = 'skroutz';
    public const BESTPRICE = 'bestprice';
    public const COD_AUTO = 'cod_auto';
    public const AADE_B2B = 'aade_b2b';
    public const GENIKI = 'geniki';
    public const COURIER_CENTER = 'courier_center';
    public const KLARNA = 'klarna';

    /** Required parent modules, declared before their dependants in keys(). */
    private const DEPENDENCIES = [self::BESTPRICE => self::SKROUTZ];

    /** @var array<int, array<string, bool>> Per-site request cache; never carry another site's module choices. */
    private static array $states = [];

    /** @var array<int, bool> Per-site Action Scheduler table existence cache. */
    private static array $actionSchedulerTablesExist = [];

    /** @return list<string> */
    public static function keys(): array
    {
        return [self::ACS, self::BOXNOW, self::SKROUTZ, self::BESTPRICE, self::COD_AUTO, self::AADE_B2B, self::GENIKI, self::COURIER_CENTER, self::KLARNA];
    }

    /** @return array<string, string> module => required parent; COD needs any enabled courier only to schedule work. */
    public static function dependencies(): array
    {
        return self::DEPENDENCIES;
    }

    public static function isEnabled(string $key): bool
    {
        $states = self::states();
        return $states[$key] ?? false;
    }

    /** Saved merchant choice, before dependency gates; use only for preference controls. */
    public static function isRequested(string $key): bool
    {
        return self::preferences()[$key] ?? false;
    }

    public static function courierEnabled(CourierSlug $courier): bool
    {
        return match ($courier) {
            CourierSlug::Acs => self::isEnabled(self::ACS),
            CourierSlug::BoxNow => self::isEnabled(self::BOXNOW),
            CourierSlug::Geniki => self::isEnabled(self::GENIKI),
        };
    }

    /** New native shipments/rates; selecting another BOX NOW owner does not turn off native history/tracking. */
    public static function courierCanCreate(CourierSlug $courier): bool
    {
        return self::courierEnabled($courier)
            && ($courier !== CourierSlug::BoxNow || EmbeddedIntegrations::boxNowOwner() === 'native');
    }

    public static function anyCourierEnabled(): bool
    {
        return self::isEnabled(self::ACS) || self::isEnabled(self::BOXNOW) || self::isEnabled(self::GENIKI);
    }

    /** @return list<CourierSlug> */
    public static function enabledCouriers(): array
    {
        return array_values(array_filter(CourierSlug::cases(), static fn(CourierSlug $courier): bool => self::courierEnabled($courier)));
    }

    /** Forget the per-request cache (tests, and after external option changes). */
    public static function reset(): void
    {
        self::$states = [];
        self::$actionSchedulerTablesExist = [];
    }

    /**
     * Persist requested choices, not dependency-gated states. A locked dependant retains its saved choice even if a hidden
     * fallback is posted. An omitted disabled control on re-enable also retains it; explicit editable values still apply.
     * Returns effectively disabled keys so their pending work can be retired. Nothing else is touched.
     *
     * @param array<string, mixed> $posted
     * @return list<string>
     */
    public static function save(array $posted): array
    {
        $before = self::states();
        $preferences = self::preferences();
        $stored = [];
        foreach (self::keys() as $key) {
            $stored[$key] = isset($posted[$key]) && in_array($posted[$key], ['1', 'yes', true, 1, 'on'], true) ? 'yes' : 'no';
        }
        foreach (self::DEPENDENCIES as $key => $parent) {
            if ($stored[$parent] === 'no' || (!$before[$parent] && !array_key_exists($key, $posted))) {
                $stored[$key] = $preferences[$key] ? 'yes' : 'no';
            }
        }
        update_option(self::OPTION, $stored, false);
        self::reset();
        $turnedOff = array_values(array_filter(self::keys(), static fn(string $key): bool => ($before[$key] ?? false) && !self::isEnabled($key)));
        foreach ($turnedOff as $key) {
            self::retirePendingWork($key);
        }
        return $turnedOff;
    }

    /**
     * Stop scheduled work of a module that was just switched off. Published feed files, vouchers and credentials stay.
     * Recurring courier/COD schedules are also re-evaluated by Plugin::registerRecurringJobs on every Action Scheduler init.
     */
    public static function retirePendingWork(string $key): void
    {
        EmbeddedIntegrations::retire($key);
        if ($key === self::KLARNA) {
            self::cancelPending(Klarna\KlarnaRefreshJob::HOOK);
        }
        if ($key === self::SKROUTZ) {
            // Feed-owned hook: take the publication lock before withdrawing the active run and its pending chunks,
            // so an in-flight finalize cannot swap the pair after the module is off. A busy lock defers to that worker.
            (new SkroutzXmlGenerator())->retirePendingPublication();
            self::cancelPending(SkroutzXmlGenerator::HOOK_CHUNK_ACTION);
            self::cancelPending(SkroutzXmlGenerator::HOOK_SCHEDULED);
        }
        if ($key === self::COD_AUTO || !self::anyCourierEnabled()) {
            self::cancelPending(JobDispatcher::HOOK_COD_DISPATCH);
            self::cancelPending(JobDispatcher::HOOK_COD_RECONCILE_CHUNK);
        }
        if (!self::anyCourierEnabled()) {
            self::cancelPending(JobDispatcher::HOOK_TRACKING_DISPATCH);
            self::cancelPending(JobDispatcher::HOOK_TRACKING_POLL_CHUNK);
        }
    }

    /**
     * Cancel every pending action of a hook whatever its arguments. Action Scheduler's unschedule-all only matches actions
     * with identical arguments, and these jobs carry payloads, so pending ids are listed and cancelled one by one.
     */
    public static function cancelPending(string $hook): void
    {
        if (!function_exists('as_get_scheduled_actions') || !class_exists(\ActionScheduler::class)) {
            return;
        }

        $isDbStore = false;
        try {
            $store = \ActionScheduler::store();
            if ($store instanceof \ActionScheduler_DBStore || $store instanceof \ActionScheduler_HybridStore) {
                $isDbStore = true;
            }
        } catch (\Throwable $e) {
            $isDbStore = false;
        }

        global $wpdb;
        if ($isDbStore && $wpdb instanceof \wpdb) {
            $siteId = function_exists('get_current_blog_id') ? (int) get_current_blog_id() : 0;
            if (!isset(self::$actionSchedulerTablesExist[$siteId])) {
                $table = $wpdb->prefix . 'actionscheduler_actions';
                $exists = $wpdb->get_var(
                    $wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))
                ) === $table;
                if ($exists) {
                    self::$actionSchedulerTablesExist[$siteId] = true;
                } else {
                    return;
                }
            }
        }

        try {
            $ids = as_get_scheduled_actions(['hook' => $hook, 'status' => \ActionScheduler_Store::STATUS_PENDING, 'per_page' => -1], 'ids');
            $store = \ActionScheduler::store();
            foreach (is_array($ids) ? $ids : [] as $id) {
                $store->cancel_action((int) $id);
            }
        } catch (\Throwable $e) {
            // Guard against store or DB exceptions.
        }
    }

    /**
     * Translated card texts. Literal AdminLocale calls keep every string visible to the catalog extractor.
     *
     * @return array<string, array{label: string, description: string, off: string, parent?: string, plugin?: string}>
     */
    public static function definitions(): array
    {
        return [
            self::GENIKI => Geniki\GenikiModule::definition(),
            self::COURIER_CENTER => CourierCenter\CourierCenterModule::definition(),
            self::KLARNA => Klarna\KlarnaModule::definition(),
            self::ACS => [
                'label' => AdminLocale::__('ACS Courier', 'gr-commerce-suite'),
                'description' => AdminLocale::__('Vouchers, tracking and shipping rates for ACS.', 'gr-commerce-suite'),
                'off' => AdminLocale::__('No new ACS vouchers or ACS shipping rate at checkout, and no ACS tracking, COD checks or connection tests. Existing vouchers, orders and credentials stay.', 'gr-commerce-suite'),
            ],
            self::BOXNOW => [
                'label' => AdminLocale::__('BOX NOW', 'gr-commerce-suite'),
                'description' => AdminLocale::__('Locker picker at checkout, vouchers, tracking and webhook.', 'gr-commerce-suite'),
                'off' => AdminLocale::__('No locker picker or BOX NOW shipping rate at checkout, no webhook, no new BOX NOW vouchers, no tracking or connection tests. Existing vouchers, orders and credentials stay.', 'gr-commerce-suite'),
            ],
            self::SKROUTZ => [
                'label' => AdminLocale::__('Skroutz XML feed', 'gr-commerce-suite'),
                'description' => AdminLocale::__('Generate the product feed for Skroutz.', 'gr-commerce-suite'),
                'off' => AdminLocale::__('No feed generation, settings or status. The last published feed file stays online and is no longer updated: remove the feed URL at Skroutz if you stop selling there.', 'gr-commerce-suite'),
            ],
            self::BESTPRICE => [
                'label' => AdminLocale::__('BestPrice preview', 'gr-commerce-suite'),
                'description' => AdminLocale::__('Preview notes only. No BestPrice feed is published.', 'gr-commerce-suite'),
                'off' => AdminLocale::__('BestPrice preview notes are hidden. Nothing else changes.', 'gr-commerce-suite'),
                'parent' => self::DEPENDENCIES[self::BESTPRICE],
            ],
            self::AADE_B2B => [
                'label' => AadeB2b\Text::get('module'),
                'description' => AadeB2b\Text::get('description'),
                'off' => AadeB2b\Text::get('off'),
            ],
            self::COD_AUTO => [
                'label' => AdminLocale::__('Automatic COD reconciliation', 'gr-commerce-suite'),
                'description' => AdminLocale::__('Daily check of cash-on-delivery payouts with the couriers.', 'gr-commerce-suite'),
                'off' => AdminLocale::__('No daily COD checks with the couriers. The COD page, manual CSV reconciliation, history and the customer blacklist stay available.', 'gr-commerce-suite'),
            ],
        ];
    }

    /** @return array<string, bool> */
    private static function states(): array
    {
        $siteId = function_exists('get_current_blog_id') ? get_current_blog_id() : 0;
        if (isset(self::$states[$siteId])) {
            return self::$states[$siteId];
        }
        $states = self::preferences();
        foreach (self::DEPENDENCIES as $key => $parent) {
            if (!$states[$parent]) {
                $states[$key] = false;
            }
        }
        return self::$states[$siteId] = $states;
    }

    /** @return array<string, bool> Saved per-site preferences; absent keys retain upgrade behaviour without writes. */
    private static function preferences(): array
    {
        $stored = function_exists('get_option') ? get_option(self::OPTION, []) : [];
        $stored = is_array($stored) ? $stored : [];
        $preferences = [];
        foreach (self::keys() as $key) {
            $preferences[$key] = in_array($key, [self::AADE_B2B, self::GENIKI, self::COURIER_CENTER, self::KLARNA], true) ? ($stored[$key] ?? null) === 'yes' : ($stored[$key] ?? 'yes') !== 'no';
        }
        return $preferences;
    }
}
