<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\AadeB2b;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Frontend\GreekInvoiceCheckout;
use GRCommerceSuite\Security\CredentialVault;
use GRCommerceSuite\Services\AadeRegistryLookup;

/** Module-owned entry point; construction and registration perform no lookup. */
final class Module implements HookSubscriberInterface
{
    public const KEY = 'aade_b2b';

    public static function enabled(): bool
    {
        $preferences = get_option('grcs_modules', []);
        return is_array($preferences) && ($preferences[self::KEY] ?? null) === 'yes';
    }

    /** @return array{key: string, default: string, label: string, description: string, off: string} */
    public static function definition(): array
    {
        return ['key' => self::KEY, 'default' => 'no', 'label' => Text::get('module'), 'description' => Text::get('description'), 'off' => Text::get('off')];
    }

    public function __construct(private readonly OrderPage $page)
    {
    }

    public static function create(AadeRegistryLookup $lookup, CredentialVault $vault): self
    {
        $check = new OrderRegistryCheck(
            self::enabled(...),
            $lookup->lookup(...),
            $lookup->isSimulation(...),
            static function () use ($vault): string {
                $credentials = $vault->getAade();
                if (trim($credentials['username']) === '' || $credentials['password'] === '') {
                    return 'missing_credentials';
                }
                $afm = get_option(GreekInvoiceCheckout::OPTION_STORE_AFM, '');
                return is_string($afm) && GreekInvoiceCheckout::validVat(trim($afm)) ? 'ready' : 'missing_store_afm';
            }
        );
        return new self(new OrderPage($check, self::enabled(...)));
    }

    public function register(): void
    {
        if (self::enabled()) {
            $this->page->register();
        }
    }
}
