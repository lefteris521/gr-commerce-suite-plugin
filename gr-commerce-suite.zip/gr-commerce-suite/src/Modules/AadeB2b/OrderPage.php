<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\AadeB2b;

use Closure;
use WC_Order;

/** A separate admin page avoids embedding a form inside WooCommerce's order-edit form. */
final class OrderPage
{
    public const SLUG = 'grcs-aade-b2b';
    private const NONCE = 'grcs_aade_b2b_order_';

    /** @param Closure(): bool $enabled */
    public function __construct(private readonly OrderRegistryCheck $check, private readonly Closure $enabled)
    {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'addPage']);
        add_action('woocommerce_admin_order_data_after_billing_address', [$this, 'renderLink']);
    }

    public function addPage(): void
    {
        if (($this->enabled)()) {
            add_submenu_page('', Text::get('open'), Text::get('open'), 'manage_woocommerce', self::SLUG, [$this, 'render']);
        }
    }

    public function canAccess(int $orderId): bool
    {
        return ($this->enabled)() && $orderId > 0 && current_user_can('manage_woocommerce')
            && current_user_can('edit_shop_orders') && current_user_can('edit_shop_order', $orderId);
    }

    public function renderLink(WC_Order $order): void
    {
        $id = $order->get_id();
        if (!$this->canAccess($id) || $order->get_meta('_grcs_document_type', true) !== 'invoice') {
            return;
        }
        echo '<p><a href="' . esc_url($this->url($id)) . '">' . esc_html(Text::get('open')) . '</a></p>';
    }

    private function url(int $id): string
    {
        return add_query_arg(['page' => self::SLUG, 'order_id' => $id], admin_url('admin.php'));
    }

    private function nonceAction(WC_Order $order): string
    {
        $vat = $order->get_meta('_grcs_vat_number', true);
        return self::NONCE . $order->get_id() . '_' . hash('sha256', is_string($vat) ? $vat : '');
    }

    /** @param array<string, mixed> $post
     * @return array{status: string, details: array<string, string>|null}
     */
    public function process(WC_Order $order, array $post): array
    {
        if (!$this->canAccess($order->get_id())) {
            return ['status' => 'disabled', 'details' => null];
        }
        $nonce = $post['_grcs_aade_nonce'] ?? '';
        if (!is_string($nonce) || !wp_verify_nonce(wp_unslash($nonce), $this->nonceAction($order))) {
            return ['status' => 'bad_nonce', 'details' => null];
        }
        if (($post['authorize'] ?? null) !== 'yes') {
            return ['status' => 'consent_required', 'details' => null];
        }
        return $this->check->check($order);
    }

    public function render(): void
    {
        $raw = $_GET['order_id'] ?? '';
        $id = is_scalar($raw) ? absint($raw) : 0;
        if (!$this->canAccess($id)) {
            wp_die(esc_html(Text::get('denied')), '', ['response' => 403]);
        }
        $order = wc_get_order($id);
        if (!$order instanceof WC_Order) {
            wp_die(esc_html(Text::get('denied')), '', ['response' => 404]);
        }
        nocache_headers();
        $result = null;
        if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
            $result = $this->process($order, $_POST);
        }
        echo '<div class="wrap"><h1>' . esc_html(Text::get('open')) . '</h1><p>' . esc_html(Text::get('explain')) . '</p>';
        $vat = $order->get_meta('_grcs_vat_number', true);
        echo '<p><strong>' . esc_html(Text::get('order')) . ':</strong> ' . esc_html($order->get_order_number()) . '<br />'
            . '<strong>' . esc_html(Text::get('billing_company')) . ':</strong> ' . esc_html($order->get_billing_company()) . '<br />'
            . '<strong>' . esc_html(Text::get('invoice_afm')) . ':</strong> ' . esc_html(is_string($vat) ? $vat : '') . '</p>';
        if ($result !== null) {
            echo '<p role="status">' . esc_html(Text::get($result['status'])) . '</p>';
            if (is_array($result['details'])) {
                echo '<dl>';
                foreach (['company', 'doy', 'profession', 'address', 'postcode', 'city'] as $key) {
                    $value = $result['details'][$key] ?? '';
                    if ($value !== '') {
                        echo '<dt><strong>' . esc_html(Text::get($key)) . '</strong></dt><dd>' . esc_html($value) . '</dd>';
                    }
                }
                echo '</dl>';
            }
        }
        echo '<form method="post" action="' . esc_url($this->url($id)) . '">';
        wp_nonce_field($this->nonceAction($order), '_grcs_aade_nonce');
        echo '<p><label><input type="checkbox" name="authorize" value="yes" required /> ' . esc_html(Text::get('authorize')) . '</label></p>';
        echo '<p><button type="submit" class="button button-primary">' . esc_html(Text::get('submit')) . '</button></p></form></div>';
    }
}
