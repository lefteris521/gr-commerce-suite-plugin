<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\AadeB2b;

use GRCommerceSuite\I18n\AdminLocale;

/** Module-local bilingual copy follows the GRCS admin language preference. */
final class Text
{
    public static function get(string $key): string
    {
        $strings = [
            'module' => ['AADE business registry', 'Μητρώο επιχειρήσεων ΑΑΔΕ'],
            'description' => ['Manually look up an invoice order’s AFM in the AADE business registry.', 'Χειροκίνητη αναζήτηση ΑΦΜ παραγγελίας τιμολογίου στο μητρώο επιχειρήσεων της ΑΑΔΕ.'],
            'off' => ['No new registry lookups from this module. Existing invoice data and credentials stay.', 'Δεν γίνονται νέες αναζητήσεις μητρώου από αυτή την ενότητα. Τα υπάρχοντα στοιχεία τιμολογίου και οι κωδικοί παραμένουν.'],
            'open' => ['AADE registry lookup', 'Αναζήτηση μητρώου ΑΑΔΕ'],
            'explain' => ['This sends the invoice AFM to AADE using the store’s credentials. A registry record is not a VAT validation or legal verification. Billing and order data are not changed.', 'Η ενέργεια αποστέλλει το ΑΦΜ τιμολογίου στην ΑΑΔΕ με τους κωδικούς του καταστήματος. Η εγγραφή στο μητρώο δεν αποτελεί έλεγχο ΦΠΑ ή νομική επαλήθευση. Τα στοιχεία χρέωσης και παραγγελίας δεν αλλάζουν.'],
            'authorize' => ['I authorize sending this invoice AFM to AADE for this lookup.', 'Εγκρίνω την αποστολή του ΑΦΜ αυτού του τιμολογίου στην ΑΑΔΕ για αυτή την αναζήτηση.'],
            'submit' => ['Look up registry record', 'Αναζήτηση εγγραφής μητρώου'],
            'order' => ['Order', 'Παραγγελία'],
            'billing_company' => ['Billing company', 'Επωνυμία χρέωσης'],
            'invoice_afm' => ['Invoice AFM', 'ΑΦΜ τιμολογίου'],
            'consent_required' => ['Select the authorization checkbox before requesting a lookup.', 'Επιλέξτε την έγκριση πριν ζητήσετε αναζήτηση.'],
            'bad_nonce' => ['The security check failed. Reload the page and try again.', 'Ο έλεγχος ασφαλείας απέτυχε. Φορτώστε ξανά τη σελίδα και δοκιμάστε πάλι.'],
            'disabled' => ['The module is disabled.', 'Η ενότητα είναι απενεργοποιημένη.'],
            'not_invoice' => ['This order has no invoice AFM to look up.', 'Η παραγγελία δεν έχει ΑΦΜ τιμολογίου για αναζήτηση.'],
            'invalid_format' => ['The invoice AFM fails the local format or checksum check. This is not a registry lookup.', 'Το ΑΦΜ τιμολογίου αποτυγχάνει στον τοπικό έλεγχο μορφής ή ψηφίου ελέγχου. Δεν έγινε αναζήτηση στο μητρώο.'],
            'missing_credentials' => ['AADE service credentials are missing or unavailable. Configure them in the existing invoice settings.', 'Οι ειδικοί κωδικοί ΑΑΔΕ λείπουν ή δεν είναι διαθέσιμοι. Ρυθμίστε τους στις υπάρχουσες ρυθμίσεις τιμολογίου.'],
            'missing_store_afm' => ['The store AFM is missing or fails the local checksum. Check the existing invoice settings.', 'Το ΑΦΜ καταστήματος λείπει ή αποτυγχάνει στον τοπικό έλεγχο. Ελέγξτε τις υπάρχουσες ρυθμίσεις τιμολογίου.'],
            'unavailable' => ['No registry record could be retrieved. The service may be unavailable or reject the request; this does not establish whether the AFM is valid.', 'Δεν ήταν δυνατή η ανάκτηση εγγραφής. Η υπηρεσία μπορεί να μην είναι διαθέσιμη ή να απέρριψε το αίτημα· αυτό δεν αποδεικνύει αν το ΑΦΜ είναι έγκυρο.'],
            'record_found' => ['Registry record retrieved. VAT status and legal eligibility have not been verified.', 'Ανακτήθηκε εγγραφή μητρώου. Το καθεστώς ΦΠΑ και η νομική επιλεξιμότητα δεν έχουν επαληθευτεί.'],
            'simulated' => ['Simulation only: these are test details, not an AADE response or VAT validation.', 'Μόνο προσομοίωση: αυτά είναι δοκιμαστικά στοιχεία, όχι απάντηση ΑΑΔΕ ή έλεγχος ΦΠΑ.'],
            'company' => ['Company name', 'Επωνυμία'],
            'doy' => ['Tax office', 'ΔΟΥ'],
            'profession' => ['Business activity', 'Δραστηριότητα'],
            'address' => ['Registered address', 'Διεύθυνση έδρας'],
            'postcode' => ['Postcode', 'Ταχυδρομικός κώδικας'],
            'city' => ['City', 'Πόλη'],
            'denied' => ['You cannot access this order or the module is disabled.', 'Δεν έχετε πρόσβαση στην παραγγελία ή η ενότητα είναι απενεργοποιημένη.'],
        ];
        return $strings[$key][AdminLocale::locale() === 'el' ? 1 : 0] ?? '';
    }
}
