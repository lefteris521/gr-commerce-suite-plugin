<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\AadeB2b;

use Closure;
use GRCommerceSuite\Frontend\GreekInvoiceCheckout;
use Throwable;
use WC_Order;

/** An explicitly requested, read-only lookup of the existing invoice AFM. */
final class OrderRegistryCheck
{
    /**
     * @param Closure(): bool $enabled Must default to false when the module preference is absent.
     * @param Closure(string): ?array<string, string> $lookup Existing AADE registry lookup.
     * @param Closure(): bool $simulation True when the lookup returns test data.
     * @param Closure(): string $readiness Returns ready, missing_credentials or missing_store_afm.
     */
    public function __construct(
        private readonly Closure $enabled,
        private readonly Closure $lookup,
        private readonly Closure $simulation,
        private readonly ?Closure $readiness = null,
    ) {
    }

    /**
     * A returned record does not establish VAT status; null includes service and credential failures.
     * No order or customer data is changed or stored by this operation.
     *
     * @return array{status: string, details: array<string, string>|null}
     */
    public function check(WC_Order $order): array
    {
        if (!(($this->enabled)())) {
            return ['status' => 'disabled', 'details' => null];
        }
        if ($order->get_meta('_grcs_document_type', true) !== 'invoice') {
            return ['status' => 'not_invoice', 'details' => null];
        }
        $vat = $order->get_meta('_grcs_vat_number', true);
        if (!is_string($vat) || !GreekInvoiceCheckout::validVat($vat)) {
            return ['status' => 'invalid_format', 'details' => null];
        }
        try {
            $simulated = ($this->simulation)();
            if (!$simulated && $this->readiness !== null) {
                $readiness = ($this->readiness)();
                if ($readiness !== 'ready') {
                    return ['status' => in_array($readiness, ['missing_credentials', 'missing_store_afm'], true) ? $readiness : 'unavailable', 'details' => null];
                }
            }
            $details = ($this->lookup)($vat);
        } catch (Throwable) {
            return ['status' => 'unavailable', 'details' => null];
        }
        if ($details === null || !isset($details['company']) || !is_string($details['company']) || trim($details['company']) === '') {
            return ['status' => 'unavailable', 'details' => null];
        }
        return ['status' => $simulated ? 'simulated' : 'record_found', 'details' => $details];
    }
}
