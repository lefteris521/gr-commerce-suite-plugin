<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use RuntimeException;

/** Classified Klarna failure. Carries only identifiers safe to log (never request/response bodies). */
final class KlarnaException extends RuntimeException
{
    public const NOT_CONFIGURED = 'not_configured';
    public const LICENSE = 'license';          // no active GRCS licence: new Klarna payments are blocked
    public const TRANSPORT = 'transport';      // failed before the request left: safe to retry
    public const AMBIGUOUS = 'ambiguous';      // request may have been processed: never blindly repeat non-idempotent calls
    public const AUTH = 'auth';                // 401: credentials rejected
    public const FORBIDDEN = 'forbidden';      // 403: operation not allowed in the order's current state
    public const NOT_FOUND = 'not_found';
    public const VALIDATION = 'validation';    // 400/422
    public const CONFLICT = 'conflict';        // 409: data does not match the session for the authorization
    public const RATE_LIMITED = 'rate_limited';
    public const SERVER = 'server';

    /** @param list<string> $messages */
    public function __construct(
        public readonly string $kind,
        string $message,
        public readonly int $status = 0,
        public readonly string $errorCode = '',
        public readonly string $correlationId = '',
        public readonly array $messages = [],
    ) {
        parent::__construct($message);
    }

    /** True when the remote side may have acted on the request. */
    public function isAmbiguous(): bool
    {
        return $this->kind === self::AMBIGUOUS || $this->kind === self::SERVER;
    }

    /** True for a rejection that means the authorization / session must be redone by the customer. */
    public function needsReauthorization(): bool
    {
        return in_array($this->kind, [self::CONFLICT, self::VALIDATION, self::NOT_FOUND, self::FORBIDDEN], true);
    }
}
