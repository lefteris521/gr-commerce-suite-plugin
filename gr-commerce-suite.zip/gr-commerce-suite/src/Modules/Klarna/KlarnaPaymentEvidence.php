<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\Payments\LedgerException;
use GRCommerceSuite\Payments\PaymentLedger;
use WC_Order;

/**
 * Klarna's adapter for the payment-attempt ledger (D1 v4 seams e and f): provider evidence decides, nothing else.
 *
 *  - ACCEPTED plus a paid WooCommerce order  -> `succeeded`.
 *  - REJECTED (Klarna's own refusal)         -> `failed`.
 *  - a definite refusal of the create call   -> `failed`.
 *  - PENDING, a missing id, `creating`, a timeout / 5xx / ambiguous create, or evidence that does not match the immutable context
 *    committed at admission -> the attempt stays unresolved.
 * `closedAtKlarna()` alone never ends an attempt (it does not prove nothing was captured). A local status, a cookie, a lock or the clock
 * never does either. Works with the module OFF and the licence expired: it reconciles existing orders and opens no payment.
 */
final class KlarnaPaymentEvidence
{
    /** Called after Klarna's fraud decision was applied to the order, from the synchronous create and from every later refresh / callback. */
    public static function observe(WC_Order $order, KlarnaOrderRecord $record, string $fraudStatus): void
    {
        $outcome = null;
        if ($fraudStatus === 'ACCEPTED' && $order->is_paid() && $record->klarnaOrderId() !== '') {
            $outcome = [PaymentLedger::STATE_SUCCEEDED, 'klarna_order_accepted', $record->klarnaOrderId()];
        } elseif ($fraudStatus === 'REJECTED' && $record->klarnaOrderId() !== '') {
            $outcome = [PaymentLedger::STATE_FAILED, 'klarna_order_rejected', $record->klarnaOrderId()];
        }
        if ($outcome === null) {
            return;
        }
        $placed = $record->placed();
        if ($placed !== null && !self::matchesAdmissionContext($order->get_id(), $placed['amount'], $placed['currency'])) {
            return; // does not match what was admitted: stays blocking, the merchant sees it
        }
        self::settle($order, $outcome[0], $outcome[1], $outcome[2]);
    }

    /** Klarna definitively refused to create the order: no Klarna order exists, nothing can be charged. */
    public static function createRefused(WC_Order $order, string $code): void
    {
        self::settle($order, PaymentLedger::STATE_FAILED, 'klarna_create_refused', substr($code, 0, 191));
    }

    /** No create call was sent to Klarna for this attempt: it is over, with nothing charged and nothing to reconcile. */
    public static function notDispatched(WC_Order $order): void
    {
        self::settle($order, PaymentLedger::STATE_FAILED, 'klarna_not_dispatched', 'no_provider_call');
    }

    /** True when there is no complete admission context for the order, or the evidence equals it exactly (amount in minor units, currency). */
    public static function matchesAdmissionContext(int $orderId, int $amountMinor, string $currency, bool $orderManagement = false): bool
    {
        try {
            $ledger = PaymentLedger::fromGlobals();
            $context = $ledger->contextForOrder($orderId, $ledger->blockingAttemptForOrder($orderId)); // the attempt the evidence will settle
        } catch (LedgerException) {
            // A ledger recorded as ready that cannot be read stays blocking for evidence settlement, but order management (capture/cancel/refund)
            // of existing orders is not gated (owner decision 2026-11-01 (c)). An unready or never-installed ledger holds no trustworthy context
            // and is never written to (see settle()), so the legacy identity checks alone keep existing Klarna orders reconcilable.
            return $orderManagement || Schema::storedLedgerReady() !== true;
        }

        return $context === null || ($context['amount_minor'] === $amountMinor && $context['currency'] === strtoupper($currency));
    }

    private static function settle(WC_Order $order, string $to, string $evidenceType, string $evidenceRef): void
    {
        if (!KlarnaModule::ledgerReady(false)) {
            return; // an unready ledger is never written to; the attempt (if any) stays blocking
        }
        try {
            $ledger = PaymentLedger::fromGlobals();
            $attempt = $ledger->blockingAttemptForOrder($order->get_id());
            if ($attempt !== null) {
                $ledger->transition($attempt, $to, 'provider', null, $evidenceType, $evidenceRef, null, null);
            }
        } catch (LedgerException) {
            // the attempt stays blocking: a failed or ambiguous transition is never read as "resolved"
        }
    }
}
