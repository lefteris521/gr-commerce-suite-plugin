<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Support\Lock;
use WC_Order;

/**
 * Turns an authorised Klarna session into a Klarna order for one WooCommerce order.
 *
 * Invariants:
 *  - The authorised quote is bound to the shopper's WooCommerce session; the WC order must reproduce its fingerprint.
 *    A different cart means "authorise again" - a recomputed payload is never sent.
 *  - Per-order lock plus stored Klarna order id: a second submit, retry or concurrent request cannot create a second order.
 *  - An ambiguous create (timeout after transmission, 5xx, 2xx without an order id) is never retried or failed: the order
 *    is held, and the push callback / refresh resolves it.
 *  - The order is only marked paid from Klarna's own create/refresh response with fraud status ACCEPTED, never from a redirect.
 *  - One unresolved Klarna order per VERIFIED shopper (account, own session order, signed guest proof - never a typed email): while
 *    another such order has an unconfirmed create or is not finally decided, and while the Klarna session already belongs to another
 *    order, nothing new is created. That state is read from the persisted orders under account- and session-scoped locks (the
 *    cross-gateway checkout lock lives in {@see KlarnaCheckoutCoordinator}), never from the WooCommerce session alone.
 */
final class KlarnaPaymentService
{
    public const PLACED = 'placed';
    public const ALREADY = 'already';
    public const BUSY = 'busy';
    public const STALE = 'stale';
    public const REJECTED = 'rejected';
    public const AMBIGUOUS = 'ambiguous';
    /** Another Klarna order of the same shopper is unresolved (or this session already belongs to an order): nothing is created. */
    public const BLOCKED = 'blocked';

    public function __construct(
        private readonly KlarnaApiClient $api,
        private readonly KlarnaSettings $settings,
        private readonly KlarnaPayloadFactory $factory,
        private readonly KlarnaOrderManagement $management,
        private readonly LoggerInterface $logger,
        private readonly \Closure $licensed,
        private readonly ?KlarnaOrderLookup $lookup = null,
    ) {
    }

    /**
     * @param array<string, mixed> $sessionRecord Server-side record from {@see KlarnaSessionService::record()}.
     * @return array{status: string, message: string, redirect: string}
     */
    public function place(WC_Order $order, string $token, array $sessionRecord): array
    {
        $record = new KlarnaOrderRecord($order);
        if ($record->klarnaOrderId() !== '') {
            return $record->fraudStatus() === 'REJECTED'
                ? $this->result(self::REJECTED, 'Klarna could not approve this purchase. Please choose another payment method.')
                : $this->result(self::ALREADY, 'This order is already placed with Klarna.');
        }
        // An earlier create whose outcome is unconfirmed is answered below from the stored phase, whatever the licence says and
        // whether or not a token is at hand: it is never created again.
        if (!in_array($record->phase(), [KlarnaOrderRecord::PHASE_AMBIGUOUS, KlarnaOrderRecord::PHASE_CREATING], true)) {
            $refused = $this->refuseNewOrder($token);
            if ($refused !== null) {
                return $refused;
            }
        }
        $lock ='klarna-order-' . $order->get_id();
        if (!Lock::acquire($lock, 60)) {
            return $this->result(self::BUSY, 'Your payment is already being processed.');
        }
        try {
            // Re-read inside the lock: a concurrent request may have placed the order meanwhile.
            $fresh = function_exists('wc_get_order') ? \wc_get_order($order->get_id()) : $order;
            if ($fresh instanceof WC_Order && (string) $fresh->get_meta(KlarnaOrderRecord::META_ORDER_ID) !== '') {
                return (new KlarnaOrderRecord($fresh))->fraudStatus() === 'REJECTED'
                    ? $this->result(self::REJECTED, 'Klarna could not approve this purchase. Please choose another payment method.')
                    : $this->result(self::ALREADY, 'This order is already placed with Klarna.');
            }
            // CREATING survives only if an earlier request died after the (persisted) intent but before any answer: Klarna may hold
            // an order for it, so it is handled exactly like an ambiguous result - never create again, never rotate the callback secret.
            $phase = $fresh instanceof WC_Order ? (string) $fresh->get_meta(KlarnaOrderRecord::META_PHASE) : $record->phase();
            if (in_array($phase, [KlarnaOrderRecord::PHASE_AMBIGUOUS, KlarnaOrderRecord::PHASE_CREATING], true)) {
                if ($order->has_status(['pending', 'failed'])) {
                    $order->update_status('on-hold', 'An earlier Klarna attempt was not confirmed. Do not retry or ship; the Klarna push callback or "Link Klarna order" will resolve it.');
                    $order->save();
                }
                return $this->result(self::AMBIGUOUS, 'Klarna has not confirmed the earlier attempt yet.');
            }
            // The phase above was read again inside the lock, so the gates are repeated here: nothing reaches create() without them.
            return $this->refuseNewOrder($token) ?? $this->createUnlessConflicting($order, $record, $token, $sessionRecord);
        } finally {
            Lock::release($lock);
        }
    }

    /**
     * The per-order lock does not serialise two different orders of one shopper (two tabs, a second device, a cleared cookie), so the
     * shopper and the Klarna session are locked as well, and the persisted orders are checked while they are held. The lock is kept
     * through create(): its CREATING marker and owner stamp are saved before the Klarna call, so the next request sees them.
     *
     * @param array<string, mixed> $sessionRecord
     * @return array{status: string, message: string, redirect: string}
     */
    private function createUnlessConflicting(WC_Order $order, KlarnaOrderRecord $record, string $token, array $sessionRecord): array
    {
        $sessionId = (string) ($sessionRecord['session_id'] ?? '');
        $names = [];
        $user = (int) $order->get_customer_id();
        if ($user > 0) {
            $names[] = 'klarna-shopper-u' . $user;
        }
        if ($sessionId !== '') {
            $names[] = 'klarna-session-' . substr(hash('sha256', $sessionId), 0, 32);
        }
        $held = [];
        try {
            foreach ($names as $name) {
                if (!Lock::acquire($name, 90)) {
                    return $this->result(self::BUSY, 'Your payment is already being processed.');
                }
                $held[] = $name;
            }
            $lookup = $this->lookup ?? new KlarnaOrderLookup();
            if ($lookup->usingSession($sessionId, $order->get_id()) !== null) {
                // The token may belong to the other order's request: it is not released here.
                return $this->result(self::BLOCKED, 'This Klarna approval is already in use. Please approve the payment again.');
            }
            // Verified identity only: the order's account, the shopper's own session order and their signed proof cookie. A billing email
            // is never evidence of who someone is (it would let a stranger block a customer, or learn that they have a payment pending).
            if ($lookup->unresolvedForShopper((int) $order->get_customer_id(), KlarnaShopperProof::orderIds(), $order->get_id()) !== null) {
                $this->release($token); // nothing was created: do not leave the shopper's approval open
                return $this->result(self::BLOCKED, 'A previous Klarna payment is still being verified. Please wait for its confirmation before trying again.');
            }
            return $this->create($order, $record, $token, $sessionRecord);
        } finally {
            foreach (array_reverse($held) as $name) {
                Lock::release($name);
            }
        }
    }

    /**
     * Gates for a genuinely new Klarna order: an active licence and an authorisation token. Null = allowed to create.
     *
     * @return array{status: string, message: string, redirect: string}|null
     */
    private function refuseNewOrder(string $token): ?array
    {
        if (!($this->licensed)()) {
            // New authorisations/orders need an active licence. A token the customer already holds is released, not used.
            $this->release($token);
            return $this->result(self::STALE, 'Klarna is not available right now. Please choose another payment method.');
        }
        if ($token === '') {
            return $this->result(self::STALE, 'Please approve the payment with Klarna before placing the order.');
        }
        return null;
    }

    /**
     * @param array<string, mixed> $sessionRecord
     * @return array{status: string, message: string, redirect: string}
     */
    private function create(WC_Order $order, KlarnaOrderRecord $record, string $token, array $sessionRecord): array
    {
        $authorized = $sessionRecord['quote'] ?? null;
        $sessionId = (string) ($sessionRecord['session_id'] ?? '');
        if (!$this->settings->ready()) {
            return $this->result(self::STALE, 'Klarna is not available right now. Please choose another payment method.');
        }
        if (!is_array($authorized) || $sessionId === '' || ($sessionRecord['environment'] ?? '') !== $this->settings->environment()) {
            return $this->result(self::STALE, 'Your Klarna session expired. Please choose Klarna again.');
        }
        try {
            $current = $this->factory->fromOrder($order);
        } catch (\InvalidArgumentException) {
            $this->release($token);
            return $this->result(self::STALE, 'The order could not be prepared for Klarna.');
        }
        if (!hash_equals((string) $authorized['fingerprint'], $current['fingerprint'])) {
            $this->release($token);
            return $this->result(self::STALE, 'Your order changed after you approved it with Klarna. Please approve it again.');
        }

        // Bind the token to this checkout's session: Klarna reports a closed session, and the token it holds when it is known.
        try {
            $remoteSession = $this->api->readSession($sessionId);
        } catch (KlarnaException $e) {
            return $e->isAmbiguous() || $e->kind === KlarnaException::TRANSPORT
                ? $this->result(self::STALE, 'Klarna could not be reached. Please try again.')
                : $this->result(self::STALE, 'Your Klarna session expired. Please choose Klarna again.');
        }
        $remoteToken = (string) ($remoteSession['authorization_token'] ?? '');
        if (($remoteSession['status'] ?? '') === 'complete' || ($remoteToken !== '' && !hash_equals($remoteToken, $token))) {
            return $this->result(self::STALE, 'This Klarna approval cannot be used for this order. Please approve it again.');
        }

        // Persist intent before the request: from here on an unknown outcome must be reconcilable.
        $secret = bin2hex(random_bytes(16));
        $record->setCallbackSecretHash(KlarnaOrderRecord::hashSecret($secret));
        $order->update_meta_data(KlarnaOrderRecord::META_SESSION, $sessionId); // lets a later cancel release an unused authorisation
        $record->stampOwner(); // persistent shopper scope for the one-unresolved-order rule
        $record->markPhase(KlarnaOrderRecord::PHASE_CREATING);
        $order->save();

        /** @var array{lines: list<array<string, mixed>>, order_amount: int, order_tax_amount: int, currency: string, country: string, fingerprint: string} $authorized */
        $payload = $this->factory->orderPayload($authorized, $order, [
            'confirmation' => $order->get_checkout_order_received_url(),
            'notification' => KlarnaRestController::url('notification', ['o' => (string) $order->get_id(), 'k' => $secret], '&klarna_order_id={order.id}'),
            'push' => KlarnaRestController::url('push', ['o' => (string) $order->get_id(), 'k' => $secret], '&klarna_order_id={order.id}'),
        ]);

        try {
            $created = $this->api->createOrder($token, $payload);
        } catch (KlarnaException $e) {
            if ($e->isAmbiguous()) {
                $record->markPhase(KlarnaOrderRecord::PHASE_AMBIGUOUS);
                $order->update_status('on-hold', 'Klarna did not confirm the order (' . $e->kind . '). Do not retry or ship; the Klarna push callback or "Refresh from Klarna" will resolve it.');
                $order->save();
                return $this->result(self::AMBIGUOUS, 'Klarna has not confirmed your payment yet. We will email you when it is confirmed.');
            }
            $record->markPhase('');
            if ($e->kind !== KlarnaException::TRANSPORT) {
                KlarnaPaymentEvidence::createRefused($order, $e->errorCode !== '' ? $e->errorCode : 'HTTP ' . $e->status);
            }
            $order->add_order_note('Klarna refused to create the order (' . ($e->errorCode !== '' ? $e->errorCode : 'HTTP ' . $e->status) . ' ' . $e->correlationId . ').');
            $order->save();
            if ($e->kind !== KlarnaException::TRANSPORT) {
                $this->release($token);
            }
            return $this->result(self::REJECTED, $e->needsReauthorization()
                ? 'Klarna could not use your approval. Please approve the payment again or choose another payment method.'
                : 'Klarna could not process this payment. Please choose another payment method.');
        }

        $record->setPlaced($created['order_id'], $created['fraud_status'], $sessionId, $created['authorized_payment_method'], [
            'amount' => $current['order_amount'],
            'currency' => $current['currency'],
            'country' => $current['country'],
            'environment' => $this->settings->environment(),
            'region' => $this->settings->region(),
        ], $authorized['lines']);
        // Persist the Klarna order id before any WooCommerce hook runs (payment_complete fires third-party code that may throw).
        $order->save();
        $this->management->applyFraudStatus($order, $record, $created['fraud_status']);
        $order->save();
        if ($this->settings->environment() === 'playground' && $created['fraud_status'] !== 'REJECTED') {
            $this->settings->recordPlaygroundOrder(); // evidence of real test checkouts, one of the live-activation requirements
        }
        $this->logger->info('Klarna order created for WooCommerce order ' . $order->get_id() . ' (' . $created['order_id'] . ').');

        if ($created['fraud_status'] === 'REJECTED') {
            return $this->result(self::REJECTED, 'Klarna could not approve this purchase. Please choose another payment method.');
        }
        return $this->result(self::PLACED, '', self::safeRedirect($created['redirect_url']));
    }

    /** Abandon an authorisation that will not be used, so it does not linger for its 60 minutes. Best effort. */
    public function release(string $token): void
    {
        if ($token === '') {
            return; // nothing was authorised: never call Klarna with an empty token
        }
        try {
            $this->api->cancelAuthorization($token);
        } catch (KlarnaException) {
            // Klarna expires unused authorisations by itself.
        }
    }

    /** Klarna may return its own redirect_url; follow it only when it is an https Klarna host. */
    public static function safeRedirect(string $url): string
    {
        $parts = parse_url($url);
        $host = is_array($parts) ? strtolower((string) ($parts['host'] ?? '')) : '';
        $https = is_array($parts) && ($parts['scheme'] ?? '') === 'https';
        $klarna = $host === 'klarna.com' || str_ends_with($host, '.klarna.com') || str_ends_with($host, '.klarna.net');
        return $https && $klarna ? $url : '';
    }

    /** @return array{status: string, message: string, redirect: string} */
    private function result(string $status, string $message, string $redirect = ''): array
    {
        return ['status' => $status, 'message' => $message, 'redirect' => $redirect];
    }
}
