<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Modules\ModuleRegistry;

/**
 * Klarna Payments module (direct API integration; no third-party plugin code).
 *
 * OFF by default, also on upgrades (absent from `grcs_modules`). While OFF the gateway is unavailable at checkout and none of the
 * checkout assets, session endpoints, Blocks registration, callback routes or jobs exist. Credentials, settings, order
 * metadata and the historical order operations (refund, capture, cancel, refresh from Klarna) stay available.
 */
final class KlarnaModule
{
    public const KEY = 'klarna';

    /**
     * ON only when the merchant switched it on AND the payment-attempt ledger passed its readiness check: Klarna cannot be enabled
     * while the ledger is unusable (missing table / column / key, non-InnoDB). Reads one stored verification, not the schema.
     */
    public static function isEnabled(): bool
    {
        return ModuleRegistry::isEnabled(ModuleRegistry::KLARNA) && self::ledgerReady();
    }

    /** The merchant's own switch, regardless of ledger readiness (for the settings UI to explain why Klarna stays off). */
    public static function requested(): bool
    {
        return ModuleRegistry::isEnabled(ModuleRegistry::KLARNA);
    }

    public static function ledgerReady(bool $repair = true): bool
    {
        $stored = Schema::storedLedgerReady();
        if ($stored !== null) {
            return $stored;
        }
        global $wpdb;
        if (!$wpdb instanceof \wpdb) {
            return true; // no database layer to judge (a standalone or unit runtime): the gate only applies where a ledger can exist
        }
        try {
            return $repair
                ? Schema::fromGlobals()->ledgerReady()
                : (bool) Schema::fromGlobals()->verifyLedgerReadiness()['ready'];
        } catch (\Throwable) {
            return false;
        }
    }

    public static function settingsUrl(): string
    {
        return function_exists('admin_url') ? admin_url('admin.php?page=wc-settings&tab=checkout&section=' . KlarnaSettings::GATEWAY_ID) : '';
    }

    /** @return array{label: string, description: string, off: string} */
    public static function definition(): array
    {
        return [
            'label' => AdminLocale::__('Klarna Payments', 'gr-commerce-suite'),
            'description' => KlarnaSubscriber::blocksEnabled()
                ? AdminLocale::__('Pay with Klarna at classic and block checkout (block checkout is switched on by a site filter), with capture, cancel and refund from the order. New Klarna payments need an active GR Commerce Suite licence.', 'gr-commerce-suite')
                : AdminLocale::__('Pay with Klarna at classic checkout, with capture, cancel and refund from the order. New Klarna payments need an active GR Commerce Suite licence.', 'gr-commerce-suite'),
            'off' => AdminLocale::__('Klarna is not offered at checkout and Klarna callbacks stop. Saved Klarna credentials and settings stay, and refunds, captures and cancellations of existing Klarna orders keep working.', 'gr-commerce-suite'),
        ];
    }
}
