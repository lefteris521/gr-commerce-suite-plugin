<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use WC_Order;

/**
 * Finds the shopper's OWN other payment attempts from persistent order data (HPOS safe: wc_get_orders / wc_get_order + order meta), never
 * from a claim the shopper types. A shopper is identified only by what they can prove: their logged-in account, and the order ids they
 * can show a valid proof for ({@see KlarnaShopperProof}). A billing email is never an identity here.
 *
 * Scope: orders created through this gateway. A local status or elapsed time cannot establish that Klarna did not charge, so there is no
 * time limit, no result-count limit and no status filter: {@see KlarnaOrderRecord::unresolved()} alone decides, from Klarna's own state.
 */
final class KlarnaOrderLookup
{
    /**
     * @param list<int> $orderIds Orders the shopper can prove they hold.
     * @param int $excludeOrderId The order being (re)tried: it is never its own conflict.
     */
    public function unresolvedForShopper(int $userId, array $orderIds, int $excludeOrderId = 0): ?WC_Order
    {
        return $this->unresolvedOrdersForShopper($userId, $orderIds, $excludeOrderId)[0] ?? null;
    }

    /**
     * @param list<int> $orderIds
     * @return list<WC_Order> unresolved Klarna orders (create unconfirmed, or not finally decided) of this verified shopper
     */
    public function unresolvedOrdersForShopper(int $userId, array $orderIds, int $excludeOrderId = 0): array
    {
        $found = [];
        $consider = static function (WC_Order $candidate) use (&$found, $excludeOrderId): void {
            if ($candidate->get_id() !== $excludeOrderId && !isset($found[$candidate->get_id()])
                && $candidate->get_payment_method() === KlarnaSettings::GATEWAY_ID && (new KlarnaOrderRecord($candidate))->unresolved()) {
                $found[$candidate->get_id()] = $candidate;
            }
        };
        if ($userId > 0) {
            foreach ($this->query(['payment_method' => KlarnaSettings::GATEWAY_ID, 'meta_query' => [['key' => KlarnaOrderRecord::META_OWNER_USER, 'value' => (string) $userId]]]) as $order) {
                $consider($order);
            }
        }
        foreach ($this->ordersById($orderIds) as $order) {
            $consider($order);
        }
        return array_values($found);
    }

    /**
     * Orders of this verified shopper that ANOTHER (third-party) gateway left pending and that may still be in flight at its provider.
     * GRCS cannot see inside such a provider: "in flight" is a stamped intent on an order that is not paid and has no terminal ledger
     * outcome, whatever its age or local status ({@see KlarnaCheckoutCoordinator::inFlight()}).
     *
     * @param list<int> $orderIds
     * @return list<WC_Order>
     */
    public function inFlightOtherGateway(int $userId, array $orderIds): array
    {
        $found = [];
        $consider = static function (WC_Order $candidate) use (&$found): void {
            if (!isset($found[$candidate->get_id()]) && $candidate->get_payment_method() !== KlarnaSettings::GATEWAY_ID && KlarnaCheckoutCoordinator::inFlight($candidate)) {
                $found[$candidate->get_id()] = $candidate;
            }
        };
        if ($userId > 0) {
            foreach ($this->query(['customer_id' => $userId, 'meta_query' => [['key' => KlarnaCheckoutCoordinator::INTENT_META, 'compare' => 'EXISTS']]]) as $order) {
                $consider($order);
            }
        }
        foreach ($this->ordersById($orderIds) as $order) {
            $consider($order);
        }
        return array_values($found);
    }

    /** Another order that already used this Klarna session for its create call (a session authorises one order). */
    public function usingSession(string $sessionId, int $excludeOrderId): ?WC_Order
    {
        if ($sessionId === '') {
            return null;
        }
        foreach ($this->query(['payment_method' => KlarnaSettings::GATEWAY_ID, 'meta_query' => [['key' => KlarnaOrderRecord::META_SESSION, 'value' => $sessionId]]]) as $candidate) {
            if ($candidate->get_id() !== $excludeOrderId && (new KlarnaOrderRecord($candidate))->heldByKlarna()) {
                return $candidate;
            }
        }
        return null;
    }

    /**
     * @param list<int> $ids
     * @return list<WC_Order>
     */
    private function ordersById(array $ids): array
    {
        $orders = [];
        if (!function_exists('wc_get_order')) {
            return $orders;
        }
        foreach (array_slice(array_values(array_unique(array_map('intval', $ids))), 0, 200) as $id) {
            $order = $id > 0 ? \wc_get_order($id) : false;
            if ($order instanceof WC_Order) {
                $orders[] = $order;
            }
        }
        return $orders;
    }

    /**
     * @param array<string, mixed> $args
     * @return list<WC_Order>
     */
    private function query(array $args): array
    {
        if (!function_exists('wc_get_orders')) {
            return [];
        }
        $args = array_merge([
            'limit' => -1,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => function_exists('wc_get_order_statuses') ? array_keys(\wc_get_order_statuses()) : ['pending', 'failed', 'on-hold', 'cancelled', 'processing', 'completed', 'refunded'],
        ], $args);
        $orders = \wc_get_orders($args);
        return is_array($orders) ? array_values(array_filter($orders, static fn($o): bool => $o instanceof WC_Order)) : [];
    }
}
