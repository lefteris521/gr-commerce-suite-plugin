<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Database\Repositories\RateCounterRepository;
use wpdb;

/**
 * Concurrency-safe request-level rate limit for the customer status endpoint.
 *
 * Architecture & Concurrency Guarantees:
 * 1. Reserve before lookup:
 *    Every client request atomically increments its bucket via RateCounterRepository before attempting
 *    an order lookup. If the post-increment value exceeds the limit, the request is immediately rejected
 *    (429) without touching the order or Klarna. A storage failure reserves PHP_INT_MAX and is rejected too.
 * 2. Guarded refund for valid pollers:
 *    When an order lookup succeeds for a legitimate customer, one UPDATE decrements the same bucket, but
 *    only while its value is positive. The limiter keeps the (key, reserved) pair of the reservation it
 *    issued, refunds only that exact key, at most once for that reservation, and only after orderByKey() succeeds.
 *    A caller that passes a different key is refused and the counted failure stays in place.
 * 3. Shared failure path:
 *    Failed lookups (unknown order, wrong key, order of another payment gateway, account order requested
 *    without login) do not refund the reservation. The reserved slot remains as the counted failure.
 * 4. Boundary burst trade-off:
 *    Rate limits use discrete fixed time buckets: prefix + client_key_hash + '_' + floor(time() / WINDOW).
 *    Because expiry is determined by the bucket timestamp rather than sliding window recalculation, a burst
 *    straddling the boundary between bucket N and bucket N+1 can permit at most <= 2 * LIMIT requests across
 *    the bucket edge. This eliminates window expiration recomputations and distributed lock contention.
 * 5. Accepted refund limit:
 *    WordPress $wpdb automatically reconnects and replays a statement after a lost connection. A refund
 *    statement replayed that way decrements one extra time, so the accepted bound is at most +1 admitted
 *    failure per reconnect during a refund. Order keys are ~77 bits, so that extra slot cannot help an
 *    unauthorised client reach another shopper's order.
 * 6. Client identification & Privacy:
 *    REMOTE_ADDR is strictly used (forwarding headers are ignored as client-controlled). IPv4-mapped IPv6
 *    addresses are normalized to IPv4; IPv6 addresses are aggregated to /64 subnets; empty or invalid addresses
 *    are assigned to a single shared fail-closed bucket. All keys are hashed using hash_hmac('sha256', key, salt)
 *    truncated to 32 characters, preventing IP exposure in option names.
 *    Behind a reverse proxy, load balancer or CDN every visitor arrives with the proxy address, so all of them
 *    share one bucket: one abusive client can throttle the others until the bucket rolls over. Deployments in
 *    that shape must configure the proxy to preserve the real client address, or accept the shared limit.
 * 7. Non-WordPress fallback:
 *    When $wpdb is not an instance of wpdb (e.g. standalone mocked smoke environments), a transient-based
 *    fallback is maintained. On a real WordPress site with $wpdb, raw SQL on $wpdb->options is always used.
 */
final class KlarnaStatusLimiter
{
    public const LIMIT = 10;
    public const WINDOW = 600;
    public const PREFIX = 'grcs_klarna_rl_';

    /** @var array{key: string, reserved: bool}|null The single reservation issued by reserve() in this request. */
    private ?array $reservation = null;

    /**
     * Atomically reserve a rate-limit slot prior to lookup.
     *
     * Returns the exact reserved key/bucket on success within limit; returns null
     * if the client is over limit or if atomic/fallback storage fails (fail-closed).
     *
     * @param int|null $time Controlled timestamp for testing bucket roll-overs, or null for current time.
     * @return string|null Exact reserved key/bucket on success within limit; null on rejection or failure.
     */
    public function reserve(?int $time = null): ?string
    {
        $this->opportunisticCleanup();
        $this->reservation = null;
        $key = $this->optionName($time);

        if ($this->isWordPress()) {
            $count = RateCounterRepository::reserve($key);
            if ($count > $this->limit()) {
                return null; // Includes a storage failure, which reserves PHP_INT_MAX.
            }
            $this->reservation = ['key' => $key, 'reserved' => true];
            return $key;
        }

        $count = $this->reserveFallback($key);
        if ($count === null || $count > $this->limit()) {
            return null;
        }
        $this->reservation = ['key' => $key, 'reserved' => true];
        return $key;
    }

    /**
     * Refund the reservation when an order lookup succeeds.
     *
     * Only the exact key issued by reserve() is ever refunded, and only once per
     * request. Passing a different key is refused without a write. The reservation
     * is not recomputed from the clock, so a refund that arrives after a bucket
     * rollover decrements the original bucket.
     *
     * @param string|null $reservedKey The exact key/bucket returned by reserve(), or null for the recorded one.
     */
    public function refund(?string $reservedKey = null): void
    {
        $reservation = $this->reservation;
        if ($reservation === null || !$reservation['reserved']) {
            return; // Nothing reserved in this request, or already refunded.
        }

        if ($reservedKey !== null && $reservedKey !== $reservation['key']) {
            return; // Refuse a mismatched key; the reserved failure stays counted.
        }

        $this->reservation['reserved'] = false; // At most one decrement per request.

        if ($this->isWordPress()) {
            RateCounterRepository::refund($reservation['key']);
            return;
        }

        $this->refundFallback($reservation['key']);
    }

    /**
     * Check if the client has already exceeded the failure limit.
     */
    public function exceeded(?int $time = null): bool
    {
        $key = $this->optionName($time);
        if ($this->isWordPress()) {
            $count = RateCounterRepository::get($key);
            // A failed read is not an empty bucket: reject rather than fail open.
            return $count === null || $count >= $this->limit();
        }

        if (!function_exists('get_transient')) {
            return true; // Fail closed if storage is unavailable
        }

        $row = get_transient($key);
        return is_array($row) && (int) ($row['n'] ?? 0) >= $this->limit();
    }

    /**
     * Record a failure (backward compatibility alias for reserve).
     */
    public function recordFailure(?int $time = null): void
    {
        $this->reserve($time);
    }

    /**
     * Opportunistically trigger bounded cleanup of expired buckets.
     */
    public function cleanup(): int
    {
        if (!$this->isWordPress()) {
            return 0;
        }

        $currentBucket = (int) floor(time() / self::WINDOW);
        $olderThanBucket = $currentBucket - 1; // Purge buckets older than previous window
        return RateCounterRepository::cleanup(self::PREFIX, $olderThanBucket, 100);
    }

    /**
     * Resolved failure limit, filtered through grcs_klarna_status_failure_limit.
     */
    public function limit(): int
    {
        return function_exists('apply_filters')
            ? max(1, (int) apply_filters('grcs_klarna_status_failure_limit', self::LIMIT))
            : self::LIMIT;
    }

    /**
     * Normalized client key extracted strictly from REMOTE_ADDR.
     */
    public function clientKey(): string
    {
        $address = isset($_SERVER['REMOTE_ADDR']) && is_string($_SERVER['REMOTE_ADDR'])
            ? trim($_SERVER['REMOTE_ADDR'])
            : '';
        return $this->normalizeIp($address);
    }

    /**
     * Salted HMAC hash of the client key, truncated to 32 characters.
     */
    public function clientHash(): string
    {
        $salt = function_exists('wp_salt') ? (string) wp_salt('auth') : 'grcs_status_limiter_salt';
        return substr(hash_hmac('sha256', $this->clientKey(), $salt), 0, 32);
    }

    /**
     * Bucket option name: prefix + truncated HMAC + '_' + floor(time() / WINDOW).
     */
    public function optionName(?int $time = null): string
    {
        $ts = $time ?? time();
        $bucket = (int) floor($ts / self::WINDOW);
        return self::PREFIX . $this->clientHash() . '_' . $bucket;
    }

    /**
     * Normalize client IP address:
     * - IPv4: canonical IPv4 string
     * - IPv4-mapped IPv6: extracted to IPv4
     * - IPv6: aggregated to /64 subnet
     * - Empty or invalid: fail-closed shared 'invalid' bucket
     */
    public function normalizeIp(string $address): string
    {
        $address = trim($address);
        if ($address === '') {
            return 'invalid';
        }

        $packed = @inet_pton($address);
        if ($packed === false) {
            return 'invalid';
        }

        if (strlen($packed) === 4) {
            $formatted = inet_ntop($packed);
            return $formatted !== false ? $formatted : 'invalid';
        }

        if (strlen($packed) === 16) {
            // IPv4-mapped IPv6 (::ffff:x.x.x.x)
            if (substr($packed, 0, 12) === "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff") {
                $mapped = inet_ntop(substr($packed, 12, 4));
                return $mapped !== false ? $mapped : 'invalid';
            }

            // Aggregate IPv6 to /64
            $subnet = substr($packed, 0, 8) . str_repeat("\x00", 8);
            $formatted = inet_ntop($subnet);
            return $formatted !== false ? $formatted . '/64' : 'invalid';
        }

        return 'invalid';
    }

    private function opportunisticCleanup(): void
    {
        $rand = function_exists('wp_rand') ? wp_rand(1, 50) : mt_rand(1, 50);
        if ($rand === 1) {
            $this->cleanup();
        }
    }

    private function isWordPress(): bool
    {
        global $wpdb;
        return $wpdb instanceof wpdb;
    }

    // --- Non-WordPress transient fallback (standalone smokes only) ---

    /**
     * Non-WordPress transient fallback reservation. Fails closed (returns null)
     * if transient functions are missing or transient write fails.
     */
    private function reserveFallback(string $key): ?int
    {
        if (!function_exists('get_transient') || !function_exists('set_transient')) {
            return null; // Fail closed (P2)
        }

        $row = get_transient($key);
        $row = is_array($row) ? $row : ['n' => 0];
        $row['n'] = (int) ($row['n'] ?? 0) + 1;
        $written = set_transient($key, $row, self::WINDOW);
        if (!$written) {
            return null; // Fail closed if transient write fails (P2)
        }
        return (int) $row['n'];
    }

    private function refundFallback(string $key): void
    {
        if (!function_exists('get_transient') || !function_exists('set_transient')) {
            return;
        }

        $row = get_transient($key);
        if (!is_array($row)) {
            return;
        }

        $row['n'] = max(0, (int) ($row['n'] ?? 0) - 1);
        set_transient($key, $row, self::WINDOW);
    }
}
