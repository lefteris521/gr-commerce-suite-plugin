<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use InvalidArgumentException;

/**
 * Pure order-line maths for Klarna (integer minor units only, no floats, no WooCommerce).
 *
 * Klarna enforces: total_amount = quantity * unit_price - total_discount_amount (exact), line tax within +/-1 of
 * total_amount * tax_rate / (10000 + tax_rate), order_amount = sum(total_amount) and order_tax_amount = sum(total_tax_amount).
 *
 * Input lines (all amounts in minor units, tax-inclusive):
 *   type          physical|digital|shipping_fee|surcharge|discount
 *   name, reference, quantity (int >= 1)
 *   gross_before  unit-price basis before discounts (quantity * unit, tax included)
 *   gross_after   line total after discounts (tax included; negative for discount lines)
 *   tax           tax contained in gross_after
 */
final class KlarnaOrderLines
{
    public const TYPES = ['physical', 'digital', 'shipping_fee', 'surcharge', 'discount'];

    /** Largest rounding difference (minor units) that may be absorbed by a synthetic rounding line. */
    public const MAX_ROUNDING = 5;

    /**
     * @param list<array<string, mixed>> $lines
     * @return array{order_lines: list<array<string, mixed>>, order_amount: int, order_tax_amount: int}
     */
    public static function build(array $lines, int $expectedTotal, string $roundingName = 'Rounding'): array
    {
        $out = [];
        foreach ($lines as $line) {
            $built = self::line($line);
            if ($built !== null) {
                $out[] = $built;
            }
        }
        $sum = array_sum(array_column($out, 'total_amount'));
        $difference = $expectedTotal - $sum;
        if ($difference !== 0) {
            if (abs($difference) > max(self::MAX_ROUNDING, count($out))) {
                throw new InvalidArgumentException('Klarna order lines do not add up to the order total.');
            }
            $out[] = [
                'type' => $difference > 0 ? 'surcharge' : 'discount',
                'reference' => 'rounding',
                'name' => $roundingName,
                'quantity' => 1,
                'unit_price' => $difference,
                'tax_rate' => 0,
                'total_amount' => $difference,
                'total_discount_amount' => 0,
                'total_tax_amount' => 0,
            ];
        }
        if (count($out) === 0 || count($out) > 1000) {
            throw new InvalidArgumentException('Klarna requires between 1 and 1000 order lines.');
        }
        return [
            'order_lines' => $out,
            'order_amount' => $expectedTotal,
            'order_tax_amount' => array_sum(array_column($out, 'total_tax_amount')),
        ];
    }

    /**
     * @param array<string, mixed> $line
     * @return array<string, mixed>|null
     */
    public static function line(array $line): ?array
    {
        $type = (string) ($line['type'] ?? 'physical');
        if (!in_array($type, self::TYPES, true)) {
            throw new InvalidArgumentException('Unsupported Klarna order line type.');
        }
        $quantity = (int) ($line['quantity'] ?? 1);
        $before = (int) ($line['gross_before'] ?? 0);
        $total = (int) ($line['gross_after'] ?? 0);
        $tax = (int) ($line['tax'] ?? 0);
        if ($quantity < 1) {
            return null;
        }
        if ($type === 'discount' || $total < 0) {
            // Negative lines are a single discount: quantity 1, no per-unit discount arithmetic.
            $quantity = 1;
            $unit = $total;
            $discount = 0;
            $type = 'discount';
        } else {
            $basis = max($before, $total);
            $unit = intdiv($basis + $quantity - 1, $quantity);
            $discount = $quantity * $unit - $total;
        }
        $rate = self::taxRate($total, $tax);
        $result = [
            'type' => $type,
            'reference' => self::cut((string) ($line['reference'] ?? ''), 256),
            'name' => self::cut((string) ($line['name'] ?? ''), 255) ?: 'Item',
            'quantity' => $quantity,
            'unit_price' => $unit,
            'tax_rate' => $rate,
            'total_amount' => $total,
            'total_discount_amount' => $discount,
            'total_tax_amount' => self::lineTax($total, $tax, $rate),
        ];
        if ($result['reference'] === '') {
            unset($result['reference']);
        }
        foreach (['product_url', 'image_url'] as $urlKey) {
            $url = (string) ($line[$urlKey] ?? '');
            if ($url !== '' && strlen($url) <= 1024 && str_starts_with($url, 'https://')) {
                $result[$urlKey] = $url;
            }
        }
        return $result;
    }

    /** Tax rate in percent with two implicit decimals (2400 = 24%). */
    public static function taxRate(int $total, int $tax): int
    {
        $net = $total - $tax;
        if ($total === 0 || $tax === 0 || $net === 0 || ($total < 0) !== ($tax < 0)) {
            return 0;
        }
        return intdiv(abs($tax) * 20000 + abs($net), abs($net) * 2);
    }

    /** Keep the measured tax unless it falls outside Klarna's +/-1 tolerance around the formula value. */
    public static function lineTax(int $total, int $tax, int $rate): int
    {
        if ($rate === 0) {
            return 0;
        }
        $divisor = 10000 + $rate;
        if (abs($tax * $divisor - $total * $rate) <= $divisor) {
            return $tax;
        }
        $numerator = $total * $rate;
        $half = intdiv($divisor, 2);
        return $numerator >= 0 ? intdiv($numerator + $half, $divisor) : -intdiv(-$numerator + $half, $divisor);
    }

    /**
     * Stable fingerprint of what Klarna must authorise (display names excluded).
     *
     * @param list<array<string, mixed>> $orderLines
     */
    public static function fingerprint(array $orderLines, int $orderAmount, string $currency, string $country): string
    {
        $canonical = [];
        foreach ($orderLines as $line) {
            $canonical[] = [(string) $line['type'], (string) ($line['reference'] ?? ''), (int) $line['quantity'], (int) $line['unit_price'],
                (int) $line['total_amount'], (int) $line['total_discount_amount'], (int) $line['total_tax_amount']];
        }
        return hash('sha256', json_encode([$canonical, $orderAmount, strtoupper($currency), strtoupper($country)], JSON_THROW_ON_ERROR));
    }

    private static function cut(string $text, int $max): string
    {
        $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
        return function_exists('mb_substr') ? mb_substr($text, 0, $max) : substr($text, 0, $max);
    }
}
