<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * WooCommerce Checkout Block payment method (the documented `AbstractPaymentMethodType` extension interface).
 * Only ever instantiated from `woocommerce_blocks_payment_method_type_registration`, i.e. when the parent class exists.
 */
final class KlarnaBlocksSupport extends AbstractPaymentMethodType
{
    protected $name = KlarnaSettings::GATEWAY_ID;

    public function initialize(): void
    {
        $this->settings = KlarnaServices::settings()->all();
    }

    public function is_active(): bool
    {
        return KlarnaModule::isEnabled()
            && KlarnaServices::licensed()
            && ($this->settings['enabled'] ?? 'no') === 'yes'
            && KlarnaServices::settings()->hasCredentials();
    }

    /** @return list<string> */
    public function get_payment_method_script_handles(): array
    {
        KlarnaSubscriber::registerSdk();
        wp_register_script(
            'grcs-klarna-blocks',
            plugins_url('assets/js/klarna-blocks.js', GRCS_PLUGIN_FILE),
            ['wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities', 'wp-i18n', 'wp-data', 'wc-blocks-checkout', KlarnaSubscriber::SDK_HANDLE],
            GRCS_VERSION,
            true
        );
        return ['grcs-klarna-blocks'];
    }

    /** @return array<string, mixed> */
    public function get_payment_method_data(): array
    {
        return [
            'title' => (string) ($this->settings['title'] ?? 'Klarna'),
            'description' => (string) ($this->settings['description'] ?? ''),
            'supports' => $this->get_supported_features(),
            'namespace' => KlarnaSubscriber::EXTENSION_NAMESPACE,
            'tokenField' => KlarnaGateway::FIELD_TOKEN,
            'i18n' => [
                'unavailable' => __('Klarna is not available for this order.', 'gr-commerce-suite'),
                'declined' => __('Klarna could not approve this purchase. Please choose another payment method.', 'gr-commerce-suite'),
            ],
        ];
    }
}
