<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Security\CredentialVault;

/**
 * Klarna settings: non-secret options live in the WooCommerce gateway settings option; API credentials (separate
 * playground and live sets) are encrypted with the shared {@see CredentialVault} in a module-owned, non-autoloaded option.
 * Reads never write. Secrets are never returned to forms.
 */
final class KlarnaSettings
{
    public const GATEWAY_ID = 'grcs_klarna';
    public const OPTION_SETTINGS = 'woocommerce_grcs_klarna_settings';
    public const OPTION_CREDENTIALS = 'grcs_credentials_klarna';
    /** Non-secret progress toward live: last playground connection test, playground orders placed, last test summary. */
    public const OPTION_STATE = 'grcs_klarna_state';

    /** Regional base URLs, https://docs.klarna.com/acquirer/klarna/get-started/integration-resilience/api-urls/ (reviewed 2026-10-30). */
    private const BASE_URLS = [
        'live' => ['eu' => 'https://api.klarna.com', 'na' => 'https://api-na.klarna.com', 'oc' => 'https://api-oc.klarna.com'],
        'playground' => ['eu' => 'https://api.playground.klarna.com', 'na' => 'https://api-na.playground.klarna.com', 'oc' => 'https://api-oc.playground.klarna.com'],
    ];

    /** Two-decimal currencies only; {@see \GRCommerceSuite\Support\Money} is cent based. */
    public const CURRENCIES = ['EUR', 'USD', 'GBP', 'SEK', 'NOK', 'DKK', 'CHF', 'PLN', 'CZK', 'RON', 'AUD', 'NZD', 'CAD'];

    /** @param array<string, mixed>|null $settings Injected for tests; null reads the saved option. */
    public function __construct(private readonly CredentialVault $vault, private readonly ?array $settings = null)
    {
    }

    /** @return array<string, mixed> */
    public function all(): array
    {
        if ($this->settings !== null) {
            return $this->settings;
        }
        $stored = function_exists('get_option') ? get_option(self::OPTION_SETTINGS, []) : [];
        return is_array($stored) ? $stored : [];
    }

    public function environment(): string
    {
        return ($this->all()['environment'] ?? 'playground') === 'live' ? 'live' : 'playground';
    }

    public function region(): string
    {
        $region = (string) ($this->all()['region'] ?? 'eu');
        return in_array($region, ['eu', 'na', 'oc'], true) ? $region : 'eu';
    }

    public function baseUrl(?string $environment = null, ?string $region = null): string
    {
        $environment = in_array($environment, ['live', 'playground'], true) ? $environment : $this->environment();
        $region = in_array($region, ['eu', 'na', 'oc'], true) ? $region : $this->region();
        return self::BASE_URLS[$environment][$region];
    }

    /** The merchant's own confirmation that Klarna approved this store for live payments (not provable by us). */
    public function liveApproved(): bool
    {
        return ($this->all()['live_approved'] ?? 'no') === 'yes';
    }

    /** @return array{playground_ok: int, playground_orders: int, last_test: array<string, mixed>} */
    public function state(): array
    {
        $stored = function_exists('get_option') ? get_option(self::OPTION_STATE, []) : [];
        $stored = is_array($stored) ? $stored : [];
        return [
            'playground_ok' => (int) ($stored['playground_ok'] ?? 0),
            'playground_orders' => (int) ($stored['playground_orders'] ?? 0),
            'last_test' => is_array($stored['last_test'] ?? null) ? $stored['last_test'] : [],
        ];
    }

    /** @param array<string, mixed> $summary Non-secret outcome (ok, environment, message, correlation id). */
    public function recordTest(string $environment, bool $ok, array $summary): void
    {
        $state = $this->state();
        $state['last_test'] = $summary + ['environment' => $environment, 'ok' => $ok, 'at' => time()];
        if ($environment === 'playground') {
            $state['playground_ok'] = $ok ? time() : 0;
        }
        update_option(self::OPTION_STATE, $state, false);
    }

    /** Count of orders Klarna accepted or reviewed in playground: evidence that real test checkouts were done. */
    public function recordPlaygroundOrder(): void
    {
        $state = $this->state();
        $state['playground_orders']++;
        update_option(self::OPTION_STATE, $state, false);
    }

    /**
     * What still blocks live payments. Live needs: live credentials, a successful playground connection test, at least one
     * playground test order, and the merchant's explicit approval confirmation. Never bypassed by saved settings alone.
     *
     * @return list<string> merchant-readable blockers; empty = live may be used
     */
    public function liveBlockers(?bool $approved = null): array
    {
        $state = $this->state();
        $blockers = [];
        if (!$this->hasCredentials('live')) {
            $blockers[] = AdminLocale::__('Save your live API username and password.', 'gr-commerce-suite');
        }
        if ($state['playground_ok'] === 0) {
            $blockers[] = AdminLocale::__('Run a successful Test Connection in the Playground environment.', 'gr-commerce-suite');
        }
        if ($state['playground_orders'] < 1) {
            $blockers[] = AdminLocale::__('Place at least one successful test order in Playground.', 'gr-commerce-suite');
        }
        if (!($approved ?? $this->liveApproved())) {
            $blockers[] = AdminLocale::__('Confirm that Klarna approved your store for live payments.', 'gr-commerce-suite');
        }
        return $blockers;
    }

    /** Selected environment may take payments now. Playground needs credentials only; live needs every blocker cleared. */
    public function ready(): bool
    {
        if (!$this->hasCredentials()) {
            return false;
        }
        return $this->environment() === 'playground' || $this->liveBlockers() === [];
    }

    public function autoCapture(): bool
    {
        return ($this->all()['auto_capture'] ?? 'yes') !== 'no';
    }

    public function autoCancel(): bool
    {
        return ($this->all()['auto_cancel'] ?? 'yes') !== 'no';
    }

    /** @return list<string> ISO 3166 alpha-2 purchase countries this store offers Klarna for (default GR; availability is Klarna-side). */
    public function countries(): array
    {
        $raw = $this->all()['countries'] ?? 'GR';
        $list = is_array($raw) ? $raw : (preg_split('/[\s,;]+/', (string) $raw) ?: []);
        $countries = [];
        foreach ($list as $code) {
            $code = strtoupper(trim((string) $code));
            if (preg_match('/^[A-Z]{2}$/', $code) === 1) {
                $countries[$code] = $code;
            }
        }
        return array_values($countries);
    }

    /** @return array{username: string, password: string}|null Credentials of the selected environment, or null when incomplete. */
    public function credentials(?string $environment = null): ?array
    {
        $set = $this->stored()[$environment ?? $this->environment()] ?? null;
        if (!is_array($set)) {
            return null;
        }
        $username = trim((string) ($set['username'] ?? ''));
        $password = trim((string) ($set['password'] ?? ''));
        return $username !== '' && $password !== '' ? ['username' => $username, 'password' => $password] : null;
    }

    public function hasCredentials(?string $environment = null): bool
    {
        return $this->credentials($environment) !== null;
    }

    /** Blank values keep the saved secret (forms never display secrets). Returns false when it could not be encrypted/stored. */
    public function saveCredentials(string $environment, string $username, string $password): bool
    {
        if (!in_array($environment, ['playground', 'live'], true) || !CredentialVault::encryptionAvailable()) {
            return false;
        }
        $all = $this->stored();
        $current = is_array($all[$environment] ?? null) ? $all[$environment] : [];
        $all[$environment] = [
            'username' => trim($username) !== '' ? trim($username) : (string) ($current['username'] ?? ''),
            'password' => trim($password) !== '' ? trim($password) : (string) ($current['password'] ?? ''),
        ];
        if ($environment === 'playground' && $all[$environment] !== $current) {
            // New playground credentials: the earlier successful test no longer proves anything.
            $state = $this->state();
            $state['playground_ok'] = 0;
            update_option(self::OPTION_STATE, $state, false);
        }
        $json = function_exists('wp_json_encode') ? (string) wp_json_encode($all) : json_encode($all, JSON_THROW_ON_ERROR);
        $saved = update_option(self::OPTION_CREDENTIALS, $this->vault->encrypt($json), false);
        return $saved || $this->stored() === $all;
    }

    /** @return array<string, array<string, string>> */
    private function stored(): array
    {
        $raw = function_exists('get_option') ? get_option(self::OPTION_CREDENTIALS, '') : '';
        $plain = is_string($raw) && $raw !== '' ? $this->vault->decrypt($raw) : null;
        $decoded = $plain !== null ? json_decode($plain, true) : null;
        $result = [];
        foreach (is_array($decoded) ? $decoded : [] as $env => $set) {
            if (is_array($set)) {
                $result[(string) $env] = array_map('strval', array_filter($set, 'is_scalar'));
            }
        }
        return $result;
    }
}
