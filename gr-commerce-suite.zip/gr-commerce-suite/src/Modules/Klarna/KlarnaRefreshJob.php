<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

/**
 * Asynchronous "read the order from Klarna and reconcile" job. Callbacks only schedule it (Klarna allows 2 s per callback);
 * a pending-review order re-schedules itself while Klarna still reports PENDING. The handler rechecks the module gate.
 */
final class KlarnaRefreshJob
{
    public const HOOK = 'grcs/klarna/refresh_order';
    private const MAX_ATTEMPTS = 14;

    public function __construct(private readonly KlarnaOrderManagement $management)
    {
    }

    public function register(): void
    {
        add_action(self::HOOK, [$this, 'run'], 10, 3);
    }

    /** Queue a refresh. False when it could not be queued (Action Scheduler absent or refused): callback callers then answer 5xx so Klarna retries. */
    public static function schedule(int $orderId, string $klarnaOrderId = '', int $attempt = 0, int $delay = 0): bool
    {
        if (!function_exists('as_schedule_single_action') || $orderId <= 0) {
            return false;
        }
        $args = [$orderId, $klarnaOrderId, $attempt];
        if (function_exists('as_has_scheduled_action') && as_has_scheduled_action(self::HOOK, $args, self::group())) {
            return true;
        }
        return (int) as_schedule_single_action(time() + max(0, $delay), self::HOOK, $args, self::group()) > 0; // 0 = Action Scheduler could not store it
    }

    public function run(mixed $orderId = 0, mixed $klarnaOrderId = '', mixed $attempt = 0): void
    {
        if (!KlarnaModule::requested() || !function_exists('wc_get_order')) {
            return;
        }
        $order = \wc_get_order((int) $orderId);
        if (!$order instanceof \WC_Order || $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID) {
            return;
        }
        $result = $this->management->refresh($order, is_string($klarnaOrderId) ? $klarnaOrderId : '');
        $record = new KlarnaOrderRecord($order);
        $attempt = (int) $attempt;
        // An order completed by hand while Klarna was still reviewing it could not be captured then: capture now that it is accepted.
        if ($result['ok'] && $record->fraudStatus() === 'ACCEPTED' && $order->has_status('completed') && KlarnaServices::settings()->autoCapture()
            && in_array((string) ($record->state()['status'] ?? ''), ['AUTHORIZED', 'PART_CAPTURED'], true)) {
            $this->management->capture($order);
        }
        // Klarna accepted (e.g. a late push for an ambiguous create) an order the merchant had already cancelled: do not leave the
        // authorisation open. cancel() is state-gated and idempotent, and the order itself is never reactivated.
        if ($result['ok'] && $record->fraudStatus() === 'ACCEPTED' && $order->has_status('cancelled') && KlarnaServices::settings()->autoCancel()
            && in_array((string) ($record->state()['status'] ?? ''), ['AUTHORIZED', 'PART_CAPTURED'], true)) {
            $cancelled = $this->management->cancel($order);
            $order->add_order_note($cancelled['ok']
                ? 'Klarna accepted this order after it was cancelled in WooCommerce; the Klarna authorisation was cancelled as well.'
                : 'Klarna accepted this order after it was cancelled in WooCommerce and it could not be cancelled in Klarna: ' . $cancelled['message']);
            $order->save();
        }
        $unresolved = !$result['ok'] || $record->fraudStatus() === 'PENDING';
        if ($unresolved && $attempt < self::MAX_ATTEMPTS) {
            self::schedule($order->get_id(), is_string($klarnaOrderId) ? $klarnaOrderId : '', $attempt + 1, $result['ok'] ? 3600 : 600 * ($attempt + 1));
        } elseif ($unresolved) {
            $order->add_order_note('Klarna still did not confirm this order after repeated automatic checks. Use "Klarna: refresh status" or "Link Klarna order", and do not ship until Klarna accepts it.');
            $order->save();
        }
    }

    private static function group(): string
    {
        return defined('GRCS_AS_GROUP') ? (string) constant('GRCS_AS_GROUP') : 'gr-commerce-suite';
    }
}
