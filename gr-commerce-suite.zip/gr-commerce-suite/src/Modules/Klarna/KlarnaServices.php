<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Http\WpHttpClient;
use GRCommerceSuite\Security\CredentialVault;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Support\Logger;

/**
 * Lazy object graph for the Klarna module. WooCommerce instantiates the gateway itself (no container), so the gateway,
 * Blocks support and hooks resolve their collaborators here. Nothing is built, read or requested until first use, and tests
 * replace the HTTP client / logger / session store with {@see configure()}.
 */
final class KlarnaServices
{
    private static ?HttpClientInterface $http = null;
    private static ?LoggerInterface $logger = null;
    private static ?KlarnaSessionStore $store = null;
    private static ?KlarnaSettings $settings = null;
    private static ?KlarnaApiClient $api = null;
    private static ?KlarnaOrderManagement $management = null;
    private static ?KlarnaSessionService $sessions = null;
    private static ?KlarnaPaymentService $payments = null;
    private static ?\Closure $licence = null;

    public static function configure(?HttpClientInterface $http = null, ?LoggerInterface $logger = null, ?KlarnaSessionStore $store = null, ?KlarnaSettings $settings = null, ?\Closure $licence = null): void
    {
        self::reset();
        self::$licence = $licence;
        self::$http = $http;
        self::$logger = $logger;
        self::$store = $store;
        self::$settings = $settings;
    }

    public static function reset(): void
    {
        self::$http = self::$logger = self::$store = self::$settings = self::$licence = null;
        self::$api = null;
        self::$management = null;
        self::$sessions = null;
        self::$payments = null;
    }

    /**
     * Active GRCS commercial licence. Required for NEW Klarna checkout sessions, authorisations and orders only; callbacks,
     * capture, cancel, refund, refresh and reconciliation of existing orders never ask for it.
     */
    public static function licensed(): bool
    {
        return self::$licence !== null ? (bool) (self::$licence)() : LicenseManager::isLicensed();
    }

    public static function logger(): LoggerInterface
    {
        return self::$logger ??= (new Logger())->withSource('grcs-klarna');
    }

    public static function settings(): KlarnaSettings
    {
        return self::$settings ??= new KlarnaSettings(new CredentialVault());
    }

    public static function api(): KlarnaApiClient
    {
        return self::$api ??= new KlarnaApiClient(self::$http ?? new WpHttpClient(), self::settings(), self::logger());
    }

    public static function management(): KlarnaOrderManagement
    {
        return self::$management ??= new KlarnaOrderManagement(self::api(), self::logger());
    }

    public static function connectionTest(): KlarnaConnectionTest
    {
        return new KlarnaConnectionTest(self::api(), self::settings());
    }

    public static function sessions(): KlarnaSessionService
    {
        return self::$sessions ??= new KlarnaSessionService(
            self::api(),
            self::settings(),
            new KlarnaPayloadFactory(),
            self::$store ?? new WcSessionStore(),
            new CredentialVault(),
            self::logger(),
            static fn(): bool => self::licensed()
        );
    }

    public static function payments(): KlarnaPaymentService
    {
        return self::$payments ??= new KlarnaPaymentService(self::api(), self::settings(), new KlarnaPayloadFactory(), self::management(), self::logger(), static fn(): bool => self::licensed());
    }
}
