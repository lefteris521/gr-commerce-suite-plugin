<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\Payments\LedgerException;
use GRCommerceSuite\Payments\LegacyIntents;
use GRCommerceSuite\Payments\PaymentLedger;
use WC_Order;

/**
 * Attested merchant release of an unresolved payment attempt (D1 v4 seam g). The merchant accepts the residual financial risk: a late
 * charge may still occur. Always available - the Klarna module OFF and the licence expired change nothing, this only ends a hold on an
 * existing order and opens no payment.
 *
 * Required, all of them: `manage_woocommerce`, a valid nonce for this very order, a reason, an evidence type, an evidence reference and the
 * explicit attestation that the original call cannot still execute or settle. The ledger transition (CAS) and its attributed audit event
 * commit together; if that fails the hold is untouched - the legacy Klarna phase is only cleared AFTER the ledger release succeeded.
 */
final class KlarnaAttemptRelease
{
    public const NONCE_PREFIX = 'grcs_release_payment_attempt_';

    /** @param array<string, mixed> $post */
    public static function release(WC_Order $order, array $post): bool
    {
        $why = self::refusalReason($order, $post);
        if ($why !== '') {
            error_log('GR Commerce Suite attempt release refused for order ' . $order->get_id() . ': ' . $why); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- support diagnosis, no shopper data

            return false;
        }

        return self::doRelease($order, $post);
    }

    /** @param array<string, mixed> $post */
    private static function refusalReason(WC_Order $order, array $post): string
    {
        if (!function_exists('current_user_can') || !current_user_can('manage_woocommerce')) {
            return 'capability';
        }
        $nonce = isset($post['_wpnonce']) && is_string($post['_wpnonce']) ? $post['_wpnonce'] : '';
        if ($nonce === '' || !function_exists('wp_verify_nonce') || !wp_verify_nonce($nonce, self::NONCE_PREFIX . $order->get_id())) {
            return 'nonce';
        }
        if (self::field($post, 'grcs_release_reason', 191) === '' || self::field($post, 'grcs_release_evidence_type', 32) === '' || self::field($post, 'grcs_release_evidence_ref', 191) === '') {
            return 'reason_or_evidence_missing';
        }

        return (string) ($post['grcs_release_attestation'] ?? '') !== '1' ? 'attestation' : '';
    }

    /** @param array<string, mixed> $post */
    private static function doRelease(WC_Order $order, array $post): bool
    {
        // Capability, nonce, reason, evidence and attestation were verified by refusalReason().
        $reason = self::field($post, 'grcs_release_reason', 191);
        $evidenceType = self::field($post, 'grcs_release_evidence_type', 32);
        $evidenceRef = self::field($post, 'grcs_release_evidence_ref', 191);
        $note = self::field($post, 'grcs_release_note', 1000);
        $user = function_exists('wp_get_current_user') ? wp_get_current_user() : null;
        $by = is_object($user) && isset($user->user_login) ? (string) $user->user_login : 'unknown';
        $userId = $user instanceof \WP_User ? $user->ID : 0;

        if (self::ledgerAvailable()) {
            try {
                $ledger = PaymentLedger::fromGlobals();
                $attempt = $ledger->blockingAttemptForOrder($order->get_id());
                if ($attempt === null) {
                    // A hold that predates the ledger (Klarna create in doubt, legacy intent) is imported as unknown first, so its release is
                    // audited exactly like any other.
                    $record = new KlarnaOrderRecord($order);
                    if ($record->unresolved()) {
                        $ledger->importLegacyIntent($order->get_id(), (int) $order->get_customer_id(), KlarnaSettings::GATEWAY_ID, 'legacy_klarna');
                    } elseif (LegacyIntents::isUnresolved($order)) {
                        LegacyIntents::import($order);
                    }
                    $attempt = $ledger->blockingAttemptForOrder($order->get_id());
                }
                if ($attempt === null) {
                    return false; // nothing unresolved to release
                }
                $attestation = 'Attested: the original payment call cannot still execute or settle. ' . $note;
                if (!$ledger->transition($attempt, PaymentLedger::STATE_RELEASED, 'merchant', $userId > 0 ? $userId : null, $evidenceType, $evidenceRef, $reason, trim($attestation))) {
                    return false;
                }
            } catch (LedgerException $e) {
                error_log('GR Commerce Suite attempt release failed for order ' . $order->get_id() . ': ' . $e->getMessage()); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- support diagnosis

                return false; // audit or commit failed: the hold stays exactly as it was
            }
        }

        if ((new KlarnaOrderRecord($order))->release($by)) {
            $order->add_order_note('Klarna hold released by ' . $by . ': the merchant attested, with evidence, that no order exists at Klarna for this attempt.');
        } elseif (!self::ledgerAvailable()) {
            return false; // nothing to release without a ledger and not a Klarna in-doubt create
        } else {
            $order->add_order_note('Payment hold released by ' . $by . ' (' . $reason . '): the merchant attested that the original payment cannot still execute or settle.');
        }
        $order->save();

        return true;
    }

    /**
     * A ledger exists on this site and passed its readiness check. When it does not (tables missing / not ready, or no database layer),
     * the attested release still works through the legacy Klarna phase and an attributed order note, so an in-doubt Klarna create can
     * never be stranded by an unusable ledger. With a ready ledger the audited ledger release is mandatory and any failure keeps the hold.
     */
    private static function ledgerAvailable(): bool
    {
        global $wpdb;
        if (!$wpdb instanceof \wpdb) {
            return false;
        }
        try {
            return Schema::fromGlobals()->ledgerReady();
        } catch (\Throwable) {
            return false;
        }
    }

    /** @param array<string, mixed> $post */
    private static function field(array $post, string $key, int $max): string
    {
        $raw = isset($post[$key]) && is_string($post[$key]) ? $post[$key] : '';
        $clean = function_exists('sanitize_text_field') ? sanitize_text_field(function_exists('wp_unslash') ? wp_unslash($raw) : $raw) : trim($raw);

        return substr(trim($clean), 0, $max);
    }

    /** True when the order has an unresolved hold the merchant could release (shown to administrators only). */
    public static function releasable(WC_Order $order): bool
    {
        if (LegacyIntents::isUnresolved($order)) {
            return true;
        }
        if ((new KlarnaOrderRecord($order))->unresolved()) {
            return true;
        }
        try {
            return PaymentLedger::fromGlobals()->orderHasBlockingAttempt($order->get_id());
        } catch (LedgerException) {
            return false;
        }
    }
}
