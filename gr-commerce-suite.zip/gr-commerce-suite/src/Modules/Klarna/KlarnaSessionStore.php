<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

/** Per-shopper storage of the Klarna session record (WooCommerce session in production). */
interface KlarnaSessionStore
{
    /** @return array<string, mixed>|null */
    public function get(): ?array;

    /** @param array<string, mixed>|null $record */
    public function set(?array $record): void;
}
