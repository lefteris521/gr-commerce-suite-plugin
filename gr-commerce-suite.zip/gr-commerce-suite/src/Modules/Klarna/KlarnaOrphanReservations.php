<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Payments\LedgerException;
use GRCommerceSuite\Payments\PaymentLedger;

/**
 * Merchant discovery and attested release of a checkout reservation that has no order and no attempt (D1 v4 seam h): a request that
 * committed its reservation and died before WooCommerce created the order. It blocks the shopper until a merchant, who has checked that
 * the worker is gone, releases it. Always registered (works with the module OFF and the licence expired); `manage_woocommerce` only.
 *
 * The list shows a non-secret reference, state and creation time - never shopper identifiers, scope hashes or tokens. A row is a
 * candidate for investigation, not proof its worker stopped; elapsed time proves nothing, which is why release needs an attestation.
 */
final class KlarnaOrphanReservations
{
    public const ACTION = 'grcs_payment_release_reservation';
    public const PAGE = 'grcs-payment-reservations';

    public static function register(): void
    {
        add_filter('grcs_payment_orphan_reservations_list', [self::class, 'listFilter']);
        add_action('admin_post_' . self::ACTION, [self::class, 'handleRelease']);
        add_action('admin_menu', [self::class, 'menu']);
    }

    /**
     * @param mixed $list
     * @return array<int, array{reference: string, state: string, created: string}>
     */
    public static function listFilter($list = []): array
    {
        $list = is_array($list) ? $list : [];
        if (!current_user_can('manage_woocommerce')) {
            error_log('GR Commerce Suite orphan reservation list: caller lacks manage_woocommerce'); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log

            return $list;
        }
        try {
            return array_merge($list, PaymentLedger::fromGlobals()->orphanReservations());
        } catch (LedgerException $e) {
            error_log('GR Commerce Suite orphan reservation list failed: ' . $e->getMessage()); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- support diagnosis

            return $list;
        }
    }

    public static function handleRelease(): void
    {
        $ok = false;
        if (current_user_can('manage_woocommerce')) {
            $ok = self::release($_POST); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified inside release()
        }
        if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
            return; // the test / ajax contract: no redirect, no exit
        }
        wp_safe_redirect(add_query_arg(['page' => self::PAGE, 'released' => $ok ? '1' : '0'], admin_url('admin.php')));
        exit;
    }

    /** @param array<string, mixed> $post */
    public static function release(array $post): bool
    {
        $hex = isset($post['reservation_id']) && is_string($post['reservation_id']) ? strtolower($post['reservation_id']) : '';
        if (preg_match('/^[0-9a-f]{32}$/', $hex) !== 1) {
            return false;
        }
        $nonce = isset($post['_wpnonce']) && is_string($post['_wpnonce']) ? $post['_wpnonce'] : '';
        if ($nonce === '' || !wp_verify_nonce($nonce, self::ACTION . '_' . $hex)) {
            return false;
        }
        $reason = self::text($post, 'reason', 191);
        $evidence = self::text($post, 'evidence', 600);
        if ($reason === '' || $evidence === '' || (string) ($post['attest_terminated'] ?? '') !== '1') {
            return false;
        }
        try {
            $ledger = PaymentLedger::fromGlobals();
            $row = $ledger->reservationRow($hex);
            if ($row === null || $row['state'] !== PaymentLedger::RESERVATION_PREPARING || $row['attempt']) {
                return false;
            }
            if ($row['candidate_order_id'] !== null && !current_user_can('edit_shop_orders')) {
                return false; // per-order access, when an order exists
            }
            $user = (int) get_current_user_id();

            return $ledger->releaseReservation(
                $hex,
                $user,
                $reason,
                'Evidence: ' . $evidence . ' | Attested: the original checkout request has terminated and can no longer change an order or start a payment.'
            );
        } catch (LedgerException) {
            return false; // audit or commit failed: the reservation stays blocking
        }
    }

    /** @param array<string, mixed> $post */
    private static function text(array $post, string $key, int $max): string
    {
        $raw = isset($post[$key]) && is_string($post[$key]) ? $post[$key] : '';

        return substr(trim(sanitize_text_field(wp_unslash($raw))), 0, $max);
    }

    public static function menu(): void
    {
        add_submenu_page(
            'woocommerce',
            AdminLocale::__('Payment holds', 'gr-commerce-suite'),
            AdminLocale::__('Payment holds', 'gr-commerce-suite'),
            'manage_woocommerce',
            self::PAGE,
            [self::class, 'render']
        );
    }

    public static function render(): void
    {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        echo '<div class="wrap"><h1>' . AdminLocale::esc_html__('Payment holds', 'gr-commerce-suite') . '</h1>';
        if (isset($_GET['released']) && $_GET['released'] === '0') { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only
            echo '<div class="notice notice-error"><p>' . AdminLocale::esc_html__('The payment attempt could not be released.', 'gr-commerce-suite') . '</p></div>';
        }
        echo '<p>' . AdminLocale::esc_html__('Checkouts that started a payment hold but never created an order. A row is a candidate for investigation, not proof that its request has stopped.', 'gr-commerce-suite') . '</p>';
        $rows = self::listFilter([]);
        if ($rows === []) {
            echo '<p>' . AdminLocale::esc_html__('No unfinished checkout holds.', 'gr-commerce-suite') . '</p></div>';

            return;
        }
        foreach ($rows as $row) {
            $ref = $row['reference'];
            echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:0 0 1.5em;padding:1em;background:#fff;border:1px solid #c3c4c7">';
            wp_nonce_field(self::ACTION . '_' . $ref);
            echo '<input type="hidden" name="action" value="' . esc_attr(self::ACTION) . '" /><input type="hidden" name="reservation_id" value="' . esc_attr($ref) . '" />';
            echo '<p><strong>' . esc_html(substr($ref, 0, 12)) . '</strong> &middot; ' . esc_html($row['state']) . ' &middot; ' . esc_html($row['created']) . ' UTC</p>';
            echo '<p><label>' . AdminLocale::esc_html__('Reason', 'gr-commerce-suite') . ' <input type="text" name="reason" class="regular-text" required /></label></p>';
            echo '<p><label>' . AdminLocale::esc_html__('Evidence checked', 'gr-commerce-suite') . ' <input type="text" name="evidence" class="large-text" required /></label></p>';
            echo '<p><label><input type="checkbox" name="attest_terminated" value="1" required /> '
                . AdminLocale::esc_html__('I confirm that the original checkout request has terminated and can no longer change an order or start a payment.', 'gr-commerce-suite') . '</label></p>';
            echo '<p class="description">' . AdminLocale::esc_html__('Releasing this attempt can allow another payment. A late charge may still occur.', 'gr-commerce-suite') . '</p>';
            echo '<button type="submit" class="button button-primary">' . AdminLocale::esc_html__('Release payment attempt', 'gr-commerce-suite') . '</button></form>';
        }
        echo '</div>';
    }
}
