<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use WC_Order;

/**
 * Klarna state of one WooCommerce order, stored only through the order CRUD API (HPOS safe: get_meta/update_meta_data/save).
 *
 * Also the idempotency ledger: every mutating Order Management operation is first recorded as a *pending intent* with a UUIDv4
 * key; a retry of the same logical operation (same type and parameters) reuses the pending key, so Klarna's
 * `Klarna-Idempotency-Key` makes the repeat safe. A finished intent is never reused.
 */
final class KlarnaOrderRecord
{
    public const META_ORDER_ID = '_grcs_klarna_order_id';
    public const META_FRAUD = '_grcs_klarna_fraud_status';
    public const META_SESSION = '_grcs_klarna_session_id';
    public const META_METHOD = '_grcs_klarna_payment_method';
    public const META_STATE = '_grcs_klarna_state';
    public const META_CALLBACK = '_grcs_klarna_callback_hash';
    public const META_PHASE = '_grcs_klarna_phase';
    public const META_PLACED = '_grcs_klarna_placed';
    public const META_LINES = '_grcs_klarna_lines';
    public const META_OPS = '_grcs_klarna_ops';
    public const META_OWNER_USER = '_grcs_klarna_owner_user';
    public const META_RELEASED = '_grcs_klarna_released';

    public const PHASE_CREATING = 'creating';
    public const PHASE_AMBIGUOUS = 'ambiguous';
    public const PHASE_PLACED = 'placed';

    private const MAX_OPS = 60;

    public function __construct(private readonly WC_Order $order)
    {
    }

    public function order(): WC_Order
    {
        return $this->order;
    }

    public function klarnaOrderId(): string
    {
        return (string) $this->order->get_meta(self::META_ORDER_ID);
    }

    public function phase(): string
    {
        return (string) $this->order->get_meta(self::META_PHASE);
    }

    /**
     * Klarna holds this order, or may hold it (an earlier create was sent and its outcome is unconfirmed). Such an order is
     * answered from its stored state and is never authorised or created again, so a retry needs no token and no usable setup.
     */
    public function heldByKlarna(): bool
    {
        return $this->klarnaOrderId() !== '' || in_array($this->phase(), [self::PHASE_CREATING, self::PHASE_AMBIGUOUS], true);
    }

    /**
     * Klarna may hold money for this order and nobody has confirmed it either way: an earlier create whose outcome is unknown, or an
     * order Klarna has not finally decided / that is not paid. A second Klarna order for the same shopper must wait for this one to be
     * resolved. Only evidence ends it - Klarna's own decision (accepted and paid, refused, or the order closed at Klarna) or the
     * merchant's explicit release after checking Klarna; never elapsed time and never a local WooCommerce status alone.
     */
    public function unresolved(): bool
    {
        if ($this->klarnaOrderId() === '') {
            return in_array($this->phase(), [self::PHASE_CREATING, self::PHASE_AMBIGUOUS], true);
        }
        if ($this->closedAtKlarna()) {
            // Closed is a provider-state observation, not proof that nothing was captured: money already captured on an unpaid order is unresolved.
            return !$this->order->is_paid() && (int) ($this->state()['captured_amount'] ?? 0) > 0;
        }
        return $this->fraudStatus() === 'PENDING'
            || (!$this->order->is_paid() && $this->fraudStatus() !== 'REJECTED');
    }

    /** Klarna itself reports this order as cancelled / expired / closed (read from Order Management, so it is evidence, not a local guess). */
    public function closedAtKlarna(): bool
    {
        return in_array(strtoupper((string) ($this->state()['status'] ?? '')), ['CANCELLED', 'EXPIRED', 'CLOSED'], true);
    }

    /**
     * Who the Klarna attempt belongs to, stored on the order itself (persistent, unlike the WooCommerce session): the authenticated
     * account only. A billing email is never recorded as an owner - anyone can type one. Guests are recognised by their proof cookie
     * ({@see KlarnaShopperProof}), not by anything stored here. Written before the create call.
     */
    public function stampOwner(): void
    {
        $user = (int) $this->order->get_customer_id();
        $this->order->update_meta_data(self::META_OWNER_USER, $user > 0 ? (string) $user : '');
    }

    /**
     * The merchant checked Klarna and confirms it holds no order for this attempt: the unconfirmed create no longer holds the shopper
     * back. Explicit, attributed, and only for an order Klarna never confirmed.
     */
    public function release(string $by): bool
    {
        if ($this->klarnaOrderId() !== '' || !in_array($this->phase(), [self::PHASE_CREATING, self::PHASE_AMBIGUOUS], true)) {
            return false;
        }
        $this->order->update_meta_data(self::META_RELEASED, ['by' => $by, 'at' => time()]);
        $this->markPhase('');
        return true;
    }

    public function fraudStatus(): string
    {
        return (string) $this->order->get_meta(self::META_FRAUD);
    }

    /** @return array{amount: int, currency: string, country: string, environment: string, region: string}|null Amounts and Klarna target of this order. */
    public function placed(): ?array
    {
        $placed = $this->order->get_meta(self::META_PLACED);
        return is_array($placed) && isset($placed['amount'], $placed['currency']) ? [
            'amount' => (int) $placed['amount'],
            'currency' => (string) $placed['currency'],
            'country' => (string) ($placed['country'] ?? ''),
            'environment' => (string) ($placed['environment'] ?? ''),
            'region' => (string) ($placed['region'] ?? ''),
        ] : null;
    }

    /** @return array<string, mixed> Last state read from Klarna Order Management. */
    public function state(): array
    {
        $state = $this->order->get_meta(self::META_STATE);
        return is_array($state) ? $state : [];
    }

    /** @return array{environment: string, region: string}|null Where this order lives at Klarna (null: use the current settings). */
    public function target(): ?array
    {
        $placed = $this->placed();
        return $placed !== null && $placed['environment'] !== '' ? ['environment' => $placed['environment'], 'region' => $placed['region']] : null;
    }

    /** @return list<array<string, mixed>> */
    public function authorizedLines(): array
    {
        $lines = $this->order->get_meta(self::META_LINES);
        return is_array($lines) ? array_values($lines) : [];
    }

    public function setCallbackSecretHash(string $hash): void
    {
        $this->order->update_meta_data(self::META_CALLBACK, $hash);
    }

    public function callbackSecretMatches(string $secret): bool
    {
        $stored = (string) $this->order->get_meta(self::META_CALLBACK);
        return $stored !== '' && $secret !== '' && hash_equals($stored, self::hashSecret($secret));
    }

    public static function hashSecret(string $secret): string
    {
        return hash('sha256', $secret);
    }

    public function markPhase(string $phase): void
    {
        $this->order->update_meta_data(self::META_PHASE, $phase);
    }

    /**
     * @param array{amount: int, currency: string, country: string, environment: string, region: string} $placed
     * @param list<array<string, mixed>> $lines
     */
    public function setPlaced(string $klarnaOrderId, string $fraudStatus, string $sessionId, string $method, array $placed, array $lines): void
    {
        $this->order->update_meta_data(self::META_ORDER_ID, $klarnaOrderId);
        $this->order->update_meta_data(self::META_FRAUD, $fraudStatus);
        $this->order->update_meta_data(self::META_SESSION, $sessionId);
        $this->order->update_meta_data(self::META_METHOD, $method);
        $this->order->update_meta_data(self::META_PLACED, $placed);
        $this->order->update_meta_data(self::META_LINES, $lines);
        $this->order->update_meta_data(self::META_PHASE, self::PHASE_PLACED);
    }

    /** @param array<string, mixed> $klarnaOrder Order Management getOrder response. */
    public function storeState(array $klarnaOrder): void
    {
        $this->order->update_meta_data(self::META_STATE, [
            'status' => (string) ($klarnaOrder['status'] ?? ''),
            'fraud_status' => (string) ($klarnaOrder['fraud_status'] ?? ''),
            'order_amount' => (int) ($klarnaOrder['order_amount'] ?? 0),
            'captured_amount' => (int) ($klarnaOrder['captured_amount'] ?? 0),
            'refunded_amount' => (int) ($klarnaOrder['refunded_amount'] ?? 0),
            'remaining_authorized_amount' => (int) ($klarnaOrder['remaining_authorized_amount'] ?? 0),
            'checked_at' => time(),
        ]);
        if (isset($klarnaOrder['fraud_status']) && is_string($klarnaOrder['fraud_status']) && $klarnaOrder['fraud_status'] !== '') {
            $this->order->update_meta_data(self::META_FRAUD, strtoupper($klarnaOrder['fraud_status']));
        }
    }

    // ---- Idempotency ledger -------------------------------------------------------------------------------------------

    /**
     * Pending intent for a logical operation. Persisted BEFORE the HTTP call; reused while unfinished.
     *
     * @param array<string, scalar> $params
     * @return array{key: string, reused: bool}
     */
    public function intent(string $type, array $params): array
    {
        ksort($params);
        $hash = hash('sha256', $type . '|' . json_encode($params, JSON_THROW_ON_ERROR));
        $ops = $this->ops();
        foreach ($ops as $op) {
            if (($op['state'] ?? '') === 'pending' && ($op['hash'] ?? '') === $hash) {
                return ['key' => (string) $op['key'], 'reused' => true];
            }
        }
        $key = self::uuid4();
        $ops[] = ['type' => $type, 'hash' => $hash, 'key' => $key, 'state' => 'pending', 'at' => time(), 'params' => $params];
        $this->order->update_meta_data(self::META_OPS, self::trim($ops));
        $this->order->save();
        return ['key' => $key, 'reused' => false];
    }

    /**
     * Key of an unfinished intent for this logical operation (an earlier attempt whose outcome is unknown), or null.
     *
     * @param array<string, scalar> $params
     */
    public function pending(string $type, array $params): ?string
    {
        ksort($params);
        $hash = hash('sha256', $type . '|' . json_encode($params, JSON_THROW_ON_ERROR));
        foreach ($this->ops() as $op) {
            if (($op['state'] ?? '') === 'pending' && ($op['hash'] ?? '') === $hash) {
                return (string) $op['key'];
            }
        }
        return null;
    }

    /** The effect of an unfinished attempt was observed at Klarna (e.g. the order is now fully captured): close it without a new call. */
    public function settlePending(string $type): void
    {
        $ops = $this->ops();
        foreach ($ops as $i => $op) {
            if (($op['type'] ?? '') === $type && ($op['state'] ?? '') === 'pending') {
                $ops[$i]['state'] = 'done';
                $ops[$i]['done_at'] = time();
                $ops[$i]['result'] = ['observed' => true];
            }
        }
        $this->order->update_meta_data(self::META_OPS, self::trim($ops));
    }

    /** @param array<string, scalar> $result */
    public function finish(string $key, array $result = []): void
    {
        $ops = $this->ops();
        foreach ($ops as $i => $op) {
            if (($op['key'] ?? '') === $key) {
                $ops[$i]['state'] = 'done';
                $ops[$i]['done_at'] = time();
                $ops[$i]['result'] = $result;
            }
        }
        $this->order->update_meta_data(self::META_OPS, self::trim($ops));
    }

    /** Operation Klarna definitively refused: it will not be retried under this key. */
    public function abandon(string $key, string $reason): void
    {
        $ops = $this->ops();
        foreach ($ops as $i => $op) {
            if (($op['key'] ?? '') === $key) {
                $ops[$i]['state'] = 'rejected';
                $ops[$i]['reason'] = $reason;
            }
        }
        $this->order->update_meta_data(self::META_OPS, self::trim($ops));
    }

    /** Sum of finished operations of a type, from the local ledger (Klarna remains authoritative). */
    public function finishedCount(string $type): int
    {
        return count(array_filter($this->ops(), static fn(array $op): bool => ($op['type'] ?? '') === $type && ($op['state'] ?? '') === 'done'));
    }

    /** @return list<array<string, mixed>> */
    public function ops(): array
    {
        $ops = $this->order->get_meta(self::META_OPS);
        return is_array($ops) ? array_values(array_filter($ops, 'is_array')) : [];
    }

    public static function uuid4(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        $hex = bin2hex($bytes);
        return sprintf('%s-%s-%s-%s-%s', substr($hex, 0, 8), substr($hex, 8, 4), substr($hex, 12, 4), substr($hex, 16, 4), substr($hex, 20, 12));
    }

    /**
     * @param list<array<string, mixed>> $ops
     * @return list<array<string, mixed>> Bounded: pending intents are always kept, old finished ones dropped first.
     */
    private static function trim(array $ops): array
    {
        if (count($ops) <= self::MAX_OPS) {
            return $ops;
        }
        $pending = array_values(array_filter($ops, static fn(array $op): bool => ($op['state'] ?? '') === 'pending'));
        $rest = array_values(array_filter($ops, static fn(array $op): bool => ($op['state'] ?? '') !== 'pending'));
        return array_merge(array_slice($rest, -(self::MAX_OPS - count($pending))), $pending);
    }
}
