<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\Payments\LedgerException;
use GRCommerceSuite\Payments\LegacyIntents;
use GRCommerceSuite\Payments\PaymentLedger;
use WC_Order;

/**
 * Classic-checkout admission into the durable payment-attempt ledger (D1 v4 seams a, b, c, d). Static hooks, so registering twice in one
 * request is harmless.
 *
 *  1. `woocommerce_create_order` (priority 1, BEFORE WooCommerce may resume or rewrite `order_awaiting_payment`): reads the verified
 *     shopper, refuses on any unresolved attempt / claim / reservation / quarantine / legacy intent, and commits a `preparing` reservation
 *     with unique active claims. A bracket at PHP_INT_MAX fails closed if any other callback produced an order instead.
 *  2. `woocommerce_checkout_order_processed` (priority 5, before every gateway code path): one pinned transaction commits the immutable
 *     payment context, the attempt, its bindings (account, WooCommerce session key - including the ORIGINAL guest session when checkout
 *     signup changes the identity - and guest proof orders), event and claims, and promotes the reservation. Any failure throws, so the
 *     gateway is never invoked; no transaction is open while the gateway runs.
 *  3. Reviewed core COD / BACS / cheque (the exact core classes) are recorded `offline_no_charge` - terminal, nonblocking, never paid - and
 *     the reviewed gateway OBJECT is pinned: if anything swaps it before WooCommerce dispatches, the checkout aborts first.
 *
 * Zero-total orders hold nothing. No timer, lock expiry, cookie, status or shutdown ever releases anything.
 */
final class KlarnaPaymentAdmission
{
    /** Reviewed offline implementations: gateway id => the exact core class. A subclass or replacement is NOT reviewed and takes the blocking path. */
    private const OFFLINE_CLASSES = ['cod' => 'WC_Gateway_COD', 'bacs' => 'WC_Gateway_BACS', 'cheque' => 'WC_Gateway_Cheque'];
    public const SELECTOR_FIELD = 'grcs_payment_submission_selector';

    /** @var array{id: string, token: string, scopes: array<string, string|list<string>>, guard: bool, created: bool, virtual?: bool, session?: string}|null */
    private static ?array $reservation = null;
    private static ?string $attemptHex = null;
    private static string $originalSession = '';
    /** @var array{0: string, 1: object}|null [gateway id, reviewed object] */
    private static ?array $pinned = null;

    public static function register(): void
    {
        add_action('woocommerce_before_checkout_process', [self::class, 'captureOriginalSession'], 1);
        add_action('woocommerce_created_customer', [self::class, 'signupJoin'], 1, 1);
        add_filter('woocommerce_create_order', [self::class, 'reserve'], 1, 2);
        add_filter('woocommerce_create_order', [self::class, 'guardLateFilters'], PHP_INT_MAX, 2);
        add_action('woocommerce_checkout_create_order', [self::class, 'coreCreatedOrder'], PHP_INT_MAX, 0);
        add_action('woocommerce_checkout_order_processed', [self::class, 'admit'], 5, 3);
        add_filter('woocommerce_available_payment_gateways', [self::class, 'pinGateways'], PHP_INT_MAX);
        add_filter('grcs_issue_submission_selector', [self::class, 'issueSelector'], 10, 2);
        add_action('grcs_payment_attempt_request_end', [self::class, 'forget']);
    }

    public static function forget(): void
    {
        self::$reservation = null;
        self::$attemptHex = null;
        self::$originalSession = '';
        self::$pinned = null;
    }

    /** Hex id of the attempt admitted in THIS request, if any. */
    public static function currentAttemptHex(): ?string
    {
        return self::$attemptHex;
    }

    /** The authenticated guest session key BEFORE checkout signup can switch the identity (seam b). Never a posted value. */
    public static function captureOriginalSession(): void
    {
        self::$originalSession = self::sessionKey();
    }

    /**
     * Checkout signup created an account: join the ORIGINAL guest session and the new account in the ledger before anything else can use
     * either (seam b). If the join cannot be recorded the checkout is refused - the identity could not be kept together.
     *
     * @param mixed $customerId
     * @throws \Exception
     */
    public static function signupJoin($customerId): void
    {
        $account = (int) $customerId;
        if ($account <= 0 || self::$originalSession === '' || !KlarnaModule::isEnabled()) {
            return;
        }
        try {
            PaymentLedger::fromGlobals()->linkScopes([PaymentLedger::SCOPE_SESSION => self::$originalSession], [PaymentLedger::SCOPE_ACCOUNT => (string) $account]);
        } catch (LedgerException $e) {
            throw self::refusal($e);
        }
    }

    private static function sessionKey(): string
    {
        $wc = function_exists('WC') ? \WC() : null;
        $session = is_object($wc) ? $wc->session : null;

        return is_object($session) && method_exists($session, 'get_customer_id') ? (string) $session->get_customer_id() : '';
    }

    private static function postedMethod(): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verified the checkout nonce; this only classifies the request
        return isset($_POST['payment_method']) && is_string($_POST['payment_method']) ? sanitize_text_field(wp_unslash($_POST['payment_method'])) : '';
    }

    private static function postedSelector(): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        return isset($_POST[self::SELECTOR_FIELD]) && is_string($_POST[self::SELECTOR_FIELD]) ? sanitize_text_field(wp_unslash($_POST[self::SELECTOR_FIELD])) : '';
    }

    /** @return 'none'|'offline'|'online' */
    private static function classify(string $method): string
    {
        if ($method === '' || !KlarnaModule::isEnabled()) {
            return 'none';
        }
        if (!isset(self::OFFLINE_CLASSES[$method])) {
            return 'online';
        }
        $gateway = self::gateway($method);

        return $gateway !== null && get_class($gateway) === self::OFFLINE_CLASSES[$method] ? 'offline' : 'online';
    }

    private static function gateway(string $method): ?object
    {
        $wc = function_exists('WC') ? \WC() : null;
        $gateways = is_object($wc) ? $wc->payment_gateways()->get_available_payment_gateways() : [];

        return isset($gateways[$method]) && is_object($gateways[$method]) ? $gateways[$method] : null;
    }

    /**
     * @param mixed $orderId null unless another callback created an order
     * @return mixed
     * @throws \Exception shown to the shopper by WooCommerce's checkout (nothing was created or changed)
     */
    public static function reserve(mixed $orderId, mixed $checkout = null): mixed
    {
        $original = self::$originalSession; // captured before signup could switch the identity: survives the reset below
        self::forget();
        self::$originalSession = $original;
        $wc = function_exists('WC') ? \WC() : null;
        $cart = is_object($wc) ? $wc->cart : null;
        if ($orderId || !is_object($cart) || !$cart->needs_payment() || self::classify(self::postedMethod()) === 'none') {
            return $orderId;
        }
        self::$originalSession = self::$originalSession !== '' ? self::$originalSession : self::sessionKey();
        try {
            // A reservation is never client-supplied: a posted id/token is refused outright (a released one must never be revived).
            // phpcs:ignore WordPress.Security.NonceVerification.Missing
            if (isset($_POST['grcs_reservation_id']) || isset($_POST['grcs_reservation_token'])) {
                throw new LedgerException('client_supplied_reservation');
            }
            self::assertReady();
            $ledger = PaymentLedger::fromGlobals();
            $selector = self::postedSelector();
            if ($selector !== '') {
                // Only a selector this very session was issued is valid; one already bound to an order is a retry of an earlier submission.
                $bound = $ledger->selectorOrder($selector, self::sessionKey());
                if ($bound === null) {
                    throw new LedgerException('submission_selector_unverified');
                }
                if ($bound > 0) {
                    throw new LedgerException('submission_selector_already_used', LedgerException::BLOCKED);
                }
            }
            $user = KlarnaShopperProof::userId();
            $proofOrders = KlarnaShopperProof::orderIds();
            if (LegacyIntents::unresolvedFor($user, $proofOrders) !== []) {
                throw new LedgerException('legacy_intent_unresolved', LedgerException::BLOCKED);
            }
            $candidate = self::candidateOrderId();
            $scopes = [];
            if ($user > 0) {
                $scopes[PaymentLedger::SCOPE_ACCOUNT] = (string) $user;
            }
            if ($candidate > 0) {
                $scopes[PaymentLedger::SCOPE_ORDER] = (string) $candidate;
            }
            $proofs = array_map('strval', KlarnaShopperProof::verifiedCookieOrderIds());
            if ($proofs !== []) {
                $scopes[PaymentLedger::SCOPE_GUEST_PROOF] = $proofs;
            }
            $recovered = \GRCommerceSuite\Payments\GuestRecovery::proofFromCookie(); // a browser that completed e-mail recovery
            if ($recovered !== '') {
                $scopes[PaymentLedger::SCOPE_RECOVERY] = $recovered;
            }
            self::$reservation = $ledger->reserve($scopes, $candidate > 0 ? $candidate : null, self::sessionKey()) + ['guard' => false, 'created' => false];
        } catch (LedgerException $e) {
            throw self::refusal($e);
        }

        return $orderId;
    }

    /** Last word on `woocommerce_create_order`: an order produced by any other callback bypasses the reservation, so it is refused. */
    public static function guardLateFilters(mixed $orderId, mixed $checkout = null): mixed
    {
        if (self::$reservation === null) {
            return $orderId;
        }
        if ($orderId) {
            throw self::refusal(new LedgerException('order_supplied_by_other_filter'));
        }
        self::$reservation['guard'] = true;

        return $orderId;
    }

    /** WooCommerce's own create/resume path ran (it fires this once per order it builds or rewrites). */
    public static function coreCreatedOrder(): void
    {
        if (self::$reservation !== null) {
            self::$reservation['created'] = true;
        }
    }

    /**
     * @param mixed $orderId
     * @param mixed $data posted checkout data
     * @param mixed $order
     * @throws \Exception
     */
    public static function admit($orderId, $data = [], $order = null): void
    {
        if (!$order instanceof WC_Order) {
            return;
        }
        $method = is_array($data) ? (string) ($data['payment_method'] ?? '') : '';
        $kind = self::classify($method);
        if ($kind === 'none' || (float) $order->get_total() <= 0) {
            return;
        }
        try {
            $reservation = self::$reservation;
            if ($reservation === null || !$reservation['guard'] || !$reservation['created']) {
                throw new LedgerException('order_not_created_under_reservation'); // an order WooCommerce built outside the guarded path
            }
            self::assertReady();
            $reviewed = $kind === 'offline' ? self::gateway($method) : null;
            if ($kind === 'offline' && $reviewed === null) {
                throw new LedgerException('reviewed_gateway_unavailable');
            }
            $context = self::context($order, $method, $kind);
            $selector = self::postedSelector();
            if ($selector !== '') {
                $context['selector_hash'] = PaymentLedger::selectorHash($selector, self::sessionKey());
            }
            $attempt = PaymentLedger::fromGlobals()->admit($reservation, self::scopesFor($reservation['scopes'], $order), $context);
            self::$attemptHex = bin2hex($attempt);
            self::$reservation = null;
            if ($reviewed !== null) {
                self::$pinned = [$method, $reviewed]; // from here on WooCommerce may only dispatch THIS object
            }
        } catch (LedgerException $e) {
            throw self::refusal($e);
        }
        if ($kind === 'online' && KlarnaShopperProof::userId() === 0) {
            KlarnaShopperProof::issue($order); // the guest's proof, before any gateway call: a request that dies mid-call still leaves it
        }
    }

    /**
     * Every scope this attempt is bound to: account, the WooCommerce session key now AND the original guest session (checkout signup),
     * each order proof the browser verifiably holds, the order, and (for a guest) the order's own proof.
     *
     * @param array<string, string|list<string>> $reserved
     * @return array<string, string|list<string>>
     */
    private static function scopesFor(array $reserved, WC_Order $order): array
    {
        $scopes = $reserved;
        $orders = array_values(array_unique(array_merge((array) ($reserved[PaymentLedger::SCOPE_ORDER] ?? []), [(string) $order->get_id()])));
        $scopes[PaymentLedger::SCOPE_ORDER] = $orders;
        $sessions = array_values(array_unique(array_filter([self::$originalSession, self::sessionKey()], static fn(string $s): bool => $s !== '')));
        if ($sessions !== []) {
            $scopes[PaymentLedger::SCOPE_SESSION] = $sessions;
        }
        $user = KlarnaShopperProof::userId();
        if ($user > 0) {
            $scopes[PaymentLedger::SCOPE_ACCOUNT] = (string) $user;
        } else {
            $scopes[PaymentLedger::SCOPE_GUEST_PROOF] = array_values(array_unique(array_merge((array) ($reserved[PaymentLedger::SCOPE_GUEST_PROOF] ?? []), [(string) $order->get_id()])));
        }

        return $scopes;
    }

    /**
     * A reviewed offline object is pinned for the dispatch WooCommerce makes after admission. Any other object under that id - swapped by a
     * filter between classification and `process_order_payment()` - aborts the checkout before any gateway is invoked.
     *
     * @param mixed $gateways
     * @return mixed
     * @throws \Exception
     */
    public static function pinGateways($gateways)
    {
        if (self::$pinned === null || !is_array($gateways)) {
            return $gateways;
        }
        [$id, $object] = self::$pinned;
        if (!isset($gateways[$id]) || $gateways[$id] !== $object) {
            self::$pinned = null;
            throw self::refusal(new LedgerException('pinned_gateway_object_changed'));
        }

        return $gateways;
    }

    /**
     * Issues the server-side submission selector for the CURRENT session (stored hashed). A value for any other customer id is refused.
     *
     * @param mixed $value
     * @param mixed $customerId
     */
    public static function issueSelector($value = '', $customerId = ''): string
    {
        $session = self::sessionKey();
        if ($session === '' || !KlarnaModule::isEnabled() || ($customerId !== '' && (string) $customerId !== $session)) {
            return is_string($value) ? $value : '';
        }
        try {
            return PaymentLedger::fromGlobals()->issueSelector($session);
        } catch (LedgerException) {
            return is_string($value) ? $value : '';
        }
    }

    /** The session's awaiting order, only when it really exists (a stale id from a deleted order is nobody's order). */
    private static function candidateOrderId(): int
    {
        $id = KlarnaShopperProof::sessionOrderId();

        return $id > 0 && function_exists('wc_get_order') && \wc_get_order($id) instanceof WC_Order ? $id : 0;
    }

    private static function assertReady(): void
    {
        $state = Schema::fromGlobals()->inspectLedger();
        if (!$state['ready']) {
            throw new LedgerException('ledger_not_ready:' . $state['reason']);
        }
    }

    /**
     * Immutable payment context (amount in exact minor units, currency, exponent, gateway, merchant identity hash and environment),
     * taken from the saved WooCommerce order and the effective gateway configuration. Never updated after insert.
     *
     * @return array{order_id: int, gateway_id: string, cart_hash: ?string, amount_minor: int, currency: string, currency_exponent: int, merchant_identity_hash: string, environment: string, context_status: string, source: string, offline?: bool, selector_hash?: string}
     */
    private static function context(WC_Order $order, string $method, string $kind): array
    {
        // Klarna's payload always carries cents (KlarnaPayloadFactory::minor), whatever the store's display decimals are: the admission
        // context of a Klarna attempt must use the same exponent and conversion, or the evidence check can never match it.
        $isKlarna = $method === KlarnaSettings::GATEWAY_ID;
        $exponent = $isKlarna ? 2 : max(0, min(4, (int) \wc_get_price_decimals()));
        $currency = strtoupper((string) $order->get_currency());
        $total = (string) \wc_format_decimal($order->get_total(), $exponent);
        if (preg_match('/^[A-Z]{3}$/', $currency) !== 1 || preg_match('/^\d+(\.\d+)?$/', $total) !== 1) {
            throw new LedgerException('payment_context_unrepresentable');
        }
        $salt = function_exists('wp_salt') ? wp_salt('auth') : 'grcs-payment-context';
        if ($method === KlarnaSettings::GATEWAY_ID) {
            $settings = KlarnaServices::settings();
            $environment = $settings->environment();
            $credentials = $settings->credentials($environment);
            if ($credentials === null) {
                throw new LedgerException('merchant_identity_unavailable');
            }
            $merchant = hash_hmac('sha256', 'klarna|' . $environment . '|' . $credentials['username'], $salt, true);
        } else {
            // No reviewed provider adapter for this gateway: the identity is the gateway id, and the environment says so.
            $environment = $kind === 'offline' ? 'offline' : 'unreviewed';
            $merchant = hash_hmac('sha256', 'gateway|' . $method, $salt, true);
        }

        return [
            'order_id' => $order->get_id(),
            'gateway_id' => $method,
            'cart_hash' => (string) $order->get_cart_hash(),
            'amount_minor' => $isKlarna ? KlarnaPayloadFactory::minor($order->get_total()) : (int) str_replace('.', '', $total),
            'currency' => $currency,
            'currency_exponent' => $exponent,
            'merchant_identity_hash' => $merchant,
            'environment' => substr($environment, 0, 32),
            'context_status' => 'complete',
            'source' => 'checkout',
            'offline' => $kind === 'offline',
        ];
    }

    private static function refusal(LedgerException $e): \Exception
    {
        if (function_exists('error_log') && $e->kind !== LedgerException::BLOCKED) {
            error_log('GR Commerce Suite payment admission closed: ' . $e->getMessage()); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- support diagnosis, no shopper data
        }

        return new \Exception($e->kind === LedgerException::BLOCKED
            ? __('A previous payment may still be in progress. Please check your email or contact the store before paying again.', 'gr-commerce-suite') // customer-facing
            : __('We could not safely start this payment. Please try again later or contact the store.', 'gr-commerce-suite')); // customer-facing
    }
}
