<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Security\CredentialVault;
use WC_Cart;

/**
 * Creates or updates the Klarna Payments session of the current checkout and binds it to the shopper's WooCommerce session.
 *
 * The record (session id, client token, authorised quote, callback secret) never leaves the server except for the
 * `client_token`, which Klarna designs to be passed to the browser. Cart changes update the same session (or open a new one
 * when Klarna no longer accepts it); an unchanged cart makes no API call.
 */
final class KlarnaSessionService
{
    private const MAX_AGE = 21600; // Klarna sessions live 48 h; refresh from the cart well before that.
    private const CALLBACK_TTL = 172800;

    public function __construct(
        private readonly KlarnaApiClient $api,
        private readonly KlarnaSettings $settings,
        private readonly KlarnaPayloadFactory $factory,
        private readonly KlarnaSessionStore $store,
        private readonly CredentialVault $vault,
        private readonly LoggerInterface $logger,
        private readonly \Closure $licensed,
    ) {
    }

    /**
     * @return array{client_token: string, categories: list<array{identifier: string, name: string}>}
     * @throws KlarnaException when Klarna cannot be offered for this cart (unsupported market/currency/amount or Klarna refusal)
     */
    public function sync(WC_Cart $cart, string $country, string $currency): array
    {
        $country = strtoupper($country);
        $currency = strtoupper($currency);
        if (!($this->licensed)()) {
            // An expired licence blocks NEW checkout sessions; restoring it re-enables them (subject to setup and the live lock).
            $this->store->set(null);
            throw new KlarnaException(KlarnaException::LICENSE, 'An active GR Commerce Suite licence is required for new Klarna payments.');
        }
        if (!$this->settings->ready()) {
            $this->store->set(null);
            throw new KlarnaException(KlarnaException::NOT_CONFIGURED, 'Klarna is not set up (or live mode is still locked).');
        }
        if (!in_array($country, $this->settings->countries(), true) || !in_array($currency, KlarnaSettings::CURRENCIES, true)) {
            $this->store->set(null);
            throw new KlarnaException(KlarnaException::VALIDATION, 'Klarna is not offered for this market or currency.');
        }
        try {
            $quote = $this->factory->fromCart($cart, $country, $currency);
        } catch (\InvalidArgumentException $e) {
            $this->store->set(null);
            throw new KlarnaException(KlarnaException::VALIDATION, 'The cart cannot be represented for Klarna.');
        }
        if ($quote['order_amount'] <= 0) {
            $this->store->set(null);
            throw new KlarnaException(KlarnaException::VALIDATION, 'Klarna needs a positive order amount.');
        }

        $environment = $this->settings->environment();
        $record = $this->store->get();
        if ($record !== null && ($record['environment'] ?? '') !== $environment) {
            $record = null;
        }
        if ($record !== null && ($record['fingerprint'] ?? '') === $quote['fingerprint'] && time() - (int) ($record['updated'] ?? 0) < self::MAX_AGE) {
            return $this->view($record);
        }

        if ($record !== null && is_string($record['session_id'] ?? null)) {
            try {
                $this->api->updateSession($record['session_id'], $this->factory->sessionPayload($quote, $this->callbackUrl((string) $record['secret'])));
                return $this->view($this->save($record, $quote, $record['client_token'], $record['categories'] ?? []));
            } catch (KlarnaException $e) {
                if (!in_array($e->kind, [KlarnaException::NOT_FOUND, KlarnaException::VALIDATION, KlarnaException::FORBIDDEN], true)) {
                    throw $e;
                }
                // The session expired or is closed: start a new one below. Order of operations never reuses a completed session.
            }
        }

        $secret = bin2hex(random_bytes(16));
        $created = $this->api->createSession($this->factory->sessionPayload($quote, $this->callbackUrl($secret)));
        $categories = [];
        foreach ($created['payment_method_categories'] as $category) {
            $identifier = (string) ($category['identifier'] ?? '');
            if (preg_match('/^[a-z0-9_]{1,64}$/', $identifier) === 1) {
                $categories[] = ['identifier' => $identifier, 'name' => (string) ($category['name'] ?? $identifier)];
            }
        }
        if ($categories === []) {
            $this->store->set(null);
            throw new KlarnaException(KlarnaException::VALIDATION, 'Klarna offers no payment method for this purchase.');
        }
        if (function_exists('set_transient')) {
            set_transient(self::callbackKey($secret), $created['session_id'], self::CALLBACK_TTL);
        }
        $fresh = ['session_id' => $created['session_id'], 'secret' => $secret, 'environment' => $environment];
        return $this->view($this->save($fresh, $quote, $created['client_token'], $categories));
    }

    /** The session record to bind a submitted authorization to, or null when none exists for this shopper. */
    /** @return array<string, mixed>|null */
    public function record(): ?array
    {
        return $this->store->get();
    }

    /** Called once an order is placed, or when the payment attempt is abandoned: the session must not be reused. */
    public function clear(): void
    {
        $this->store->set(null);
    }

    /**
     * Authorization callback (server-to-server). Only a trigger/hint: it remembers the token for the session the secret
     * belongs to so a lost browser response can be recovered; nothing is created or paid here.
     */
    public function acceptAuthorizationCallback(string $secret, string $sessionId, string $token): bool
    {
        if (!function_exists('get_transient') || preg_match('/^[a-f0-9]{32}$/', $secret) !== 1) {
            return false;
        }
        $expected = get_transient(self::callbackKey($secret));
        if (!is_string($expected) || $expected === '' || !hash_equals($expected, $sessionId)
            || preg_match('/^[A-Za-z0-9._~-]{8,512}$/', $token) !== 1) {
            return false;
        }
        try {
            set_transient(self::tokenKey($sessionId), $this->vault->encrypt($token), 3600);
        } catch (\Throwable) {
            return false; // no encryption available: never store a payment token in clear text
        }
        return true;
    }

    /** Token delivered by the authorization callback for a session, if any (valid for 60 minutes on Klarna's side). */
    public function callbackToken(string $sessionId): string
    {
        $stored = function_exists('get_transient') ? get_transient(self::tokenKey($sessionId)) : false;
        $plain = is_string($stored) ? $this->vault->decrypt($stored) : null;
        return $plain ?? '';
    }

    /**
     * @param array<string, mixed> $record
     * @param array<string, mixed> $quote
     * @param list<array{identifier: string, name: string}> $categories
     * @return array<string, mixed>
     */
    private function save(array $record, array $quote, string $clientToken, array $categories): array
    {
        $record['client_token'] = $clientToken;
        $record['fingerprint'] = $quote['fingerprint'];
        $record['quote'] = $quote;
        $record['categories'] = $categories;
        $record['updated'] = time();
        $this->store->set($record);
        $this->logger->info('Klarna session synchronised.');
        return $record;
    }

    /**
     * @param array<string, mixed> $record
     * @return array{client_token: string, categories: list<array{identifier: string, name: string}>}
     */
    private function view(array $record): array
    {
        return ['client_token' => (string) $record['client_token'], 'categories' => array_values((array) ($record['categories'] ?? []))];
    }

    private function callbackUrl(string $secret): string
    {
        return KlarnaRestController::url('authorization', ['k' => $secret]);
    }

    private static function callbackKey(string $secret): string
    {
        return 'grcs_klarna_cb_' . substr(hash('sha256', $secret), 0, 40);
    }

    private static function tokenKey(string $sessionId): string
    {
        return 'grcs_klarna_tk_' . substr(hash('sha256', $sessionId), 0, 40);
    }
}
