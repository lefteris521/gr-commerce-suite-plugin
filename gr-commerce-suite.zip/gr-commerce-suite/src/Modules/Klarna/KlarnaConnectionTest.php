<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\I18n\AdminLocale;

/**
 * "Test Connection" for the merchant's own Klarna credentials.
 *
 * Klarna has no ping endpoint. The check opens a Klarna Payments *session* for a synthetic one-line cart: nothing is charged,
 * no order exists, and an unused session just expires. That single call proves, with separate answers, that the credentials are
 * accepted (401), that Klarna Payments is enabled for the account (403), and that Klarna offers payment methods for the store's
 * market and currency (400 / empty categories). It uses the SAVED credentials of the environment under test; the outcome is
 * recorded (without secrets) toward the live-activation checklist.
 */
final class KlarnaConnectionTest
{
    public function __construct(private readonly KlarnaApiClient $api, private readonly KlarnaSettings $settings)
    {
    }

    /** @return array{ok: bool, message: string} Merchant-readable, never contains credentials or tokens. */
    public function run(?string $environment = null, string $currency = 'EUR'): array
    {
        $environment = $environment === 'live' ? 'live' : ($environment === 'playground' ? 'playground' : $this->settings->environment());
        $region = $this->settings->region();
        $country = $this->settings->countries()[0] ?? 'GR';
        $currency = in_array(strtoupper($currency), KlarnaSettings::CURRENCIES, true) ? strtoupper($currency) : 'EUR';
        $label = ($environment === 'live' ? AdminLocale::__('Live', 'gr-commerce-suite') : AdminLocale::__('Playground', 'gr-commerce-suite'))
            . ', ' . strtoupper($region) . ', ' . $country . '/' . $currency;

        $result = $this->attempt($environment, $region, $country, $currency, $label);
        $this->settings->recordTest($environment, $result['ok'], ['message' => $result['message'], 'region' => $region, 'country' => $country]);
        return $result;
    }

    /** @return array{ok: bool, message: string} */
    private function attempt(string $environment, string $region, string $country, string $currency, string $label): array
    {
        $payload = [
            'purchase_country' => $country,
            'purchase_currency' => $currency,
            'order_amount' => 100,
            'order_tax_amount' => 0,
            'order_lines' => [['type' => 'digital', 'name' => 'Connection test', 'quantity' => 1, 'unit_price' => 100,
                'tax_rate' => 0, 'total_amount' => 100, 'total_discount_amount' => 0, 'total_tax_amount' => 0]],
        ];
        try {
            $session = $this->api->createSession($payload, ['environment' => $environment, 'region' => $region]);
        } catch (KlarnaException $e) {
            return ['ok' => false, 'message' => $this->explain($e, $environment, $label)];
        }
        $names = array_values(array_filter(array_map(static fn(array $c): string => (string) ($c['name'] ?? $c['identifier'] ?? ''), $session['payment_method_categories'])));
        if ($names === []) {
            return ['ok' => false, 'message' => sprintf(AdminLocale::__('Connected (%s), but Klarna offers no payment method for this market and currency. Ask Klarna to enable it for your account.', 'gr-commerce-suite'), $label)];
        }
        return ['ok' => true, 'message' => sprintf(AdminLocale::__('Connected to Klarna (%1$s). Available: %2$s.', 'gr-commerce-suite'), $label, implode(', ', $names))];
    }

    private function explain(KlarnaException $e, string $environment, string $label): string
    {
        $support = $e->correlationId !== '' ? sprintf(AdminLocale::__(' Klarna reference for support: %s.', 'gr-commerce-suite'), $e->correlationId) : '';
        $name = $environment === 'live' ? AdminLocale::__('Live', 'gr-commerce-suite') : AdminLocale::__('Playground', 'gr-commerce-suite');
        $detail = $e->errorCode !== '' ? $label . ' · ' . $e->errorCode : $label;
        return match ($e->kind) {
            KlarnaException::NOT_CONFIGURED => AdminLocale::__('Save the API username and password for this environment first, then test.', 'gr-commerce-suite'),
            KlarnaException::AUTH => sprintf(AdminLocale::__('Klarna rejected these credentials (%1$s). Check that the username and password belong to the %2$s environment and region. Credentials from a payment provider (PSP) do not work here: use API credentials from your own Klarna Merchant Portal.', 'gr-commerce-suite'), $label, $name) . $support,
            KlarnaException::FORBIDDEN => sprintf(AdminLocale::__('The credentials are valid, but Klarna does not allow Klarna Payments for this account or market (%s). Ask Klarna to enable Klarna Payments.', 'gr-commerce-suite'), $label) . $support,
            KlarnaException::NOT_FOUND => sprintf(AdminLocale::__('Klarna did not recognise the request (%s). The region is probably wrong for this account.', 'gr-commerce-suite'), $label) . $support,
            KlarnaException::VALIDATION, KlarnaException::CONFLICT => sprintf(AdminLocale::__('Klarna refused the test purchase (%s). The market or currency is probably not enabled for your account.', 'gr-commerce-suite'), $detail) . $support,
            KlarnaException::RATE_LIMITED => AdminLocale::__('Klarna asked to slow down. Wait a minute and test again.', 'gr-commerce-suite') . $support,
            default => AdminLocale::__('Klarna could not be reached or did not answer reliably. Check that the server can make HTTPS requests, then try again.', 'gr-commerce-suite') . $support,
        };
    }
}
