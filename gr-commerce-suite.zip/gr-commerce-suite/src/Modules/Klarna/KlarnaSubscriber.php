<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\I18n\AdminLocale;

/**
 * Active-module checkout surface: SDK and classic checkout script, the classic session endpoint, and the Checkout Block
 * integration (payment method type + Store API cart extension). Registered by the kernel only while the module is on, and
 * every entry point rechecks the gate.
 */
final class KlarnaSubscriber implements HookSubscriberInterface
{
    public const SDK_HANDLE = 'grcs-klarna-sdk';
    public const SDK_URL = 'https://x.klarnacdn.net/kp/lib/v1/api.js';
    public const EXTENSION_NAMESPACE = 'grcs-klarna';
    public const NONCE_ACTION = 'grcs-klarna-session';
    public const TEST_ACTION = 'grcs_klarna_test_connection';

    public function register(): void
    {
        add_action('wp_enqueue_scripts', [$this, 'enqueueClassic']);
        add_action('wc_ajax_grcs_klarna_session', [$this, 'ajaxSession']);
        add_action('wp_ajax_' . self::TEST_ACTION, [$this, 'ajaxTestConnection']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdmin']);
        add_action('woocommerce_blocks_loaded', [$this, 'registerBlocks']);
        add_action('woocommerce_rest_checkout_process_payment_with_context', [$this, 'mirrorBlocksPaymentData'], 10, 2);
        if (did_action('woocommerce_blocks_loaded') > 0) {
            $this->registerBlocks();
        }
    }

    public static function registerSdk(): void
    {
        // Loaded from Klarna at runtime, never bundled. No version query: the CDN file is Klarna's evergreen build.
        wp_register_script(self::SDK_HANDLE, self::SDK_URL, [], null, true);
    }

    public function enqueueClassic(): void
    {
        if (!KlarnaModule::isEnabled() || !KlarnaServices::licensed() || !function_exists('is_checkout') || !is_checkout() || is_order_received_page()
            || (function_exists('has_block') && has_block('woocommerce/checkout'))) {
            return;
        }
        self::registerSdk();
        wp_enqueue_script('grcs-klarna-checkout', plugins_url('assets/js/klarna-checkout.js', GRCS_PLUGIN_FILE), ['jquery', self::SDK_HANDLE], GRCS_VERSION, true);
        wp_localize_script('grcs-klarna-checkout', 'grcsKlarna', [
            'gateway' => KlarnaSettings::GATEWAY_ID,
            'tokenField' => KlarnaGateway::FIELD_TOKEN,
            'sessionUrl' => \WC_AJAX::get_endpoint('grcs_klarna_session'),
            'nonce' => wp_create_nonce(self::NONCE_ACTION),
            'i18n' => [
                'unavailable' => __('Klarna is not available for this order.', 'gr-commerce-suite'),
                'declined' => __('Klarna could not approve this purchase. Please choose another payment method.', 'gr-commerce-suite'),
                'resume' => __('Your Klarna payment for this order is already in progress. Press "Place order" to continue; you will not be asked to approve it again.', 'gr-commerce-suite'), // customer-facing
                'status' => __('View your payment status', 'gr-commerce-suite'), // customer-facing
                'pending' => __('A previous Klarna payment is still being verified. Please wait for its confirmation before trying again.', 'gr-commerce-suite'), // customer-facing
            ],
        ]);
    }

    /** Classic checkout: create/update the Klarna session for the current cart and return the browser-side client token. */
    public function ajaxSession(): void
    {
        if (!KlarnaModule::isEnabled() || !KlarnaServices::licensed() || !check_ajax_referer(self::NONCE_ACTION, 'nonce', false)) {
            wp_send_json_error(['code' => 'unavailable'], 403);
        }
        // The shopper's own awaiting order that Klarna already holds is resumed by WooCommerce on the next submit: no new Klarna session
        // and no new authorisation (a new one would only be left open at Klarna). Decided from the stored order, the same way the
        // gateway decides it, and re-evaluated by the browser on every checkout update.
        $resumable = KlarnaGateway::resumableOrder();
        if ($resumable !== null) {
            wp_send_json_success(['resume' => true]);
        }
        $pending = KlarnaGateway::unresolvedElsewhereOrder();
        if ($pending !== null) {
            // Only a shopper who can prove they hold that order (account / own session / signed proof) ever reaches this: it is THEIR link.
            wp_send_json_success(['pending_verification' => true, 'url' => $pending->get_checkout_order_received_url()]);
        }
        try {
            wp_send_json_success($this->sync());
        } catch (KlarnaException $e) {
            wp_send_json_error(['code' => $e->kind]);
        }
    }

    public function enqueueAdmin(): void
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only screen detection
        if (!KlarnaModule::isEnabled() || !current_user_can('manage_woocommerce') || ($_GET['section'] ?? '') !== KlarnaSettings::GATEWAY_ID) {
            return;
        }
        wp_enqueue_script('grcs-klarna-admin', plugins_url('assets/js/klarna-admin.js', GRCS_PLUGIN_FILE), ['jquery'], GRCS_VERSION, true);
        wp_localize_script('grcs-klarna-admin', 'grcsKlarnaAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'action' => self::TEST_ACTION,
            'nonce' => wp_create_nonce(self::TEST_ACTION),
            'i18n' => ['testing' => AdminLocale::__('Testing...', 'gr-commerce-suite'), 'failed' => AdminLocale::__('The test request failed. Reload the page and try again.', 'gr-commerce-suite')],
        ]);
    }

    /** Admin only: tests the SAVED credentials of one environment. Returns a merchant-readable message, never secrets. */
    public function ajaxTestConnection(): void
    {
        if (!KlarnaModule::isEnabled() || !current_user_can('manage_woocommerce') || !check_ajax_referer(self::TEST_ACTION, 'nonce', false)) {
            wp_send_json_error(['message' => AdminLocale::__('Not allowed.', 'gr-commerce-suite')], 403);
        }
        $environment = isset($_POST['environment']) && $_POST['environment'] === 'live' ? 'live' : 'playground'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified above
        $result = KlarnaServices::connectionTest()->run($environment, (string) get_woocommerce_currency());
        $result['ok'] ? wp_send_json_success(['message' => $result['message']]) : wp_send_json_error(['message' => $result['message']]);
    }

    /**
     * Checkout Block support is uncertified (no browser run yet; the plugin still declares cart_checkout_blocks incompatible), so
     * Klarna is not registered with the block checkout unless the owner opts in with the `grcs_klarna_blocks_enabled` filter.
     */
    public static function blocksEnabled(): bool
    {
        return function_exists('apply_filters') && (bool) apply_filters('grcs_klarna_blocks_enabled', false);
    }

    public function registerBlocks(): void
    {
        if (!KlarnaModule::isEnabled() || !self::blocksEnabled()) {
            return;
        }
        add_action('woocommerce_blocks_payment_method_type_registration', static function ($registry): void {
            if (is_object($registry) && method_exists($registry, 'register') && class_exists(KlarnaBlocksSupport::class)) {
                $registry->register(new KlarnaBlocksSupport());
            }
        });
        if (function_exists('woocommerce_store_api_register_endpoint_data')) {
            woocommerce_store_api_register_endpoint_data([
                'endpoint' => 'cart',
                'namespace' => self::EXTENSION_NAMESPACE,
                // Read-only: returns the stored session view; Klarna is only called by the update callback below.
                'data_callback' => static function (): array {
                    $record = KlarnaModule::isEnabled() && KlarnaServices::licensed() ? KlarnaServices::sessions()->record() : null;
                    return [
                        'client_token' => is_array($record) ? (string) ($record['client_token'] ?? '') : '',
                        'categories' => is_array($record) ? array_values((array) ($record['categories'] ?? [])) : [],
                    ];
                },
                'schema_callback' => static fn(): array => [
                    'client_token' => ['type' => 'string', 'readonly' => true],
                    'categories' => ['type' => 'array', 'readonly' => true],
                ],
                'schema_type' => ARRAY_A,
            ]);
        }
        if (function_exists('woocommerce_store_api_register_update_callback')) {
            woocommerce_store_api_register_update_callback([
                'namespace' => self::EXTENSION_NAMESPACE,
                'callback' => function (): void {
                    if (!KlarnaModule::isEnabled() || !KlarnaServices::licensed()) {
                        return;
                    }
                    try {
                        $this->sync();
                    } catch (KlarnaException $e) {
                        // The data callback then reports no client token and the block hides Klarna.
                        KlarnaServices::logger()->warning('Klarna block session not available (' . $e->kind . ').');
                    }
                },
            ]);
        }
    }

    /**
     * Blocks sends payment data in the Store API request; the gateway reads the legacy request variables. Mirror only the
     * documented, validated token field.
     *
     * @param mixed $context
     * @param mixed $result
     */
    public function mirrorBlocksPaymentData(mixed $context, mixed $result = null): void
    {
        if (!KlarnaModule::isEnabled() || !is_object($context) || ($context->payment_method ?? '') !== KlarnaSettings::GATEWAY_ID) {
            return;
        }
        $data = is_array($context->payment_data ?? null) ? $context->payment_data : [];
        $token = (string) ($data[KlarnaGateway::FIELD_TOKEN] ?? '');
        if (preg_match('/^[A-Za-z0-9._~-]{8,512}$/', $token) === 1) {
            $_POST[KlarnaGateway::FIELD_TOKEN] = $token; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Store API authenticates the request.
        }
    }

    /** @return array{client_token: string, categories: list<array{identifier: string, name: string}>} */
    private function sync(): array
    {
        $woocommerce = \WC();
        if (!is_object($woocommerce->cart) || !is_object($woocommerce->customer)) {
            throw new KlarnaException(KlarnaException::VALIDATION, 'The cart is not available.');
        }
        $woocommerce->cart->calculate_totals();
        $country = (string) $woocommerce->customer->get_billing_country();
        return KlarnaServices::sessions()->sync($woocommerce->cart, $country !== '' ? $country : (string) $woocommerce->countries->get_base_country(), (string) get_woocommerce_currency());
    }
}
