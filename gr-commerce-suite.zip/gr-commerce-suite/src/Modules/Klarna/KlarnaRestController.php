<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Klarna server-to-server callbacks: authorization, push and notification.
 *
 * Registered only while the module is on (off = 404, the current suite webhook policy; any change needs owner approval).
 * Each URL embeds a secret Klarna cannot predict (per checkout session / per order, stored hashed); the payload itself is
 * never trusted: a callback only triggers a re-read of the real state from Klarna. Valid callbacks answer 2xx quickly,
 * duplicates included - never 409 - and do the real work in Action Scheduler.
 */
final class KlarnaRestController implements HookSubscriberInterface
{
    public const NAMESPACE = 'grcs/v1';

    public function __construct(
        private readonly KlarnaSessionService $sessions,
        private readonly LoggerInterface $logger,
    ) {
    }

    /** Absolute callback URL. $raw is appended verbatim so Klarna placeholders such as {order.id} stay literal. */
    /** @param array<string, mixed> $query */
    public static function url(string $route, array $query = [], string $raw = ''): string
    {
        $base = rest_url(self::NAMESPACE . '/klarna/' . $route);
        return $base . (str_contains($base, '?') ? '&' : '?') . http_build_query($query, '', '&', PHP_QUERY_RFC3986) . $raw;
    }

    public function register(): void
    {
        add_action('rest_api_init', [$this, 'routes']);
    }

    public function routes(): void
    {
        if (!KlarnaModule::requested()) {
            return;
        }
        $authorizations = KlarnaModule::isEnabled(); // an unready ledger keeps push/notification answering for existing orders, never a new authorization
        foreach (['authorization' => 'authorization', 'push' => 'push', 'notification' => 'notification'] as $route => $method) {
            if ($route === 'authorization' && !$authorizations) {
                continue;
            }
            register_rest_route(self::NAMESPACE, '/klarna/' . $route, [
                // Authorization is a documented POST with a JSON body. Push/notification carry only ids and are re-verified with
                // Klarna, so they also accept GET: the HTTP method of those two callbacks could not be verified from the documentation.
                'methods' => $route === 'authorization' ? 'POST' : 'GET, POST',
                'callback' => [$this, $method],
                // Public by design: Klarna cannot authenticate with WordPress. The unguessable per-session/per-order secret is the gate.
                'permission_callback' => '__return_true',
            ]);
        }
    }

    public function authorization(WP_REST_Request $request): WP_REST_Response
    {
        $secret = (string) $request->get_param('k');
        $json = $request->get_json_params();
        $body = is_array($json) ? $json : [];
        $accepted = $this->sessions->acceptAuthorizationCallback(
            $secret,
            (string) ($body['session_id'] ?? ''),
            (string) ($body['authorization_token'] ?? '')
        );
        if (!$accepted) {
            $this->logger->warning('Klarna authorization callback rejected.');
            return new WP_REST_Response(null, 403);
        }
        return new WP_REST_Response(null, 204);
    }

    public function push(WP_REST_Request $request): WP_REST_Response
    {
        return $this->orderCallback($request, 'push');
    }

    public function notification(WP_REST_Request $request): WP_REST_Response
    {
        return $this->orderCallback($request, 'notification');
    }

    private function orderCallback(WP_REST_Request $request, string $kind): WP_REST_Response
    {
        $orderId = (int) $request->get_param('o');
        $secret = (string) $request->get_param('k');
        $order = $orderId > 0 && function_exists('wc_get_order') ? \wc_get_order($orderId) : null;
        if (!$order instanceof \WC_Order || $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID
            || !(new KlarnaOrderRecord($order))->callbackSecretMatches($secret)) {
            $this->logger->warning('Klarna ' . $kind . ' callback rejected.');
            return new WP_REST_Response(null, 403);
        }
        $klarnaId = (string) $request->get_param('klarna_order_id');
        if (preg_match('/^[A-Za-z0-9._~-]{8,255}$/', $klarnaId) !== 1) {
            $klarnaId = ''; // unresolved placeholder or garbage: the stored id is used.
        }
        // Duplicates are expected (at-least-once delivery); scheduling is deduplicated and always acknowledged.
        if (!KlarnaRefreshJob::schedule($orderId, $klarnaId)) {
            // Acknowledging without a queued refresh would lose the notification; a 5xx makes Klarna deliver it again.
            $this->logger->warning('Klarna ' . $kind . ' callback could not be queued.');
            return new WP_REST_Response(null, 503);
        }
        return new WP_REST_Response(null, 204);
    }
}
