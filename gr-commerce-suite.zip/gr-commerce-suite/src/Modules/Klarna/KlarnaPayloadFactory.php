<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Support\Money;
use InvalidArgumentException;
use WC_Cart;
use WC_Order;

/**
 * Turns a WooCommerce cart (session creation) or order (order creation) into the same normalised Klarna quote.
 * Both paths use {@see KlarnaOrderLines}, so the fingerprints of cart and order are comparable: a mismatch means the
 * authorised cart is no longer the order being paid and the customer must authorise again.
 *
 * @phpstan-type Quote array{lines: list<array<string, mixed>>, order_amount: int, order_tax_amount: int, currency: string, country: string, fingerprint: string}
 */
class KlarnaPayloadFactory
{
    /** Amount in minor units from WooCommerce decimal strings/floats without float arithmetic. */
    public static function minor(mixed $value): int
    {
        if (is_float($value) || is_int($value)) {
            $value = sprintf('%.6F', $value);
        }
        $text = trim((string) $value);
        if ($text === '' || stripos($text, 'e') !== false) {
            $text = $text === '' ? '0' : sprintf('%.6F', (float) $text);
        }
        return Money::fromDecimalString($text)->cents();
    }

    /** @return Quote */
    public function fromCart(WC_Cart $cart, string $country, string $currency): array
    {
        $lines = [];
        foreach ($cart->get_cart() as $item) {
            $product = $item['data'] ?? null;
            if (!is_object($product) || !method_exists($product, 'get_name')) {
                throw new InvalidArgumentException('Cart item without a product.');
            }
            $lines[] = $this->productLine(
                $product,
                (int) ($item['quantity'] ?? 1),
                self::minor($item['line_subtotal'] ?? 0) + self::minor($item['line_subtotal_tax'] ?? 0),
                self::minor($item['line_total'] ?? 0) + self::minor($item['line_tax'] ?? 0),
                self::minor($item['line_tax'] ?? 0)
            );
        }
        $lines = array_merge($lines, $this->shippingLine(self::minor($cart->get_shipping_total()), self::minor($cart->get_shipping_tax())));
        foreach ($cart->get_fees() as $fee) {
            $lines[] = $this->feeLine((string) $fee->name, self::minor($fee->total ?? 0), self::minor($fee->tax ?? 0));
        }
        return $this->quote($lines, self::minor($cart->get_total('edit')), $country, $currency);
    }

    /** @return Quote */
    public function fromOrder(WC_Order $order): array
    {
        $lines = [];
        foreach ($order->get_items('line_item') as $item) {
            /** @var \WC_Order_Item_Product $item */
            $product = $item->get_product();
            if (!is_object($product)) {
                throw new InvalidArgumentException('Order item without a product.');
            }
            $lines[] = $this->productLine(
                $product,
                (int) $item->get_quantity(),
                self::minor($item->get_subtotal()) + self::minor($item->get_subtotal_tax()),
                self::minor($item->get_total()) + self::minor($item->get_total_tax()),
                self::minor($item->get_total_tax())
            );
        }
        $lines = array_merge($lines, $this->shippingLine(self::minor($order->get_shipping_total()), self::minor($order->get_shipping_tax())));
        foreach ($order->get_items('fee') as $fee) {
            /** @var \WC_Order_Item_Fee $fee */
            $lines[] = $this->feeLine((string) $fee->get_name(), self::minor($fee->get_total()), self::minor($fee->get_total_tax()));
        }
        return $this->quote($lines, self::minor($order->get_total()), (string) $order->get_billing_country(), (string) $order->get_currency());
    }

    /**
     * Session create/update body.
     *
     * @param Quote $quote
     * @return array<string, mixed>
     */
    public function sessionPayload(array $quote, string $authorizationCallbackUrl): array
    {
        return [
            'purchase_country' => $quote['country'],
            'purchase_currency' => $quote['currency'],
            'order_amount' => $quote['order_amount'],
            'order_tax_amount' => $quote['order_tax_amount'],
            'order_lines' => $quote['lines'],
            'merchant_urls' => ['authorization' => $authorizationCallbackUrl],
        ];
    }

    /**
     * Create-order body: exactly the authorised lines and amounts, plus addresses, references and callback URLs.
     *
     * @param Quote $authorized
     * @param array<string, string> $urls confirmation / notification / push
     * @return array<string, mixed>
     */
    public function orderPayload(array $authorized, WC_Order $order, array $urls): array
    {
        $payload = [
            'purchase_country' => $authorized['country'],
            'purchase_currency' => $authorized['currency'],
            'order_amount' => $authorized['order_amount'],
            'order_tax_amount' => $authorized['order_tax_amount'],
            'order_lines' => $authorized['lines'],
            'merchant_reference1' => substr((string) $order->get_order_number(), 0, 255),
            'merchant_reference2' => (string) $order->get_id(),
            'merchant_urls' => $urls,
        ];
        $billing = self::address($order, 'billing');
        if ($billing !== []) {
            $payload['billing_address'] = $billing;
        }
        if ($order->has_shipping_address()) {
            $shipping = self::address($order, 'shipping');
            if ($shipping !== []) {
                $payload['shipping_address'] = $shipping;
            }
        }
        return $payload;
    }

    /** @return array<string, string> */
    private static function address(WC_Order $order, string $kind): array
    {
        $get = static fn(string $field): string => trim((string) $order->{'get_' . $kind . '_' . $field}());
        $address = [
            'given_name' => $get('first_name'),
            'family_name' => $get('last_name'),
            'street_address' => $get('address_1'),
            'street_address2' => $get('address_2'),
            'postal_code' => $get('postcode'),
            'city' => $get('city'),
            'region' => $get('state'),
            'country' => strtoupper($get('country')),
        ];
        if ($kind === 'billing') {
            $address['email'] = $get('email');
            $phone = $get('phone');
            if (preg_match('/^\+?[0-9 ()\-]{6,20}$/', $phone) === 1) {
                $address['phone'] = $phone;
            }
        }
        return array_filter($address, static fn(string $value): bool => $value !== '');
    }

    /** @return array<string, mixed> */
    private function productLine(object $product, int $quantity, int $before, int $after, int $tax): array
    {
        $sku = method_exists($product, 'get_sku') ? (string) $product->get_sku() : '';
        $id = method_exists($product, 'get_id') ? (int) $product->get_id() : 0;
        $line = [
            'type' => method_exists($product, 'is_virtual') && $product->is_virtual() ? 'digital' : 'physical',
            'name' => method_exists($product, 'get_name') ? (string) $product->get_name() : '',
            'reference' => $sku !== '' ? $sku : 'id-' . $id,
            'quantity' => $quantity,
            'gross_before' => $before,
            'gross_after' => $after,
            'tax' => $tax,
        ];
        if ($id > 0 && function_exists('get_permalink')) {
            $line['product_url'] = (string) get_permalink($id);
        }
        return $line;
    }

    /** @return list<array<string, mixed>> */
    private function shippingLine(int $net, int $tax): array
    {
        $total = $net + $tax;
        if ($total === 0) {
            return [];
        }
        return [[
            'type' => 'shipping_fee',
            'name' => function_exists('__') ? __('Shipping', 'gr-commerce-suite') : 'Shipping',
            'reference' => 'shipping',
            'quantity' => 1,
            'gross_before' => $total,
            'gross_after' => $total,
            'tax' => $tax,
        ]];
    }

    /** @return array<string, mixed> */
    private function feeLine(string $name, int $net, int $tax): array
    {
        $total = $net + $tax;
        $slug = function_exists('sanitize_title') ? sanitize_title($name) : strtolower(preg_replace('/[^A-Za-z0-9]+/', '-', $name) ?? '');
        return [
            'type' => $total < 0 ? 'discount' : 'surcharge',
            'name' => $name,
            'reference' => 'fee-' . substr($slug, 0, 60),
            'quantity' => 1,
            'gross_before' => $total,
            'gross_after' => $total,
            'tax' => $tax,
        ];
    }

    /**
     * @param list<array<string, mixed>> $lines
     * @return Quote
     */
    private function quote(array $lines, int $total, string $country, string $currency): array
    {
        $currency = strtoupper($currency);
        $country = strtoupper($country);
        $built = KlarnaOrderLines::build($lines, $total, function_exists('__') ? __('Rounding', 'gr-commerce-suite') : 'Rounding');
        return [
            'lines' => $built['order_lines'],
            'order_amount' => $built['order_amount'],
            'order_tax_amount' => $built['order_tax_amount'],
            'currency' => $currency,
            'country' => $country,
            'fingerprint' => KlarnaOrderLines::fingerprint($built['order_lines'], $built['order_amount'], $currency, $country),
        ];
    }
}
