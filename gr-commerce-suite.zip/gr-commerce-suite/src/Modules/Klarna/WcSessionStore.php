<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

/** Klarna session record stored in the shopper's WooCommerce session (cookie-bound, server side). */
final class WcSessionStore implements KlarnaSessionStore
{
    private const KEY = 'grcs_klarna_session';

    public function get(): ?array
    {
        $session = function_exists('WC') ? \WC()->session : null;
        $record = is_object($session) ? $session->get(self::KEY) : null;
        return is_array($record) ? $record : null;
    }

    public function set(?array $record): void
    {
        $session = function_exists('WC') ? \WC()->session : null;
        if (!is_object($session)) {
            return;
        }
        $session->set(self::KEY, $record);
    }
}
