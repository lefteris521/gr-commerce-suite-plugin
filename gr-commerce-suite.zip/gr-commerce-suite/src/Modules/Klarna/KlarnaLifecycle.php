<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Support\Lock;
use WC_Order;

/**
 * Klarna hooks that must survive the module being switched off (historical operations on existing Klarna orders):
 * gateway registration (needed by WooCommerce to refund), capture on completion, cancel on cancellation, the order actions and the
 * refresh job handler. Nothing here touches checkout, creates sessions, or acts on orders that never had a Klarna order id;
 * the checkout surface lives in {@see KlarnaSubscriber}.
 */
final class KlarnaLifecycle implements HookSubscriberInterface
{
    private const ACTION_CAPTURE = 'grcs_klarna_capture';
    private const ACTION_CANCEL = 'grcs_klarna_cancel';
    private const ACTION_REFRESH = 'grcs_klarna_refresh';
    private const ACTION_LINK = 'grcs_klarna_link';
    private const ACTION_RELEASE = 'grcs_klarna_release';
    private const ACTION_RELEASE_ATTEMPT = 'grcs_release_payment_attempt';
    public const AJAX_STATUS = 'grcs_klarna_status';

    public function register(): void
    {
        add_filter('woocommerce_payment_gateways', [$this, 'addGateway']);
        add_action('woocommerce_order_status_completed', [$this, 'onCompleted'], 20, 1);
        add_action('woocommerce_order_status_cancelled', [$this, 'onCancelled'], 20, 1);
        add_action('woocommerce_order_status_failed', [$this, 'releaseUnusedAuthorization'], 20, 1);
        add_filter('woocommerce_order_actions', [$this, 'orderActions']);
        add_action('woocommerce_order_action_' . self::ACTION_CAPTURE, [$this, 'actionCapture']);
        add_action('woocommerce_order_action_' . self::ACTION_CANCEL, [$this, 'actionCancel']);
        add_action('woocommerce_order_action_' . self::ACTION_REFRESH, [$this, 'actionRefresh']);
        add_action('add_meta_boxes', [$this, 'addLinkBox'], 10, 2);
        add_action('admin_post_' . self::ACTION_LINK, [$this, 'handleLink']);
        // Customer-side safety of Klarna orders that exist already. These stay on while the module is off or the licence expired:
        // they only ever refuse or explain, they never open a new payment, and an order Klarna holds still needs them.
        add_action('woocommerce_after_checkout_validation', [$this, 'guardCheckout'], 10, 2);
        add_filter('woocommerce_order_needs_payment', [$this, 'holdPayPage'], 10, 2);
        add_filter('woocommerce_thankyou_order_received_text', [$this, 'receivedText'], 10, 2);
        add_filter('woocommerce_endpoint_order-received_title', [$this, 'receivedTitle']);
        add_filter('woocommerce_thankyou_order_received_title', [$this, 'receivedHeading'], 10, 2); // block-based order confirmation
        add_action('wp_enqueue_scripts', [$this, 'enqueueStatus']);
        add_action('wc_ajax_' . self::AJAX_STATUS, [$this, 'ajaxStatus']);
        add_action('woocommerce_email_before_order_table', [$this, 'emailStatusLink'], 10, 4);
        add_action('woocommerce_order_action_' . self::ACTION_RELEASE, [$this, 'actionRelease']);
        add_action('admin_post_' . self::ACTION_RELEASE_ATTEMPT, [$this, 'handleReleaseAttempt']);
        add_action('admin_notices', [$this, 'releaseNotice']);
        // Cross-gateway coordination (one checkout request at a time per shopper, payment intents, unpaid-order cancellation): see the class.
        (new KlarnaCheckoutCoordinator())->register();
        (new KlarnaRefreshJob(KlarnaServices::management()))->register();
    }

    /**
     * Cross-gateway guards at WooCommerce's own validation step, for the VERIFIED shopper only (account, own session order, signed guest
     * proof - never a typed email, see {@see KlarnaShopperProof}):
     *  - another gateway must not become a second way to pay for what Klarna may already hold: a Klarna-held order WooCommerce is about to
     *    resume (switching it would also drop the Klarna callbacks), or an unresolved Klarna order for the SAME cart. A different cart is
     *    not blocked;
     *  - Klarna must not be started for a cart whose payment another (third-party) gateway left pending and may still be completing.
     * The refusal links the shopper's own order page (their key proves it is theirs); nothing about anyone else is ever revealed.
     *
     * @param mixed $data
     * @param mixed $errors WP_Error
     */
    public function guardCheckout($data, $errors): void
    {
        if (!is_array($data) || !is_object($errors) || !method_exists($errors, 'add')) {
            return;
        }
        $posted = (string) ($data['payment_method'] ?? '');
        if ($posted === '') {
            return;
        }
        $wc = function_exists('WC') ? \WC() : null;
        $cart = is_object($wc) ? $wc->cart : null;
        $hash = is_object($cart) ? (string) $cart->get_cart_hash() : '';
        $user = KlarnaShopperProof::userId();
        $orderIds = KlarnaShopperProof::orderIds();
        $lookup = new KlarnaOrderLookup();
        if ($posted === KlarnaSettings::GATEWAY_ID) {
            // Klarna's own validate_fields() speaks for unresolved Klarna orders; a third-party payment in flight is checked here.
            foreach ($hash !== '' ? $lookup->inFlightOtherGateway($user, $orderIds) : [] as $other) {
                if ($other->has_cart_hash($hash)) {
                    $errors->add('grcs_klarna_inflight', __('A previous payment may still be in progress. Please check your email or contact the store before paying again.', 'gr-commerce-suite')); // customer-facing
                    return;
                }
            }
            return;
        }
        $pending = KlarnaGateway::resumableOrder();
        if ($pending === null && $hash !== '') {
            foreach ($lookup->unresolvedOrdersForShopper($user, $orderIds) as $other) {
                if ($other->has_cart_hash($hash)) {
                    $pending = $other;
                    break;
                }
            }
        }
        if ($pending !== null) {
            $errors->add('grcs_klarna_pending', KlarnaGateway::pendingNotice($pending));
        }
    }

    /** The pay-for-order page must not offer another way to pay for an order Klarna holds (it would drop the Klarna callbacks). Checkout is unaffected. */
    public function holdPayPage(mixed $needsPayment, mixed $order): mixed
    {
        if (!$needsPayment || !$order instanceof WC_Order || $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID
            || !function_exists('is_wc_endpoint_url') || !is_wc_endpoint_url('order-pay')) {
            return $needsPayment;
        }
        $record = new KlarnaOrderRecord($order);
        return $record->heldByKlarna() && $record->fraudStatus() !== 'REJECTED' ? false : $needsPayment;
    }

    /** Klarna has (or may have) this order but has not confirmed it: the shopper is told so, never "paid" and never "thank you, done". */
    public static function awaitingKlarna(WC_Order $order): bool
    {
        if ($order->get_payment_method() !== KlarnaSettings::GATEWAY_ID || !$order->has_status(['pending', 'on-hold'])) {
            return false;
        }
        $record = new KlarnaOrderRecord($order);
        return $record->heldByKlarna() && $record->fraudStatus() !== 'REJECTED';
    }

    public function receivedText(mixed $text, mixed $order = null): mixed
    {
        if (!$order instanceof WC_Order || !self::awaitingKlarna($order)) {
            return $text;
        }
        return esc_html__('Your Klarna payment is pending verification. Klarna has not confirmed it yet, so your order is not paid. Please do not pay again: we will email you as soon as it is confirmed.', 'gr-commerce-suite') // customer-facing
            . ' <span id="grcs-klarna-status" class="grcs-klarna-status" role="status" aria-live="polite"></span>';
    }

    public function receivedTitle(mixed $title): mixed
    {
        $order = $this->receivedOrder();
        return $order !== null && self::awaitingKlarna($order) ? __('Payment pending verification', 'gr-commerce-suite') : $title; // customer-facing
    }

    public function receivedHeading(mixed $title, mixed $order = null): mixed
    {
        return $order instanceof WC_Order && self::awaitingKlarna($order) ? __('Payment pending verification', 'gr-commerce-suite') : $title; // customer-facing
    }

    /** The order of the order-received page when the link carries its order key (the same bearer check WooCommerce itself makes), else null. */
    private function receivedOrder(): ?WC_Order
    {
        if (!function_exists('is_order_received_page') || !is_order_received_page() || !function_exists('wc_get_order')) {
            return null;
        }
        global $wp;
        $orderId = is_object($wp) && isset($wp->query_vars['order-received']) ? absint($wp->query_vars['order-received']) : 0;
        $key = isset($_GET['key']) && is_string($_GET['key']) ? sanitize_text_field(wp_unslash($_GET['key'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- bearer key, compared below
        return $this->orderByKey($orderId, $key);
    }

    private function orderByKey(int $orderId, string $key): ?WC_Order
    {
        $order = $orderId > 0 && $key !== '' && function_exists('wc_get_order') ? \wc_get_order($orderId) : null;
        if (!$order instanceof WC_Order || $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID || !hash_equals((string) $order->get_order_key(), $key)) {
            return null;
        }
        // An order that belongs to an account is only served to that logged-in account: the key alone (a link that may have been shared or
        // leaked) is not enough. Guest orders are served to whoever holds the key, exactly like WooCommerce's own order-received page.
        $owner = (int) $order->get_customer_id();
        return $owner > 0 && KlarnaShopperProof::userId() !== $owner ? null : $order;
    }

    public function enqueueStatus(): void
    {
        $order = $this->receivedOrder();
        if ($order === null || !self::awaitingKlarna($order)) {
            return;
        }
        wp_enqueue_script('grcs-klarna-status', plugins_url('assets/js/klarna-status.js', GRCS_PLUGIN_FILE), [], GRCS_VERSION, true);
        wp_localize_script('grcs-klarna-status', 'grcsKlarnaStatus', [
            'url' => \WC_AJAX::get_endpoint(self::AJAX_STATUS),
            'order' => $order->get_id(),
            'key' => (string) $order->get_order_key(),
            'i18n' => [
                'check' => __('Check status now', 'gr-commerce-suite'), // customer-facing
                'checking' => __('Checking with Klarna...', 'gr-commerce-suite'), // customer-facing
            ],
        ]);
    }

    /**
     * Customer status / recovery check for an order Klarna holds: answers from the order, and (at most every 20 seconds per order)
     * asks Klarna for its decision and applies it. Works with the module off and the licence expired - it reconciles an existing
     * order and never opens a payment. The order key is the only credential, as on WooCommerce's own order-received page; any
     * mismatch answers the same generic "unknown", so another shopper's order is never confirmed or described.
     */
    public function ajaxStatus(): void
    {
        $orderId = isset($_REQUEST['order']) ? absint($_REQUEST['order']) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the order key below is the credential
        $key = isset($_REQUEST['key']) && is_string($_REQUEST['key']) ? sanitize_text_field(wp_unslash($_REQUEST['key'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $limiter = new KlarnaStatusLimiter();
        $reservation = $limiter->reserve();
        if ($reservation === null) {
            wp_send_json_error(['state' => 'unknown'], 429); // same answer for every request of that client, valid or not, existing order or not
        }
        $order = $this->orderByKey($orderId, $key);
        if ($order === null) {
            // Reservation stays as counted failure; shared path for unknown, wrong key, other gateway, other account
            wp_send_json_error(['state' => 'unknown'], 404);
        }
        $limiter->refund($reservation);
        $record = new KlarnaOrderRecord($order);
        $throttle = 'grcs_klarna_status_' . $order->get_id();
        $lock = 'klarna-status-' . $order->get_id();
        if ($record->klarnaOrderId() !== '' && !$order->is_paid() && Lock::acquire($lock, 120)) {
            try {
                if (get_transient($throttle) === false) {
                    set_transient($throttle, 1, 20);
                    KlarnaServices::management()->refresh($order);
                    $refreshed = \wc_get_order($order->get_id());
                    if ($refreshed instanceof WC_Order) {
                        $order = $refreshed;
                    }
                }
            } finally {
                Lock::release($lock);
            }
        }
        wp_send_json_success(self::statusFor($order));
    }

    /**
     * The mail to the order's own billing address (WooCommerce sends it on pending -> on-hold) carries the status link for an order Klarna
     * has not confirmed. Having the inbox of that address is verified ownership: it is the recovery path for a guest who lost every cookie.
     *
     * @param mixed $order
     * @param mixed $sentToAdmin
     * @param mixed $plainText
     * @param mixed $email
     */
    public function emailStatusLink($order, $sentToAdmin = false, $plainText = false, $email = null): void
    {
        if ($sentToAdmin || !$order instanceof WC_Order || !self::awaitingKlarna($order)) {
            return;
        }
        $text = __('Your Klarna payment is pending verification. Klarna has not confirmed it yet, so your order is not paid. Please do not pay again.', 'gr-commerce-suite'); // customer-facing
        $url = $order->get_checkout_order_received_url();
        $label = __('Check the status of your payment', 'gr-commerce-suite'); // customer-facing
        echo $plainText ? "\n" . $text . "\n" . $label . ': ' . esc_url_raw($url) . "\n\n" : '<p>' . esc_html($text) . ' <a href="' . esc_url($url) . '">' . esc_html($label) . '</a></p>';
    }

    /**
     * Attested merchant release (D1 v4): needs `manage_woocommerce`, a nonce for this order, a reason, evidence type + reference and the
     * explicit attestation, and records an attributed event in the payment ledger in the same transaction. Works with the module off.
     * Kept as the programmatic entry point; the admin form posts to {@see self::handleReleaseAttempt()}.
     */
    public function actionRelease(WC_Order $order): void
    {
        KlarnaAttemptRelease::release($order, $_POST); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified inside release()
    }

    public function handleReleaseAttempt(): void
    {
        $orderId = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified inside release()
        $order = $orderId > 0 && function_exists('wc_get_order') ? \wc_get_order($orderId) : null;
        if (!$order instanceof WC_Order || !current_user_can('manage_woocommerce')) {
            wp_die(AdminLocale::esc_html__('The payment attempt could not be released.', 'gr-commerce-suite'), '', ['response' => 403]);
        }
        $ok = KlarnaAttemptRelease::release($order, $_POST); // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (function_exists('wp_doing_ajax') && wp_doing_ajax()) {
            return;
        }
        wp_safe_redirect(add_query_arg('grcs_release', $ok ? 'ok' : 'failed', $order->get_edit_order_url()));
        exit;
    }

    public function releaseNotice(): void
    {
        if (isset($_GET['grcs_release']) && $_GET['grcs_release'] === 'failed' && current_user_can('manage_woocommerce')) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only
            echo '<div class="notice notice-error"><p>' . AdminLocale::esc_html__('The payment attempt could not be released.', 'gr-commerce-suite') . '</p></div>';
        }
    }

    /** @return array{state: string, message: string} */
    public static function statusFor(WC_Order $order): array
    {
        $record = new KlarnaOrderRecord($order);
        if ($order->is_paid()) {
            return ['state' => 'confirmed', 'message' => __('Klarna confirmed your payment. Thank you!', 'gr-commerce-suite')]; // customer-facing
        }
        if (!$record->unresolved() && ($record->fraudStatus() === 'REJECTED' || $order->has_status(['failed', 'cancelled']))) {
            return ['state' => 'failed', 'message' => __('Klarna did not complete this payment. Please place a new order or choose another payment method.', 'gr-commerce-suite')]; // customer-facing
        }
        return ['state' => 'pending', 'message' => __('Klarna has not confirmed this payment yet. Please do not pay again.', 'gr-commerce-suite')]; // customer-facing
    }

    /**
     * @param array<int, string> $gateways
     * @return array<int, string>
     */
    public function addGateway(array $gateways): array
    {
        $gateways[] = KlarnaGateway::class;
        return $gateways;
    }

    public function onCompleted(mixed $orderId): void
    {
        $order = $this->klarnaOrder($orderId);
        if ($order === null || !KlarnaServices::settings()->autoCapture()) {
            return;
        }
        $this->note($order, 'capture', KlarnaServices::management()->capture($order));
    }

    /**
     * A Klarna checkout that never became a Klarna order (failed or cancelled): release the approval Klarna still holds for it.
     * Never for an order whose create call was ambiguous - Klarna may have an order we cannot name yet.
     */
    public function releaseUnusedAuthorization(mixed $orderId): void
    {
        $order = function_exists('wc_get_order') ? \wc_get_order((int) $orderId) : null;
        if (!$order instanceof WC_Order || $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID) {
            return;
        }
        $record = new KlarnaOrderRecord($order);
        $sessionId = (string) $order->get_meta(KlarnaOrderRecord::META_SESSION);
        if ($record->klarnaOrderId() !== '' || $sessionId === '' || in_array($record->phase(), [KlarnaOrderRecord::PHASE_AMBIGUOUS, KlarnaOrderRecord::PHASE_CREATING], true)) {
            return;
        }
        $token = KlarnaServices::sessions()->callbackToken($sessionId);
        if ($token !== '') {
            KlarnaServices::payments()->release($token);
        }
    }

    public function onCancelled(mixed $orderId): void
    {
        $this->releaseUnusedAuthorization($orderId);
        $order = $this->klarnaOrder($orderId);
        if ($order !== null && KlarnaServices::settings()->autoCancel()) {
            $this->note($order, 'cancel', KlarnaServices::management()->cancel($order));
        }
    }

    /**
     * @param array<string, string> $actions
     * @return array<string, string>
     */
    public function orderActions(array $actions): array
    {
        global $theorder;
        if ($theorder instanceof WC_Order && $this->isPlacedKlarnaOrder($theorder) && current_user_can('manage_woocommerce')) {
            $actions[self::ACTION_REFRESH] = AdminLocale::__('Klarna: refresh status', 'gr-commerce-suite');
            $actions[self::ACTION_CAPTURE] = AdminLocale::__('Klarna: capture', 'gr-commerce-suite');
            $actions[self::ACTION_CANCEL] = AdminLocale::__('Klarna: cancel / release authorisation', 'gr-commerce-suite');
        }
        return $actions;
    }

    public function actionCapture(WC_Order $order): void
    {
        if ($this->allowed($order)) {
            $this->note($order, 'capture', KlarnaServices::management()->capture($order));
        }
    }

    public function actionCancel(WC_Order $order): void
    {
        if ($this->allowed($order)) {
            $this->note($order, 'cancel', KlarnaServices::management()->cancel($order));
        }
    }

    /** Historical, works with the module off: covers missed callbacks and the ambiguous-create recovery. */
    public function actionRefresh(WC_Order $order): void
    {
        if ($this->allowed($order, true)) {
            $this->note($order, 'refresh', KlarnaServices::management()->refresh($order));
        }
    }

    /** Order screen box for a Klarna order whose creation was never confirmed (shown only then). */
    public function addLinkBox(mixed $postType = null, mixed $postOrOrder = null): void
    {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        $screen = function_exists('wc_get_page_screen_id') ? \wc_get_page_screen_id('shop-order') : 'shop_order';
        if ($this->unconfirmedKlarnaOrder($postOrOrder) !== null) {
            add_meta_box('grcs-klarna-link', AdminLocale::__('Klarna: unconfirmed order', 'gr-commerce-suite'), [$this, 'renderLinkBox'], $screen, 'side');
        }
        $id = $postOrOrder instanceof WC_Order ? $postOrOrder->get_id() : ($postOrOrder instanceof \WP_Post ? $postOrOrder->ID : 0);
        $order = $id > 0 && function_exists('wc_get_order') ? \wc_get_order($id) : null;
        if ($order instanceof WC_Order && KlarnaAttemptRelease::releasable($order)) {
            add_meta_box('grcs-release-attempt', AdminLocale::__('Release payment attempt', 'gr-commerce-suite'), [$this, 'renderReleaseBox'], $screen, 'side');
        }
    }

    /** @param mixed $postOrOrder */
    public function renderReleaseBox($postOrOrder): void
    {
        $id = $postOrOrder instanceof WC_Order ? $postOrOrder->get_id() : ($postOrOrder instanceof \WP_Post ? $postOrOrder->ID : 0);
        if ($id <= 0 || !current_user_can('manage_woocommerce')) {
            return;
        }
        echo '<p class="description">' . AdminLocale::esc_html__('Releasing this attempt can allow another payment. A late charge may still occur.', 'gr-commerce-suite') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field(KlarnaAttemptRelease::NONCE_PREFIX . $id);
        echo '<input type="hidden" name="action" value="' . esc_attr(self::ACTION_RELEASE_ATTEMPT) . '" /><input type="hidden" name="order_id" value="' . esc_attr((string) $id) . '" />'
            . '<p><label>' . AdminLocale::esc_html__('Reason', 'gr-commerce-suite') . '<input type="text" name="grcs_release_reason" class="widefat" required /></label></p>'
            . '<p><label>' . AdminLocale::esc_html__('Evidence checked', 'gr-commerce-suite') . '<input type="text" name="grcs_release_evidence_type" class="widefat" placeholder="provider_portal" required /></label></p>'
            . '<p><input type="text" name="grcs_release_evidence_ref" class="widefat" placeholder="reference" required /></p>'
            . '<p><textarea name="grcs_release_note" class="widefat" rows="2"></textarea></p>'
            . '<p><label><input type="checkbox" name="grcs_release_attestation" value="1" required /> ' . AdminLocale::esc_html__('I confirm that the original payment cannot still execute or settle', 'gr-commerce-suite') . '</label></p>'
            . '<button type="submit" class="button">' . AdminLocale::esc_html__('Release payment attempt', 'gr-commerce-suite') . '</button></form>';
    }

    /** The order behind an order-screen object when it is a Klarna order Klarna never confirmed; otherwise null. */
    private function unconfirmedKlarnaOrder(mixed $postOrOrder): ?WC_Order
    {
        $id = $postOrOrder instanceof WC_Order ? $postOrOrder->get_id() : ($postOrOrder instanceof \WP_Post ? $postOrOrder->ID : 0);
        $order = $id > 0 && function_exists('wc_get_order') ? \wc_get_order($id) : null;
        if (!$order instanceof WC_Order || $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID
            || (new KlarnaOrderRecord($order))->klarnaOrderId() !== '') {
            return null;
        }
        return $order;
    }

    /** @param mixed $postOrOrder */
    public function renderLinkBox($postOrOrder): void
    {
        $order = $this->unconfirmedKlarnaOrder($postOrOrder);
        if ($order === null) {
            return;
        }
        echo '<p>' . AdminLocale::esc_html__('Klarna never confirmed this order. If the Klarna merchant portal shows an order for it, enter its Klarna order ID. It is verified against this order (reference, currency and amount) before anything changes.', 'gr-commerce-suite') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field(self::ACTION_LINK . $order->get_id());
        echo '<input type="hidden" name="action" value="' . esc_attr(self::ACTION_LINK) . '" />'
            . '<input type="hidden" name="order_id" value="' . esc_attr((string) $order->get_id()) . '" />'
            . '<input type="text" name="klarna_order_id" class="widefat" autocomplete="off" /> '
            . '<button type="submit" class="button">' . AdminLocale::esc_html__('Link Klarna order', 'gr-commerce-suite') . '</button></form>';
    }

    public function handleLink(): void
    {
        $orderId = isset($_POST['order_id']) ? (int) $_POST['order_id'] : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified below
        check_admin_referer(self::ACTION_LINK . $orderId);
        $order = function_exists('wc_get_order') ? \wc_get_order($orderId) : null;
        $klarnaId = isset($_POST['klarna_order_id']) ? trim(wp_unslash((string) $_POST['klarna_order_id'])) : '';
        if (!current_user_can('manage_woocommerce') || !$order instanceof WC_Order || $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID
            || preg_match('/^[A-Za-z0-9._~-]{8,255}$/', $klarnaId) !== 1) {
            wp_die(AdminLocale::esc_html__('This Klarna order cannot be linked.', 'gr-commerce-suite'), '', ['response' => 403]);
        }
        $this->note($order, 'link', KlarnaServices::management()->refresh($order, $klarnaId));
        wp_safe_redirect($order->get_edit_order_url());
        exit;
    }

    private function allowed(WC_Order $order, bool $mayLackKlarnaId = false): bool
    {
        return current_user_can('manage_woocommerce')
            && $order->get_payment_method() === KlarnaSettings::GATEWAY_ID
            && ($mayLackKlarnaId || $this->isPlacedKlarnaOrder($order));
    }

    private function klarnaOrder(mixed $orderId): ?WC_Order
    {
        $order = function_exists('wc_get_order') ? \wc_get_order((int) $orderId) : null;
        return $order instanceof WC_Order && $this->isPlacedKlarnaOrder($order) ? $order : null;
    }

    private function isPlacedKlarnaOrder(WC_Order $order): bool
    {
        return $order->get_payment_method() === KlarnaSettings::GATEWAY_ID && (new KlarnaOrderRecord($order))->klarnaOrderId() !== '';
    }

    /** @param array{ok: bool, message: string} $result */
    private function note(WC_Order $order, string $what, array $result): void
    {
        if (!$result['ok']) {
            $order->add_order_note('Klarna ' . $what . ': ' . $result['message']);
            $order->save();
        }
    }
}
