<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\I18n\AdminLocale;
use WC_Payment_Gateway;
use WP_Error;

/**
 * WooCommerce gateway for Klarna Payments.
 *
 * Registered with WooCommerce for as long as the plugin is active so refunds of existing Klarna orders keep working; while the
 * module is off {@see is_available()} is false and the settings screen only explains that. The customer never enters payment
 * details on this site: the Klarna SDK iframe authorises the purchase and the browser hands back only an opaque authorization
 * token, which the server binds to this checkout and exchanges for a Klarna order.
 */
final class KlarnaGateway extends WC_Payment_Gateway
{
    public const FIELD_TOKEN = 'grcs_klarna_token';
    private const SECRET_FIELDS = ['playground_username', 'playground_password', 'live_username', 'live_password'];

    public function __construct()
    {
        $this->id = KlarnaSettings::GATEWAY_ID;
        $this->method_title = AdminLocale::__('Klarna Payments (GR Commerce Suite)', 'gr-commerce-suite');
        $this->method_description = AdminLocale::__('Direct Klarna Payments API integration: session, authorisation, order creation, capture, cancellation and refunds.', 'gr-commerce-suite');
        $this->has_fields = true;
        $this->supports = ['products', 'refunds'];
        $this->init_form_fields();
        $this->init_settings();
        $this->title = (string) $this->get_option('title', 'Klarna');
        $this->description = (string) $this->get_option('description', '');
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, function (): void {
            $this->process_admin_options();
        });
        add_filter('woocommerce_settings_api_sanitized_fields_' . $this->id, [$this, 'stripSecrets']);
    }

    public function init_form_fields(): void
    {
        $settings = KlarnaServices::settings();
        // Decrypting credentials is only needed to label the admin form; skip it on storefront requests.
        $saved = static fn(string $env): string => !is_admin() ? '' : ($settings->hasCredentials($env)
            ? AdminLocale::__('Saved. Leave blank to keep it.', 'gr-commerce-suite') : AdminLocale::__('Not saved yet.', 'gr-commerce-suite'));
        $this->form_fields = [
            'enabled' => ['title' => AdminLocale::__('Enable', 'gr-commerce-suite'), 'type' => 'checkbox', 'label' => AdminLocale::__('Offer Klarna at checkout', 'gr-commerce-suite'), 'default' => 'no'],
            'title' => ['title' => AdminLocale::__('Title', 'gr-commerce-suite'), 'type' => 'text', 'default' => 'Klarna'],
            'description' => ['title' => AdminLocale::__('Description', 'gr-commerce-suite'), 'type' => 'textarea', 'default' => ''],
            'environment' => [
                'title' => AdminLocale::__('Environment', 'gr-commerce-suite'), 'type' => 'select', 'default' => 'playground',
                'description' => AdminLocale::__('Start with Playground (test payments, no real money). Live stays locked until the checklist above is complete.', 'gr-commerce-suite'),
                'options' => ['playground' => AdminLocale::__('Playground (test)', 'gr-commerce-suite'), 'live' => AdminLocale::__('Live', 'gr-commerce-suite')],
            ],
            'live_approved' => [
                'title' => AdminLocale::__('Live approval', 'gr-commerce-suite'), 'type' => 'checkbox', 'default' => 'no',
                'label' => AdminLocale::__('Klarna has approved my store for live payments and I completed test orders in Playground', 'gr-commerce-suite'),
            ],
            'region' => [
                'title' => AdminLocale::__('Klarna region', 'gr-commerce-suite'), 'type' => 'select', 'default' => 'eu',
                'description' => AdminLocale::__('Must match the region of your Klarna merchant account (Europe, North America or Oceania).', 'gr-commerce-suite'),
                'options' => ['eu' => AdminLocale::__('Europe', 'gr-commerce-suite'), 'na' => AdminLocale::__('North America', 'gr-commerce-suite'), 'oc' => AdminLocale::__('Oceania', 'gr-commerce-suite')],
            ],
            'countries' => [
                'title' => AdminLocale::__('Purchase countries', 'gr-commerce-suite'), 'type' => 'text', 'default' => 'GR',
                'description' => AdminLocale::__('Comma-separated ISO country codes where you offer Klarna. Klarna decides availability per market and contract.', 'gr-commerce-suite'),
            ],
            'auto_capture' => ['title' => AdminLocale::__('Capture', 'gr-commerce-suite'), 'type' => 'checkbox', 'default' => 'yes',
                'label' => AdminLocale::__('Capture in Klarna when the order is marked Completed', 'gr-commerce-suite')],
            'auto_cancel' => ['title' => AdminLocale::__('Cancel', 'gr-commerce-suite'), 'type' => 'checkbox', 'default' => 'yes',
                'label' => AdminLocale::__('Cancel in Klarna when the order is marked Cancelled', 'gr-commerce-suite')],
            'playground_username' => ['title' => AdminLocale::__('Playground API username', 'gr-commerce-suite'), 'type' => 'text', 'description' => $saved('playground'), 'default' => ''],
            'playground_password' => ['title' => AdminLocale::__('Playground API password', 'gr-commerce-suite'), 'type' => 'password', 'description' => $saved('playground'), 'default' => ''],
            'live_username' => ['title' => AdminLocale::__('Live API username', 'gr-commerce-suite'), 'type' => 'text', 'description' => $saved('live'), 'default' => ''],
            'live_password' => ['title' => AdminLocale::__('Live API password', 'gr-commerce-suite'), 'type' => 'password', 'description' => $saved('live'), 'default' => ''],
        ];
    }

    public function admin_options(): void
    {
        if (!KlarnaModule::requested()) {
            echo '<h2>' . esc_html($this->get_method_title()) . '</h2><p>'
                . AdminLocale::esc_html__('The Klarna module is off. Turn it on under GR Commerce Suite > Modules. Saved credentials and existing Klarna orders are not affected.', 'gr-commerce-suite') . '</p>';
            return;
        }
        if (!KlarnaModule::ledgerReady()) {
            echo '<div class="notice notice-warning inline"><p>'
                . AdminLocale::esc_html__('Klarna is switched on but is not offered at checkout: the payment-attempt ledger is not ready (database tables missing or not InnoDB). Other payment methods are not affected. Save these settings to re-check, or contact support if this stays.', 'gr-commerce-suite') . '</p></div>';
        }
        $this->renderSetupStatus();
        parent::admin_options();
        echo '<p>' . AdminLocale::esc_html__('Use the API credentials of your own Klarna merchant account (Klarna Merchant Portal > API credentials). Credentials from a payment provider (PSP) do not work with this direct integration. They are stored encrypted and never shown again.', 'gr-commerce-suite') . '</p>';
    }

    /** Checklist plus Test Connection buttons (wired by assets/js/klarna-admin.js; the test uses the saved credentials). */
    private function renderSetupStatus(): void
    {
        $settings = KlarnaServices::settings();
        $state = $settings->state();
        $yes = static fn(bool $ok): string => $ok ? '&#10003; ' : '&#9675; ';
        $last = $state['last_test'];
        echo '<div class="grcs-klarna-status"><h3>' . AdminLocale::esc_html__('Setup status', 'gr-commerce-suite') . '</h3><ul>';
        if (!KlarnaServices::licensed()) {
            echo '<li>&#9675; ' . AdminLocale::esc_html__('An active GR Commerce Suite licence is required for new Klarna payments. Existing Klarna orders can still be captured, cancelled and refunded.', 'gr-commerce-suite') . '</li>';
        }
        echo '<li>' . $yes($settings->hasCredentials('playground')) . AdminLocale::esc_html__('Playground credentials saved', 'gr-commerce-suite') . '</li>';
        echo '<li>' . $yes($state['playground_ok'] > 0) . AdminLocale::esc_html__('Playground connection tested', 'gr-commerce-suite') . '</li>';
        echo '<li>' . $yes($state['playground_orders'] > 0) . esc_html(sprintf(AdminLocale::__('Playground test orders placed: %d', 'gr-commerce-suite'), $state['playground_orders'])) . '</li>';
        $blockers = $settings->liveBlockers();
        echo '<li>' . $yes($blockers === []) . ($blockers === []
            ? AdminLocale::esc_html__('Live mode can be used', 'gr-commerce-suite')
            : AdminLocale::esc_html__('Live mode is locked:', 'gr-commerce-suite') . ' ' . esc_html(implode(' ', $blockers))) . '</li>';
        if ($last !== []) {
            echo '<li>' . esc_html(sprintf(AdminLocale::__('Last test: %1$s (%2$s)', 'gr-commerce-suite'), (string) ($last['message'] ?? ''),
                function_exists('wp_date') ? (string) wp_date('j/n/Y H:i', (int) ($last['at'] ?? 0)) : '')) . '</li>';
        }
        echo '</ul><p><button type="button" class="button" data-grcs-klarna-test="playground">' . AdminLocale::esc_html__('Test connection (Playground)', 'gr-commerce-suite') . '</button> '
            . '<button type="button" class="button" data-grcs-klarna-test="live">' . AdminLocale::esc_html__('Test connection (Live)', 'gr-commerce-suite') . '</button> '
            . '<span id="grcs-klarna-test-result" role="status" aria-live="polite"></span></p>'
            . '<p class="description">' . AdminLocale::esc_html__('Save your changes first: the test uses the saved credentials. It opens a Klarna session for a test cart; nothing is charged.', 'gr-commerce-suite') . '</p></div>';
    }

    public function process_admin_options(): bool
    {
        if (!current_user_can('manage_woocommerce')) {
            return false;
        }
        if (!KlarnaModule::requested()) {
            \WC_Admin_Settings::add_error(AdminLocale::__('Klarna settings were not saved: the Klarna module is switched off.', 'gr-commerce-suite'));
            return false;
        }
        try {
            Schema::fromGlobals()->verifyLedgerReadiness(); // cheap re-check so a repaired ledger recovers without a release
        } catch (\Throwable) {
            // the stored readiness stays as it was
        }
        $prefix = $this->plugin_id . $this->id . '_';
        $post = $this->get_post_data();
        $field = static fn(string $name): string => isset($post[$prefix . $name]) ? trim(wp_unslash((string) $post[$prefix . $name])) : '';
        $settings = KlarnaServices::settings();
        foreach (['playground', 'live'] as $environment) {
            $user = $field($environment . '_username');
            $password = $field($environment . '_password');
            if (($user !== '' || $password !== '') && !$settings->saveCredentials($environment, $user, $password)) {
                \WC_Admin_Settings::add_error(AdminLocale::__('Klarna credentials could not be saved (encryption unavailable).', 'gr-commerce-suite'));
            }
        }
        foreach (self::SECRET_FIELDS as $name) {
            unset($_POST[$prefix . $name]);
        }
        $saved = parent::process_admin_options();
        KlarnaServices::reset();
        return $saved;
    }

    /**
     * @param array<string, mixed> $fields
     * @return array<string, mixed>
     */
    public function stripSecrets(array $fields): array
    {
        $fields = array_diff_key($fields, array_flip(self::SECRET_FIELDS));
        if (($fields['environment'] ?? '') === 'live') {
            $blockers = KlarnaServices::settings()->liveBlockers(($fields['live_approved'] ?? 'no') === 'yes');
            if ($blockers !== []) {
                $fields['environment'] = 'playground';
                \WC_Admin_Settings::add_error(AdminLocale::__('Live mode is still locked, so Playground stays selected:', 'gr-commerce-suite') . ' ' . implode(' ', $blockers));
            }
        }
        return $fields;
    }

    public function is_available(): bool
    {
        if (!KlarnaModule::isEnabled() || !KlarnaServices::licensed() || !parent::is_available()) {
            return false;
        }
        $settings = KlarnaServices::settings();
        if (!$settings->ready() || !in_array(strtoupper((string) get_woocommerce_currency()), KlarnaSettings::CURRENCIES, true)) {
            return false;
        }
        if (function_exists('is_wc_endpoint_url') && is_wc_endpoint_url('order-pay')) {
            return false; // The session is built from the cart; the pay-for-order page has none.
        }
        $customer = function_exists('WC') ? \WC()->customer : null;
        $country = is_object($customer) ? strtoupper((string) $customer->get_billing_country()) : '';
        return $country === '' || in_array($country, $settings->countries(), true);
    }

    public function payment_fields(): void
    {
        if ($this->description !== '') {
            echo '<p>' . wp_kses_post($this->description) . '</p>';
        }
        echo '<div id="grcs-klarna-container" class="grcs-klarna-container"></div>'
            . '<input type="hidden" name="' . esc_attr(self::FIELD_TOKEN) . '" id="grcs-klarna-token" value="" autocomplete="off" />'
            . '<input type="hidden" name="grcs_klarna_category" id="grcs-klarna-category" value="" autocomplete="off" />';
    }

    public function validate_fields(): bool
    {
        $resumable = self::resumableOrder();
        // Persistent, shopper-scoped refusal first: no authorisation is worth collecting while another Klarna payment of this shopper
        // is unresolved. The order WooCommerce is about to resume is not "another" payment.
        $pending = self::unresolvedElsewhereOrder($resumable);
        if ($pending !== null) {
            wc_add_notice(self::pendingNotice($pending), 'error');
            return false;
        }
        if (self::postedToken() === '' && !$this->callbackTokenAvailable() && $resumable === null) {
            wc_add_notice(__('Please approve the payment with Klarna before placing the order.', 'gr-commerce-suite'), 'error');
            return false;
        }
        return true;
    }

    /** @return array{result: string, redirect?: string} */
    public function process_payment($order_id): array
    {
        $result = $this->dispatchPayment($order_id);
        if (($result['result'] ?? '') !== 'success') {
            // Klarna refused locally (no usable approval, stale session, not available...) WITHOUT sending a create call: nothing was
            // dispatched and nothing can be charged by this attempt, so it must not block the shopper. An order Klarna holds, or whose create
            // outcome is in doubt, is NOT touched here - only Klarna's own evidence or a merchant release ends that.
            $order = wc_get_order($order_id);
            if ($order instanceof \WC_Order && !(new KlarnaOrderRecord($order))->heldByKlarna()) {
                KlarnaPaymentEvidence::notDispatched($order);
            }
        }

        return $result;
    }

    /** @return array{result: string, redirect?: string} */
    private function dispatchPayment(mixed $order_id): array
    {
        $order = wc_get_order($order_id);
        // An order Klarna already holds (or may hold: unconfirmed create) is never stranded by a licence/setup change or a cleared
        // session between submit and retry: place() answers it from the order itself. Decided from stored order state only,
        // never from posted data, and such an order is never given a token or a session record to create from.
        $held = $order instanceof \WC_Order && (new KlarnaOrderRecord($order))->heldByKlarna();
        if (!$order instanceof \WC_Order || (!$held && (!KlarnaModule::isEnabled() || !KlarnaServices::licensed() || !KlarnaServices::settings()->ready()))) {
            wc_add_notice(__('Klarna is not available right now. Please choose another payment method.', 'gr-commerce-suite'), 'error');
            return ['result' => 'failure'];
        }
        $sessions = KlarnaServices::sessions();
        $record = $held ? [] : ($sessions->record() ?? []);
        $token = $held ? '' : self::postedToken();
        if ($token === '' && isset($record['session_id'])) {
            $token = $sessions->callbackToken((string) $record['session_id']);
        }
        if ($token === '' && !$held) {
            wc_add_notice(__('Please approve the payment with Klarna before placing the order.', 'gr-commerce-suite'), 'error');
            return ['result' => 'failure'];
        }
        $result = KlarnaServices::payments()->place($order, $token, $record);
        if ($result['status'] === KlarnaPaymentService::ALREADY && $order->has_status(['pending', 'failed'])) {
            $result = $this->reconcileHeldOrder($order, $result); // Klarna holds it but the result was never applied (a hook threw, a request died)
        }
        if (in_array($result['status'], [KlarnaPaymentService::PLACED, KlarnaPaymentService::ALREADY, KlarnaPaymentService::AMBIGUOUS], true)) {
            $sessions->clear();
            if ($order->has_status('on-hold') && (new KlarnaOrderRecord($order))->fraudStatus() === 'PENDING') {
                KlarnaRefreshJob::schedule($order->get_id(), '', 0, 900);
            }
            // Ambiguous and pending-review orders are on-hold: the thank-you page (KlarnaLifecycle) says "pending verification", never "paid".
            return ['result' => 'success', 'redirect' => $result['redirect'] !== '' ? $result['redirect'] : $this->get_return_url($order)];
        }
        if ($result['status'] === KlarnaPaymentService::BLOCKED) {
            if (str_contains($result['message'], 'in use')) {
                wc_add_notice(__('This Klarna approval is already in use. Please approve the payment again.', 'gr-commerce-suite'), 'error');
            } else {
                wc_add_notice(self::pendingNotice(self::unresolvedElsewhereOrder($order)), 'error');
            }
            return ['result' => 'failure'];
        }
        if (in_array($result['status'], [KlarnaPaymentService::STALE, KlarnaPaymentService::REJECTED], true)) {
            $sessions->clear(); // the next sync opens a fresh session instead of retrying a stale or closed one
        }
        if ($result['status'] === KlarnaPaymentService::REJECTED) {
            self::forgetAwaitingOrder(); // WooCommerce would resume this refused order forever; the next attempt gets a new order and a new approval
        }
        wc_add_notice($result['message'] !== '' ? $result['message'] : __('Klarna could not process this payment.', 'gr-commerce-suite'), 'error');
        return ['result' => 'failure'];
    }

    /**
     * An order Klarna holds that is still pending/failed in WooCommerce: read Klarna's real decision before anything is shown as done.
     * Never answers "success" for an order that is not confirmed - it is parked on-hold and reported as unconfirmed instead.
     *
     * @param array{status: string, message: string, redirect: string} $result
     * @return array{status: string, message: string, redirect: string}
     */
    private function reconcileHeldOrder(\WC_Order $order, array $result): array
    {
        KlarnaServices::management()->refresh($order);
        $record = new KlarnaOrderRecord($order);
        if ($record->fraudStatus() === 'REJECTED') {
            return ['status' => KlarnaPaymentService::REJECTED, 'message' => 'Klarna could not approve this purchase. Please choose another payment method.', 'redirect' => ''];
        }
        if ($order->has_status(['pending', 'failed'])) {
            $order->update_status('on-hold', 'Klarna holds this order but its decision could not be read yet. Do not ship until Klarna accepts it; use "Klarna: refresh status".');
            $order->save();
            KlarnaRefreshJob::schedule($order->get_id(), '', 0, 300);
            return ['status' => KlarnaPaymentService::AMBIGUOUS, 'message' => 'Klarna has not confirmed the payment yet.', 'redirect' => ''];
        }
        return $result;
    }

    /**
     * @param int $order_id
     * @param float|string|null $amount
     * @param string $reason
     * @return bool|WP_Error
     */
    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $order = wc_get_order($order_id);
        if (!$order instanceof \WC_Order || $amount === null || (string) $amount === '') {
            return new WP_Error('grcs_klarna_refund', AdminLocale::__('Klarna refunds need an order and an amount.', 'gr-commerce-suite'));
        }
        // Historical operation: deliberately independent of the module switch.
        $result = KlarnaServices::management()->refund($order, KlarnaPayloadFactory::minor($amount), (string) $reason);
        return $result['ok'] ? true : new WP_Error('grcs_klarna_refund', $result['message']);
    }

    /** Token handed over by the browser (classic form field, or Blocks payment data mirrored into the request). */
    public static function postedToken(): string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce verifies the checkout nonce before gateways run.
        $raw = isset($_POST[self::FIELD_TOKEN]) ? wp_unslash((string) $_POST[self::FIELD_TOKEN]) : '';
        return preg_match('/^[A-Za-z0-9._~-]{8,512}$/', $raw) === 1 ? $raw : '';
    }

    /**
     * WooCommerce validates fields before it creates (or reuses) the order. A retry of the shopper's own awaiting-payment order
     * that Klarna already holds is not a new payment, so it needs no new token; process_payment() decides again from the real order.
     * Only the orders WooCommerce itself resumes qualify (pending/failed, unchanged cart hash - see WC_Checkout::create_order):
     * for any other order WooCommerce creates a new one, which must still be approved. An order Klarna refused is never resumed:
     * the shopper needs a new order and a new approval, not the same refusal again.
     */
    public static function resumableOrder(): ?\WC_Order
    {
        $wc = function_exists('WC') ? \WC() : null;
        $session = is_object($wc) ? $wc->session : null;
        $cart = is_object($wc) ? $wc->cart : null;
        $orderId = is_object($session) ? (int) $session->get('order_awaiting_payment') : 0;
        $order = $orderId > 0 ? wc_get_order($orderId) : false;
        if (!$order instanceof \WC_Order || !is_object($cart) || $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID
            || !$order->has_status(['pending', 'failed']) || !$order->has_cart_hash((string) $cart->get_cart_hash())) {
            return null;
        }
        $record = new KlarnaOrderRecord($order);
        return $record->heldByKlarna() && $record->fraudStatus() !== 'REJECTED' ? $order : null;
    }

    /**
     * Another Klarna order of THIS VERIFIED shopper that is unconfirmed or not finally decided. Verified = the logged-in account, the
     * order their own WooCommerce session waits on, or an order they hold a valid signed proof for ({@see KlarnaShopperProof}). A billing
     * email is never used: typing someone else's email must neither block them nor tell the typist anything.
     */
    public static function unresolvedElsewhereOrder(?\WC_Order $resumable = null): ?\WC_Order
    {
        $exclude = $resumable instanceof \WC_Order ? $resumable->get_id() : 0;
        return (new KlarnaOrderLookup())->unresolvedForShopper(KlarnaShopperProof::userId(), KlarnaShopperProof::orderIds(), $exclude);
    }

    public static function unresolvedElsewhere(?\WC_Order $resumable = null): bool
    {
        return self::unresolvedElsewhereOrder($resumable) !== null;
    }

    /** The refusal text for a shopper who really does hold the unresolved order: it links THEIR order page (their key proves ownership). */
    public static function pendingNotice(?\WC_Order $order): string
    {
        $text = __('A previous Klarna payment is still being verified. Please wait for its confirmation before trying again.', 'gr-commerce-suite'); // customer-facing
        if (!$order instanceof \WC_Order) {
            return $text;
        }
        return $text . ' <a href="' . esc_url($order->get_checkout_order_received_url()) . '">' . esc_html__('View your payment status', 'gr-commerce-suite') . '</a>'; // customer-facing
    }

    private static function forgetAwaitingOrder(): void
    {
        $wc = function_exists('WC') ? \WC() : null;
        $session = is_object($wc) ? $wc->session : null;
        if (is_object($session) && method_exists($session, 'set')) {
            $session->set('order_awaiting_payment', false);
        }
    }

    private function callbackTokenAvailable(): bool
    {
        $record = KlarnaServices::sessions()->record();
        return is_array($record) && isset($record['session_id']) && KlarnaServices::sessions()->callbackToken((string) $record['session_id']) !== '';
    }
}
