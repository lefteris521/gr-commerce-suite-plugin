<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Support\Lock;
use WC_Order;

/**
 * Klarna Order Management for existing orders: refresh, capture, cancel / release and refund.
 *
 * Historical operations: they work for orders that already carry a Klarna order id even when the module is switched off.
 * Every action first reads the order from Klarna and only proceeds when the documented transition is permitted
 * (cancel: no captures; release: part captured; refund: at most captured minus refunded). Mutations use a persisted
 * idempotency intent ({@see KlarnaOrderRecord::intent()}) plus a per-order lock, so retries and double clicks cannot repeat them.
 *
 * Every method returns array{ok: bool, message: string}; nothing here echoes or logs payloads.
 */
class KlarnaOrderManagement
{
    public function __construct(
        private readonly KlarnaApiClient $api,
        private readonly LoggerInterface $logger,
    ) {
    }

    /**
     * Read the order from Klarna, verify it is this order, store its state and reconcile fraud status.
     *
     * @param string $adoptKlarnaOrderId Klarna order id announced by a push callback for an order whose create call was ambiguous.
     * @return array{ok: bool, message: string}
     */
    public function refresh(WC_Order $order, string $adoptKlarnaOrderId = ''): array
    {
        $record = new KlarnaOrderRecord($order);
        $klarnaId = $record->klarnaOrderId();
        if ($klarnaId !== '' && $adoptKlarnaOrderId !== '' && $adoptKlarnaOrderId !== $klarnaId) {
            $this->logger->warning('Klarna push named a different order id than the one stored; ignored.');
            return $this->fail('The Klarna order id does not match this order.');
        }
        $klarnaId = $klarnaId !== '' ? $klarnaId : $adoptKlarnaOrderId;
        if ($klarnaId === '') {
            return $this->fail('This order has no Klarna order id yet.');
        }
        try {
            $remote = $this->api->getOrder($klarnaId, $record->target());
        } catch (KlarnaException $e) {
            return $this->fail($this->describe($e));
        }
        if (!$this->identityMatches($order, $record, $remote)) {
            $order->add_order_note('Klarna order did not match this WooCommerce order (reference, currency or amount); it was not applied.');
            $order->save();
            return $this->fail('The Klarna order does not match this order.');
        }
        if ($record->klarnaOrderId() === '') {
            $amount = (int) ($remote['original_order_amount'] ?? $remote['order_amount'] ?? 0);
            $record->setPlaced($klarnaId, strtoupper((string) ($remote['fraud_status'] ?? '')), (string) $order->get_meta(KlarnaOrderRecord::META_SESSION),
                (string) ($remote['initial_payment_method']['type'] ?? ''), [
                    'amount' => $amount,
                    'currency' => strtoupper((string) ($remote['purchase_currency'] ?? '')),
                    'country' => strtoupper((string) ($remote['purchase_country'] ?? '')),
                    // Found with the current settings, so that is where the order lives.
                    'environment' => $this->api->currentTarget()['environment'],
                    'region' => $this->api->currentTarget()['region'],
                ], []);
        }
        $record->storeState($remote);
        $this->applyFraudStatus($order, $record, strtoupper((string) ($remote['fraud_status'] ?? '')));
        $order->save();
        return ['ok' => true, 'message' => 'Klarna status: ' . (string) ($remote['status'] ?? '')];
    }

    /** Idempotently move the WooCommerce order to match Klarna's fraud decision. Never pays an order Klarna has not accepted. */
    public function applyFraudStatus(WC_Order $order, KlarnaOrderRecord $record, string $fraudStatus): void
    {
        $klarnaId = $record->klarnaOrderId();
        $open = $order->has_status(['pending', 'on-hold', 'failed']);
        switch ($fraudStatus) {
            case 'ACCEPTED':
                if ($open) {
                    $order->payment_complete($klarnaId);
                    $order->add_order_note('Klarna accepted the order (' . $klarnaId . ').');
                }
                break;
            case 'PENDING':
                if ($order->has_status(['pending', 'failed'])) {
                    $order->update_status('on-hold', 'Klarna is reviewing the order (' . $klarnaId . '). It will be completed automatically when Klarna accepts it.');
                }
                break;
            case 'REJECTED':
                if ($order->has_status(['pending', 'on-hold'])) {
                    $order->update_status('failed', 'Klarna rejected the order (' . $klarnaId . ').');
                } elseif ($order->is_paid()) {
                    $order->add_order_note('Klarna rejected this order after it was marked paid. Do not ship; review in the Klarna merchant portal.');
                }
                break;
            default:
                break;
        }
        KlarnaPaymentEvidence::observe($order, $record, $fraudStatus);
    }

    /**
     * Capture what is not captured yet (or $amount minor units), never more than Klarna still has authorised.
     *
     * @return array{ok: bool, message: string}
     */
    public function capture(WC_Order $order, ?int $amount = null): array
    {
        return $this->locked($order, function (KlarnaOrderRecord $record) use ($amount): array {
            $order = $record->order();
            $remote = $this->read($order, $record);
            $placed = $record->placed();
            $captured = (int) ($remote['captured_amount'] ?? 0);
            $remaining = (int) ($remote['remaining_authorized_amount'] ?? 0);
            // The logical operation is the requested amount. An unfinished earlier attempt for it may already have succeeded at Klarna:
            // replay it unchanged (same key, same amount) instead of recomputing against the reduced remaining authorisation.
            // Never capture more than the order is worth now: an on-hold order may have been edited while Klarna reviewed it.
            $orderTotal = KlarnaPayloadFactory::minor($order->get_total());
            $requested = $amount ?? ($placed !== null ? max(0, min($placed['amount'], $orderTotal) - $captured) : $remaining);
            $params = ['amount' => $requested];
            $resume = $record->pending('capture', $params) !== null;
            $want = $resume ? $requested : min($requested, $remaining);

            if (!$resume) {
                if (($remote['fraud_status'] ?? '') !== 'ACCEPTED') {
                    return $this->fail('Klarna has not accepted this order yet (fraud status ' . (string) ($remote['fraud_status'] ?? '?') . ').');
                }
                $status = (string) ($remote['status'] ?? '');
                if ($status === 'CAPTURED' || ($amount === null && $want <= 0 && $captured > 0)) {
                    $record->settlePending('capture');
                    return ['ok' => true, 'message' => 'Already fully captured in Klarna.'];
                }
                if (!in_array($status, ['AUTHORIZED', 'PART_CAPTURED'], true) || $want <= 0) {
                    return $this->fail('Klarna cannot capture an order in status ' . $status . '.');
                }
            }
            $intent = $record->intent('capture', $params);
            $body = ['captured_amount' => $want, 'description' => 'Order ' . $order->get_order_number(), 'reference' => 'wc-' . $order->get_id()];
            if ($captured === 0 && $placed !== null && $want === $placed['amount'] && $orderTotal === $placed['amount'] && $record->authorizedLines() !== []) {
                $body['order_lines'] = $record->authorizedLines();
            }
            try {
                $result = $this->api->capture($record->klarnaOrderId(), $body, $intent['key'], $record->target());
            } catch (KlarnaException $e) {
                return $this->mutationFailed($order, $record, $intent['key'], 'capture', $e);
            }
            $record->finish($intent['key'], ['capture_id' => $result['capture_id'], 'amount' => $want]);
            $order->add_order_note(sprintf('Captured %s in Klarna (capture %s).', self::format($want, (string) ($placed['currency'] ?? '')), $result['capture_id'] ?: 'n/a'));
            $this->refreshQuietly($record);
            return ['ok' => true, 'message' => 'Captured in Klarna.'];
        });
    }

    /**
     * Cancel an uncaptured order, or release the remaining authorisation of a part-captured one.
     *
     * @return array{ok: bool, message: string}
     */
    public function cancel(WC_Order $order): array
    {
        return $this->locked($order, function (KlarnaOrderRecord $record): array {
            $order = $record->order();
            $remote = $this->read($order, $record);
            $status = (string) ($remote['status'] ?? '');
            $captured = (int) ($remote['captured_amount'] ?? 0);
            $remaining = (int) ($remote['remaining_authorized_amount'] ?? 0);
            if (in_array($status, ['CANCELLED', 'EXPIRED', 'CLOSED'], true)) {
                return ['ok' => true, 'message' => 'The Klarna order is already ' . strtolower($status) . '.'];
            }
            if ($status === 'CAPTURED' || ($status === 'PART_CAPTURED' && $remaining <= 0)) {
                return $this->fail('Everything is captured in Klarna; refund instead of cancelling.');
            }
            $release = $captured > 0;
            $type = $release ? 'release' : 'cancel';
            $intent = $record->intent($type, []);
            try {
                if ($release) {
                    $this->api->releaseRemainingAuthorization($record->klarnaOrderId(), $intent['key'], $record->target());
                } else {
                    $this->api->cancelOrder($record->klarnaOrderId(), $intent['key'], $record->target());
                }
            } catch (KlarnaException $e) {
                return $this->mutationFailed($order, $record, $intent['key'], $type, $e);
            }
            $record->finish($intent['key']);
            $order->add_order_note($release ? 'Released the remaining Klarna authorisation.' : 'Cancelled the order in Klarna.');
            $this->refreshQuietly($record);
            return ['ok' => true, 'message' => $release ? 'Remaining authorisation released.' : 'Cancelled in Klarna.'];
        });
    }

    /**
     * Refund captured money. Klarna cannot refund what was never captured.
     *
     * @return array{ok: bool, message: string}
     */
    public function refund(WC_Order $order, int $amountMinor, string $reason = ''): array
    {
        if ($amountMinor <= 0) {
            return $this->fail('The refund amount must be positive.');
        }
        return $this->locked($order, function (KlarnaOrderRecord $record) use ($amountMinor, $reason): array {
            $order = $record->order();
            $params = ['amount' => $amountMinor];
            // An unfinished earlier attempt of this same refund may already have succeeded at Klarna: replay its key and let Klarna answer.
            $resume = $record->pending('refund', $params) !== null;
            $remote = $this->read($order, $record);
            if (!$resume) {
                $captured = (int) ($remote['captured_amount'] ?? 0);
                $refunded = (int) ($remote['refunded_amount'] ?? 0);
                if ($captured <= 0) {
                    return $this->fail('Nothing is captured in Klarna yet. Capture the order first, or cancel it instead of refunding.');
                }
                if ($amountMinor > $captured - $refunded) {
                    return $this->fail('The refund exceeds what Klarna can still refund (captured minus already refunded).');
                }
            }
            $intent = $record->intent('refund', $params);
            $description = trim($reason) !== '' ? $reason : 'Refund for order ' . $order->get_order_number();
            $body = ['refunded_amount' => $amountMinor, 'description' => substr($description, 0, 255), 'reference' => 'wc-' . $order->get_id()];
            try {
                $result = $this->api->refund($record->klarnaOrderId(), $body, $intent['key'], $record->target());
            } catch (KlarnaException $e) {
                return $this->mutationFailed($order, $record, $intent['key'], 'refund', $e);
            }
            $record->finish($intent['key'], ['refund_id' => $result['refund_id'], 'amount' => $amountMinor]);
            $placed = $record->placed();
            $order->add_order_note(sprintf('Refunded %s in Klarna (refund %s).', self::format($amountMinor, (string) ($placed['currency'] ?? '')), $result['refund_id'] ?: 'n/a'));
            $this->refreshQuietly($record);
            return ['ok' => true, 'message' => 'Refunded in Klarna.'];
        });
    }

    // ---- internals ---------------------------------------------------------------------------------------------------

    /**
     * @param callable(KlarnaOrderRecord): array{ok: bool, message: string} $work
     * @return array{ok: bool, message: string}
     */
    private function locked(WC_Order $order, callable $work): array
    {
        if ((new KlarnaOrderRecord($order))->klarnaOrderId() === '') {
            return $this->fail('This order has no Klarna order.');
        }
        $lock = 'klarna-op-' . $order->get_id();
        if (!Lock::acquire($lock, 90)) {
            return $this->fail('Another Klarna operation is running for this order. Try again in a moment.');
        }
        // The caller's object was loaded BEFORE the lock: another request may have saved an intent (or finished an operation) since.
        // Everything below - intent lookup, work, final save - runs on a copy read from the data store after the lock is held.
        $reloaded = $this->reloaded($order);
        if (!$reloaded instanceof WC_Order) {
            Lock::release($lock);
            return $this->fail('The order could not be re-read. Try again.');
        }
        $order = $reloaded;
        $record = new KlarnaOrderRecord($order);
        try {
            $result = $work($record);
        } catch (KlarnaException $e) {
            $result = $this->fail($this->describe($e));
        } finally {
            $order->save();
            Lock::release($lock);
        }
        return $result;
    }

    /** A fresh read of the order from the data store (order and meta caches dropped first); null when it cannot be re-read. */
    private function reloaded(WC_Order $order): ?WC_Order
    {
        $id = $order->get_id();
        if (function_exists('clean_post_cache')) {
            clean_post_cache($id); // posts storage: post + meta cache
        }
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete($id, 'orders'); // HPOS order cache group
        }
        $fresh = function_exists('wc_get_order') ? \wc_get_order($id) : false;
        return $fresh instanceof WC_Order ? $fresh : null;
    }

    /** @return array<string, mixed> */
    private function read(WC_Order $order, KlarnaOrderRecord $record): array
    {
        $remote = $this->api->getOrder($record->klarnaOrderId(), $record->target());
        if (!$this->identityMatches($order, $record, $remote)) {
            throw new KlarnaException(KlarnaException::VALIDATION, 'The Klarna order does not match this WooCommerce order.');
        }
        $record->storeState($remote);
        return $remote;
    }

    private function refreshQuietly(KlarnaOrderRecord $record): void
    {
        try {
            $record->storeState($this->api->getOrder($record->klarnaOrderId(), $record->target()));
        } catch (KlarnaException) {
            // The mutation succeeded; the next refresh will update the stored state.
        }
    }

    /**
     * Klarna refused: drop the intent (a new attempt gets a new key). Ambiguous: keep it so the retry replays the same key.
     *
     * @return array{ok: bool, message: string}
     */
    private function mutationFailed(WC_Order $order, KlarnaOrderRecord $record, string $key, string $type, KlarnaException $e): array
    {
        if ($e->isAmbiguous() || $e->kind === KlarnaException::TRANSPORT || $e->kind === KlarnaException::RATE_LIMITED) {
            $order->add_order_note(sprintf('Klarna %s was not confirmed (%s). Repeat the same action: the same idempotency key is reused, so it cannot be applied twice.', $type, $e->kind));
            return $this->fail('Klarna did not confirm the ' . $type . '. Repeat the same action; it will not be applied twice.');
        }
        $record->abandon($key, $e->kind . ':' . $e->errorCode);
        $order->add_order_note(sprintf('Klarna refused the %s (%s %s).', $type, $e->errorCode !== '' ? $e->errorCode : 'HTTP ' . $e->status, $e->correlationId));
        return $this->fail($this->describe($e));
    }

    /** @param array<string, mixed> $remote */
    private function identityMatches(WC_Order $order, KlarnaOrderRecord $record, array $remote): bool
    {
        if ((string) ($remote['merchant_reference2'] ?? '') !== (string) $order->get_id()) {
            return false;
        }
        $currency = strtoupper((string) ($remote['purchase_currency'] ?? ''));
        $amount = (int) ($remote['original_order_amount'] ?? $remote['order_amount'] ?? -1);
        if (!KlarnaPaymentEvidence::matchesAdmissionContext($order->get_id(), $amount, $currency, true)) {
            return false; // evidence is compared to the immutable context committed at admission, never to the mutable order or settings
        }
        $placed = $record->placed();
        if ($placed !== null && $placed['amount'] > 0) {
            return $currency === $placed['currency'] && $amount === $placed['amount'];
        }
        return $currency === strtoupper((string) $order->get_currency()) && $amount === KlarnaPayloadFactory::minor($order->get_total());
    }

    private function describe(KlarnaException $e): string
    {
        return match ($e->kind) {
            KlarnaException::NOT_CONFIGURED => 'Klarna API credentials are not saved for the selected environment.',
            KlarnaException::AUTH => 'Klarna rejected the API credentials.',
            KlarnaException::FORBIDDEN => 'Klarna does not allow this action in the order\'s current state.',
            KlarnaException::NOT_FOUND => 'Klarna does not know this order in the selected environment/region.',
            KlarnaException::TRANSPORT, KlarnaException::AMBIGUOUS, KlarnaException::SERVER, KlarnaException::RATE_LIMITED => 'Klarna did not respond reliably. Try again shortly.',
            default => 'Klarna rejected the request' . ($e->errorCode !== '' ? ' (' . $e->errorCode . ')' : '') . '.',
        };
    }

    /** @return array{ok: bool, message: string} */
    private function fail(string $message): array
    {
        return ['ok' => false, 'message' => $message];
    }

    private static function format(int $minor, string $currency): string
    {
        $negative = $minor < 0 ? '-' : '';
        $digits = str_pad((string) abs($minor), 3, '0', STR_PAD_LEFT);
        return trim($negative . substr($digits, 0, -2) . '.' . substr($digits, -2) . ' ' . $currency);
    }
}
