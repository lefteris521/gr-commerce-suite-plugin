<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Http\HttpRequest;
use GRCommerceSuite\Http\HttpResponse;

/**
 * Thin, typed client for Klarna Payments v1 and Order Management v1 (HTTP Basic, JSON).
 *
 * - Payments `POST /payments/v1/authorizations/{token}/order` has no idempotency header in the documented contract: the single-use
 *   authorization token is the guard, and callers must treat an ambiguous failure as "may exist".
 * - Order Management mutations send `Klarna-Idempotency-Key`; callers persist the key before the call and reuse it on retries.
 * - Never logs bodies, credentials or customer data; only operation, HTTP status, Klarna identifiers and the correlation id.
 */
class KlarnaApiClient
{
    public function __construct(
        private readonly HttpClientInterface $http,
        private readonly KlarnaSettings $settings,
        private readonly LoggerInterface $logger,
    ) {
    }

    // ---- Payments API -----------------------------------------------------------------------------------------------

    /**
     * @param array<string, mixed> $payload
     * @param array{environment?: string, region?: string}|null $target
     * @return array{session_id: string, client_token: string, payment_method_categories: list<array<string, mixed>>}
     */
    public function createSession(array $payload, ?array $target = null): array
    {
        $r = $this->request('create_session', 'POST', '/payments/v1/sessions', $payload, null, $target);
        $body = $r['body'];
        if (!is_string($body['session_id'] ?? null) || !is_string($body['client_token'] ?? null) || $body['session_id'] === '' || $body['client_token'] === '') {
            throw new KlarnaException(KlarnaException::VALIDATION, 'Klarna session response was incomplete.', $r['status'], '', $r['correlation']);
        }
        $categories = is_array($body['payment_method_categories'] ?? null) ? array_values(array_filter($body['payment_method_categories'], 'is_array')) : [];
        return ['session_id' => $body['session_id'], 'client_token' => $body['client_token'], 'payment_method_categories' => $categories];
    }

    /** @param array<string, mixed> $payload */
    public function updateSession(string $sessionId, array $payload): void
    {
        $this->request('update_session', 'POST', '/payments/v1/sessions/' . self::id($sessionId), $payload);
    }

    /** @return array<string, mixed> */
    public function readSession(string $sessionId): array
    {
        return $this->request('read_session', 'GET', '/payments/v1/sessions/' . self::id($sessionId))['body'];
    }

    public function cancelAuthorization(string $authorizationToken): void
    {
        $this->request('cancel_authorization', 'DELETE', '/payments/v1/authorizations/' . self::id($authorizationToken));
    }

    /**
     * @param array<string, mixed> $payload
     * @return array{order_id: string, fraud_status: string, redirect_url: string, authorized_payment_method: string}
     */
    public function createOrder(string $authorizationToken, array $payload): array
    {
        $r = $this->request('create_order', 'POST', '/payments/v1/authorizations/' . self::id($authorizationToken) . '/order', $payload);
        $body = $r['body'];
        if (!is_string($body['order_id'] ?? null) || $body['order_id'] === '') {
            // 2xx without an order id: Klarna may hold an order we cannot name. Never retry; reconcile through the push callback.
            throw new KlarnaException(KlarnaException::AMBIGUOUS, 'Klarna accepted the request but returned no order id.', $r['status'], '', $r['correlation']);
        }
        $method = is_array($body['authorized_payment_method'] ?? null) ? (string) ($body['authorized_payment_method']['type'] ?? '') : '';
        return [
            'order_id' => $body['order_id'],
            'fraud_status' => strtoupper((string) ($body['fraud_status'] ?? '')),
            'redirect_url' => (string) ($body['redirect_url'] ?? ''),
            'authorized_payment_method' => $method,
        ];
    }

    /** @return array{environment: string, region: string} Where new requests go now; stored with an order so its later operations hit the same Klarna. */
    public function currentTarget(): array
    {
        return ['environment' => $this->settings->environment(), 'region' => $this->settings->region()];
    }

    // ---- Order Management API ---------------------------------------------------------------------------------------
    // Every method takes the environment/region the order was placed in (a store may switch playground/live later).

    /**
     * @param array{environment?: string, region?: string}|null $target
     * @return array<string, mixed>
     */
    public function getOrder(string $orderId, ?array $target = null): array
    {
        return $this->request('get_order', 'GET', '/ordermanagement/v1/orders/' . self::id($orderId), null, null, $target)['body'];
    }

    /**
     * @param array<string, mixed> $body
     * @param array{environment?: string, region?: string}|null $target
     * @return array{capture_id: string}
     */
    public function capture(string $orderId, array $body, string $idempotencyKey, ?array $target = null): array
    {
        $r = $this->request('capture', 'POST', '/ordermanagement/v1/orders/' . self::id($orderId) . '/captures', $body, $idempotencyKey, $target);
        return ['capture_id' => $r['headers']['capture-id'] ?? ''];
    }

    /**
     * @param array<string, mixed> $body
     * @param array{environment?: string, region?: string}|null $target
     * @return array{refund_id: string}
     */
    public function refund(string $orderId, array $body, string $idempotencyKey, ?array $target = null): array
    {
        $r = $this->request('refund', 'POST', '/ordermanagement/v1/orders/' . self::id($orderId) . '/refunds', $body, $idempotencyKey, $target);
        return ['refund_id' => $r['headers']['refund-id'] ?? ''];
    }

    /** @param array{environment?: string, region?: string}|null $target */
    public function cancelOrder(string $orderId, string $idempotencyKey, ?array $target = null): void
    {
        $this->request('cancel_order', 'POST', '/ordermanagement/v1/orders/' . self::id($orderId) . '/cancel', null, $idempotencyKey, $target);
    }

    /** @param array{environment?: string, region?: string}|null $target */
    public function releaseRemainingAuthorization(string $orderId, string $idempotencyKey, ?array $target = null): void
    {
        $this->request('release_authorization', 'POST', '/ordermanagement/v1/orders/' . self::id($orderId) . '/release-remaining-authorization', null, $idempotencyKey, $target);
    }

    // ---- Transport ---------------------------------------------------------------------------------------------------

    /**
     * @param array<string, mixed>|null $payload
     * @param array{environment?: string, region?: string}|null $target Environment/region override for an existing order.
     * @return array{status: int, body: array<string, mixed>, headers: array<string, string>, correlation: string}
     */
    private function request(string $operation, string $method, string $path, ?array $payload = null, ?string $idempotencyKey = null, ?array $target = null): array
    {
        $environment = isset($target['environment']) && $target['environment'] !== '' ? $target['environment'] : null;
        $credentials = $this->settings->credentials($environment);
        if ($credentials === null) {
            throw new KlarnaException(KlarnaException::NOT_CONFIGURED, 'Klarna API credentials are not saved for the selected environment.');
        }
        $headers = [
            'Authorization' => 'Basic ' . base64_encode($credentials['username'] . ':' . $credentials['password']),
            'Accept' => 'application/json',
            'User-Agent' => 'GR-Commerce-Suite/' . (defined('GRCS_VERSION') ? (string) constant('GRCS_VERSION') : 'dev'),
        ];
        $body = null;
        if ($payload !== null) {
            $headers['Content-Type'] = 'application/json';
            $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION);
        }
        if ($idempotencyKey !== null) {
            $headers['Klarna-Idempotency-Key'] = $idempotencyKey;
        }

        $response = $this->http->send(new HttpRequest($method, $this->settings->baseUrl($environment, $target['region'] ?? null) . $path, $headers, $body, 15, 5));
        $correlation = self::cleanId($response->header('klarna-correlation-id') ?? '');

        if ($response->hasError()) {
            $kind = $response->failedBeforeTransmission && !$response->timedOutAfterTransmission ? KlarnaException::TRANSPORT : KlarnaException::AMBIGUOUS;
            $this->logger->warning(sprintf('Klarna %s transport failure (%s).', $operation, $kind));
            throw new KlarnaException($kind, 'Klarna could not be reached.', 0, '', $correlation);
        }

        $decoded = $response->body !== '' ? json_decode($response->body, true) : [];
        $data = is_array($decoded) ? $decoded : [];
        $status = $response->statusCode;
        $this->logger->info(sprintf('Klarna %s status=%d correlation=%s', $operation, $status, $correlation !== '' ? $correlation : '-'));

        if ($status >= 200 && $status < 300 && !$response->timedOutAfterTransmission) {
            return ['status' => $status, 'body' => $data, 'headers' => $response->headers, 'correlation' => $correlation];
        }
        throw $this->failure($response, $data, $correlation);
    }

    /** @param array<string, mixed> $data */
    private function failure(HttpResponse $response, array $data, string $correlation): KlarnaException
    {
        $status = $response->statusCode;
        $kind = match (true) {
            $response->timedOutAfterTransmission || $status === 408 || $status === 504 => KlarnaException::AMBIGUOUS,
            $status === 401 => KlarnaException::AUTH,
            $status === 403 => KlarnaException::FORBIDDEN,
            $status === 404 => KlarnaException::NOT_FOUND,
            $status === 409 => KlarnaException::CONFLICT,
            $status === 429 => KlarnaException::RATE_LIMITED,
            $status >= 500 => KlarnaException::SERVER,
            default => KlarnaException::VALIDATION,
        };
        $messages = [];
        foreach (is_array($data['error_messages'] ?? null) ? $data['error_messages'] : [] as $message) {
            if (is_string($message)) {
                $messages[] = substr($message, 0, 300);
            }
        }
        $code = self::cleanId((string) ($data['error_code'] ?? ''));
        $this->logger->warning(sprintf('Klarna request rejected status=%d kind=%s code=%s correlation=%s', $status, $kind, $code !== '' ? $code : '-', $correlation !== '' ? $correlation : '-'));
        return new KlarnaException($kind, 'Klarna returned HTTP ' . $status . '.', $status, $code, $correlation, $messages);
    }

    private static function id(string $id): string
    {
        if (preg_match('/^[A-Za-z0-9._~-]{1,512}$/', $id) !== 1) {
            throw new KlarnaException(KlarnaException::VALIDATION, 'Invalid Klarna identifier.');
        }
        return rawurlencode($id);
    }

    private static function cleanId(string $value): string
    {
        return preg_match('/^[A-Za-z0-9._:-]{1,128}$/', $value) === 1 ? $value : '';
    }
}
