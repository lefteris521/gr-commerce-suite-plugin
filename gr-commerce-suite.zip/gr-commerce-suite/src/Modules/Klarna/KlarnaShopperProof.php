<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Payments\LedgerException;
use GRCommerceSuite\Payments\LegacyIntents;
use GRCommerceSuite\Payments\PaymentLedger;
use WC_Order;

/**
 * Verified identity of the shopper in front of a checkout, for the one purpose of recognising THEIR OWN earlier payment attempts.
 *
 * What counts as proof (and nothing else does - above all not a billing email, which anyone can type):
 *  - the logged-in account (WordPress authenticated it);
 *  - the order the shopper's own WooCommerce session is waiting on (`order_awaiting_payment`, bound to their session cookie);
 *  - a guest proof cookie holding a fixed-size bearer handle (`bin2hex(random_bytes(16))` + HMAC with `wp_salt('auth')`).
 *    The binding to orders is stored server-side via order meta `_grcs_proof_handle` containing the keyed hash of the handle.
 *    This avoids cookie and header growth while retaining every unresolved order without eviction.
 *    Legacy signed per-order cookie proofs are read and migrated to the handle on issue().
 *
 * A guest who lost every cookie has no proof left. That scenario cannot be protected without trusting an unverified claim, so it is
 * not blocked (documented limitation); the merchant gets a private "possible duplicate" note instead.
 */
final class KlarnaShopperProof
{
    public const COOKIE = 'grcs_guest_proof';
    public const META_HANDLE = '_grcs_proof_handle';
    private const PARSE_LIMIT = 200;
    private const LIFETIME = 2592000; // 30 days

    private static function secret(): string
    {
        return function_exists('wp_salt') ? (string) wp_salt('auth') : 'grcs-klarna-proof';
    }

    /** Keyed signature of one order for legacy cookie format. */
    public static function sign(WC_Order $order): string
    {
        return substr(hash_hmac('sha256', $order->get_id() . '|' . $order->get_order_key(), self::secret()), 0, 32);
    }

    /** Keyed hash binding an order to the guest handle, stored server-side in order meta. */
    public static function handleHash(string $handle): string
    {
        return hash_hmac('sha256', 'order|' . $handle, self::secret());
    }

    /** HMAC protecting the cookie value; domain-separated from the order binding so one cannot be replayed as the other. */
    public static function cookieHmac(string $handle): string
    {
        return hash_hmac('sha256', 'cookie|' . $handle, self::secret());
    }

    public static function currentValidHandle(): ?string
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $raw = isset($_COOKIE[self::COOKIE]) && is_string($_COOKIE[self::COOKIE]) ? $_COOKIE[self::COOKIE] : '';
        if (preg_match('/^([a-f0-9]{32})\.([a-f0-9]{64})$/', $raw, $m) === 1) {
            if (hash_equals(self::cookieHmac($m[1]), $m[2])) {
                return $m[1];
            }
        }
        return null;
    }

    /** Give a guest's browser the proof for an order that may end up held (Klarna order created, or another gateway left pending). */
    public static function issue(WC_Order $order): void
    {
        if ((int) $order->get_customer_id() > 0) {
            return; // an account is its own proof
        }

        $handle = self::currentValidHandle();
        if ($handle === null) {
            $handle = bin2hex(random_bytes(16));
        }

        // Backward compatibility: migrate verified legacy entries onto the handle
        $legacy = self::legacyEntries();
        if ($legacy !== [] && function_exists('wc_get_order')) {
            $handleHash = self::handleHash($handle);
            foreach ($legacy as $legacyId => $signature) {
                $legacyOrder = \wc_get_order($legacyId);
                if ($legacyOrder instanceof WC_Order && hash_equals(self::sign($legacyOrder), $signature)) {
                    $legacyOrder->update_meta_data(self::META_HANDLE, $handleHash);
                    $legacyOrder->save();
                }
                // Unverified legacy entries are ignored and are not looked up more than once
            }
        }

        $order->update_meta_data(self::META_HANDLE, self::handleHash($handle));
        $order->save();

        $value = $handle . '.' . self::cookieHmac($handle);
        $_COOKIE[self::COOKIE] = $value; // the same request sees it
        if (!headers_sent() && function_exists('setcookie')) {
            setcookie(self::COOKIE, $value, [
                'expires' => time() + self::LIFETIME,
                'path' => defined('COOKIEPATH') && COOKIEPATH !== '' ? (string) COOKIEPATH : '/',
                'secure' => function_exists('is_ssl') && is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
    }

    public static function unresolved(WC_Order $order): bool
    {
        if ((new KlarnaOrderRecord($order))->unresolved()) {
            return true;
        }
        if (LegacyIntents::isUnresolved($order)) {
            return true;
        }
        global $wpdb;
        if (!$wpdb instanceof \wpdb) {
            return false; // no database layer, so no ledger can hold anything for this order
        }
        try {
            return PaymentLedger::fromGlobals()->orderHasBlockingAttempt($order->get_id());
        } catch (LedgerException) {
            return true; // a ledger exists but cannot be read: keep the proof
        }
    }

    /** @return array<int, string> order id => signature, exactly as sent by the browser in legacy format (NOT yet verified) */
    private static function legacyEntries(): array
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each part is matched against a strict pattern below
        $raw = isset($_COOKIE[self::COOKIE]) && is_string($_COOKIE[self::COOKIE]) ? $_COOKIE[self::COOKIE] : '';
        $entries = [];
        foreach (explode('|', $raw) as $part) {
            if (preg_match('/^(\d{1,12})\.([a-f0-9]{32})$/', $part, $m) === 1) {
                $entries[(int) $m[1]] = $m[2];
            }
        }
        return array_slice($entries, -self::PARSE_LIMIT, null, true); // a hard ceiling on what one request parses
    }

    /** @return list<int> orders whose proof matches (via handle meta or legacy signature) */
    public static function verifiedCookieOrderIds(): array
    {
        $handle = self::currentValidHandle();
        if ($handle !== null) {
            if (!function_exists('wc_get_orders')) {
                return [];
            }
            $results = \wc_get_orders([
                'limit' => -1,
                'return' => 'ids',
                'meta_query' => [
                    [
                        'key' => self::META_HANDLE,
                        'value' => self::handleHash($handle),
                        'compare' => '=',
                    ],
                ],
            ]);
            $ids = [];
            foreach (is_array($results) ? $results : [] as $result) {
                if ($result instanceof WC_Order) {
                    $ids[] = (int) $result->get_id();
                } elseif (is_numeric($result)) {
                    $ids[] = (int) $result;
                }
            }
            return array_values(array_unique($ids));
        }

        // Backward compatibility: read legacy cookie format if present
        $legacy = self::legacyEntries();
        if ($legacy === [] || !function_exists('wc_get_order')) {
            return [];
        }

        $ids = [];
        foreach ($legacy as $id => $signature) {
            $order = \wc_get_order($id);
            if ($order instanceof WC_Order && hash_equals(self::sign($order), $signature)) {
                $ids[] = $id;
            }
        }
        return array_values(array_unique($ids));
    }

    /** The order this shopper's own WooCommerce session is waiting on, or 0. */
    public static function sessionOrderId(): int
    {
        $wc = function_exists('WC') ? \WC() : null;
        $session = is_object($wc) ? $wc->session : null;
        return is_object($session) ? (int) $session->get('order_awaiting_payment') : 0;
    }

    /**
     * All order ids this shopper can prove they hold: their session's awaiting order and the verified cookie.
     *
     * @return list<int>
     */
    public static function orderIds(): array
    {
        $ids = self::verifiedCookieOrderIds();
        $awaiting = self::sessionOrderId();
        if ($awaiting > 0) {
            $ids[] = $awaiting;
        }
        return array_values(array_unique($ids));
    }

    public static function userId(): int
    {
        return function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;
    }
}
