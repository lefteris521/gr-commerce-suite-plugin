<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\Klarna;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\Payments\LedgerException;
use GRCommerceSuite\Payments\LegacyIntents;
use GRCommerceSuite\Payments\PaymentLedger;
use GRCommerceSuite\Support\Lock;
use WC_Order;

/**
 * Coordination between Klarna and ALL other WooCommerce payment gateways at the Classic Checkout, including gateways GRCS does not
 * control. Registered by {@see KlarnaLifecycle} (always on, so it also protects existing Klarna orders while the module is off).
 *
 * What is guaranteed (classic shortcode checkout, same verified shopper = same account or same WooCommerce session):
 *  1. ONE checkout request at a time. An atomic, persistent lock ({@see Lock}, `add_option`) keyed on the shopper's WooCommerce customer
 *     id (the account id when logged in, the session id for a guest) is taken before WooCommerce validates, creates or pays anything and
 *     held until the request ends (shutdown, so also after wp_send_json()/exit). A second tab or device of the same account, or a double
 *     click, is answered "already being processed" before any gateway - Klarna or third-party - is called. This works for gateways GRCS
 *     does not control because it wraps their whole process_payment() call.
 *  2. A cart already placed in this session is not paid again (WooCommerce keeps `order_awaiting_payment` until the thank-you page).
 *  3. Durable payment-attempt ledger ({@see KlarnaPaymentAdmission}, D1): an unresolved attempt blocks the verified shopper's next online
 *     payment, committed BEFORE any gateway is called. The legacy `_grcs_pay_intent` stamp stays readable and counts as an unknown attempt
 *     whatever its age or local order status; nothing is ever released by a timer ({@see KlarnaLifecycle::guardCheckout()}).
 *  4. WooCommerce's own unpaid-order cancellation never cancels an order with an unresolved attempt - any gateway, Klarna module on or
 *     off (it would silently release the hold).
 *
 * What is NOT guaranteed (documented limitations, see docs/agents/handoffs/2026-10-30-klarna-cross-gateway-guest-privacy.md):
 *  - two DIFFERENT guest browsers with no shared cookie (no verified identity links them);
 *  - the block (Store API) checkout: Klarna is not offered there and these hooks are classic-checkout hooks.
 * (The S1 request lock is only an optimisation now: a gateway call longer than {@see self::LOCK_TTL} seconds is still held by the ledger.)
 */
final class KlarnaCheckoutCoordinator implements HookSubscriberInterface
{
    public const LOCK_TTL = 120;
    public const INTENT_META = '_grcs_pay_intent';

    /** @var array<string, true> */
    private static array $held = [];
    private static bool $shutdownRegistered = false;

    public function register(): void
    {
        add_action('woocommerce_before_checkout_process', [$this, 'begin']);
        add_action('woocommerce_checkout_order_processed', [$this, 'orderProcessed'], 10, 3);
        add_filter('woocommerce_payment_successful_result', [$this, 'recordIntent'], 10, 2);
        add_filter('woocommerce_cancel_unpaid_order', [$this, 'keepHeldOrders'], 10, 2);
        add_action('woocommerce_cart_emptied', [self::class, 'forgetPlaced']);
        KlarnaPaymentAdmission::register();
        KlarnaOrphanReservations::register();
        \GRCommerceSuite\Payments\GuestRecovery::register();
    }

    /**
     * Runs inside WooCommerce's process_checkout() try block: an Exception here is shown to the shopper as a checkout error and nothing
     * else happens. Only while the Klarna module is on (that is when Klarna and another gateway can compete for the same cart).
     *
     * @throws \Exception
     */
    public function begin(): void
    {
        if (!KlarnaModule::isEnabled()) {
            return;
        }
        $wc = function_exists('WC') ? \WC() : null;
        $session = is_object($wc) ? $wc->session : null;
        if (!is_object($session) || !method_exists($session, 'get_customer_id')) {
            return;
        }
        $customer = (string) $session->get_customer_id();
        if ($customer === '') {
            return;
        }
        $name = 'grcs-checkout-' . substr(hash('sha256', $customer), 0, 32);
        if (!Lock::acquire($name, self::LOCK_TTL)) {
            throw new \Exception(__('Your payment is already being processed. Please wait a moment and check your email before trying again.', 'gr-commerce-suite')); // customer-facing
        }
        self::$held[$name] = true;
        if (!self::$shutdownRegistered) {
            self::$shutdownRegistered = true;
            register_shutdown_function([self::class, 'releaseAll']);
        }
        // Inside the lock: a request that finished a moment ago has already left its result on the order. WooCommerce forgets the awaiting
        // order the moment a payment completes, so the cart this session placed last is remembered here until the cart is emptied.
        $cart = $wc->cart;
        $candidates = array_filter([KlarnaShopperProof::sessionOrderId(), self::placedOrderId($session)]);
        foreach (array_unique($candidates) as $candidateId) {
            $order = function_exists('wc_get_order') ? \wc_get_order((int) $candidateId) : false;
            if ($order instanceof WC_Order && is_object($cart) && $order->has_status(['processing', 'completed', 'on-hold'])
                && $order->has_cart_hash((string) $cart->get_cart_hash())
                && !($order->get_payment_method() === KlarnaSettings::GATEWAY_ID && (new KlarnaOrderRecord($order))->unresolved())) { // an unresolved Klarna order gets its own, more specific message
                throw new \Exception(sprintf(
                    /* translators: %s: link to the order page */
                    __('This order has already been placed, so it will not be paid a second time. %s', 'gr-commerce-suite'), // customer-facing
                    '<a href="' . esc_url($order->get_checkout_order_received_url()) . '">' . esc_html__('View your order', 'gr-commerce-suite') . '</a>'
                ));
            }
        }
    }

    private const PLACED_KEY = 'grcs_last_placed';

    /** @param object $session */
    private static function placedOrderId($session): int
    {
        $row = method_exists($session, 'get') ? $session->get(self::PLACED_KEY) : null;
        return is_array($row) ? (int) ($row['id'] ?? 0) : 0;
    }

    /** The cart was emptied (payment done and thank-you page reached): the next checkout is a new purchase. */
    public static function forgetPlaced(): void
    {
        $wc = function_exists('WC') ? \WC() : null;
        $session = is_object($wc) ? $wc->session : null;
        if (is_object($session) && method_exists($session, 'set')) {
            $session->set(self::PLACED_KEY, null);
        }
    }

    /** Release every lock this request took. Registered as a shutdown function, so it also runs after wp_send_json() / exit. */
    public static function releaseAll(): void
    {
        foreach (array_keys(self::$held) as $name) {
            Lock::release($name);
        }
        self::$held = [];
    }

    /**
     * The order exists and the payment is about to start. For a Klarna order: give a guest their proof cookie NOW (before the Klarna call,
     * so a request that dies mid-create still leaves the proof), and tell the merchant - privately - when another unresolved Klarna order
     * carries the same billing email. The email is a hint for the merchant, never proof of anything and never shown to a customer.
     *
     * @param mixed $orderId
     * @param mixed $data
     * @param mixed $order
     */
    public function orderProcessed($orderId, $data = [], $order = null): void
    {
        if (!$order instanceof WC_Order || !KlarnaModule::isEnabled()) {
            return;
        }
        $wc = function_exists('WC') ? \WC() : null;
        $session = is_object($wc) ? $wc->session : null;
        if (is_object($session) && method_exists($session, 'set')) {
            $session->set(self::PLACED_KEY, ['id' => $order->get_id()]); // any gateway: see begin()
        }
        if ((is_array($data) ? (string) ($data['payment_method'] ?? '') : '') !== KlarnaSettings::GATEWAY_ID) {
            return;
        }
        KlarnaShopperProof::issue($order);
        $email = (string) $order->get_billing_email();
        if ($email === '' || !function_exists('wc_get_orders')) {
            return;
        }
        $others = \wc_get_orders(['limit' => 10, 'billing_email' => $email, 'payment_method' => KlarnaSettings::GATEWAY_ID, 'exclude' => [$order->get_id()],
            'status' => function_exists('wc_get_order_statuses') ? array_keys(\wc_get_order_statuses()) : ['pending', 'failed', 'on-hold']]);
        foreach (is_array($others) ? $others : [] as $other) {
            if ($other instanceof WC_Order && (new KlarnaOrderRecord($other))->unresolved()) {
                // Private notes (never a customer note). Unverified: it only tells the merchant where to look before shipping twice.
                $order->add_order_note(sprintf('Possible duplicate: Klarna order #%d (same billing email, not verified as the same person) is still unresolved. Check before shipping.', $other->get_id()));
            }
        }
    }

    /**
     * A third-party gateway answered "success" but the order is still pending: the shopper is at (or on the way to) the provider and GRCS
     * cannot see how that ends. Stamp it, persistently, and give a guest their proof cookie.
     *
     * @param mixed $result
     * @param mixed $orderId
     * @return mixed
     */
    public function recordIntent($result, $orderId = 0)
    {
        if (!KlarnaModule::isEnabled() || !function_exists('wc_get_order')) {
            return $result;
        }
        $order = \wc_get_order((int) $orderId);
        if ($order instanceof WC_Order && $order->get_payment_method() !== KlarnaSettings::GATEWAY_ID && $order->has_status('pending')) {
            $order->update_meta_data(self::INTENT_META, ['gateway' => $order->get_payment_method(), 'at' => time(), 'cart' => (string) $order->get_cart_hash()]);
            $order->save();
            KlarnaShopperProof::issue($order);
        }
        return $result;
    }

    /**
     * A third-party order whose provider may still be completing it. GRCS cannot see the provider's session, so the legacy intent is an
     * UNKNOWN attempt until the order is paid or the ledger records a terminal outcome for it: elapsed time, a local `failed` / `cancelled`
     * status or the shop's unpaid-order window never resolve it (D1 owner decision: no timer release). Callers exclude Klarna orders,
     * which stay unresolved until Klarna's own evidence says otherwise.
     */
    public static function inFlight(WC_Order $order): bool
    {
        return LegacyIntents::isUnresolved($order);
    }

    /** The shop's unpaid-order window. Informational only: it no longer releases anything. */
    public static function window(): int
    {
        $minutes = function_exists('get_option') ? (int) get_option('woocommerce_hold_stock_minutes', 60) : 60;
        $window = max(900, $minutes * 60);
        return function_exists('apply_filters') ? max(0, (int) apply_filters('grcs_klarna_inflight_window', $window)) : $window;
    }

    /**
     * WooCommerce cancels pending checkout orders after the hold-stock window. For an order with an unresolved attempt - a Klarna order
     * Klarna holds (or may hold), any gateway's attempt in the ledger, or a legacy intent - that would be an automatic release, so it is
     * kept; only provider evidence or an audited merchant release ends it. Runs for every gateway and with the Klarna module OFF.
     *
     * @param mixed $cancel
     * @param mixed $order
     */
    public function keepHeldOrders(mixed $cancel, mixed $order = null): mixed
    {
        if (!$cancel || !$order instanceof WC_Order) {
            return $cancel;
        }
        $record = new KlarnaOrderRecord($order);
        if ($record->heldByKlarna() && $record->fraudStatus() !== 'REJECTED') {
            return false;
        }
        if (LegacyIntents::isUnresolved($order)) {
            return false;
        }
        try {
            if (PaymentLedger::fromGlobals()->orderHasBlockingAttempt($order->get_id())) {
                return false;
            }
        } catch (LedgerException) {
            if (Schema::ledgerWasInstalled()) {
                return false; // the ledger existed but cannot be read now: never cancel on a guess; the next cron run decides
            }
            // ledger never installed: nothing to veto on from the ledger
        }

        return $cancel;
    }
}
