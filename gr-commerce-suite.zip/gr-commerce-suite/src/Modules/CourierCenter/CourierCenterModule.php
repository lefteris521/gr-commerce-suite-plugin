<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\CourierCenter;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Admin\EmbeddedIntegrationPanel;
use GRCommerceSuite\Modules\EmbeddedIntegrations;
use GRCommerceSuite\Modules\ModuleRegistry;

/** Configuration for the provider implementation shipped and booted inside GRCS. */
final class CourierCenterModule implements HookSubscriberInterface
{
    public const PLUGIN = 'courier-center-for-woocommerce/courier-center-for-woocommerce.php';
    public const SECTION = 'courier_center';
    public const FIELD_TYPE = 'grcs_courier_center_status';


    /** @return array{label: string, description: string, off: string, plugin: string} */
    public static function definition(): array
    {
        return ['label' => Text::get('module'), 'description' => Text::get('description'), 'off' => Text::get('off'), 'plugin' => self::PLUGIN];
    }

    public function register(): void
    {
        if (ModuleRegistry::isEnabled(ModuleRegistry::COURIER_CENTER)) {
            add_action('woocommerce_admin_field_' . self::FIELD_TYPE, [$this, 'renderSettingsField']);
        }
    }

    /** @return list<array<string, mixed>> */
    public static function fields(): array
    {
        return ModuleRegistry::isEnabled(ModuleRegistry::COURIER_CENTER) ? [
            ['type' => 'title', 'id' => 'grcs_courier_center_title', 'title' => Text::get('module')],
            ['type' => self::FIELD_TYPE, 'id' => 'grcs_courier_center_status', 'is_option' => false],
            ['type' => 'sectionend', 'id' => 'grcs_courier_center_end'],
        ] : [];
    }

    public static function setupUrl(): string
    {
        return admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite&section=' . self::SECTION);
    }

    public static function settingsUrl(): string
    {
        return admin_url('admin.php?page=courier-center');
    }

    /** @return array{state: string, version: string} */
    public static function status(): array
    {
        if (!ModuleRegistry::isEnabled(ModuleRegistry::COURIER_CENTER)) {
            return ['state' => 'off_status', 'version' => ''];
        }
        $info = EmbeddedIntegrations::status(ModuleRegistry::COURIER_CENTER);
        return ['state' => $info['state'], 'version' => $info['version']];
    }

    /** @param array<string, mixed> $field */
    public function renderSettingsField(array $field = []): void
    {
        EmbeddedIntegrationPanel::render(ModuleRegistry::COURIER_CENTER, self::settingsUrl(), Text::get('module'), 'manage_woocommerce');
    }
}
