<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules\CourierCenter;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Admin\EmbeddedIntegrationPanel;

final class Text
{
    public static function get(string $key): string
    {
        $strings = [
            'module' => ['Courier Center', 'Courier Center'],
            'description' => ['Shipments, labels, tracking and returns using the included Courier Center implementation.', 'Αποστολές, ετικέτες, tracking και επιστροφές με την ενσωματωμένη υλοποίηση Courier Center.'],
            'off' => ['Stops new work and automatic jobs. Credentials and history remain; explicit historical actions stay available.', 'Σταματούν οι νέες εργασίες και οι αυτόματες εργασίες. Οι κωδικοί και το ιστορικό διατηρούνται· οι ρητές ενέργειες ιστορικού παραμένουν διαθέσιμες.'],
            'setup' => ['Configure Courier Center', 'Ρυθμίσεις Courier Center'],
            'native' => ['BOX NOW (native GRCS)', 'BOX NOW (εγγενές GRCS)'],
        ];
        return isset($strings[$key]) ? $strings[$key][AdminLocale::locale() === 'el' ? 1 : 0] : EmbeddedIntegrationPanel::stateLabel($key);
    }
}
