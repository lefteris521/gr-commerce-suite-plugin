<?php

declare(strict_types=1);

namespace GRCommerceSuite\Modules;

/** Pinned provider implementations shipped inside this plugin, loaded before their normal WC hooks. */
final class EmbeddedIntegrations
{
    public const BOXNOW_OWNER = 'grcs_boxnow_owner';

    private const PACKAGES = [
        ModuleRegistry::COURIER_CENTER => ['file' => 'courier_center/courier-center-for-woocommerce.php', 'plugin' => 'courier-center-for-woocommerce/courier-center-for-woocommerce.php', 'version' => '1.6.0', 'marker' => 'Courier_Center_WooCommerce'],
    ];

    /** @var array<string, string> */
    private static array $loaded = [];

    public static function register(): void
    {
        add_action('plugins_loaded', [self::class, 'boot'], 1);
        add_filter('pre_schedule_event', [self::class, 'allowSchedule'], 10, 2);
        add_filter('woocommerce_admin_settings_sanitize_option_' . self::BOXNOW_OWNER, [self::class, 'sanitizeOwner']);
    }

    public static function boot(): void
    {
        if (!class_exists('WooCommerce')) {
            return;
        }
        if (!function_exists('is_plugin_active') && defined('ABSPATH')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        foreach (array_keys(self::PACKAGES) as $key) {
            // A previously bundled credential remains readable if a merchant already has a standalone copy.
            if (get_option('grcs_embedded_used_' . $key, 'no') === 'yes') {
                \GRCommerceSuite\Security\IntegrationSecrets::register($key, false);
            }
            if (ModuleRegistry::isEnabled($key) || self::historicalRequest($key)) {
                self::load($key);
            }
        }
    }

    public static function path(string $key): string
    {
        return isset(self::PACKAGES[$key]) ? dirname(__DIR__, 2) . '/integrations/' . self::PACKAGES[$key]['file'] : '';
    }

    public static function externalActive(string $key): bool
    {
        return isset(self::PACKAGES[$key]) && function_exists('is_plugin_active')
            && is_plugin_active(self::PACKAGES[$key]['plugin']);
    }

    /** @return array{state: string, version: string, source: string} */
    public static function status(string $key): array
    {
        if (!isset(self::PACKAGES[$key])) {
            return ['state' => 'unavailable', 'version' => '', 'source' => ''];
        }
        $source = self::$loaded[$key] ?? (self::externalActive($key) ? 'external' : 'bundled');
        $state = self::$loaded[$key] ?? '';
        return ['state' => $state === 'failed' ? 'unavailable' : (!is_file(self::path($key)) && $source !== 'external' ? 'missing_bundle'
            : ($state === '' && $source !== 'external' ? 'pending' : 'available')),
            'version' => self::PACKAGES[$key]['version'], 'source' => $source];
    }

    public static function newWorkEnabled(string $key): bool
    {
        if (!ModuleRegistry::isEnabled($key)) {
            return false;
        }
        return isset(self::PACKAGES[$key]);
    }

    public static function historyOnly(string $key): bool
    {
        return !self::newWorkEnabled($key);
    }

    public static function sanitizeOwner(mixed $value): string
    {
        return in_array($value, ['native', 'courier_center'], true) ? $value : 'native';
    }

    public static function boxNowOwner(): string
    {
        return self::sanitizeOwner(get_option(self::BOXNOW_OWNER, 'native'));
    }

    public static function courierCenterPickerEnabled(): bool
    {
        return self::newWorkEnabled(ModuleRegistry::COURIER_CENTER) && self::boxNowOwner() === 'courier_center';
    }

    public static function load(string $key): void
    {
        if (isset(self::$loaded[$key]) || !isset(self::PACKAGES[$key])) {
            return;
        }
        $package = self::PACKAGES[$key];
        \GRCommerceSuite\Security\IntegrationSecrets::register($key, false);
        if (self::externalActive($key) || function_exists($package['marker']) || class_exists($package['marker'], false)) {
            self::$loaded[$key] = 'external';
            return;
        }
        if (!is_file(self::path($key))) {
            self::$loaded[$key] = 'failed';
            return;
        }
        self::$loaded[$key] = 'loading';
        try {
            if (!\GRCommerceSuite\Security\IntegrationSecrets::register($key, ModuleRegistry::isEnabled($key))) {
                throw new \RuntimeException('Credential encryption is unavailable.');
            }
            require_once self::path($key);
            self::$loaded[$key] = 'bundled';
            if (ModuleRegistry::isEnabled($key) && get_option('grcs_embedded_used_' . $key, 'no') !== 'yes') {
                update_option('grcs_embedded_used_' . $key, 'yes', false);
            }
        } catch (\Throwable $error) {
            self::$loaded[$key] = 'failed';
            if (function_exists('wc_get_logger')) {
                wc_get_logger()->error('Bundled integration could not start.', ['source' => 'gr-commerce-suite', 'integration' => $key, 'exception' => $error::class]);
            }
        }
    }

    /** Retire only automatic work; keep credentials, history and callback entry points. */
    public static function retire(string $key): void
    {
        $hooks = match ($key) {
            ModuleRegistry::COURIER_CENTER => ['cc_status_tracking_cron'],
            default => [],
        };
        foreach ($hooks as $hook) {
            if (function_exists('wp_clear_scheduled_hook')) {
                wp_clear_scheduled_hook($hook);
            }
        }
    }

    public static function allowSchedule(mixed $pre, object $event): mixed
    {
        $hook = $event->hook ?? '';
        $key = match ($hook) {
            'cc_status_tracking_cron' => ModuleRegistry::COURIER_CENTER,
            default => '',
        };
        return $key !== '' && !self::externalActive($key) && !self::newWorkEnabled($key) ? false : $pre;
    }

    private static function historicalRequest(string $key): bool
    {
        $uri = is_string($_SERVER['REQUEST_URI'] ?? null) ? $_SERVER['REQUEST_URI'] : '';
        if (!function_exists('is_admin') || !is_admin()) {
            $viewingHistory = str_contains($uri, '/view-order/') || str_contains($uri, '/order-received/')
                || str_contains($uri, '/my-account/') || isset($_GET['view-order'], $_GET['order-received']);
            return $viewingHistory && get_option('grcs_embedded_used_' . $key, 'no') === 'yes';
        }
        $page = is_string($_GET['page'] ?? null) ? $_GET['page'] : '';
        $action = is_string($_REQUEST['action'] ?? null) ? $_REQUEST['action'] : '';
        $orderRequest = in_array($page, ['wc-orders', 'courier-center-returns', 'courier-center-manifest'], true)
            || ($_GET['post_type'] ?? '') === 'shop_order' || isset($_GET['post'])
            || str_starts_with($action, 'cc_');
        return $orderRequest && get_option('grcs_embedded_used_' . $key, 'no') === 'yes';
    }

}
