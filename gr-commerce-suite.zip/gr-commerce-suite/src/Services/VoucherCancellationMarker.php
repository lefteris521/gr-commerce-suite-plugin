<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use WC_Order;

/**
 * Durable "cancellation dispatched, outcome unknown" marker stored on the order.
 *
 * The row state stays `created` while a cancellation is in flight, so printing and the order screen must
 * consult this marker instead of trusting `state` alone: a process killed after Geniki cancelled the
 * shipment must leave a row that is neither printable nor presented as active.
 */
final class VoucherCancellationMarker
{
    private const PREFIX = '_grcs_voucher_cancel_pending_';

    /** @return array{token: string, at_utc: string, voucher_no: string, courier: string}|null */
    public static function pending(WC_Order $order, int $voucherId): ?array
    {
        $value = $order->get_meta(self::PREFIX . max(0, $voucherId), true);
        if (!is_array($value) || trim((string) ($value['token'] ?? '')) === '') {
            return null;
        }

        return [
            'token' => (string) $value['token'],
            'at_utc' => (string) ($value['at_utc'] ?? ''),
            'voucher_no' => (string) ($value['voucher_no'] ?? ''),
            'courier' => (string) ($value['courier'] ?? ''),
        ];
    }

    public static function isPending(WC_Order $order, int $voucherId): bool
    {
        return self::pending($order, $voucherId) !== null;
    }

    /** Persist the marker and return its random owner token, before any carrier cancellation request. */
    public static function mark(WC_Order $order, int $voucherId, string $voucherNo, CourierSlug $courier): string
    {
        $token = bin2hex(random_bytes(16));
        $order->update_meta_data(self::PREFIX . max(0, $voucherId), [
            'token' => $token,
            'at_utc' => gmdate('c'),
            'voucher_no' => $voucherNo,
            'courier' => $courier->value,
        ]);
        $order->save();

        return $token;
    }

    /** Roll the marker back (carrier failure proven before/without cancellation) or clear it after success. */
    public static function clear(WC_Order $order, int $voucherId): void
    {
        if (!self::isPending($order, $voucherId)) {
            return;
        }
        $order->delete_meta_data(self::PREFIX . max(0, $voucherId));
        $order->save();
    }
}
