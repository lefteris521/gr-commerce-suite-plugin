<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Domain\Voucher\VoucherResult;
use WC_Order;
use WC_Order_Item_Product;

/** Shared warehouse defaults; all weights leaving this class are kilograms. */
final class ShippingOptions
{
    public const SENDER = 'grcs_sender_name';
    public const WEIGHT = 'grcs_default_parcel_weight';
    public const AUTO_ISSUE = 'grcs_auto_issue_completed';
    public const AUTO_STATUS = 'grcs_auto_update_tracking_status';

    public static function senderName(): string
    {
        $name = trim((string) get_option(self::SENDER, ''));
        return $name !== '' ? $name : (string) get_option('blogname', 'GR Commerce Store');
    }

    public static function parcelCount(WC_Order $order): int
    {
        return max(1, min(100, (int) $order->get_meta('_grcs_parcel_count', true)));
    }

    public static function weightKg(WC_Order $order): float
    {
        return self::weightSource($order)['kg'];
    }

    /**
     * The voucher weight and where it came from, so the order screen can explain the number.
     * `missing` counts shippable product lines without a weight; they add nothing to the sum.
     *
     * @return array{kg: float, source: 'override'|'products'|'default', missing: int}
     */
    public static function weightSource(WC_Order $order): array
    {
        $override = $order->get_meta('_grcs_custom_weight', true);
        if (is_numeric($override) && (float) $override > 0 && is_finite((float) $override)) {
            return ['kg' => (float) $override, 'source' => 'override', 'missing' => 0];
        }
        $weight = 0.0;
        $missing = 0;
        foreach ($order->get_items() as $item) {
            if (!$item instanceof WC_Order_Item_Product) {
                continue;
            }
            $product = $item->get_product();
            if (!$product instanceof \WC_Product) {
                continue;
            }
            $raw = (float) $product->get_weight();
            if ($raw <= 0 && !$product->is_virtual()) {
                $missing++;
            }
            $kg = function_exists('wc_get_weight') ? (float) wc_get_weight($raw, 'kg') : $raw;
            $weight += max(0.0, $kg) * max(1, (int) $item->get_quantity());
        }
        if ($weight > 0 && is_finite($weight)) {
            return ['kg' => $weight, 'source' => 'products', 'missing' => $missing];
        }
        $default = get_option(self::WEIGHT, '1.0');
        return ['kg' => is_numeric($default) && (float) $default > 0 && is_finite((float) $default)
            ? (float) $default : 1.0, 'source' => 'default', 'missing' => $missing];
    }

    /** @return non-empty-list<non-empty-string> */
    public static function resultVoucherNumbers(VoucherResult $result): array
    {
        $numbers = [];
        $parcels = $result->rawResponse['parcels'] ?? [];
        if ($result->courier->value === 'boxnow' && is_array($parcels)) {
            foreach ($parcels as $parcel) {
                $id = is_array($parcel) ? trim((string) ($parcel['id'] ?? '')) : '';
                if ($id !== '') {
                    $numbers[] = $id;
                }
            }
        }
        $primary = trim($result->voucherNo);
        if ($primary === '') {
            throw new \RuntimeException(__('Voucher number is missing.', 'gr-commerce-suite'));
        }
        if ($result->courier->value === 'geniki') {
            if (preg_match('/^[A-Za-z0-9_-]{1,100}$/D', $primary) !== 1) {
                throw new \RuntimeException(__('Invalid voucher number.', 'gr-commerce-suite'));
            }
            $numbers = [$primary];
            $children = $result->rawResponse['sub_vouchers'] ?? [];
            foreach (is_array($children) ? $children : [] as $child) {
                if (is_string($child) && preg_match('/^[A-Za-z0-9_-]{1,100}$/D', trim($child)) === 1) {
                    $numbers[] = trim($child);
                }
            }
        }
        return $numbers !== [] ? array_values(array_unique($numbers)) : [$primary];
    }

    /**
     * @param array<string, mixed> $row
     * @return non-empty-list<non-empty-string>
     */
    public static function voucherNumbers(array $row): array
    {
        $order = wc_get_order((int) $row['order_id']);
        $snapshot = $order instanceof WC_Order ? $order->get_meta('_grcs_shipment_' . (int) $row['id'], true) : [];
        $numbers = is_array($snapshot) ? ($snapshot['voucher_numbers'] ?? []) : [];
        $numbers = is_array($numbers) ? array_values(array_filter($numbers, static fn($id): bool => is_string($id) && $id !== '')) : [];
        $fallback = trim((string) ($row['voucher_no'] ?? ''));
        if ($numbers === [] && $fallback === '') {
            throw new \RuntimeException(__('Voucher number is missing.', 'gr-commerce-suite'));
        }
        return $numbers !== [] ? $numbers : [$fallback];
    }

    /** @return list<string> */
    public static function acsProducts(WC_Order $order, bool $cod): array
    {
        $products = $cod ? ['COD'] : [];
        foreach (['saturday' => 'SAT', 'rdo' => 'RDO', 'rec' => 'REC'] as $key => $code) {
            if ($order->get_meta('_grcs_acs_' . $key, true) === 'yes') {
                $products[] = $code;
            }
        }
        return $products;
    }
}
