<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Tracking\TrackingResult;
use GRCommerceSuite\Domain\Tracking\TrackingStatus;
use GRCommerceSuite\Support\Redactor;

/**
 * Polls courier tracking APIs and updates `tracking_status` and `last_tracked_at` (SPEC.md §11).
 */
final readonly class TrackingService
{
    /** Public destinations only; no courier API calls or stored, potentially obsolete URLs.
     * ACS publishes this route and generalCode parameter on its public Track & Trace page:
     * https://www.acscourier.net/el/track-and-trace?generalCode=0000000000
     */
    public static function publicUrl(string $voucherNo, CourierSlug $courier): string
    {
        $voucherNo = trim($voucherNo);
        if ($voucherNo === '') {
            return '';
        }
        $encoded = rawurlencode($voucherNo);
        $url = match ($courier) {
            CourierSlug::Acs => 'https://www.acscourier.net/el/track-and-trace?generalCode=' . $encoded,
            CourierSlug::BoxNow => 'https://boxnow.gr/?track=' . $encoded,
            CourierSlug::Geniki => 'https://www.taxydromiki.com/track/' . $encoded,
        };
        // Allows a removed/unavailable destination to be disabled without hiding the voucher number.
        $url = apply_filters('grcs_public_tracking_url', $url, $voucherNo, $courier);
        if (!is_string($url) || filter_var($url, FILTER_VALIDATE_URL) === false
            || strtolower((string) parse_url($url, PHP_URL_SCHEME)) !== 'https') {
            return '';
        }
        return $url;
    }

    public function __construct(
        private VoucherRepository $repository,
        private CourierRegistry $courierRegistry,
        private LoggerInterface $logger,
    ) {
    }

    public function pollVoucherById(int $voucherId): ?TrackingResult
    {
        // Read-only tracking of an existing voucher works without a licence (owner decision 2026-11-03).
        $row = $this->repository->findById($voucherId);
        if ($row === null) {
            return null;
        }

        $voucherNo = trim((string) ($row['voucher_no'] ?? ''));
        if ($voucherNo === '') {
            return null;
        }

        $courier = CourierSlug::from((string) $row['courier_slug']);
        $oldStatus = TrackingStatus::tryFrom((string) ($row['tracking_status'] ??
             'pending')) ??
             TrackingStatus::Pending;

        $provider = $this->courierRegistry->get($courier);
        $result = $provider->getTrackingStatus($voucherNo);
        if (in_array($courier, [CourierSlug::BoxNow, CourierSlug::Geniki], true)) {
            $results = [$result];
            foreach (ShippingOptions::voucherNumbers($row) as $number) {
                if ($number !== $voucherNo) {
                    $results[] = $provider->getTrackingStatus($number);
                }
            }
            $result = self::aggregateParcels($voucherNo, $results);
        }
        $this->logger->debug(
            'Courier tracking polled.',
            ['voucher_id' => $voucherId,
            'status' => $result->status->value]
        );

        $updated = $this->repository->updateTracking(
            id: $voucherId,
            status: $result->status,
            rawResponseJson: Redactor::toRedactedJson($result->rawResponse),
        );

        if ($updated && $oldStatus !== $result->status && function_exists('do_action')) {
            do_action(
                'grcs/tracking/status_changed',
                $voucherId,
                $oldStatus,
                $result->status,
                (int) $row['order_id']
            );
        }

        return $result;
    }
    /** @param non-empty-list<TrackingResult> $results */
    public static function aggregateParcels(string $voucherNo, array $results): TrackingResult
    {
        $selected = $results[0];
        foreach ($results as $result) {
            if ($result->status !== TrackingStatus::Delivered) {
                $selected = $result;
            }
            if (in_array($result->status, [TrackingStatus::Returned, TrackingStatus::Returning, TrackingStatus::Exception], true)) {
                $selected = $result;
                break;
            }
        }
        return new TrackingResult(
            $voucherNo,
            $selected->status,
            $selected->courierStatusCode,
            $selected->courierStatusLabel,
            $selected->lastEventAt,
            $selected->events,
            ['parcels' => array_map(
                static fn(TrackingResult $result): array => [
                'id' => $result->voucherNo, 'status' => $result->status->value, 'response' => $result->rawResponse,
                ],
                $results
            )]
        );
    }
}
