<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Contracts\CourierProviderInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Contracts\VoucherLookupInterface;
use GRCommerceSuite\Contracts\VoucherStateTrackerInterface;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Voucher\VoucherResult;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Exceptions\Courier\CourierAmbiguousResultException;
use GRCommerceSuite\Exceptions\Courier\CourierAuthenticationException;
use GRCommerceSuite\Exceptions\Courier\CourierRateLimitedException;
use GRCommerceSuite\Exceptions\Courier\CourierTransportException;
use GRCommerceSuite\Exceptions\Courier\CourierValidationException;
use GRCommerceSuite\Jobs\JobDispatcher;
use GRCommerceSuite\Support\Lock;
use GRCommerceSuite\Support\Logger;
use GRCommerceSuite\Support\Money;
use GRCommerceSuite\Support\Redactor;
use InvalidArgumentException;
use RuntimeException;
use Throwable;
use WC_Order;

/**
 * Atomic Voucher State & Locking Service (SPEC.md §6, §7).
 *
 * Enforces:
 * 1. Exact state machine transitions (`reserved`, `created`, `unknown`, `failed`, `cancelled`).
 * 2. Deterministic SHA-256 `idempotency_key` generation and atomic lock / row reservation in
 *    `{prefix}_grcs_vouchers` prior to any `CourierProviderInterface::createVoucher()` call,
 *    preventing double-clicks on "Issue Voucher" or concurrent Action Scheduler jobs from ever
 *    creating two paid vouchers for the same order.
 * 3. Post-transmission HTTP timeout / connection-drop protection: sets `state = 'unknown'` and
 *    records `last_error` instead of blindly retrying.
 * 4. Admin resolution methods to reconcile `'unknown'` vouchers against the courier's daily
 *    pickup list or manually mark (`created`) / clear (`failed`) them.
 */
final class VoucherLockService implements VoucherStateTrackerInterface
{
    private const MAX_TRANSPORT_ATTEMPTS = 5;

    private const LOCK_TTL_SECONDS = 60;

    /** Default stale threshold: 30 minutes (well above max backoff 1020s + request timeout). */
    public const STALE_RESERVATION_SECONDS = 1800;

    /** Minimum age before an unknown voucher may be cleared (default 15 minutes). */
    public const CLEAR_UNKNOWN_MIN_AGE_SECONDS = 900;

    /** `last_error` prefix of a row whose carrier voucher surfaced after the row left `unknown`. */
    public const ORPHAN_CARRIER_VOUCHER_PREFIX = '[orphan-carrier-voucher]';

    /** `last_error` prefix once an operator has resolved such an orphan. */
    public const ORPHAN_CARRIER_VOUCHER_RESOLVED_PREFIX = '[orphan-carrier-voucher-resolved]';

    /**
     * Normative state transition graph (SPEC.md §6.3).
     *
     * @var array<string, list<string>>
     */
    private const ALLOWED_TRANSITIONS = [
        'reserved' => ['reserved', 'created', 'failed', 'unknown'],
        'unknown' => ['created', 'failed'],
        'created' => ['created', 'cancelled'],
        'failed' => [],
        'cancelled' => [],
    ];

    private readonly LoggerInterface $logger;

    public function __construct(
        private readonly VoucherRepository $repository,
        private readonly ?CourierRegistry $courierRegistry = null,
        private readonly ?JobDispatcher $jobDispatcher = null,
        ?LoggerInterface $logger = null,
    ) {
        $this->logger = $logger ?? new Logger('gr-commerce-suite');
    }

    /**
     * Check whether a state transition is permitted by the SPEC.md §6.3 state machine.
     */
    public function canTransition(VoucherState|string $from, VoucherState|string $to): bool
    {
        $fromValue = $from instanceof VoucherState ? $from->value : strtolower(trim($from));
        $toValue = $to instanceof VoucherState ? $to->value : strtolower(trim($to));

        if (!isset(self::ALLOWED_TRANSITIONS[$fromValue])) {
            return false;
        }

        return in_array($toValue, self::ALLOWED_TRANSITIONS[$fromValue], true);
    }

    /**
     * Assert that a state transition is valid according to SPEC.md §6.3.
     *
     * @throws InvalidArgumentException When the transition violates the voucher state machine.
     */
    public function assertValidTransition(VoucherState|string $from, VoucherState|string $to): void
    {
        $fromValue = $from instanceof VoucherState ? $from->value : strtolower(trim($from));
        $toValue = $to instanceof VoucherState ? $to->value : strtolower(trim($to));

        if (!$this->canTransition($fromValue, $toValue)) {
            throw new InvalidArgumentException(
                sprintf(__('Invalid voucher state transition from "%s" to "%s".', 'gr-commerce-suite'), $fromValue, $toValue)
            );
        }
    }

    /**
     * Perform a validated optimistic-concurrency state transition in `{prefix}_grcs_vouchers` (SPEC.md §6.3).
     *
     * @param array<string, scalar|null> $changes
     */
    public function transition(
        int $voucherId,
        VoucherState $from,
        VoucherState $to,
        array $changes = [],
    ): bool {
        $this->assertValidTransition($from, $to);

        return $this->repository->transition($voucherId, $from, $to, $changes);
    }

    /**
     * Derive the deterministic SHA-256 idempotency key for an order and courier (SPEC.md §7).
     *
     * Formula:
     *   n   = 1 + count(rows WHERE order_id = :order AND courier_slug = :courier AND state IN ('failed','cancelled'))
     *   key = sha256("grcs|v1|{order_id}|{courier_slug}|{series}|{n}")
     */
    public function deriveIdempotencyKey(int $orderId, CourierSlug $courier, int $series = 0): string
    {
        if ($orderId <= 0) {
            throw new InvalidArgumentException(__('Order ID must be a positive integer.', 'gr-commerce-suite'));
        }

        $safeSeries = max(0, $series);
        $n = 1 + $this->repository->countFailedOrCancelled($orderId, $courier);

        return hash('sha256', sprintf('grcs|v1|%d|%s|%d|%d', $orderId, $courier->value, $safeSeries, $n));
    }

    /**
     * Atomically acquire an order-level mutex lock and insert/reserve the voucher row with its
     * deterministic `idempotency_key` in `{prefix}_grcs_vouchers` (SPEC.md §6, §7).
     *
     * @return array{
     *     inserted: bool,
     *     lock_acquired: bool,
     *     idempotency_key: string,
     *     voucher_id: int,
     *     state: VoucherState,
     *     row: array<string, mixed>,
     *     dispatch_allowed: bool
     * }
     */
    public function acquireLockAndReserve(
        int $orderId,
        CourierSlug $courier,
        int $codAmountCents = 0,
        int $series = 0,
        bool $isScheduledRetry = false,
    ): array {
        LicenseManager::assertLicensed();

        $lockKey = $this->buildMutexName($orderId, $courier);
        $lockAcquired = Lock::acquire($lockKey, self::LOCK_TTL_SECONDS);

        $idempotencyKey = $this->deriveIdempotencyKey($orderId, $courier, $series);
        $reservation = $this->repository->reserve($orderId, $courier, $idempotencyKey, max(0, $codAmountCents));
        $row = $reservation['row'];
        $voucherId = (int) ($row['id'] ?? 0);
        $state = VoucherState::tryFrom((string) ($row['state'] ?? '')) ?? VoucherState::Reserved;
        // A new row may dispatch; an existing one only from a scheduled retry that holds the courier mutex.
        $dispatchAllowed = $reservation['inserted'] || ($isScheduledRetry && $lockAcquired);
        if ($dispatchAllowed && !$reservation['inserted'] && $state === VoucherState::Reserved) {
            // Heartbeat: a resumed reservation is about to dispatch, so the stale sweeper must not
            // see its old `updated_at` and take it while CreateJob is in flight.
            $this->repository->touchReserved($voucherId);
        }

        return [
            'inserted' => $reservation['inserted'],
            'lock_acquired' => $lockAcquired,
            'idempotency_key' => $idempotencyKey,
            'voucher_id' => $voucherId,
            'state' => $state,
            'row' => $row,
            'dispatch_allowed' => $dispatchAllowed,
        ];
    }

    /**
     * Release the atomic mutex lock for an order + courier.
     */
    public function releaseLock(int $orderId, CourierSlug $courier): void
    {
        Lock::release($this->buildMutexName($orderId, $courier));
    }

    /**
     * Issue a voucher for an order with atomic lock acquisition, duplicate-voucher protection,
     * and post-transmission timeout handling (`state = 'unknown'`) (SPEC.md §6, §7).
     */
    public function createVoucherWithLock(
        WC_Order $order,
        CourierSlug $courier,
        ?CourierProviderInterface $provider = null,
        bool $isScheduledRetry = false,
        bool $confirmedRiskyStatus = false,
    ): VoucherResult {
        LicenseManager::assertLicensed();
        if (!\GRCommerceSuite\Modules\ModuleRegistry::courierCanCreate($courier)) {
            throw new CourierValidationException(__('This courier is not selected for new shipments.', 'gr-commerce-suite'), $courier);
        }
        $orderId = (int) $order->get_id();
        if ($orderId <= 0) {
            throw new CourierValidationException(__('Cannot create a voucher for an unsaved order.', 'gr-commerce-suite'), $courier);
        }
        $token = VoucherOperationLock::acquire($orderId);
        try {
            // Do not allow a changed courier/series to bypass a previous live reservation.
            $orderRows = $this->repository->findByOrderId($orderId);
            foreach ($orderRows as $row) {
                if (!in_array($row['state'] ?? '', ['reserved', 'unknown', 'created'], true)) {
                    continue;
                }
                if (($row['courier_slug'] ?? '') !== $courier->value) {
                    throw new CourierValidationException(__('Cancel or resolve the existing voucher before changing courier.', 'gr-commerce-suite'), $courier, 409);
                }
                if (($row['state'] ?? '') === 'created' && !empty($row['voucher_no'])) {
                    return new VoucherResult((string) $row['voucher_no'], $courier,
                        Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents());
                }
                // Resume only the original deterministic reservation, including scheduled retries.
                $series = max(0, (int) $order->get_meta('_grcs_voucher_series', true));
                if (($row['idempotency_key'] ?? '') !== $this->deriveIdempotencyKey($orderId, $courier, $series)) {
                    throw new CourierValidationException(__('Resolve the existing voucher request before re-issuing.', 'gr-commerce-suite'), $courier, 409);
                }
            }
            // Status rule (decision 2026-11-06): after the return-existing dedupe, before any orphan check or courier call.
            $refusal = VoucherStatusRule::refusal($order, $courier, $confirmedRiskyStatus);
            if ($refusal !== null) {
                throw new CourierValidationException($refusal, $courier);
            }
            $this->assertNoOrphanCarrierVoucher($orderId, $courier, $orderRows);
            return $this->createVoucherUnderLock($order, $courier, $provider, $isScheduledRetry);
        } finally {
            VoucherOperationLock::release($orderId, $token);
        }
    }

    private function createVoucherUnderLock(
        WC_Order $order,
        CourierSlug $courier,
        ?CourierProviderInterface $provider = null,
        bool $isScheduledRetry = false,
    ): VoucherResult {
        LicenseManager::assertLicensed();

        $orderId = (int) $order->get_id();
        if ($orderId <= 0) {
            throw new CourierValidationException(__('Cannot create a voucher for an unsaved order.', 'gr-commerce-suite'), $courier);
        }

        if (function_exists('apply_filters')) {
            $allowed = (bool) apply_filters('grcs/voucher/before_create', true, $order, $courier);
            if (!$allowed) {
                throw new CourierValidationException(
                    __('Voucher creation was blocked by the grcs/voucher/before_create filter.', 'gr-commerce-suite'),
                    $courier
                );
            }
        }

        $series = max(0, (int) $order->get_meta('_grcs_voucher_series', true));
        $codAmountCents = $this->resolveExpectedCodCents($order);

        $lockInfo = $this->acquireLockAndReserve($orderId, $courier, $codAmountCents, $series, $isScheduledRetry);
        $row = $lockInfo['row'];
        $voucherId = $lockInfo['voucher_id'];
        $idempotencyKey = $lockInfo['idempotency_key'];
        $currentState = $lockInfo['state'];

        try {
            // 1. Already created for this deterministic key -> return deduplicated VoucherResult (zero duplicate API call)
            if (
                $currentState === VoucherState::Created
                && isset($row['voucher_no'])
                && is_string($row['voucher_no'])
                && trim($row['voucher_no']) !== ''
            ) {
                $this->logger->info(
                    sprintf(
                        'Deduplicated voucher creation for order #%d (%s): returning existing voucher %s.',
                        $orderId,
                        $courier->value,
                        $row['voucher_no']
                    )
                );

                return new VoucherResult(
                    voucherNo: trim($row['voucher_no']),
                    courier: $courier,
                    codAmountCents: Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents(),
                    parcelCount: max(1, (int) $order->get_meta('_grcs_parcel_count', true) ?: 1),
                );
            }

            // 2. Unresolved `unknown` state -> block duplicate creation until reconciled or cleared (SPEC.md §6.3, §7)
            if ($currentState === VoucherState::Unknown) {
                throw new CourierAmbiguousResultException(
                    sprintf(__('Order #%d has an unresolved voucher in unknown state (ID %d).', 'gr-commerce-suite'), $orderId, $voucherId),
                    $courier,
                    null,
                    ['voucher_id' => $voucherId, 'order_id' => $orderId, 'state' => VoucherState::Unknown->value],
                    'A previous voucher request for this order timed out and is in unknown state. ' .
                        'Reconcile or clear it before issuing a new voucher.'
                );
            }

            // 3. Concurrent double-click or parallel Action Scheduler job while reservation is already in-flight
            if (!$lockInfo['dispatch_allowed']) {
                $rechecked = $this->repository->findById($voucherId);
                if (
                    is_array($rechecked)
                    && ($rechecked['state'] ?? '') === VoucherState::Created->value
                    && !empty($rechecked['voucher_no'])
                ) {
                    return new VoucherResult(
                        voucherNo: (string) $rechecked['voucher_no'],
                        courier: $courier,
                        codAmountCents: Money::fromDecimalString((string) ($rechecked['cod_amount'] ??
                             '0.00'))->cents(),
                        parcelCount: 1,
                    );
                }

                throw new CourierValidationException(
                    sprintf(__('A voucher creation request for order #%d is already in progress.', 'gr-commerce-suite'), $orderId),
                    $courier,
                    409,
                    ['voucher_id' => $voucherId, 'order_id' => $orderId],
                    'A voucher is currently being issued for this order. Please wait a moment.'
                );
            }

            // Test-only pause point (native concurrency tests hook it); no listener in production.
            if (function_exists('do_action')) {
                do_action('grcs_test_voucher_after_reserve', $orderId, $voucherId, $courier);
            }

            // Re-check after reserve: an orphan number a background link recorded since the pre-check blocks the carrier call.
            try {
                $this->assertNoOrphanCarrierVoucher($orderId, $courier);
            } catch (CourierValidationException $e) {
                $this->transition(
                    $voucherId,
                    VoucherState::Reserved,
                    VoucherState::Failed,
                    ['last_error' => $e->merchantMessage()]
                );

                throw $e;
            }

            // 4. Persist `_grcs_active_idempotency_key` via HPOS CRUD so adapter can embed 16-char reference prefix.
            // The dispatch marker is written in the same save: a `reserved` row that ends up abandoned can then
            // be told apart by the stale sweeper (never transmitted vs. possibly transmitted).
            $dispatchMetaKey = self::dispatchMarkerKey($voucherId);
            $order->update_meta_data('_grcs_active_idempotency_key', $idempotencyKey);
            $order->update_meta_data($dispatchMetaKey, gmdate('c'));
            $order->save();

            $resolvedProvider = $provider ?? $this->resolveProvider($courier);
            $result = $resolvedProvider->createVoucher($order);

            // 5. Transition `reserved` -> `created` atomically
            $transitioned = $this->transition(
                $voucherId,
                VoucherState::Reserved,
                VoucherState::Created,
                [
                    'voucher_no' => $result->voucherNo,
                    'cod_amount' => Money::fromCents($result->codAmountCents)->toDecimalString(),
                    'last_error' => null,
                    'raw_response' => Redactor::toRedactedJson($result->rawResponse),
                ]
            );

            if (!$transitioned) {
                throw new CourierAmbiguousResultException(
                    __('The courier created a voucher but the local reservation changed. Reconcile it before retrying.', 'gr-commerce-suite'),
                    $courier,
                    null,
                    ['voucher_id' => $voucherId, 'voucher_no' => $result->voucherNo]
                );
            }

            $order->update_meta_data('_grcs_voucher_no', $result->voucherNo);
            $order->update_meta_data('_grcs_last_voucher_no', $result->voucherNo);
            $order->update_meta_data('_grcs_last_courier', $courier->value);
            $order->delete_meta_data($dispatchMetaKey);
            $order->add_order_note(
                sprintf(
                    AdminLocale::__('GR Commerce Suite: Created %1$s voucher %2$s.', 'gr-commerce-suite'),
                    $courier->label(),
                    $result->voucherNo
                )
            );
            $order->save();

            if (function_exists('do_action')) {
                do_action('grcs/voucher/created', $voucherId, $result, $orderId);
            }

            return $result;
        } catch (CourierAmbiguousResultException $e) {
            $this->recordUnknownAfterAmbiguousCall(
                voucherId: $voucherId,
                courier: $courier,
                errorMessage: $e->merchantMessage() !== '' ? $e->merchantMessage() : $e->getMessage(),
                rawContext: $e->context(),
                provider: $provider,
            );

            throw $e;
        } catch (CourierAuthenticationException $e) {
            $this->transition(
                $voucherId,
                VoucherState::Reserved,
                VoucherState::Failed,
                ['last_error' => $e->merchantMessage()]
            );
            // Proven pre-transmission failure: the marker must not make the sweeper treat this row as sent.
            $this->clearDispatchMarker($order, $voucherId);

            throw $e;
        } catch (CourierValidationException $e) {
            // Only transition to failed if this wasn't a 409 concurrent-in-progress guard
            if ($e->httpStatus() !== 409) {
                $this->transition(
                    $voucherId,
                    VoucherState::Reserved,
                    VoucherState::Failed,
                    ['last_error' => $e->merchantMessage()]
                );
                $this->clearDispatchMarker($order, $voucherId);

                $order->add_order_note(
                    sprintf('GR Commerce Suite (%s): %s', $courier->label(), $e->merchantMessage())
                );
                $order->save();
            }

            throw $e;
        } catch (CourierRateLimitedException $e) {
            $attempts = max(1, (int) ($row['attempts'] ?? 1));
            if ($attempts >= self::MAX_TRANSPORT_ATTEMPTS) {
                $this->transition($voucherId, VoucherState::Reserved, VoucherState::Failed, [
                    'last_error' => $e->merchantMessage(),
                ]);
                $this->clearDispatchMarker($order, $voucherId);
                throw $e;
            }
            // Rate-limited before any mutation: a later sweep must classify this as never transmitted.
            $this->clearDispatchMarker($order, $voucherId);
            $this->repository->incrementAttempts($voucherId, $e->merchantMessage());

            if ($this->jobDispatcher !== null) {
                $backoff = 60 * (2 ** max(0, $attempts - 1));
                $delay = max($e->getRetryAfterSeconds(), $backoff);
                $this->jobDispatcher->scheduleSingle(
                    time() + $delay,
                    JobDispatcher::HOOK_RETRY_VOUCHER,
                    ['voucher_id' => $voucherId, 'attempt' => $attempts + 1],
                    true
                );
            }

            throw $e;
        } catch (CourierTransportException $e) {
            // The typed before/after-transmission flag decides first; message matching is only a fallback
            // for callers that supplied no classification (SPEC.md §6, §7).
            if ($this->isTransmittedFailure($e)) {
                $this->recordUnknownAfterAmbiguousCall(
                    voucherId: $voucherId,
                    courier: $courier,
                    errorMessage: $e->getMessage(),
                    rawContext: $e->context(),
                    provider: $provider,
                );

                throw new CourierAmbiguousResultException(
                    $e->getMessage(),
                    $courier,
                    $e->httpStatus(),
                    $e->context(),
                    'Connection dropped or timed out after sending the voucher request. Marked as ' .
                        'unknown to prevent duplicate creation.',
                    $e
                );
            }

            $attempts = max(1, (int) ($row['attempts'] ?? 1)) + 1;

            if ($attempts >= self::MAX_TRANSPORT_ATTEMPTS) {
                $this->transition(
                    $voucherId,
                    VoucherState::Reserved,
                    VoucherState::Failed,
                    [
                        'attempts' => $attempts,
                        'last_error' => $e->merchantMessage(),
                    ]
                );
                $this->clearDispatchMarker($order, $voucherId);
            } else {
                // Proven pre-transmission (typed flag): no carrier mutation can exist, so drop the marker
                // before the retry chain. The retry writes it again immediately before its own dispatch.
                $this->clearDispatchMarker($order, $voucherId);
                $this->repository->incrementAttempts($voucherId, $e->merchantMessage());
                if ($this->jobDispatcher !== null) {
                    $backoff = (60 * (2 ** max(0, $attempts - 1))) + random_int(0, 30);
                    $this->jobDispatcher->scheduleSingle(
                        time() + $backoff,
                        JobDispatcher::HOOK_RETRY_VOUCHER,
                        ['voucher_id' => $voucherId, 'attempt' => $attempts],
                        true
                    );
                }
            }

            throw $e;
        } catch (Throwable $e) {
            if ($this->isTransmittedFailure($e)) {
                $this->recordUnknownAfterAmbiguousCall(
                    voucherId: $voucherId,
                    courier: $courier,
                    errorMessage: $e->getMessage(),
                    rawContext: ['exception' => $e::class],
                    provider: $provider,
                );

                throw new CourierAmbiguousResultException(
                    $e->getMessage(),
                    $courier,
                    null,
                    ['voucher_id' => $voucherId, 'order_id' => $orderId],
                    'The courier connection timed out or dropped after transmission. Voucher marked as unknown.',
                    $e
                );
            }

            $this->transition($voucherId, VoucherState::Reserved, VoucherState::Failed, ['last_error' => $e->getMessage()]);
            $this->clearDispatchMarker($order, $voucherId);
            $this->logger->error('Voucher creation failed.', ['courier' => $courier->value, 'exception' => $e->getMessage()]);
            throw $e;
        } finally {
            if ($lockInfo['lock_acquired']) {
                $this->releaseLock($orderId, $courier);
            }
        }
    }

    /**
     * Alias for `createVoucherWithLock` for convenient invocation.
     */
    public function issueVoucher(
        WC_Order $order,
        CourierSlug $courier,
        ?CourierProviderInterface $provider = null,
    ): VoucherResult {
        return $this->createVoucherWithLock($order, $courier, $provider);
    }

    /**
     * Transition a voucher row to `state = 'unknown'` and record `last_error` when a courier HTTP call
     * times out or drops connection after the request payload was sent (SPEC.md §6.3, §7).
     */
    public function markUnknownOnTimeout(
        int $orderId,
        CourierSlug $courier,
        string $errorMessage,
        ?string $idempotencyKey = null,
    ): void {
        $this->logger->warning(
            sprintf(
                'Marking voucher as unknown on timeout for order #%d (%s): %s',
                $orderId,
                $courier->value,
                $errorMessage
            )
        );

        $this->repository->markUnknownOnTimeout($orderId, $courier, $errorMessage, $idempotencyKey);
    }

    /**
     * Transition a specific voucher ID from `reserved` (or `unknown`) to `state = 'unknown'` and record `last_error`.
     *
     * @param array<string, mixed> $rawContext
     */
    public function markVoucherUnknown(
        int $voucherId,
        string $errorMessage,
        array $rawContext = [],
    ): bool {
        $row = $this->repository->findById($voucherId);
        if ($row === null) {
            return false;
        }

        $currentState = VoucherState::tryFrom((string) ($row['state'] ?? '')) ?? VoucherState::Reserved;
        if ($currentState !== VoucherState::Reserved && $currentState !== VoucherState::Unknown) {
            return false;
        }

        $changes = [
            'last_error' => $errorMessage,
        ];

        if ($rawContext !== []) {
            $changes['raw_response'] = Redactor::toRedactedJson($rawContext);
        }

        if ($currentState === VoucherState::Unknown) {
            // Already unknown: recording the same uncertainty again must not attempt Unknown -> Created
            // without a voucher number, and callers must not read a false "failure" from a no-op.
            return true;
        }

        return $this->transition($voucherId, VoucherState::Reserved, VoucherState::Unknown, $changes);
    }

    /**
     * Retrieve all vouchers currently in `'unknown'` state, optionally filtered by courier.
     *
     * @return list<array<string, mixed>>
     */
    public function getUnknownVouchers(?CourierSlug $courier = null, int $limit = 100): array
    {
        return $this->repository->findUnknownVouchers($courier, $limit);
    }

    /**
     * Admin resolution method: Reconcile `'unknown'` vouchers against a courier's daily pickup list
     * or `VoucherLookupInterface` (SPEC.md §6.3, §7).
     *
     * Supported `$pickupListVouchers` formats:
     *  - Associative map of `[order_id_or_reference => voucher_no]`, e.g. `[1001 => '790000123456', 'a1b2c3d4e5f60123' => '790000123456']`
     *  - List of associative records, e.g. `[['order_id' => 1001, 'voucher_no' => '790000123456', 'reference' => '...'], ...]`
     *
     * @param array<int|string, mixed> $pickupListVouchers
     * @return array{
     *     resolved_created: int,
     *     remaining_unknown: int,
     *     matched_vouchers: array<int, string>
     * }
     */
    public function reconcileUnknownWithPickupList(
        CourierSlug $courier,
        array $pickupListVouchers = [],
        ?string $pickupDate = null,
    ): array {
        LicenseManager::assertLicensed();

        $unknownRows = $this->repository->findUnknownVouchers($courier, 200);
        if ($unknownRows === []) {
            return [
                'resolved_created' => 0,
                'remaining_unknown' => 0,
                'matched_vouchers' => [],
            ];
        }

        $lookupIndex = $this->buildPickupListIndex($pickupListVouchers);
        $provider = ($this->courierRegistry !== null && $this->courierRegistry->has($courier))
            ? $this->courierRegistry->get($courier)
            : null;

        // If no explicit entries were passed and the provider supports issuePickupList, query it
        if ($lookupIndex === [] && $provider !== null && method_exists($provider, 'issuePickupList')) {
            try {
                /** @var array<string, mixed> $manifest */
                $manifest = $provider->issuePickupList($pickupDate ?? gmdate('Y-m-d'), []);
                if (isset($manifest['raw_response']) && is_array($manifest['raw_response'])) {
                    $lookupIndex = $this->buildPickupListIndex($manifest['raw_response']);
                }
            } catch (Throwable $e) {
                $this->logger->warning('Pickup list lookup during unknown voucher reconciliation failed: ' .
                     $e->getMessage());
            }
        }

        $resolvedCreated = 0;
        $remainingUnknown = 0;
        /** @var array<int, string> $matchedVouchers */
        $matchedVouchers = [];

        foreach ($unknownRows as $row) {
            $voucherId = (int) ($row['id'] ?? 0);
            $orderId = (int) ($row['order_id'] ?? 0);
            $idempotencyKey = (string) ($row['idempotency_key'] ?? '');
            $refPrefix = $idempotencyKey !== '' ? substr($idempotencyKey, 0, 16) : '';

            $lookupResult = null;

            $matchedVoucherNo = $this->matchUnknownRowInPickupIndex(
                $orderId,
                $idempotencyKey,
                $refPrefix,
                $lookupIndex
            );

            // Fallback to provider's VoucherLookupInterface if available
            if ($matchedVoucherNo === null && $provider instanceof VoucherLookupInterface && $refPrefix !== '') {
                try {
                    $lookupResult = $provider->findVoucherByReference($refPrefix);
                    if ($lookupResult !== null && trim($lookupResult->voucherNo) !== '') {
                        $matchedVoucherNo = trim($lookupResult->voucherNo);
                    }
                } catch (Throwable $e) {
                    $this->logger->warning(
                        sprintf('VoucherLookupInterface failed for voucher #%d: %s', $voucherId, $e->getMessage())
                    );
                }
            }

            if ($matchedVoucherNo !== null && $matchedVoucherNo !== '') {
                try {
                    if (
                        $this->markUnknownAsCreated(
                            $voucherId,
                            $matchedVoucherNo,
                            'Resolved via courier daily pickup list reconciliation.',
                            $lookupResult?->courier === CourierSlug::Geniki ? $lookupResult : null,
                        )
                    ) {
                        $resolvedCreated++;
                        $matchedVouchers[$voucherId] = $matchedVoucherNo;
                        continue;
                    }
                } catch (InvalidArgumentException $e) {
                    // One unresolvable row must not abort reconciliation of the remaining unknowns.
                    $this->logger->error(sprintf(
                        'Reconciliation could not link unknown voucher #%d: %s',
                        $voucherId,
                        $e->getMessage()
                    ));
                }
            }

            $remainingUnknown++;
        }

        return [
            'resolved_created' => $resolvedCreated,
            'remaining_unknown' => $remainingUnknown,
            'matched_vouchers' => $matchedVouchers,
        ];
    }

    /**
     * Admin resolution method: Manually resolve an `'unknown'` voucher by either linking its confirmed
     * `voucher_no` (`$action = 'created'`) or clearing/marking it failed (`$action = 'failed'` or `'clear'`)
     * when nothing was created at the courier (SPEC.md §6.3, §7).
     */
    public function resolveUnknownVoucherManually(
        int $voucherId,
        string $action,
        ?string $voucherNo = null,
        string $adminNote = '',
    ): bool {
        LicenseManager::assertLicensed();

        $normalizedAction = strtolower(trim($action));

        if (in_array($normalizedAction, ['created', 'link', 'confirm', 'mark_created'], true)) {
            $cleanVoucherNo = trim((string) $voucherNo);
            if ($cleanVoucherNo === '') {
                throw new InvalidArgumentException(
                    __('A valid voucher_no is required when resolving an unknown voucher as created.', 'gr-commerce-suite')
                );
            }

            return $this->markUnknownAsCreated($voucherId, $cleanVoucherNo, $adminNote);
        }

        if (in_array($normalizedAction, ['failed', 'clear', 'discard', 'mark_failed'], true)) {
            $reason = trim($adminNote) !== ''
                ? trim($adminNote)
                : 'Cleared by administrator: confirmed no voucher was created at courier.';

            return $this->clearUnknownVoucher($voucherId, $reason, false);
        }

        throw new InvalidArgumentException(
            sprintf(
                __('Unsupported unknown voucher resolution action "%s". Expected "created" or "clear"/"failed".', 'gr-commerce-suite'),
                $action
            )
        );
    }

    /**
     * Admin resolution: Link a confirmed `voucher_no` to an `'unknown'` voucher, transitioning `unknown -> created`.
     */
    public function markUnknownAsCreated(int $voucherId, string $voucherNo, string $adminNote = '', ?VoucherResult $recoveredResult = null): bool
    {
        $cleanVoucherNo = trim($voucherNo);
        if ($cleanVoucherNo === '') {
            throw new InvalidArgumentException(__('Voucher number cannot be empty.', 'gr-commerce-suite'));
        }

        $row = $this->repository->findById($voucherId);
        if ($row === null) {
            return false;
        }

        $currentState = VoucherState::tryFrom((string) ($row['state'] ?? ''));
        if ($currentState !== VoucherState::Unknown) {
            return false;
        }

        // Duplicate active voucher detection: if another created voucher exists for this order+courier
        // with a different voucher number, refuse to silently overwrite. The existing voucher is the
        // financial identity (SPEC.md §7, §10); linking a new number would corrupt COD and printing.
        $orderId = (int) ($row['order_id'] ?? 0);
        $courierSlug = (string) ($row['courier_slug'] ?? '');
        $courier = CourierSlug::tryFrom($courierSlug) ?? CourierSlug::Acs;
        if ($orderId > 0) {
            $existingCreated = null;
            foreach ($this->repository->findByOrderId($orderId) as $r) {
                if (($r['courier_slug'] ?? '') === $courier->value
                    && ($r['state'] ?? '') === VoucherState::Created->value
                    && !empty($r['voucher_no'])
                    && $r['voucher_no'] !== $cleanVoucherNo
                    && ($r['id'] ?? 0) !== $voucherId) {
                    $existingCreated = $r;
                    break;
                }
            }
            if ($existingCreated !== null) {
                $this->logger->error(sprintf(
                    'Refused to link unknown voucher #%d to %s: another active voucher #%d (%s) already exists for order #%d.',
                    $voucherId,
                    $cleanVoucherNo,
                    $existingCreated['id'] ?? 0,
                    $existingCreated['voucher_no'] ?? '?',
                    $orderId
                ));
                $this->flagSecondActiveVoucher($orderId, $voucherId, $cleanVoucherNo, $existingCreated);
                throw new InvalidArgumentException(sprintf(
                    AdminLocale::__('Another active voucher (%s) already exists for this order. Cancel it first before linking a recovered shipment.', 'gr-commerce-suite'),
                    $existingCreated['voucher_no']
                ));
            }
        }

        $data = ['voucher_no' => $cleanVoucherNo, 'last_error' => null];
        if ($recoveredResult !== null) {
            if ($recoveredResult->courier->value !== ($row['courier_slug'] ?? '')
                || $recoveredResult->voucherNo !== $cleanVoucherNo) {
                throw new InvalidArgumentException('Recovered voucher identity does not match the reservation.');
            }
            ShippingOptions::resultVoucherNumbers($recoveredResult);
            $data['raw_response'] = Redactor::toRedactedJson($recoveredResult->rawResponse);
        }

        $transitioned = $this->transition(
            $voucherId,
            VoucherState::Unknown,
            VoucherState::Created,
            $data
        );

        if (!$transitioned) {
            return false;
        }

        $orderId = (int) ($row['order_id'] ?? 0);
        $courierSlug = (string) ($row['courier_slug'] ?? 'acs');
        $courier = CourierSlug::tryFrom($courierSlug) ?? CourierSlug::Acs;

        if ($orderId > 0 && function_exists('wc_get_order')) {
            $order = wc_get_order($orderId);
            if ($order instanceof WC_Order) {
                if ($recoveredResult !== null) {
                    $order->update_meta_data('_grcs_voucher_no', $cleanVoucherNo);
                }
                $order->update_meta_data('_grcs_last_voucher_no', $cleanVoucherNo);
                $order->update_meta_data('_grcs_last_courier', $courier->value);
                $noteSuffix = trim($adminNote) !== '' ? ' (' . trim($adminNote) . ')' : '';
                $order->add_order_note(
                    sprintf(
                        AdminLocale::__('GR Commerce Suite: Resolved unknown %1$s voucher as created with number %2$s%3$s.', 'gr-commerce-suite'),
                        $courier->label(),
                        $cleanVoucherNo,
                        $noteSuffix
                    )
                );
                $order->save();
            }
        }

        if ($recoveredResult !== null && function_exists('do_action')) {
            do_action('grcs/voucher/created', $voucherId, $recoveredResult, $orderId);
        }

        $this->logger->info(
            sprintf(
                'Resolved unknown voucher #%d (order #%d) as created with voucher_no %s.',
                $voucherId,
                $orderId,
                $cleanVoucherNo
            )
        );

        return true;
    }

    /**
     * Background recovery: link a carrier voucher found for an `unknown` reservation without ever dropping it.
     *
     * If the link loses (the operator cleared the row while the carrier lookup was in flight, or another
     * number was linked first), the found number is recorded on the row and the order, and new issuance
     * for the order is refused until an operator resolves it.
     *
     * @throws InvalidArgumentException from markUnknownAsCreated() when another active voucher already exists.
     */
    public function linkFoundVoucher(int $voucherId, string $voucherNo, ?VoucherResult $recoveredResult = null): bool
    {
        if ($this->markUnknownAsCreated($voucherId, $voucherNo, '', $recoveredResult)) {
            return true;
        }
        $cleanVoucherNo = trim($voucherNo);
        for ($attempt = 0; $attempt < 3; $attempt++) {
            $row = $this->repository->findById($voucherId);
            $state = $row === null ? null : VoucherState::tryFrom((string) ($row['state'] ?? ''));
            if ($row === null || $state === null || $state === VoucherState::Unknown) {
                return false; // Nothing committed against it; the next lookup retries.
            }
            if ($state === VoucherState::Created && trim((string) ($row['voucher_no'] ?? '')) === $cleanVoucherNo) {
                return true; // Linked concurrently with the same number.
            }
            $existing = (string) ($row['last_error'] ?? '');
            $marker = self::ORPHAN_CARRIER_VOUCHER_PREFIX . ' ' . $cleanVoucherNo;
            if (str_starts_with($existing, $marker)
                || $this->repository->transition($voucherId, $state, $state, ['last_error' => $marker . ' | ' . $existing])) {
                $this->noteOrphanCarrierVoucher((int) ($row['order_id'] ?? 0), $voucherId, $cleanVoucherNo, $state);
                return false;
            }
        }
        $this->logger->error(sprintf('Carrier voucher %s found for voucher #%d could not be recorded; the row kept changing.', $cleanVoucherNo, $voucherId));

        return false;
    }

    /**
     * Refuse new issuance while a carrier voucher surfaced after a manual clear is unresolved.
     *
     * @param list<array<string, mixed>>|null $orderRows
     */
    public function assertNoOrphanCarrierVoucher(int $orderId, CourierSlug $courier, ?array $orderRows = null): void
    {
        $orphan = $this->findOrphanCarrierVoucher($orderId, $orderRows);
        if ($orphan !== null) {
            throw new CourierValidationException(sprintf(
                AdminLocale::__('Carrier voucher %s was found at the courier after a voucher request for this order was manually cleared. Check it at the courier and resolve it before issuing a new voucher.', 'gr-commerce-suite'),
                $orphan['voucher_no']
            ), $courier, 409);
        }
    }

    /**
     * @param list<array<string, mixed>>|null $orderRows
     * @return array{voucher_id: int, voucher_no: string}|null
     */
    public function findOrphanCarrierVoucher(int $orderId, ?array $orderRows = null): ?array
    {
        $rows = $orderRows ?? $this->repository->findByOrderId($orderId);
        foreach ($rows as $row) {
            $number = self::orphanNumber((string) ($row['last_error'] ?? ''));
            if ($number !== null) {
                return ['voucher_id' => (int) ($row['id'] ?? 0), 'voucher_no' => $number];
            }
        }

        return null;
    }

    /** Operator confirmed the orphan carrier voucher at the courier: lift the issuance block, keep the audit. */
    public function resolveOrphanCarrierVoucher(int $voucherId, string $reason): bool
    {
        $trimmedReason = trim($reason);
        if ($trimmedReason === '') {
            throw new InvalidArgumentException(AdminLocale::__('A non-empty reason is required to resolve an orphan carrier voucher.', 'gr-commerce-suite'));
        }
        $row = $this->repository->findById($voucherId);
        $number = $row === null ? null : self::orphanNumber((string) ($row['last_error'] ?? ''));
        $state = $row === null ? null : VoucherState::tryFrom((string) ($row['state'] ?? ''));
        if ($number === null || $state === null || !$this->repository->transition($voucherId, $state, $state, [
            'last_error' => self::ORPHAN_CARRIER_VOUCHER_RESOLVED_PREFIX . ' ' . $number . ' | ' . $trimmedReason,
        ])) {
            return false;
        }
        $orderId = (int) ($row['order_id'] ?? 0);
        $order = $orderId > 0 && function_exists('wc_get_order') ? wc_get_order($orderId) : null;
        if ($order instanceof WC_Order) {
            $order->delete_meta_data('_grcs_orphan_carrier_voucher_' . $voucherId);
            $order->add_order_note(sprintf(
                AdminLocale::__('GR Commerce Suite: operator resolved carrier voucher %1$s found after a manual clear. Reason: %2$s', 'gr-commerce-suite'),
                $number,
                $trimmedReason
            ));
            $order->save();
        }
        $this->logger->info(sprintf('Orphan carrier voucher %s on voucher #%d resolved. Reason: %s', $number, $voucherId, $trimmedReason));

        return true;
    }

    private static function orphanNumber(string $lastError): ?string
    {
        $prefix = self::ORPHAN_CARRIER_VOUCHER_PREFIX . ' ';
        if (!str_starts_with($lastError, $prefix)) {
            return null;
        }
        $number = trim(explode(' | ', substr($lastError, strlen($prefix)), 2)[0]);

        return $number === '' ? null : $number;
    }

    private function noteOrphanCarrierVoucher(int $orderId, int $voucherId, string $voucherNo, VoucherState $state): void
    {
        $this->logger->error(sprintf(
            'Carrier voucher %s was found for voucher #%d (order #%d) after it left the unknown state (%s); recorded as an orphan and new issuance is blocked.',
            $voucherNo,
            $voucherId,
            $orderId,
            $state->value
        ));
        $order = $orderId > 0 && function_exists('wc_get_order') ? wc_get_order($orderId) : null;
        if (!$order instanceof WC_Order) {
            return;
        }
        $metaKey = '_grcs_orphan_carrier_voucher_' . $voucherId;
        if ((string) $order->get_meta($metaKey, true) === $voucherNo) {
            return;
        }
        $order->update_meta_data($metaKey, $voucherNo);
        $order->add_order_note(sprintf(
            AdminLocale::__('GR Commerce Suite: carrier voucher %s was found after this voucher request was manually cleared. Check it at the courier before re-issuing; new vouchers for this order are blocked until it is resolved.', 'gr-commerce-suite'),
            $voucherNo
        ));
        $order->save();
    }

    /**
     * Admin resolution: Clear an `'unknown'` voucher by transitioning `unknown -> failed` when the merchant
     * confirms no voucher was created at the courier, allowing a fresh voucher to be issued for the order.
     *
     * Safeguards:
     * 1. Minimum age since last attempt (configurable via CLEAR_UNKNOWN_MIN_AGE_SECONDS).
     * 2. Non-empty, explicit reason required.
     * 3. Fresh carrier lookup via VoucherLookupInterface (if supported) to verify no job exists.
     * 4. For COD orders, stronger warning and explicit confirmation required.
     */
    public function clearUnknownVoucher(
        int $voucherId,
        string $reason = '',
        bool $confirmedCodWarning = false,
    ): bool {
        $row = $this->repository->findById($voucherId);
        if ($row === null) {
            return false;
        }

        $currentState = VoucherState::tryFrom((string) ($row['state'] ?? ''));
        if ($currentState !== VoucherState::Unknown) {
            return false;
        }

        // 1. Enforce minimum age since last attempt.
        $updatedAt = $row['updated_at'] ?? '';
        if (is_string($updatedAt) && $updatedAt !== '') {
            $age = time() - strtotime($updatedAt . ' UTC');
            if ($age < self::CLEAR_UNKNOWN_MIN_AGE_SECONDS) {
                throw new InvalidArgumentException(sprintf(
                    AdminLocale::__('This unknown voucher is only %d minutes old. Wait at least %d minutes after the last attempt before clearing.', 'gr-commerce-suite'),
                    max(1, $age / 60),
                    self::CLEAR_UNKNOWN_MIN_AGE_SECONDS / 60
                ));
            }
        }

        // 2. Non-empty, explicit reason.
        $trimmedReason = trim($reason);
        if ($trimmedReason === '') {
            throw new InvalidArgumentException(AdminLocale::__('A non-empty reason is required when clearing an unknown voucher.', 'gr-commerce-suite'));
        }

        // 3. Fresh carrier lookup if the provider supports it.
        $courierSlug = (string) ($row['courier_slug'] ?? '');
        $courier = CourierSlug::tryFrom($courierSlug) ?? CourierSlug::Acs;
        $provider = $this->courierRegistry !== null && $this->courierRegistry->has($courier)
            ? $this->courierRegistry->get($courier) : null;
        $idempotencyKey = (string) ($row['idempotency_key'] ?? '');
        $refPrefix = $idempotencyKey !== '' ? substr($idempotencyKey, 0, 16) : '';
        $isCod = (float) ($row['cod_amount'] ?? 0) > 0;

        if ($provider instanceof VoucherLookupInterface && $refPrefix !== '') {
            // Only the carrier call itself is wrapped: a "voucher found" verdict must reach the merchant.
            try {
                $lookup = $provider->findVoucherByReference($refPrefix);
            } catch (Throwable $e) {
                // Lookup failure: cannot prove absence; refuse to clear.
                $this->logger->warning(sprintf(
                    'Carrier lookup failed during clearUnknownVoucher for voucher #%d: %s',
                    $voucherId,
                    $e->getMessage()
                ));
                throw new InvalidArgumentException(AdminLocale::__('Carrier lookup failed; cannot verify whether a voucher exists at the courier. Aborting clear action for safety.', 'gr-commerce-suite'));
            }
            if ($lookup !== null && trim($lookup->voucherNo) !== '') {
                $this->logger->warning(sprintf(
                    'Attempted to clear unknown voucher #%d but carrier lookup found voucher %s.',
                    $voucherId,
                    $lookup->voucherNo
                ));
                throw new InvalidArgumentException(sprintf(
                    AdminLocale::__('Carrier lookup found active voucher %1$s for this reservation. Do not clear it: use the link/recover action to mark this unknown voucher as created with that number instead.', 'gr-commerce-suite'),
                    $lookup->voucherNo
                ));
            }
        } elseif ($provider === null || !$provider instanceof VoucherLookupInterface) {
            $this->logger->info(sprintf(
                'Carrier %s does not support VoucherLookupInterface; skipping fresh lookup during clear.',
                $courier->label()
            ));
        }

        // 4. COD orders require explicit confirmation of the financial risk.
        if ($isCod && !$confirmedCodWarning) {
            throw new InvalidArgumentException(AdminLocale::__('This voucher has a COD amount. Clearing it may create a duplicate COD voucher if the original job surfaces later. Confirm you understand the risk.', 'gr-commerce-suite'));
        }

        $transitioned = $this->transition(
            $voucherId,
            VoucherState::Unknown,
            VoucherState::Failed,
            [
                'last_error' => $trimmedReason,
            ]
        );

        if (!$transitioned) {
            return false;
        }

        $orderId = (int) ($row['order_id'] ?? 0);
        if ($orderId > 0 && function_exists('wc_get_order')) {
            $order = wc_get_order($orderId);
            if ($order instanceof WC_Order) {
                $order->delete_meta_data('_grcs_active_idempotency_key');
                $order->add_order_note(
                    sprintf(
                        AdminLocale::__('GR Commerce Suite: Cleared unknown voucher #%1$d (%2$s). A new voucher can now be issued.', 'gr-commerce-suite'),
                        $voucherId,
                        $trimmedReason
                    )
                );
                $order->save();
            }
        }

        $this->logger->info(
            sprintf('Cleared unknown voucher #%d (order #%d) to failed state. Reason: %s', $voucherId, $orderId, $trimmedReason)
        );

        return true;
    }

    /**
     * Sweep stale `reserved` rows using per-order locking and transmission evidence.
     *
     * - Only rows with a recorded dispatch attempt become `unknown`; rows that never transmitted
     *   become `failed` (allowing a fresh issuance with a new idempotency key).
     * - Rows locked by an in-flight operation are skipped.
     * - The staleness threshold defaults to {@see STALE_RESERVATION_SECONDS} (30 min), safely above
     *   the maximum exponential backoff chain plus request timeout.
     */
    public function sweepStaleReservations(int $olderThanSeconds = self::STALE_RESERVATION_SECONDS): int
    {
        LicenseManager::assertLicensed();

        $cutoff = gmdate('Y-m-d H:i:s', time() - max(60, $olderThanSeconds));
        $rows = $this->repository->findStaleReserved($cutoff, 100);

        $swept = 0;
        foreach ($rows as $row) {
            $voucherId = (int) $row['id'];
            $orderId = (int) $row['order_id'];

            // Skip if another process is actively working on this voucher.
            try {
                $token = VoucherOperationLock::acquire($orderId);
            } catch (RuntimeException) {
                continue;
            }

            try {
                // Re-validate under the lock: state may have changed.
                $row2 = $this->repository->findById($voucherId);
                if ($row2 === null || ($row2['state'] ?? '') !== VoucherState::Reserved->value) {
                    continue;
                }
                // Re-check staleness against the row's own updated_at (may have been refreshed by a retry).
                if (strtotime((string) ($row2['updated_at'] ?? '')) > time() - max(60, $olderThanSeconds)) {
                    continue;
                }

                // Was a dispatch actually attempted? We infer from the order meta marker.
                $transmitted = $this->wasDispatchAttempted($orderId, $voucherId);

                $target = $transmitted ? VoucherState::Unknown : VoucherState::Failed;
                $error = $transmitted
                    ? 'Reservation timed out before courier response was recorded.'
                    : 'No dispatch was recorded before the reservation became stale; safe to re-issue.';

                $ok = $this->transition(
                    $voucherId,
                    VoucherState::Reserved,
                    $target,
                    ['last_error' => $error]
                );

                if ($ok) {
                    $swept++;
                    $this->logger->info(sprintf(
                        'Swept stale reserved voucher #%d (order #%d) to %s.',
                        $voucherId,
                        $orderId,
                        $target->value
                    ));
                }
            } finally {
                VoucherOperationLock::release($orderId, $token);
            }
        }

        return $swept;
    }

    /** @return string Meta key name for the dispatch-intent marker on the order. */
    private static function dispatchMarkerKey(int $voucherId): string
    {
        return '_grcs_voucher_dispatch_' . max(0, $voucherId);
    }

    /**
     * Remove the dispatch-intent marker after a proven pre-transmission failure or a failed row.
     *
     * Kept only while the carrier mutation may have reached Geniki (ambiguous/transmitted paths), so the
     * sweeper can send a genuinely ambiguous reservation to `unknown` instead of the safe `failed` path.
     */
    private function clearDispatchMarker(WC_Order $order, int $voucherId): void
    {
        $order->delete_meta_data(self::dispatchMarkerKey($voucherId));
        $order->save();
    }

    /** Check whether a dispatch was attempted for a given voucher row. */
    private function wasDispatchAttempted(int $orderId, int $voucherId): bool
    {
        if (!function_exists('wc_get_order')) {
            return false;
        }
        $order = wc_get_order($orderId);
        if (!$order instanceof WC_Order) {
            return false;
        }
        $value = $order->get_meta(self::dispatchMarkerKey($voucherId), true);
        return is_string($value) && trim($value) !== '';
    }

    /**
     * @param array<string, mixed> $rawContext
     */
    private function recordUnknownAfterAmbiguousCall(
        int $voucherId,
        CourierSlug $courier,
        string $errorMessage,
        array $rawContext,
        ?CourierProviderInterface $provider = null,
    ): void {
        $this->transition(
            $voucherId,
            VoucherState::Reserved,
            VoucherState::Unknown,
            [
                'last_error' => $errorMessage,
                'raw_response' => Redactor::toRedactedJson($rawContext),
            ]
        );

        $resolvedProvider = $provider;
        if ($resolvedProvider === null && $this->courierRegistry !== null && $this->courierRegistry->has($courier)) {
            $resolvedProvider = $this->courierRegistry->get($courier);
        }

        if ($resolvedProvider instanceof VoucherLookupInterface && $this->jobDispatcher !== null) {
            $this->jobDispatcher->scheduleSingle(
                time() + 60,
                JobDispatcher::HOOK_LOOKUP_UNKNOWN,
                ['voucher_id' => $voucherId],
                true
            );
        }
    }

    private function resolveProvider(CourierSlug $courier): CourierProviderInterface
    {
        if ($this->courierRegistry === null) {
            throw new RuntimeException(__('CourierRegistry is not configured on VoucherLockService.', 'gr-commerce-suite'));
        }

        return $this->courierRegistry->get($courier);
    }

    private function resolveExpectedCodCents(WC_Order $order): int
    {
        $customCod = $order->get_meta('_grcs_custom_cod_amount', true);
        if (is_string($customCod) && trim($customCod) !== '') {
            try {
                return max(0, Money::fromDecimalString($customCod)->cents());
            } catch (Throwable) {
                // Fall through to standard order payment method check
            }
        }

        if (strtolower((string) $order->get_payment_method()) === 'cod') {
            return max(0, Money::fromDecimalString((string) $order->get_total())->cents());
        }

        return 0;
    }

    private function isPostTransmissionDropOrTimeout(string $message): bool
    {
        $lower = strtolower($message);

        return str_contains($lower, 'timed out')
            || str_contains($lower, 'timeout')
            || str_contains($lower, 'curl error 28')
            || str_contains($lower, 'connection reset')
            || str_contains($lower, 'dropped connection')
            || str_contains($lower, 'empty reply from server')
            || str_contains($lower, 'operation timed out');
    }

    /**
     * Decide whether a failed transport may have reached the courier.
     *
     * The typed flag from the HTTP client wins whenever it exists. Message matching is a fallback only for
     * errors that carried no classification, so a pre-connection connect timeout can never become `unknown`.
     */
    private function isTransmittedFailure(Throwable $error): bool
    {
        if ($error instanceof CourierTransportException && $error->failedBeforeTransmission() !== null) {
            return $error->failedBeforeTransmission() === false;
        }

        return $this->isPostTransmissionDropOrTimeout($error->getMessage());
    }

    /**
     * A lookup/reconciliation was about to create a second active voucher for one order+courier.
     *
     * Detection only: never sums, overwrites or auto-cancels COD. The note is written once per recovered
     * voucher so repeated jobs do not spam the order.
     *
     * @param array<string, mixed> $existingCreated
     */
    private function flagSecondActiveVoucher(int $orderId, int $voucherId, string $recoveredNo, array $existingCreated): void
    {
        if ($orderId <= 0 || !function_exists('wc_get_order')) {
            return;
        }
        $order = wc_get_order($orderId);
        if (!$order instanceof WC_Order) {
            return;
        }
        $noteKey = '_grcs_duplicate_active_voucher_' . max(0, $voucherId);
        if ($order->get_meta($noteKey, true)) {
            return;
        }
        $order->add_order_note(sprintf(
            AdminLocale::__('GR Commerce Suite: a second active %1$s voucher was found for this order (existing %2$s, recovered %3$s). Two COD jobs may now exist. Do not add the COD amounts together or cancel either job automatically; review both at the courier.', 'gr-commerce-suite'),
            CourierSlug::tryFrom((string) ($existingCreated['courier_slug'] ?? ''))?->label() ?? (string) ($existingCreated['courier_slug'] ?? ''),
            (string) ($existingCreated['voucher_no'] ?? '?'),
            $recoveredNo
        ));
        $order->update_meta_data($noteKey, 'yes');
        $order->save();
    }

    private function buildMutexName(int $orderId, CourierSlug $courier): string
    {
        return sprintf('voucher_order_%d_%s', $orderId, $courier->value);
    }

    /**
     * Normalize pickup list entries into a lookup dictionary keyed by order ID, reference key, or idempotency key.
     *
     * @param array<int|string, mixed> $pickupListVouchers
     * @return array<string, string>
     */
    private function buildPickupListIndex(array $pickupListVouchers): array
    {
        $index = [];

        foreach ($pickupListVouchers as $key => $entry) {
            if (is_string($entry) && trim($entry) !== '') {
                $index[(string) $key] = trim($entry);
                continue;
            }

            if (!is_array($entry)) {
                continue;
            }

            $voucherNo = trim((string) (
                $entry['voucher_no']
                ?? $entry['Voucher_No']
                ?? $entry['parcel_id']
                ?? $entry['parcelId']
                ?? $entry['awb']
                ?? ''
            ));

            if ($voucherNo === '') {
                continue;
            }

            $candidateKeys = [
                $entry['order_id'] ?? null,
                $entry['order_number'] ?? null,
                $entry['Relevant_Code'] ?? null,
                $entry['reference'] ?? null,
                $entry['Reference_Key1'] ?? null,
                $entry['idempotency_key'] ?? null,
            ];

            foreach ($candidateKeys as $candidate) {
                if ($candidate !== null && trim((string) $candidate) !== '') {
                    $index[trim((string) $candidate)] = $voucherNo;
                }
            }
        }

        return $index;
    }

    /**
     * @param array<string, string> $lookupIndex
     */
    private function matchUnknownRowInPickupIndex(
        int $orderId,
        string $idempotencyKey,
        string $refPrefix,
        array $lookupIndex,
    ): ?string {
        $candidates = array_filter([
            $orderId > 0 ? (string) $orderId : '',
            $idempotencyKey,
            $refPrefix,
            $refPrefix !== '' ? 'REF:' . $refPrefix : '',
        ]);

        foreach ($candidates as $candidate) {
            if (isset($lookupIndex[$candidate]) && $lookupIndex[$candidate] !== '') {
                return $lookupIndex[$candidate];
            }
        }

        return null;
    }
}
