<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use DOMDocument;
use DOMXPath;
use GRCommerceSuite\Frontend\GreekInvoiceCheckout;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Http\HttpRequest;
use GRCommerceSuite\Security\CredentialVault;
use Throwable;

/** Optional registry autofill; failure must never prevent manual invoice entry. */
final class AadeRegistryLookup
{
    public const ENDPOINT = 'https://www1.gsis.gr/wsaade/RgWsPublic2/RgWsPublic2';

    public function __construct(private readonly HttpClientInterface $http, private readonly CredentialVault $vault)
    {
    }

    public function isSimulation(): bool
    {
        return get_option('grcs_sandbox_mode', 'no') === 'yes';
    }

    /** @return array<string, string>|null */
    public function lookup(string $vat): ?array
    {
        if (!GreekInvoiceCheckout::validVat($vat)) {
            return null;
        }
        if ($this->isSimulation()) {
            (new DiagnosticLogger())->record('INFO', 'INVOICE', 'Simulated AADE registry lookup.',
                ['action' => 'aade_lookup_simulation', 'vat_number' => $vat]);
            return ['company' => 'ΕΛΛΗΝΙΚΗ ΕΜΠΟΡΙΚΗ Α.Ε.', 'company_name' => 'ΕΛΛΗΝΙΚΗ ΕΜΠΟΡΙΚΗ Α.Ε.',
                'doy' => "Δ' ΑΘΗΝΩΝ", 'profession' => 'ΧΟΝΔΡΙΚΟ ΚΑΙ ΛΙΑΝΙΚΟ ΕΜΠΟΡΙΟ',
                'address' => 'Σταδίου 24', 'postcode' => '10564', 'city' => 'Αθήνα'];
        }
        ['username' => $username, 'password' => $password] = $this->vault->getAade();
        if (trim($username) === '' || $password === '') {
            return null;
        }
        $storeAfm = trim((string) get_option(GreekInvoiceCheckout::OPTION_STORE_AFM, ''));
        if (!GreekInvoiceCheckout::validVat($storeAfm)) {
            (new DiagnosticLogger())->validationFailure('INVOICE', 'aade_store_afm', ['vat_number' => $storeAfm], null, false);
            return null;
        }
        $escape = static fn(string $s): string => htmlspecialchars($s, ENT_XML1 | ENT_QUOTES, 'UTF-8');
        $xml = '<?xml version="1.0" encoding="UTF-8"?>'
            . '<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope"'
            . ' xmlns:w="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"'
            . ' xmlns:r="http://rgwspublic2/RgWsPublic2Service" xmlns:d="http://rgwspublic2/RgWsPublic2">'
            . '<s:Header><w:Security><w:UsernameToken><w:Username>' . $escape($username)
            . '</w:Username><w:Password>' . $escape($password) . '</w:Password></w:UsernameToken></w:Security></s:Header>'
            . '<s:Body><r:rgWsPublic2AfmMethod><r:INPUT_REC><d:afm_called_by>' . $escape($storeAfm) . '</d:afm_called_by>'
            . '<d:afm_called_for>' . $escape($vat) . '</d:afm_called_for></r:INPUT_REC></r:rgWsPublic2AfmMethod></s:Body></s:Envelope>';
        try {
            $response = (new DiagnosticLogger())->send($this->http, new HttpRequest(
                'POST',
                self::ENDPOINT,
                ['Content-Type' => 'application/soap+xml; charset=utf-8'],
                $xml,
                8
            ), 'INVOICE', 'aade_lookup');
            $parsed = $response->isSuccess() ? self::parseResponse($response->body, $vat) : null;
            if ($response->isSuccess() && $parsed === null) {
                (new DiagnosticLogger())->record('ERROR', 'INVOICE', 'Registry response could not be validated.',
                    ['action' => 'aade_lookup', 'response_code' => $response->statusCode]);
            }
            return $parsed;
        } catch (Throwable) {
            return null; // Do not surface authentication errors or registry PII in logs or checkout notices.
        }
    }

    /** @return array<string, string>|null */
    public static function parseResponse(string $xml, string $vat): ?array
    {
        if (strlen($xml) > 1048576 || stripos($xml, '<!DOCTYPE') !== false || stripos($xml, '<!ENTITY') !== false) {
            return null;
        }
        $previous = libxml_use_internal_errors(true);
        try {
            $document = new DOMDocument();
            if (!$document->loadXML($xml, LIBXML_NONET | LIBXML_NOBLANKS)) {
                return null;
            }
            $xpath = new DOMXPath($document);
            $text = static fn(string $name): string => sanitize_text_field(trim((string) $xpath->evaluate('string(//*[local-name()="' . $name . '"][1])')));
            if ($xpath->evaluate('boolean(//*[local-name()="Fault"])')
                || !in_array($text('error_code') ?: $text('errorCode'), ['', '0'], true)
                || $text('afm') !== $vat || $text('onomasia') === '') {
                return null;
            }
            return ['company' => $text('onomasia'), 'company_name' => $text('onomasia'),
                'doy' => $text('doyDescr') ?: $text('doy_descr'),
                'profession' => $text('actLongDescr') ?: ($text('act_main_descr') ?: $text('firm_act_descr')),
                'address' => $text('postalAddress') ?: trim($text('postal_address') . ' ' . $text('postal_address_no')),
                'postcode' => $text('postalZipCode') ?: $text('postal_zip_code'),
                'city' => $text('postalAreaDescription') ?: $text('postal_area_description')];
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
    }
}
