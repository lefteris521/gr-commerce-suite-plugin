<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Couriers\AcsProvider;
use GRCommerceSuite\Couriers\BoxNowProvider;
use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Security\CredentialVault;
use Throwable;

/** Read-only, bounded support probes. Never activates licenses or creates courier shipments. */
final class SystemDiagnostics
{
    public static function checkoutMode(): string
    {
        $id = function_exists('wc_get_page_id') ? wc_get_page_id('checkout') : -1;
        $page = $id > 0 ? get_post($id) : null;
        if (!$page instanceof \WP_Post) {
            return 'Unavailable';
        }
        // Blocks take precedence when a page accidentally contains both renderers.
        if (str_contains($page->post_content, '<!-- wp:woocommerce/checkout')) {
            return 'Block Checkout';
        }
        // WooCommerce's editor "switch to classic" saves a classic-shortcode block, not the literal shortcode.
        $classicBlock = preg_match('#<!--\s+wp:woocommerce/classic-shortcode\s+\{[^}]*"shortcode"\s*:\s*"checkout"#', $page->post_content) === 1;
        return $classicBlock || has_shortcode($page->post_content, 'woocommerce_checkout')
            ? 'Classic Checkout ([woocommerce_checkout])' : 'Unrecognized checkout content';
    }

    /** @return array<string, string> */
    public function environment(): array
    {
        $curl = function_exists('curl_version') ? curl_version() : [];
        $phpSecurity = self::phpSecurityStatus(PHP_VERSION);
        $environment = [
            'WordPress' => (string) ($GLOBALS['wp_version'] ?? 'Unavailable'),
            'WooCommerce' => defined('WC_VERSION') ? WC_VERSION : 'Unavailable',
            'PHP' => PHP_VERSION,
            'PHP security status' => $phpSecurity['status'],
            'PHP security details' => $phpSecurity['details'],
            'Web Server' => DiagnosticSanitizer::value((string) ($_SERVER['SERVER_SOFTWARE'] ?? 'Unavailable')),
            'memory_limit' => (string) ini_get('memory_limit'),
            'max_execution_time' => (string) ini_get('max_execution_time'),
            'OpenSSL' => defined('OPENSSL_VERSION_TEXT') ? OPENSSL_VERSION_TEXT : 'Unavailable',
            'cURL' => (string) ($curl['version'] ?? 'Unavailable'),
        ];
        if ($phpSecurity['warning'] !== '') {
            $environment['PHP security warning'] = $phpSecurity['warning'];
        }
        return $environment;
    }

    /** @return array{status: string, details: string, warning: string} */
    public static function phpSecurityStatus(string $version): array
    {
        // PHP2Shell advisory of 21 October 2026: https://www.php.net/archive/2026.php
        $thresholds = ['8.2' => '8.2.35', '8.3' => '8.3.36', '8.4' => '8.4.27', '8.5' => '8.5.12'];
        $unknown = ['status' => 'Unknown',
            'details' => 'The PHP branch or patch status cannot be determined reliably from the reported version. Contact your hosting provider to confirm security patches.',
            'warning' => ''];

        // Accept stable upstream versions and numeric vendor package revisions only.
        // Custom builds and prereleases cannot reliably establish patch status.
        if (preg_match('/\A((?:0|[1-9][0-9]*)\.(?:0|[1-9][0-9]*))\.(0|[1-9][0-9]*)(?:[-+][0-9][0-9A-Za-z.+~_-]*|\+deb[0-9]+u[0-9]+)?\z/', $version, $matches) !== 1
            || preg_match('/dev|alpha|beta|rc|snapshot/i', $version) === 1
            || !isset($thresholds[$matches[1]])) {
            return $unknown;
        }

        $threshold = $thresholds[$matches[1]];
        // Compare the upstream version, not a hosting provider's package revision.
        if (version_compare($matches[1] . '.' . $matches[2], $threshold, '>=')) {
            return ['status' => 'Patched',
                'details' => 'The reported PHP version meets the official PHP2Shell security patch threshold (' . $threshold . ').',
                'warning' => ''];
        }

        return ['status' => 'Update recommended',
            'details' => 'The reported PHP version is below the official PHP2Shell security patch threshold (' . $threshold . ') and may be vulnerable. Hosting providers may backport security fixes without changing the reported PHP version.',
            'warning' => 'Your hosting environment may be affected by known PHP security vulnerabilities (CVE-2026-109618 and CVE-2026-109619). Contact your hosting provider to confirm the security patches are installed.'];
    }

    /** @return array<string, string> */
    public function extensions(): array
    {
        $extensions = [];
        foreach (['curl', 'json', 'mbstring', 'simplexml', 'openssl'] as $extension) {
            $extensions[$extension] = extension_loaded($extension) ? 'Available' : 'Missing';
        }
        $extensions['sodium'] = CredentialVault::encryptionAvailable()
            ? (extension_loaded('sodium') ? 'Available (native)' : 'Available (sodium_compat)')
            : 'Missing';
        $extensions['gd / imagick'] = extension_loaded('gd') || extension_loaded('imagick') ? 'Available' : 'Missing';
        return $extensions;
    }

    /** @return array<string, mixed> */
    public function shipping(): array
    {
        $result = [
            'Plugin file' => defined('GRCS_PLUGIN_FILE') ? GRCS_PLUGIN_FILE : 'Unavailable',
            'Sandbox' => (new LicenseManager())->isSandboxEnabled(),
            'Sandbox constant override' => defined('GRCS_SANDBOX_MODE'),
            'Hide other rates when free shipping is available' => get_option('woocommerce_shipping_hide_rates_when_free', 'no'),
            'Zone instances' => [],
        ];
        if (!class_exists(\WC_Shipping_Zones::class)) {
            $result['Inspection'] = 'WooCommerce shipping runtime unavailable';
            return $result;
        }
        try {
            $registered = WC()->shipping()->get_shipping_methods();
            $result['Native methods registered'] = [
                'grcs_acs' => isset($registered['grcs_acs']), 'grcs_boxnow' => isset($registered['grcs_boxnow']),
            ];
            $zones = \WC_Shipping_Zones::get_zones();
            $zones[] = ['zone_id' => 0];
            foreach ($zones as $zone) {
                $instance = new \WC_Shipping_Zone((int) $zone['zone_id']);
                foreach ($instance->get_shipping_methods(false) as $method) {
                    if (!in_array($method->id, ['grcs_acs', 'grcs_boxnow', 'free_shipping'], true)) {
                        continue;
                    }
                    $result['Zone instances'][] = [
                        'zone' => $instance->get_id(), 'zone_name' => $instance->get_zone_name(),
                        'method' => $method->id, 'instance' => $method->instance_id,
                        'zone_enabled' => $method->is_enabled(), 'instance_enabled' => $method->get_option('enabled', 'yes'),
                        'pricing_mode' => $method->get_option('pricing_mode', 'fixed'),
                        'cost' => $method->get_option('cost', ''),
                    ];
                }
            }
        } catch (Throwable) {
            $result['Inspection'] = 'Partially unavailable';
        }
        return $result;
    }

    /** @return array<string, mixed> */
    private function commerce(): array
    {
        $result = ['HPOS' => class_exists(\Automattic\WooCommerce\Utilities\OrderUtil::class)
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ? 'Enabled' : 'Disabled',
            'Pending orders sync count' => 'Unavailable', 'Active theme' => 'Unavailable', 'Checkout template overrides' => []];
        $result['Checkout Mode'] = self::checkoutMode();
        try {
            $synchronizer = \Automattic\WooCommerce\Internal\DataStores\Orders\DataSynchronizer::class;
            if (function_exists('wc_get_container') && class_exists($synchronizer)) {
                $service = wc_get_container()->get($synchronizer);
                if (is_object($service) && method_exists($service, 'get_current_orders_pending_sync_count')) {
                    $result['Pending orders sync count'] = $service->get_current_orders_pending_sync_count();
                }
            }
            if (function_exists('wp_get_theme')) {
                $theme = wp_get_theme();
                $result['Active theme'] = DiagnosticSanitizer::value($theme->get('Name') . ' ' . $theme->get('Version'));
            }
            $roots = [];
            foreach (['get_stylesheet_directory', 'get_template_directory'] as $function) {
                if (function_exists($function)) {
                    $roots[] = $function() . '/woocommerce/checkout';
                }
            }
            $overrides = [];
            foreach (array_unique($roots) as $root) {
                if (!is_dir($root)) {
                    continue;
                }
                $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS));
                foreach ($files as $file) {
                    if ($file instanceof \SplFileInfo && $file->isFile() && !$file->isLink() && $file->getExtension() === 'php') {
                        $overrides[] = 'checkout/' . DiagnosticLogger::maskText(str_replace('\\', '/', substr($file->getPathname(), strlen($root) + 1)));
                    }
                    if (count($overrides) >= 100) {
                        break 2;
                    }
                }
            }
            $result['Checkout template overrides'] = array_values(array_unique($overrides));
        } catch (Throwable) {
            $result['Inspection'] = 'Partially unavailable';
        }
        return $result;
    }

    /** @return array<string, string> */
    private function conflicts(): array
    {
        $active = get_option('active_plugins', []);
        $network = function_exists('get_site_option') ? get_site_option('active_sitewide_plugins', []) : [];
        $plugins = array_merge(is_array($active) ? $active : [], is_array($network) ? array_keys($network) : []);
        $found = [];
        foreach ($plugins as $plugin) {
            if (!is_string($plugin)) {
                continue;
            }
            foreach (
                ['wpslash|acs.*courier|courier.*acs|box.?now' => 'Courier extension',
                'checkout.*field|field.*checkout|checkout-manager' => 'Checkout field editor',
                'wp-rocket|litespeed|w3-total-cache|wp-super-cache|cache-enabler|breeze' => 'Caching layer'] as $pattern => $category
            ) {
                if (preg_match('~' . $pattern . '~i', $plugin)) {
                    $found[$category . ' ' . (count($found) + 1)] = $category . ' (review configuration; not proof of a conflict)';
                }
            }
        }
        return $found;
    }

    /** @return array<string, mixed> */
    private function handshakes(): array
    {
        $configured = ['ACS' => false, 'BOXNOW' => false, 'Lemon Squeezy' => (new LicenseManager())->getLicenseKey() !== '', 'AADE GSIS' => false];
        try {
            $vault = new CredentialVault();
            foreach (['ACS' => CourierSlug::Acs, 'BOXNOW' => CourierSlug::BoxNow] as $name => $courier) {
                $credentials = $vault->getForCourier($courier);
                $fields = $name === 'ACS' ? ['api_key', 'company_id', 'company_password', 'user_id', 'user_password'] : ['client_id', 'client_secret'];
                $configured[$name] = true;
                foreach ($fields as $field) {
                    $configured[$name] = $configured[$name] && trim($credentials[$field] ?? '') !== '';
                }
            }
            $aade = $vault->getAade();
            $configured['AADE GSIS'] = $aade['username'] !== '' && $aade['password'] !== '';
        } catch (Throwable) {
            // Invalid/unreadable encrypted credentials count as unconfigured.
        }
        $sandbox = (new LicenseManager())->isSandboxEnabled();
        $endpoints = ['ACS' => AcsProvider::ENDPOINT_URL,
            'BOXNOW' => ($sandbox ? BoxNowProvider::STAGING_BASE_URL : BoxNowProvider::PRODUCTION_BASE_URL) . BoxNowProvider::PATH_AUTH_SESSIONS,
            'Lemon Squeezy' => LicenseManager::VALIDATION_ENDPOINT, 'AADE GSIS' => AadeRegistryLookup::ENDPOINT];
        $results = [];
        foreach ($endpoints as $service => $url) {
            if (!$configured[$service]) {
                $results[$service] = ['status' => 'Not Configured'];
                continue;
            }
            $cacheKey = 'grcs_diagnostic_ping_' . md5($url);
            $cached = function_exists('get_transient') ? get_transient($cacheKey) : false;
            if (is_array($cached)) {
                $results[$service] = $cached;
                continue;
            }
            if (!function_exists('wp_remote_head')) {
                $results[$service] = ['status' => 'HTTP client unavailable'];
                continue;
            }
            $start = hrtime(true);
            try {
                // HEAD is a live TLS/HTTP reachability probe: 401/405 also prove reachability.
                // No credentials or customer data leave the store during this support check.
                $response = wp_remote_head($url, ['timeout' => 3, 'redirection' => 0, 'sslverify' => true]);
                $result = ['http_status' => is_wp_error($response) ? null : (int) wp_remote_retrieve_response_code($response),
                    'error_code' => is_wp_error($response) ? DiagnosticLogger::maskText((string) $response->get_error_code()) : null,
                    'latency_ms' => round((hrtime(true) - $start) / 1e6, 3),
                    'checked_at' => gmdate('Y-m-d\TH:i:s\Z'), 'probe' => 'HEAD reachability; authentication not tested'];
            } catch (Throwable) {
                $result = ['status' => 'Transport error', 'latency_ms' => round((hrtime(true) - $start) / 1e6, 3)];
            }
            $results[$service] = $result;
            if (function_exists('set_transient')) {
                set_transient($cacheKey, $result, 300);
            }
        }
        return $results;
    }

    /** @param list<array<string, mixed>> $events
     * @return array<string, mixed>
     */
    public function report(array $events): array
    {
        try {
            $database = Schema::fromGlobals()->diagnosticIntegrity();
        } catch (Throwable) {
            $database = ['status' => 'Database inspection unavailable'];
        }
        return ['Environment' => $this->environment(), 'Required Extensions' => $this->extensions(),
            'WooCommerce & HPOS' => $this->commerce(), 'Checkout Shipping' => $this->shipping(), 'Plugin Conflicts' => $this->conflicts(),
            'Live Handshake Ping' => $this->handshakes(), 'Database Integrity' => $database,
            'Recent Error Logs' => array_slice(array_values(array_filter($events, static fn(array $event): bool => in_array($event['level'] ?? '', ['ERROR', 'CRITICAL'], true))), -25)];
    }
}
