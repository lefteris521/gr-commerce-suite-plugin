<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\I18n\AdminLocale;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Support\Lock;
use RuntimeException;

/**
 * Commercial License Key validation and admin notice service.
 */
final class LicenseManager implements HookSubscriberInterface
{
    public const OPTION_LICENSE_KEY = 'grcs_license_key';
    public const OPTION_LICENSE_STATUS = 'grcs_license_status';
    public const OPTION_SANDBOX_MODE = 'grcs_sandbox_mode';
    public const OPTION_INSTANCE = 'grcs_license_instance';
    // Do not reuse approvals cached by the older, permissive validation rules.
    public const TRANSIENT_PREFIX = 'grcs_license_valid_v3_';
    public const VALIDATION_ENDPOINT = 'https://api.lemonsqueezy.com/v1/licenses/validate';
    public const ACTIVATION_ENDPOINT = 'https://api.lemonsqueezy.com/v1/licenses/activate';
    public const DEV_TEST_KEY = 'GRCS-DEV-LOCAL-2026';
    public const CACHE_TTL = 43200; // 12 hours in seconds
    public const RETRY_TTL = 300;
    public const OUTAGE_GRACE = 259200; // Three days since the last successful instance validation.
    public const EXPIRY_WARNING = 1209600; // Fourteen days.
    // Merchant-facing states reported by merchantStatus().
    public const STATE_MISSING = 'missing';
    public const STATE_ACTIVE = 'active';
    public const STATE_EXPIRING = 'expiring';
    public const STATE_UNVERIFIED = 'unverified';
    public const STATE_EXPIRED = 'expired';
    public const STATE_INVALID = 'invalid';
    public const STATE_UNREACHABLE = 'unreachable';

    /** @var array<int, bool> */
    private static array $activeCache = [];

    /** @var array<string, bool> */
    private static array $validationCache = [];

    public static function resetRequestCache(): void
    {
        self::$activeCache = [];
        self::$validationCache = [];
    }

    public function register(): void
    {
        if (!function_exists('add_action')) {
            return;
        }

        add_action('admin_init', [$this, 'handleAdminInit']);
        add_action('admin_notices', [$this, 'renderAdminNotice']);
        add_action('update_option_' . self::OPTION_LICENSE_KEY, [$this, 'handleLicenseKeyUpdated'], 10, 2);
        add_action('add_option_' . self::OPTION_LICENSE_KEY, [$this, 'handleLicenseKeyAdded'], 10, 2);
        add_action('update_option_home', [$this, 'handleHomeUpdated']);
    }

    public function handleHomeUpdated(): void
    {
        $this->clearValidationCache();
    }

    public static function isLicensed(): bool
    {
        $site = function_exists('get_current_blog_id') ? get_current_blog_id() : 0;
        if (!array_key_exists($site, self::$activeCache)) {
            $manager = new self();
            self::$activeCache[$site] = $manager->validateLicense($manager->getLicenseKey());
        }
        return self::$activeCache[$site];
    }

    public static function assertLicensed(): void
    {
        if (!self::isLicensed()) {
            throw new RuntimeException(__('License Required: Enter a valid License Key to enable GR Commerce Suite ' .
                'features.', 'gr-commerce-suite'));
        }
    }

    public function handleLicenseKeyUpdated(mixed $oldValue, mixed $newValue): void
    {
        $this->clearValidationCache(is_string($oldValue) ? $oldValue : '');
        $this->refreshLicenseKey($newValue);
    }

    public function handleLicenseKeyAdded(string $option, mixed $value): void
    {
        $this->refreshLicenseKey($value);
    }

    private function refreshLicenseKey(mixed $value): void
    {
        $key = is_string($value) ? trim($value) : '';
        $this->clearValidationCache($key);
        $this->validateLicense($key);
    }

    /**
     * Early admin hook (`admin_init`) that validates the configured license key.
     */
    public function handleAdminInit(): void
    {
        $key = $this->getLicenseKey();
        if ($key !== '') {
            $this->validateLicense($key);
        }
    }

    /**
     * Render a dismissible WordPress admin notice when the license key is empty or invalid.
     */
    public function renderAdminNotice(): void
    {
        $status = $this->merchantStatus();
        // Active licenses need no notice; the GRCS settings screen already shows the same status in its banner.
        if (in_array($status['state'], [self::STATE_ACTIVE, self::STATE_UNVERIFIED], true)
            || (function_exists('current_user_can') && !current_user_can('manage_woocommerce'))
            || (($_GET['page'] ?? '') === 'wc-settings' && ($_GET['tab'] ?? '') === 'gr_commerce_suite')
            // The tools page replaces its content with the same explanation while unlicensed (diagnostics stays open).
            || (!$status['licensed'] && ($_GET['page'] ?? '') === 'grcs-cod-reconciliation' && ($_GET['tab'] ?? '') !== 'diagnostics')) {
            return;
        }

        $url = function_exists('admin_url') ? admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite&section=license') : '';
        echo '<div class="notice ' . ($status['state'] === self::STATE_EXPIRING ? 'notice-info' : 'notice-warning')
            . ' is-dismissible grcs-license-notice" data-grcs-license-state="' . esc_attr($status['state']) . '"><p><strong>GR Commerce Suite:</strong> '
            . esc_html($status['description'])
            . ($url !== '' ? ' <a href="' . esc_url($url) . '">' . esc_html($status['action']) . '</a>' : '')
            . '</p></div>';
    }

    /**
     * Merchant-facing license state, read from the saved key, stored instance and last check result.
     * Never contacts the license server itself.
     *
     * @return array{state: string, licensed: bool, expires_at: ?int, label: string, pill: string, description: string, action: string}
     */
    public function merchantStatus(): array
    {
        $key = $this->getLicenseKey();
        $licensed = $key !== '' && self::isLicensed();
        $host = function_exists('home_url') ? strtolower((string) parse_url(home_url(), PHP_URL_HOST)) : '';
        $stored = $key !== '' && function_exists('get_option') ? get_option(self::OPTION_INSTANCE, []) : [];
        $instance = is_array($stored) && ($stored['key_hash'] ?? '') === hash('sha256', $key) && ($stored['host'] ?? '') === $host
            ? $stored : [];
        $expires = is_string($instance['expires_at'] ?? null) && $instance['expires_at'] !== ''
            ? (strtotime($instance['expires_at']) ?: null) : null;

        if ($key === '') {
            $state = self::STATE_MISSING;
        } elseif ($licensed) {
            $state = $expires !== null && $expires - time() <= self::EXPIRY_WARNING ? self::STATE_EXPIRING
                // A cached approval older than one cache cycle means the last revalidation failed (outage grace).
                : (!empty($instance['id']) && (int) ($instance['last_validated_at'] ?? 0) < time() - self::CACHE_TTL - self::RETRY_TTL
                    ? self::STATE_UNVERIFIED : self::STATE_ACTIVE);
        } elseif ($expires !== null && $expires <= time()) {
            $state = self::STATE_EXPIRED;
        } else {
            $cached = $key !== self::DEV_TEST_KEY && function_exists('get_transient') ? get_transient($this->transientKey($key)) : 'invalid';
            $state = $cached === 'invalid' || $cached === '0' ? self::STATE_INVALID : self::STATE_UNREACHABLE;
        }

        $date = $expires !== null ? (function_exists('wp_date') ? (string) wp_date('j/n/Y', $expires) : gmdate('j/n/Y', $expires)) : '';
        $tools = AdminLocale::__('courier vouchers, COD reconciliation and XML feeds', 'gr-commerce-suite');
        [$label, $pill, $description, $action] = match ($state) {
            self::STATE_ACTIVE => [AdminLocale::__('ACTIVE', 'gr-commerce-suite'), AdminLocale::__('Active', 'gr-commerce-suite'),
                AdminLocale::__('All GR Commerce Suite features are enabled for this store.', 'gr-commerce-suite'), ''],
            self::STATE_EXPIRING => [sprintf(AdminLocale::__('ACTIVE — expires on %s', 'gr-commerce-suite'), $date),
                sprintf(AdminLocale::__('Expires %s', 'gr-commerce-suite'), $date),
                sprintf(AdminLocale::__('Your license expires on %1$s. Renew it before then to keep %2$s running.', 'gr-commerce-suite'), $date, $tools),
                AdminLocale::__('Open license settings', 'gr-commerce-suite')],
            self::STATE_UNVERIFIED => [AdminLocale::__('ACTIVE — verification pending', 'gr-commerce-suite'),
                AdminLocale::__('Active (verification pending)', 'gr-commerce-suite'),
                AdminLocale::__('The license server has not answered recently. Features stay on for up to three days after the last successful check; nothing needs to be done unless this continues.', 'gr-commerce-suite'), ''],
            self::STATE_MISSING => [AdminLocale::__('NOT ACTIVATED', 'gr-commerce-suite'), AdminLocale::__('Not activated', 'gr-commerce-suite'),
                sprintf(AdminLocale::__('Enter your license key to turn on %s. Checkout shipping, lockers and invoice fields already work without it.', 'gr-commerce-suite'), $tools),
                AdminLocale::__('Enter license key', 'gr-commerce-suite')],
            self::STATE_EXPIRED => [sprintf(AdminLocale::__('EXPIRED on %s', 'gr-commerce-suite'), $date), AdminLocale::__('Expired', 'gr-commerce-suite'),
                sprintf(AdminLocale::__('Your license expired on %1$s. Renew it to restore %2$s. Checkout keeps working.', 'gr-commerce-suite'), $date, $tools),
                AdminLocale::__('Open license settings', 'gr-commerce-suite')],
            self::STATE_UNREACHABLE => [AdminLocale::__('NOT VERIFIED', 'gr-commerce-suite'), AdminLocale::__('Could not verify', 'gr-commerce-suite'),
                sprintf(AdminLocale::__('The license server could not be reached, so the key could not be verified. %s stay paused until a check succeeds; checkout keeps working.', 'gr-commerce-suite'), AdminLocale::__('Courier vouchers, COD reconciliation and XML feeds', 'gr-commerce-suite')),
                AdminLocale::__('Open license settings', 'gr-commerce-suite')],
            default => [AdminLocale::__('KEY NOT ACCEPTED', 'gr-commerce-suite'), AdminLocale::__('Key not accepted', 'gr-commerce-suite'),
                sprintf(AdminLocale::__('The license key was not accepted. It may be mistyped, revoked or already used on another site. %s are paused; checkout keeps working.', 'gr-commerce-suite'), AdminLocale::__('Courier vouchers, COD reconciliation and XML feeds', 'gr-commerce-suite')),
                AdminLocale::__('Check license key', 'gr-commerce-suite')],
        };

        return ['state' => $state, 'licensed' => $licensed, 'expires_at' => $expires, 'label' => $label, 'pill' => $pill,
            'description' => $description, 'action' => $action];
    }

    /**
     * Validate a license key against the external license validation API and cache the result for 12 hours.
     */
    public function validateLicense(string $key): bool
    {
        $normalizedKey = trim($key);
        if ($normalizedKey === '') {
            return false;
        }
        $site = function_exists('get_current_blog_id') ? get_current_blog_id() : 0;
        $memoryKey = $site . ':' . hash('sha256', $normalizedKey);
        if (array_key_exists($memoryKey, self::$validationCache)) {
            return self::$validationCache[$memoryKey];
        }
        $transientKey = $this->transientKey($normalizedKey);
        if ($normalizedKey === self::DEV_TEST_KEY) {
            $host = function_exists('home_url') ? parse_url(home_url(), PHP_URL_HOST) : null;
            $host = is_string($host) ? strtolower($host) : '';
            if ($host === 'localhost' || $host === '127.0.0.1' || str_ends_with($host, '.local')) {
                if (function_exists('set_transient')) {
                    set_transient($transientKey, 'valid', self::CACHE_TTL);
                }
                return self::$validationCache[$memoryKey] = true;
            }
            if (function_exists('delete_transient')) {
                delete_transient($transientKey);
            }
            return self::$validationCache[$memoryKey] = false;
        }
        if (function_exists('get_transient')) {
            $cached = get_transient($transientKey);
            if ($cached === 'valid' || $cached === true || $cached === 1 || $cached === '1') {
                return self::$validationCache[$memoryKey] = true;
            }
            if ($cached === 'invalid' || $cached === '0' || $cached === 'unreachable') {
                return self::$validationCache[$memoryKey] = false;
            }
        }
        $host = function_exists('home_url') ? parse_url(home_url(), PHP_URL_HOST) : null;
        $host = is_string($host) ? strtolower($host) : '';
        $stored = function_exists('get_option') ? get_option(self::OPTION_INSTANCE, []) : [];
        $instance = is_array($stored) && ($stored['key_hash'] ?? '') === hash('sha256', $normalizedKey)
            && ($stored['host'] ?? '') === $host ? $stored : [];
        // Checkout, REST and other storefront requests only read cached approval/grace.
        // Never activate, lock, write logs or wait for the license server on that path.
        if (!(function_exists('is_admin') && is_admin())
            && !(function_exists('wp_doing_cron') && wp_doing_cron())) {
            return self::$validationCache[$memoryKey] = !empty($instance['id']) && $this->graceRemaining($instance) > 0;
        }
        if (empty($instance['id'])) {
            if (!Lock::acquire('license_activation', 30)) {
                return self::$validationCache[$memoryKey] = false;
            }
            try {
                $latest = get_option(self::OPTION_INSTANCE, []);
                if (
                    is_array($latest) && ($latest['host'] ?? '') === $host
                    && ($latest['key_hash'] ?? '') === hash('sha256', $normalizedKey) && !empty($latest['id'])
                ) {
                    $instance = $latest;
                } else {
                    $activation = $this->request(self::ACTIVATION_ENDPOINT, [
                        'license_key' => $normalizedKey,
                        'instance_name' => $host,
                    ]);
                    if ($activation === null) {
                        return $this->cacheResult($memoryKey, $transientKey, false, self::RETRY_TTL, true);
                    }
                    $id = $activation['instance']['id'] ?? null;
                    if (
                        ($activation['activated'] ?? false) !== true || !is_string($id) || $id === ''
                        || ($activation['license_key']['status'] ?? '') !== 'active'
                    ) {
                        return $this->cacheResult($memoryKey, $transientKey, false, self::CACHE_TTL);
                    }
                    $instance = ['id' => $id, 'key_hash' => hash('sha256', $normalizedKey), 'host' => $host];
                    // Persist before validation so an interrupted request cannot consume another activation slot.
                    update_option(self::OPTION_INSTANCE, $instance, false);
                }
            } finally {
                Lock::release('license_activation');
            }
        }
        $validation = $this->request(self::VALIDATION_ENDPOINT, [
            'license_key' => $normalizedKey,
            'instance_id' => (string) $instance['id'],
        ]);
        if ($validation === null) {
            $remaining = $this->graceRemaining($instance);
            return $this->cacheResult(
                $memoryKey,
                $transientKey,
                $remaining > 0,
                max(
                    1,
                    min(
                        self::RETRY_TTL,
                        $remaining
                    )
                ),
                true
            );
        }
        // Explicit revocation, expiry, or an instance mismatch never qualifies for outage grace.
        $valid = ($validation['valid'] ?? false) === true
            && ($validation['license_key']['status'] ?? '') === 'active'
            && ($validation['instance']['id'] ?? null) === $instance['id'];
        $instance['last_validated_at'] = $valid ? time() : 0;
        $instance['expires_at'] = $validation['license_key']['expires_at'] ?? null;
        update_option(self::OPTION_INSTANCE, $instance, false);
        $ttl = self::CACHE_TTL;
        if ($valid && is_string($instance['expires_at']) && $instance['expires_at'] !== '') {
            $ttl = max(1, min($ttl, (strtotime($instance['expires_at']) ?: 0) - time()));
            $valid = (strtotime($instance['expires_at']) ?: 0) > time();
        }
        return $this->cacheResult($memoryKey, $transientKey, $valid, $ttl);
    }

    /** @param array<string, mixed> $instance */
    private function graceRemaining(array $instance): int
    {
        $remaining = (int) ($instance['last_validated_at'] ?? 0) + self::OUTAGE_GRACE - time();
        $expires = $instance['expires_at'] ?? null;
        if (is_string($expires) && $expires !== '') {
            $remaining = min($remaining, (strtotime($expires) ?: 0) - time());
        }
        return $remaining;
    }

    /**
     * @param array<string, string> $body
     * @return array<string, mixed>|null
     */
    private function request(string $endpoint, array $body): ?array
    {
        if (!function_exists('wp_remote_post')) {
            return null;
        }
        $start = hrtime(true);
        try {
            $response = wp_remote_post($endpoint, [
                'timeout' => 8,
                'redirection' => 0,
                'headers' => ['Accept' => 'application/json'],
                'body' => $body,
            ]);
        } catch (\Throwable $error) {
            (new DiagnosticLogger())->record('ERROR', 'LICENSE', 'License transport failed.',
                ['action' => $endpoint === self::ACTIVATION_ENDPOINT ? 'activate_license' : 'validate_license',
                    'request_url' => $endpoint, 'request_data' => $body, 'response_code' => $error->getCode(),
                    'duration_ms' => (hrtime(true) - $start) / 1e6, 'exception' => $error]);
            return null;
        }
        $failed = function_exists('is_wp_error') && is_wp_error($response);
        $httpStatus = $failed ? 0 : (int) wp_remote_retrieve_response_code($response);
        (new DiagnosticLogger())->record(!$failed && $httpStatus >= 200 && $httpStatus < 300 ? 'INFO' : 'ERROR', 'LICENSE', 'License request completed.',
            ['action' => $endpoint === self::ACTIVATION_ENDPOINT ? 'activate_license' : 'validate_license',
                'request_url' => $endpoint, 'request_data' => $body,
                'response_code' => $failed ? $response->get_error_code() : $httpStatus,
                'response_data' => $failed ? [] : wp_remote_retrieve_body($response),
                'duration_ms' => (hrtime(true) - $start) / 1e6]);
        if (function_exists('is_wp_error') && is_wp_error($response)) {
            return null;
        }
        $status = (int) wp_remote_retrieve_response_code($response);
        if ($status === 0 || $status >= 500 || in_array($status, [408, 429], true)) {
            return null;
        }
        if ($status < 200 || $status >= 300) {
            return []; // A definitive HTTP rejection fails closed.
        }
        $decoded = json_decode((string) wp_remote_retrieve_body($response), true);
        return is_array($decoded) ? $decoded : null;
    }

    private function cacheResult(string $memoryKey, string $transientKey, bool $valid, int $ttl, bool $unreachable = false): bool
    {
        if (function_exists('set_transient')) {
            // "unreachable" is a failed check like "invalid", kept apart only so the merchant is told why.
            set_transient($transientKey, $valid ? 'valid' : ($unreachable ? 'unreachable' : 'invalid'), $ttl);
        }
        (new DiagnosticLogger())->record($valid ? 'INFO' : 'WARNING', 'LICENSE', $valid ? 'License check succeeded.' : 'License check failed.', ['action' => 'validate_license']);
        return self::$validationCache[$memoryKey] = $valid;
    }

    private function transientKey(string $key): string
    {
        $host = function_exists('home_url') ? strtolower((string) parse_url(home_url(), PHP_URL_HOST)) : '';
        return self::TRANSIENT_PREFIX . md5($key . '|' . $host);
    }

    /**
     * Determine whether Sandbox Mode is currently enabled.
     */
    public function isSandboxEnabled(): bool
    {
        if (defined('GRCS_SANDBOX_MODE')) {
            return (bool) constant('GRCS_SANDBOX_MODE');
        }

        $enabled = false;

        if (function_exists('get_option')) {
            $directOption = get_option(self::OPTION_SANDBOX_MODE, null);
            if ($directOption === 'yes' || $directOption === true || $directOption === '1' || $directOption === 1) {
                $enabled = true;
            } elseif (
                $directOption === 'no' ||
                 $directOption === false ||
                 $directOption === '0' ||
                 $directOption === 0
            ) {
                $enabled = false;
            } else {
                $settings = get_option('grcs_settings', []);
                if (is_array($settings) && array_key_exists('sandbox_mode', $settings)) {
                    $settingVal = $settings['sandbox_mode'];
                    $enabled = (
                        $settingVal === 'yes'
                        || $settingVal === true
                        || $settingVal === '1'
                        || $settingVal === 1
                    );
                } else {
                    $enabled = true;
                }
            }
        }

        if (function_exists('apply_filters')) {
            return (bool) apply_filters('grcs/sandbox/enabled', $enabled);
        }

        return $enabled;
    }

    /**
     * Check whether the currently saved license key is active.
     */
    public function isLicenseActive(): bool
    {
        return self::isLicensed();
    }

    /**
     * Retrieve the stored license key from WordPress options.
     */
    public function getLicenseKey(): string
    {
        if (!function_exists('get_option')) {
            return '';
        }

        $key = get_option(self::OPTION_LICENSE_KEY, null);
        if ($key !== null) {
            // An explicitly cleared key must not resurrect a legacy settings key.
            return is_string($key) ? trim($key) : '';
        }

        $settings = get_option('grcs_settings', []);
        if (is_array($settings) && isset($settings['license_key'])) {
            return is_string($settings['license_key']) ? trim($settings['license_key']) : '';
        }

        return '';
    }

    /**
     * Clear the cached validation transient for a given license key (or the current key).
     */
    public function clearValidationCache(?string $key = null): void
    {
        self::resetRequestCache();
        if (!function_exists('delete_transient')) {
            return;
        }

        $targetKey = $key !== null ? trim($key) : $this->getLicenseKey();
        if ($targetKey !== '') {
            delete_transient($this->transientKey($targetKey));
        }
    }
}
