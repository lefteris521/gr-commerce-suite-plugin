<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\I18n\AdminLocale;

use WC_Order;
use WC_Order_Item_Product;
use WC_Product;

/** Presentation data only: no warranty entitlement calculation or claims workflow. */
final class CustomerPurchaseEvidence
{
    /**
     * Only explicitly supported warranty keys are exposed, never arbitrary private metadata.
     *
     * @return array<string, array<string, string>>
     */
    public function warranty(WC_Order_Item_Product $item): array
    {
        $keys = apply_filters('grcs_customer360_warranty_meta_keys', [
            '_warranty' => AdminLocale::__('Warranty', 'gr-commerce-suite'),
            '_warranty_type' => AdminLocale::__('Warranty type', 'gr-commerce-suite'),
            '_warranty_duration' => AdminLocale::__('Warranty duration', 'gr-commerce-suite'),
            '_warranty_period' => AdminLocale::__('Warranty period', 'gr-commerce-suite'),
            '_warranty_terms' => AdminLocale::__('Warranty terms', 'gr-commerce-suite'),
            '_warranty_expiry_date' => AdminLocale::__('Recorded warranty expiry', 'gr-commerce-suite'),
            'warranty' => AdminLocale::__('Warranty', 'gr-commerce-suite'),
            'warranty_duration' => AdminLocale::__('Warranty duration', 'gr-commerce-suite'),
            'warranty_period' => AdminLocale::__('Warranty period', 'gr-commerce-suite'),
            '_grcs_warranty_duration' => AdminLocale::__('Warranty duration', 'gr-commerce-suite'),
            '_grcs_warranty_terms' => AdminLocale::__('Warranty terms', 'gr-commerce-suite'),
        ]);
        $sources = [AdminLocale::__('Order item metadata (saved purchase record)', 'gr-commerce-suite') => $item];
        $product = $item->get_product();
        if ($product instanceof WC_Product) {
            $sources[AdminLocale::__('Current product / variation metadata', 'gr-commerce-suite')] = $product;
            if ($product->get_parent_id() > 0) {
                $parent = wc_get_product($product->get_parent_id());
                if ($parent instanceof WC_Product) {
                    $sources[AdminLocale::__('Current parent product metadata', 'gr-commerce-suite')] = $parent;
                }
            }
        }
        $evidence = [];
        foreach ($sources as $source => $object) {
            foreach (is_array($keys) ? array_slice($keys, 0, 30, true) : [] as $key => $label) {
                if (!is_string($key) || !is_string($label)) {
                    continue;
                }
                $value = $object->get_meta($key, true);
                $text = self::metadataText($value);
                if ($text !== '') {
                    $evidence[$source][$label . ' (' . $key . ')'] = $text;
                }
            }
        }
        return $evidence;
    }

    public function sku(WC_Order_Item_Product $item): string
    {
        $snapshot = $item->get_meta('_sku', true);
        if (is_scalar($snapshot) && (string) $snapshot !== '') {
            return (string) $snapshot;
        }
        $product = $item->get_product();
        return $product instanceof WC_Product ? $product->get_sku() : '';
    }

    public function refundedTotal(WC_Order $order, WC_Order_Item_Product $item): float
    {
        $amount = (float) $order->get_total_refunded_for_item($item->get_id());
        $taxes = $item->get_taxes();
        foreach (array_keys($taxes['total'] ?? []) as $key) {
            $rateId = self::taxRateId($key);
            if ($rateId !== null) {
                $amount += (float) $order->get_tax_refunded_for_item($item->get_id(), $rateId);
            }
        }
        return $amount;
    }

    /** Line-tax keys are WooCommerce tax-rate IDs; a malformed key is skipped rather than coerced to rate 0. */
    private static function taxRateId(int|string $key): ?int
    {
        $rateId = filter_var($key, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        return is_int($rateId) ? $rateId : null;
    }

    private static function metadataText(mixed $value): string
    {
        if (is_array($value)) {
            // Some warranty extensions store a small structured duration/terms value.
            $value = wp_json_encode($value);
        }
        return is_scalar($value) ? mb_substr((string) $value, 0, 4000) : '';
    }
}
