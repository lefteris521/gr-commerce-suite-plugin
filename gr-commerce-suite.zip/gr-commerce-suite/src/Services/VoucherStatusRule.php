<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\I18n\AdminLocale;
use WC_Order;

/**
 * Voucher creation rule by order status (decision 2026-11-06, option `grcs_voucher_status_rule`).
 *
 * `free` (default, also when missing): any status; RISKY statuses need an explicit per-order confirmation, UNPAID is UI-warning only.
 * `strict`: only processing/completed, plus pending/on-hold for COD; confirmation never overrides.
 * Pure policy: no courier call, no writes.
 */
final class VoucherStatusRule
{
    public const OPTION = 'grcs_voucher_status_rule';
    public const FREE = 'free';
    public const STRICT = 'strict';

    /** Statuses of a dead order. */
    public const RISKY_STATUSES = ['cancelled', 'refunded', 'failed'];

    /** Rule is stored per site; anything but 'strict' (missing, empty, unknown) is 'free'. */
    public static function mode(): string
    {
        return get_option(self::OPTION, self::FREE) === self::STRICT ? self::STRICT : self::FREE;
    }

    public static function sanitize(mixed $value): string
    {
        return $value === self::STRICT ? self::STRICT : self::FREE;
    }

    public static function isRisky(WC_Order $order): bool
    {
        return in_array($order->get_status(), self::RISKY_STATUSES, true);
    }

    /** pending, or on-hold when the payment method is not COD. */
    public static function isUnpaid(WC_Order $order): bool
    {
        $status = $order->get_status();
        if ($status === 'pending') {
            return true;
        }

        return $status === 'on-hold' && strtolower((string) $order->get_payment_method()) !== 'cod';
    }

    /** @return list<string> */
    public static function strictAllowed(WC_Order $order, CourierSlug $courier): array
    {
        $allowed = ['processing', 'completed'];
        if (strtolower((string) $order->get_payment_method()) === 'cod') {
            $allowed[] = 'pending';
            $allowed[] = 'on-hold';
        }
        if (function_exists('apply_filters')) {
            $filtered = apply_filters('grcs/voucher/allowed_statuses', $allowed, $order, $courier);
            if (is_array($filtered)) {
                $allowed = array_values(array_filter(array_map('strval', $filtered), static fn(string $s): bool => $s !== ''));
            }
        }

        return $allowed;
    }

    /**
     * Refusal message when the rule blocks creation, or null when it allows it.
     * In free mode a confirmed RISKY order is allowed.
     */
    public static function refusal(WC_Order $order, CourierSlug $courier, bool $confirmedRiskyStatus = false): ?string
    {
        $status = $order->get_status();
        $name = function_exists('wc_get_order_status_name') ? wc_get_order_status_name($status) : $status;

        if (self::mode() === self::STRICT) {
            $allowed = self::strictAllowed($order, $courier);
            if (in_array($status, $allowed, true)) {
                return null;
            }
            $names = array_map(
                static fn(string $s): string => function_exists('wc_get_order_status_name') ? wc_get_order_status_name($s) : $s,
                $allowed
            );

            return sprintf(
                AdminLocale::__('Vouchers can only be created for orders with status: %2$s. This order is "%1$s".', 'gr-commerce-suite'),
                $name,
                implode(', ', $names)
            );
        }

        if (self::isRisky($order) && !$confirmedRiskyStatus) {
            return sprintf(
                AdminLocale::__('This order is "%s". Creating a voucher for it needs explicit confirmation.', 'gr-commerce-suite'),
                $name
            );
        }

        return null;
    }
}
