<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Support\Lock;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Http\HttpRequest;
use GRCommerceSuite\Http\HttpResponse;
use Throwable;

/** Bounded, non-autoloaded support log. Never persist raw credentials or recipient data. */
final class DiagnosticLogger implements HookSubscriberInterface
{
    public const OPTION = 'grcs_diagnostic_events';
    public const LIMIT = 250;

    public function register(): void
    {
        add_action('grcs/voucher/created', [$this, 'voucherCreated'], 10, 3);
        add_action('grcs/voucher/cancelled', [$this, 'voucherCancelled'], 10, 2);
    }

    public function voucherCreated(int $id, mixed $result = null, int $orderId = 0): void
    {
        $context = $result instanceof \GRCommerceSuite\Domain\Voucher\VoucherResult ? $result->courier->value : 'RECONCILIATION';
        $this->record('INFO', $context, 'Voucher created.', ['action' => 'create_voucher', 'voucher_id' => $id, 'order_id' => $orderId]);
    }

    public function voucherCancelled(int $id, int $orderId): void
    {
        $this->record('INFO', 'RECONCILIATION', 'Voucher cancelled.', ['action' => 'cancel_voucher', 'voucher_id' => $id, 'order_id' => $orderId]);
    }

    /** Local call-site metadata only. External data belongs in request/response payload fields and is omitted.
     * @param array<string, mixed> $data
     */
    public function record(string $level, string $context, string $message, array $data = []): void
    {
        if (!function_exists('get_option') || !function_exists('update_option')) {
            return;
        }
        // Logging must never interrupt checkout, courier calls or background jobs.
        try {
            if (!Lock::acquire('diagnostic_events', 5)) {
                return;
            }
            try {
                $events = $this->safeEvents();
                $level = self::level($level);
                $error = $data['exception'] ?? null;
                $events[] = [
                    'timestamp' => (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format('Y-m-d\TH:i:s.u\Z'),
                    'level' => $level,
                    'context' => self::context($context),
                    'order_id' => is_int($data['order_id'] ?? null) && $data['order_id'] > 0 && $data['order_id'] < 100000000 ? $data['order_id'] : null,
                    'action' => DiagnosticSanitizer::action($data['action'] ?? null),
                    'request_url' => DiagnosticSanitizer::endpoint(is_string($data['request_url'] ?? null) ? $data['request_url'] : ''),
                    'request_data' => DiagnosticSanitizer::payload($data['request_data'] ?? $data['request'] ?? []),
                    'response_code' => isset($data['response_code']) ? DiagnosticSanitizer::code($data['response_code']) : null,
                    'response_data' => DiagnosticSanitizer::payload($data['response_data'] ?? $data['response'] ?? []),
                    'duration_ms' => (is_int($data['duration_ms'] ?? null) || is_float($data['duration_ms'] ?? null)) && is_finite((float) $data['duration_ms']) && $data['duration_ms'] >= 0 && $data['duration_ms'] <= 60000 ? round((float) $data['duration_ms'], 3) : 0.0,
                    'memory_peak_mb' => DiagnosticSanitizer::memoryPeak(round(memory_get_peak_usage(true) / 1048576, 2)),
                    'error_details' => in_array($level, ['ERROR', 'CRITICAL'], true)
                        ? $this->errorDetails($error instanceof Throwable ? $error : null, !empty($data['db_related'])) : null,
                    'message' => self::maskText($message),
                    'data' => DiagnosticSanitizer::mask($data),
                ];
                // Keep the support buffer out of WordPress's frontend alloptions cache.
                update_option(self::OPTION, array_slice($events, -self::LIMIT), false);
            } finally {
                Lock::release('diagnostic_events');
            }
        } catch (Throwable) {
            // Best effort only, including during installation or a database outage.
        }
    }

    /** @return list<array<string, mixed>> */
    public function events(string $level = '', string $context = ''): array
    {
        $stored = function_exists('get_option') ? get_option(self::OPTION, []) : [];
        if (!is_array($stored)) {
            return [];
        }
        // Every public read rebuilds the approved representation without writing historical storage.
        $events = array_map(static function (array $event): array {
            $safe = [
                'timestamp' => is_string($event['timestamp'] ?? null) && preg_match('/^\d{4}-\d{2}-\d{2}T[0-9:.]+Z$/D', $event['timestamp']) ? $event['timestamp'] : '',
                'level' => self::level(is_string($event['level'] ?? null) ? $event['level'] : ''),
                'context' => self::context(is_string($event['context'] ?? null) ? $event['context'] : ''),
                'action' => DiagnosticSanitizer::action($event['action'] ?? null),
                'message' => self::maskText(is_string($event['message'] ?? null) ? $event['message'] : ''),
                'order_id' => is_int($event['order_id'] ?? null) && $event['order_id'] > 0 && $event['order_id'] < 100000000 ? $event['order_id'] : null,
                'duration_ms' => (is_int($event['duration_ms'] ?? null) || is_float($event['duration_ms'] ?? null)) && is_finite((float) $event['duration_ms']) && $event['duration_ms'] >= 0 && $event['duration_ms'] <= 60000 ? $event['duration_ms'] : 0.0,
                'memory_peak_mb' => DiagnosticSanitizer::memoryPeak($event['memory_peak_mb'] ?? null),
                'data' => is_array($event['data'] ?? null) ? DiagnosticSanitizer::mask($event['data']) : [],
                'error_details' => isset($event['error_details']) ? DiagnosticSanitizer::errorDetails($event['error_details']) : null,
            ];
            foreach (['request_data', 'response_data'] as $field) {
                if (isset($event[$field])) {
                    $payload = DiagnosticSanitizer::payload($event[$field]);
                    $safe[$field] = $payload;
                }
            }
            if (array_key_exists('response_code', $event)) {
                $safe['response_code'] = $event['response_code'] === null ? null : DiagnosticSanitizer::code($event['response_code']);
            }
            if (isset($event['request_url'])) {
                $safe['request_url'] = DiagnosticSanitizer::endpoint(is_string($event['request_url']) ? $event['request_url'] : '');
            }
            return $safe;
        }, array_values(array_filter(array_slice($stored, -self::LIMIT), 'is_array')));
        return array_values(array_filter($events, static fn(array $event): bool =>
            ($level === '' || $event['level'] === self::level($level))
                && ($context === '' || $event['context'] === self::context($context))));
    }

    public function clear(): void
    {
        try {
            if (!Lock::acquire('diagnostic_events', 5)) {
                return;
            }
            try {
                update_option(self::OPTION, [], false);
            } finally {
                Lock::release('diagnostic_events');
            }
        } catch (Throwable) {
            // A support action must remain usable during a database outage.
        }
    }

    /**
     * @param array<mixed> $data
     * @return array<string, mixed>
     */
    public static function mask(array $data, int $depth = 0): array
    {
        return DiagnosticSanitizer::mask($data, $depth);
    }

    public static function maskText(string $text): string
    {
        return DiagnosticSanitizer::text($text);
    }

    /** @return array<string, string> */
    public function health(): array
    {
        $uploads = function_exists('wp_upload_dir') ? wp_upload_dir() : [];
        $path = is_array($uploads) ? ($uploads['basedir'] ?? '') : '';
        return array_merge((new SystemDiagnostics())->environment(), [
            'WordPress' => (string) ($GLOBALS['wp_version'] ?? 'Unavailable'),
            'WooCommerce' => defined('WC_VERSION') ? WC_VERSION : 'Unavailable',
            'PHP' => PHP_VERSION,
            'HPOS' => class_exists(\Automattic\WooCommerce\Utilities\OrderUtil::class)
                && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ? 'Enabled' : 'Disabled',
            'Action Scheduler' => function_exists('as_enqueue_async_action') ? 'Available' : 'Unavailable',
            'Uploads writable' => is_string($path) && $path !== '' && is_writable($path) ? 'Yes' : 'No',
            'License' => LicenseManager::isLicensed() ? 'Active' : 'Inactive',
        ]);
    }

    /** @param array<string, mixed>|null $systemReport */
    public function report(bool $allEvents = false, ?array $systemReport = null): string
    {
        if ($allEvents) {
            return (string) json_encode($this->safeEvents(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE) . "\n";
        }
        $markdown = "# GR Commerce Suite diagnostic report (UTC)\n";
        foreach ($systemReport ?? $this->generate_system_report() as $section => $values) {
            $markdown .= "\n## " . $section . "\n\n";
            // A JSON fence preserves nested structure and makes remote strings inert in Markdown.
            $markdown .= "```json\n" . str_replace('`', '\\u0060', (string) json_encode($values, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE)) . "\n```\n";
        }
        return $markdown;
    }

    /** @return array<string, mixed> */
    public function generate_system_report(): array
    {
        $report = (new SystemDiagnostics())->report($this->safeEvents());
        $report['Environment'] = $this->health();
        return $report;
    }

    /** @return list<array<string, mixed>> */
    public function safeEvents(): array
    {
        return $this->events();
    }

    private static function level(string $level): string
    {
        return match (strtoupper($level)) {
            'WARN', 'WARNING' => 'WARNING', 'ERROR' => 'ERROR',
            'CRITICAL', 'ALERT', 'EMERGENCY' => 'CRITICAL', default => 'INFO',
        };
    }

    private static function context(string $context): string
    {
        return match (strtoupper($context)) {
            'ACS', 'COURIER' => 'ACS', 'BOXNOW', 'BOX NOW' => 'BOXNOW',
            'BLACKLIST' => 'BLACKLIST', 'COD', 'RECONCILIATION' => 'RECONCILIATION',
            'INVOICE', 'AADE' => 'INVOICE', 'LICENSE' => 'LICENSE', 'XML' => 'XML', default => 'RECONCILIATION',
        };
    }

    /** @return array<string, mixed> */
    private function errorDetails(?Throwable $error, bool $database): array
    {
        $trace = $error?->getTrace() ?? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 30);
        $frames = [];
        $root = str_replace('\\', '/', dirname(__DIR__, 2)) . '/';
        foreach ($trace as $frame) {
            $class = (string) ($frame['class'] ?? '');
            $database = $database || str_starts_with($class, 'GRCommerceSuite\\Database\\');
            $file = str_replace('\\', '/', (string) ($frame['file'] ?? ''));
            // The project's GRCS namespace is spelled GRCommerceSuite in its PSR-4 map.
            if ((str_starts_with($class, 'GRCommerceSuite\\') || str_starts_with($class, 'GRCS\\'))
                && str_starts_with($file, $root . 'src/')) {
                $frames[] = substr($file, strlen($root)) . ':' . (int) ($frame['line'] ?? 0);
            }
            if (count($frames) >= 12) {
                break;
            }
        }
        $details = ['stack_trace' => $frames];
        if ($database) {
            global $wpdb;
            $dbError = $wpdb instanceof \wpdb ? $wpdb->last_error : '';
            // SQL error text can embed customer values: remove all quoted literals first.
            $details['database_error'] = $dbError !== '';
        }
        return DiagnosticSanitizer::errorDetails($details);
    }

    /** @return array{length: int, prefix: string, has_special_chars: bool, checksum_valid: ?bool} */
    public static function validationMetadata(string $value, ?bool $checksumValid = null): array
    {
        return ['length' => mb_strlen($value, 'UTF-8'),
            'prefix' => str_starts_with($value, '+30') ? '+30' : (str_starts_with($value, '0030') ? '0030'
                : (str_starts_with(strtoupper($value), 'EL') ? 'EL' : 'none')),
            'has_special_chars' => preg_match('/[^\p{L}\p{N}]/u', $value) === 1,
            'checksum_valid' => $checksumValid];
    }

    /** @param array<string, string> $fields */
    public function validationFailure(string $context, string $action, array $fields, ?int $orderId = null, ?bool $checksumValid = null): void
    {
        $metadata = [];
        foreach ($fields as $field => $value) {
            $metadata[$field] = self::validationMetadata($value, $checksumValid);
        }
        $this->record('WARNING', $context, 'Validation failed.', ['action' => $action, 'order_id' => $orderId,
            'validation' => $metadata]);
    }

    /** Timed at the provider boundary, including injected clients, transport exceptions and OAuth. */
    public function send(HttpClientInterface $client, HttpRequest $request, string $context, string $action, ?int $orderId = null): HttpResponse
    {
        $started = hrtime(true);
        try {
            $response = $client->send($request);
        } catch (Throwable $error) {
            $this->record('ERROR', $context, 'Remote request failed.', [
                'action' => $action, 'order_id' => $orderId, 'request_url' => $request->url,
                'request_data' => $request->body, 'response_code' => $error->getCode(),
                'duration_ms' => (hrtime(true) - $started) / 1e6, 'exception' => $error,
            ]);
            throw $error;
        }
        $decoded = $context === 'ACS' && strlen($response->body) <= 1048576 ? json_decode($response->body, true) : null;
        $apiError = is_array($decoded) && $context === 'ACS' ? self::acsErrorCode($decoded) : null;
        $this->record($response->isSuccess() && $apiError === null ? 'INFO' : 'ERROR', $context, 'Remote request completed.', [
            'action' => $action, 'order_id' => $orderId, 'request_url' => $request->url,
            'request_data' => $request->body, 'response_code' => $response->errorCode ?? $apiError ?? $response->statusCode,
            'response_data' => $response->body, 'duration_ms' => (hrtime(true) - $started) / 1e6,
        ]);
        return $response;
    }

    /** ACS commonly reports business/authentication errors inside an HTTP 200 envelope.
     * @param array<mixed> $data
     */
    private static function acsErrorCode(array $data, int $depth = 0): ?string
    {
        if ($depth > 8) {
            return null;
        }
        if (!empty($data['Error_Message']) || !empty($data['error_message'])) {
            $code = $data['Error_Code'] ?? $data['error_code'] ?? 'api_error';
            return is_scalar($code) ? (string) $code : 'api_error';
        }
        foreach (array_slice($data, 0, 80) as $value) {
            if (is_array($value)) {
                $code = self::acsErrorCode($value, $depth + 1);
                if ($code !== null) {
                    return $code;
                }
            }
        }
        return null;
    }
}
