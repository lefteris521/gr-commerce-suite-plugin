<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

/** Diagnostics accept fixed local metadata, never externally supplied payload schemas. */
final class DiagnosticSanitizer
{
    /** Exact local Phase 3 labels map to fixed identifiers; never match substrings or external values. */
    private const RECOVERY_MESSAGES = [
        'Interrupted feed publication could not be rolled back; XML and ZIP may differ.' => 'feed_recovery_rollback_failed',
        'Interrupted feed publication recovered.' => 'feed_recovery_succeeded',
        'Interrupted feed publication recovery failed.' => 'feed_recovery_failed',
    ];
    private const ACTIONS = ['event', 'create_voucher', 'cancel_voucher', 'print_voucher', 'track_voucher',
        'authenticate', 'issue_pickup_list', 'list_pickup_points', 'courier_request', 'aade_lookup',
        'aade_lookup_simulation', 'validate_shipping', 'validate_afm', 'validate_invoice', 'aade_store_afm',
        'blacklist_check', 'activate_license', 'validate_license', 'csv_header_detection', 'feed_complete'];
    private const MESSAGES = ['Voucher created.', 'Voucher cancelled.', 'Validation failed.',
        'Remote request failed.', 'Remote request completed.', 'Simulated AADE registry lookup.',
        'Registry response could not be validated.', 'Blacklist check completed.',
        'License transport failed.', 'License request completed.', 'License check succeeded.',
        'License check failed.', 'COD CSV headers could not be matched.', 'COD CSV reconciliation completed.',
        'COD CSV row skipped: invalid collected amount.', 'Request failed', 'Diagnostic event.',
        'XML feed generation started.', 'Feed publication failed.', 'XML and verified ZIP feed published.',
        'Could not atomically publish the XML feed; the previous feed was retained.',
        'ACS COD amount exceeds configured cash transaction warning threshold.',
        'BOX NOW COD amount exceeds configured cash transaction warning threshold.',
        'Unmapped ACS tracking status code encountered; mapped to TrackingStatus::Unknown.',
        'Unmapped BOX NOW tracking state encountered; mapped to TrackingStatus::Unknown.'];

    public static function action(mixed $value): string
    {
        return in_array($value, self::ACTIONS, true) ? $value : 'event';
    }

    /** No free-form message is safe merely because it resembles prose or an identifier. */
    public static function text(string $text): string
    {
        if (isset(self::RECOVERY_MESSAGES[$text])) { return self::RECOVERY_MESSAGES[$text]; }
        // Stored identifiers cross this boundary again on reads/exports.
        if (in_array($text, self::RECOVERY_MESSAGES, true)) { return $text; }
        return in_array($text, self::MESSAGES, true) ? $text : 'Diagnostic event.';
    }

    /**
     * Locally read environment labels (web server banner, theme name) that are not event messages: strip markup,
     * redact anything shaped like a credential, e-mail address or URL login, then cap the length.
     */
    public static function value(string $text, int $max = 120): string
    {
        $text = function_exists('wp_strip_all_tags') ? wp_strip_all_tags($text) : strip_tags($text);
        $text = trim((string) preg_replace('/[\x00-\x1F\x7F\s]+/u', ' ', $text));
        $text = (string) preg_replace([
            '~[^\s/@:]+:[^\s/@]*@[^\s]+~',
            '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i',
            '/\b(?:pass(?:word)?|secret|token|api[_-]?key|auth(?:orization)?|key)\s*[=:]\s*\S+/i',
            '/\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b/i',
            '~\b(?=[A-Za-z0-9_+/=]*\d)(?=[A-Za-z0-9_+/=]*[A-Za-z])[A-Za-z0-9_+/=]{24,}~',
        ], '[redacted]', $text);
        return mb_substr($text, 0, max(0, $max));
    }

    /** Transport/HTTP codes and explicitly supported internal categories only. */
    public static function code(mixed $value): int|string
    {
        if (is_int($value) && (($value >= 0 && $value <= 99) || ($value >= 100 && $value <= 599))) {
            return $value;
        }
        if (in_array($value, ['E100', 'api_error', 'http_request_failed', 'timeout', 'blocked',
            'provider_error', 'transport_error', 'invalid_response'], true)) {
            return $value;
        }
        return 'provider_error';
    }

    /** @param array<mixed> $data
     * @return array<string, mixed>
     */
    public static function mask(array $data, int $depth = 0, bool $remotePayload = false): array
    {
        if ($remotePayload || $depth > 0) { return []; }
        $safe = [];
        // These counters are calculated locally by the CSV reconciliation workflow, not parsed from provider bodies.
        foreach (['count', 'total_rows', 'exact_match_count', 'mismatch_count', 'overdue_count', 'unmatched_count'] as $key) {
            if (isset($data[$key]) && is_int($data[$key]) && $data[$key] >= 0 && $data[$key] <= 9999) {
                $safe[$key] = $data[$key];
            }
        }
        if (isset($data['action'])) { $safe['action'] = self::action($data['action']); }
        if (isset($data['response_code'])) { $safe['response_code'] = self::code($data['response_code']); }
        if (isset($data['encoding']) && in_array($data['encoding'], ['UTF-8', 'Windows-1253', 'ISO-8859-7'], true)) {
            $safe['encoding'] = $data['encoding'];
        }
        if (isset($data['delimiter']) && in_array($data['delimiter'], [',', ';', 'tab', '|'], true)) {
            $safe['delimiter'] = $data['delimiter'];
        }
        if (isset($data['validation']) && is_array($data['validation'])) {
            $safe['validation'] = self::validation($data['validation']);
        }
        if (isset($data['outcome']) && in_array($data['outcome'], ['completed', 'not_published', 'rolled_back'], true)) {
            $safe['outcome'] = $data['outcome'];
        }
        if (isset($data['stage']) && in_array($data['stage'], ['complete_xml', 'compress_zip', 'publication_lock', 'identity_transitions',
            'snapshot_xml', 'publish_xml', 'publish_zip', 'record_success'], true)) { $safe['stage'] = $data['stage']; }
        foreach (['partial', 'background'] as $key) {
            if (isset($data[$key]) && is_bool($data[$key])) { $safe[$key] = $data[$key]; }
        }
        // All arbitrary keys, nested data, names, financial values and payload contents are dropped.
        return $safe;
    }

    public static function payload(mixed $payload): string
    {
        return $payload === null || $payload === '' || $payload === [] ? '' : '[Payload omitted]';
    }

    /** @param array<mixed> $metadata
     * @return array<string, array<string, int|bool|string|null>>
     */
    public static function validation(array $metadata): array
    {
        $safe = [];
        foreach (['vat_number', 'phone', 'postcode', 'company_name', 'doy', 'profession',
            'recipient_phone', 'recipient_name', 'recipient_address', 'city', 'locker_id'] as $field) {
            $entry = $metadata[$field] ?? null;
            if (!is_array($entry) || !isset($entry['length']) || !is_int($entry['length'])
                || $entry['length'] < 0 || $entry['length'] > 4096
                || !in_array($entry['prefix'] ?? null, ['EL', '+30', '0030', 'none'], true)
                || !is_bool($entry['has_special_chars'] ?? null)
                || !(is_bool($entry['checksum_valid'] ?? null) || array_key_exists('checksum_valid', $entry) && $entry['checksum_valid'] === null)) {
                continue;
            }
            $safe[$field] = ['length' => $entry['length'], 'prefix' => $entry['prefix'],
                'has_special_chars' => $entry['has_special_chars'], 'checksum_valid' => $entry['checksum_valid']];
        }
        return $safe;
    }

    public static function endpoint(string $url): string
    {
        // Stored categories have already crossed this boundary; accept only the exact closed enum.
        if (in_array($url, ['aade', 'boxnow', 'acs', 'remote'], true)) { return $url; }
        // Host/path can themselves be customer identifiers. Retain only a fixed provider category.
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        return match ($host) {
            'www1.gsis.gr' => 'aade',
            'api-production.boxnow.gr', 'api-stage.boxnow.gr' => 'boxnow',
            'webservices.acscourier.net' => 'acs',
            default => 'remote',
        };
    }

    /** Local peak memory measurement in MiB, bounded to a supported 4 GiB PHP process. */
    public static function memoryPeak(mixed $value): ?float
    {
        return (is_int($value) || is_float($value)) && is_finite((float) $value) && $value >= 0 && $value <= 4096
            ? (float) $value : null;
    }

    public static function source(string $source): string
    {
        return in_array($source, ['gr-commerce-suite', 'grcs-acs', 'grcs-boxnow', 'grcs-geniki', 'grcs-feeds'], true)
            ? $source : 'gr-commerce-suite';
    }

    /** @return array{stack_trace: list<string>, database_error?: bool} */
    public static function errorDetails(mixed $details): array
    {
        $safe = ['stack_trace' => []];
        if (!is_array($details)) { return $safe; }
        foreach (is_array($details['stack_trace'] ?? null) ? array_slice($details['stack_trace'], 0, 12) : [] as $frame) {
            $separator = is_string($frame) ? strrpos($frame, ':') : false;
            if ($separator !== false && is_string($frame) && preg_match('~^src/(?:[A-Za-z0-9_-]+/)*[A-Za-z0-9_-]+\\.php:[1-9][0-9]{0,5}$~D', $frame)
                && is_file(dirname(__DIR__, 2) . '/' . substr($frame, 0, $separator))) {
                $safe['stack_trace'][] = $frame;
            }
        }
        if (isset($details['database_error']) && is_bool($details['database_error'])) { $safe['database_error'] = $details['database_error']; }
        return $safe;
    }
}
