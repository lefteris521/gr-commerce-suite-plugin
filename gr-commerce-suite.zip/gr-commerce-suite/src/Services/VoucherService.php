<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Voucher\VoucherResult;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Jobs\JobDispatcher;
use InvalidArgumentException;
use WC_Order;

/**
 * Orchestrates idempotent voucher creation, cancellation, printing, and retry/timeout state transitions (SPEC.md §6.3, §7, §9.5).
 */
final readonly class VoucherService
{
    public function __construct(
        private VoucherRepository $repository,
        private CourierRegistry $courierRegistry,
        private JobDispatcher $jobDispatcher,
        private LoggerInterface $logger,
    ) {
    }

    /**
     * Derive the deterministic SHA-256 idempotency key for an order and courier (SPEC.md §7).
     */
    public function deriveIdempotencyKey(int $orderId, CourierSlug $courier, int $series = 0): string
    {
        $n = 1 + $this->repository->countFailedOrCancelled($orderId, $courier);

        return hash('sha256', sprintf('grcs|v1|%d|%s|%d|%d', $orderId, $courier->value, $series, $n));
    }

    /**
     * Create a voucher for an order with atomic idempotency reservation and timeout safety (SPEC.md §7).
     */
    public function createForOrder(WC_Order $order, CourierSlug $courier, bool $confirmedRiskyStatus = false): VoucherResult
    {
        // A trashed order must not get a courier voucher: the parcel would be collected for an order the merchant deleted.
        if ($order->get_status() === 'trash') {
            throw new \GRCommerceSuite\Exceptions\Courier\CourierValidationException(
                AdminLocale::__('A voucher cannot be issued for an order in the trash. Restore the order first.', 'gr-commerce-suite'),
                $courier
            );
        }
        // New vouchers only. Existing vouchers stay fully manageable (print, cancel, track) while a module is off.
        if (!\GRCommerceSuite\Modules\ModuleRegistry::courierCanCreate($courier)) {
            throw new \RuntimeException(sprintf(AdminLocale::__('The %s module is turned off. Turn it on in GR Commerce Suite > Modules to issue new vouchers.', 'gr-commerce-suite'), $courier->label()));
        }
        return (new VoucherLockService($this->repository, $this->courierRegistry, $this->jobDispatcher, $this->logger))
            ->createVoucherWithLock($order, $courier, confirmedRiskyStatus: $confirmedRiskyStatus);
    }
    /**
     * Cancel a created voucher and update its state to `cancelled` (SPEC.md §6.3, §8.2).
     */
    public function cancelVoucherById(int $voucherId): bool
    {
        $row = $this->repository->findById($voucherId);
        if ($row === null) {
            return false;
        }

        $orderId = (int) $row['order_id'];
        $token = VoucherOperationLock::acquire($orderId);
        try {
            // Re-read after locking: creation/cancellation may have completed while waiting.
            $row = $this->repository->findById($voucherId);
            return $row !== null && $this->cancelLockedVoucher($voucherId, $row);
        } finally {
            VoucherOperationLock::release($orderId, $token);
        }
    }

    /** @param array<string, mixed> $row */
    private function cancelLockedVoucher(int $voucherId, array $row): bool
    {
        $state = VoucherState::tryFrom((string) $row['state']);
        $order = function_exists('wc_get_order') ? wc_get_order((int) $row['order_id']) : null;
        if ($state === VoucherState::Cancelled) {
            if ($order instanceof WC_Order) {
                VoucherCancellationMarker::clear($order, $voucherId);
            }
            $this->clearCancelledOrderState($row);
            return true;
        }

        if ($state !== VoucherState::Created) {
            return false;
        }

        $courier = CourierSlug::from((string) $row['courier_slug']);
        $voucherNo = trim((string) ($row['voucher_no'] ?? ''));
        if ($voucherNo === '') {
            return false;
        }

        // A marker left by an earlier attempt means a cancellation may already have reached the carrier.
        // Retrying is allowed (CancelJob is idempotent) but a refused retry must never roll the marker back
        // into a printable voucher.
        $marker = $order instanceof WC_Order ? VoucherCancellationMarker::pending($order, $voucherId) : null;
        $retrying = $marker !== null;
        if ($order instanceof WC_Order && !$retrying) {
            // Durable before the carrier call: a crash after Geniki cancels must not leave a printable row.
            VoucherCancellationMarker::mark($order, $voucherId, $voucherNo, $courier);
        }

        $provider = $this->courierRegistry->get($courier);
        $cancelled = true;
        $anyCancelled = false;
        try {
            // Geniki cancels the shipment job, which includes all its child vouchers.
            $numbers = $courier === CourierSlug::Geniki ? [$voucherNo] : ShippingOptions::voucherNumbers($row);
            foreach ($numbers as $number) {
                $ok = $provider->cancelVoucher($number);
                $anyCancelled = $anyCancelled || $ok;
                $cancelled = $ok && $cancelled;
            }
        } catch (\Throwable $e) {
            if ($retrying || $anyCancelled || $this->isAmbiguousCarrierCall($e)) {
                $this->logger->error(sprintf(
                    'Voucher cancellation for voucher #%d has an unknown carrier outcome; the cancel-pending marker is retained.',
                    $voucherId
                ));
                throw $e;
            }
            if ($order instanceof WC_Order) {
                VoucherCancellationMarker::clear($order, $voucherId);
            }
            throw $e;
        }

        if (!$cancelled) {
            if ($retrying || $anyCancelled) {
                // The carrier may have cancelled it on the earlier attempt and now refuse a repeat.
                $this->logger->warning(sprintf(
                    'Voucher #%d cancellation was refused (retry, or after another voucher number was already cancelled); the cancel-pending marker is retained until the carrier state is confirmed.',
                    $voucherId
                ));
                return false;
            }
            if ($order instanceof WC_Order) {
                VoucherCancellationMarker::clear($order, $voucherId);
            }
            return false;
        }

        $transitioned = $this->repository->transition(
            $voucherId,
            VoucherState::Created,
            VoucherState::Cancelled
        );

        if (!$transitioned) {
            // The carrier cancelled it but the local row did not move: keep the marker so the voucher
            // cannot be printed as active, and leave the discrepancy for reconciliation.
            $this->logger->error(sprintf(
                'Courier confirmed cancellation for voucher #%d but the local created -> cancelled transition failed; the cancel-pending marker is retained.',
                $voucherId
            ));
            return false;
        }

        if ($order instanceof WC_Order) {
            VoucherCancellationMarker::clear($order, $voucherId);
        }
        $this->clearCancelledOrderState($row);
        if (function_exists('do_action')) {
            do_action('grcs/voucher/cancelled', $voucherId, (int) $row['order_id']);
        }

        return true;
    }

    /**
     * Operator confirmed at the carrier that the pending cancellation did complete.
     *
     * This is the only path that may move `created -> cancelled` without a carrier call: the marker exists
     * precisely because the carrier call could not prove its outcome. Side effects are identical to a normal
     * cancellation (state transition, marker clear, order state cleanup, `grcs/voucher/cancelled` hook).
     */
    public function finalizeConfirmedCancellation(int $voucherId, string $reason = ''): bool
    {
        $trimmedReason = trim($reason);
        if ($trimmedReason === '') {
            throw new InvalidArgumentException(AdminLocale::__('A non-empty reason is required when confirming a cancellation at the carrier.', 'gr-commerce-suite'));
        }

        $row = $this->repository->findById($voucherId);
        if ($row === null) {
            return false;
        }
        $orderId = (int) $row['order_id'];
        $token = VoucherOperationLock::acquire($orderId);
        try {
            $row = $this->repository->findById($voucherId);
            if ($row === null || VoucherState::tryFrom((string) $row['state']) !== VoucherState::Created) {
                return false;
            }
            $order = function_exists('wc_get_order') ? wc_get_order($orderId) : null;
            if (!$order instanceof WC_Order || !VoucherCancellationMarker::isPending($order, $voucherId)) {
                return false;
            }
            if (!$this->repository->transition($voucherId, VoucherState::Created, VoucherState::Cancelled)) {
                return false;
            }
            $numbers = ShippingOptions::voucherNumbers($row);
            VoucherCancellationMarker::clear($order, $voucherId);
            $order->add_order_note(sprintf(
                AdminLocale::__('GR Commerce Suite: Operator confirmed courier cancellation of voucher %1$s. Reason: %2$s', 'gr-commerce-suite'),
                implode(', ', $numbers),
                $trimmedReason
            ));
            $order->save();
            $this->clearCancelledOrderState($row);
            if (function_exists('do_action')) {
                do_action('grcs/voucher/cancelled', $voucherId, $orderId);
            }
            $this->logger->info(sprintf(
                'Operator confirmed cancellation for voucher #%d (order #%d). Reason: %s',
                $voucherId,
                $orderId,
                $trimmedReason
            ));

            return true;
        } finally {
            VoucherOperationLock::release($orderId, $token);
        }
    }

    /**
     * Operator confirmed at the carrier that the shipment is still active: clear the marker only.
     *
     * The voucher row is untouched (`created`) and becomes printable/active again. No carrier call is made.
     */
    public function restoreAfterCancellationRefused(int $voucherId, string $reason = ''): bool
    {
        $trimmedReason = trim($reason);
        if ($trimmedReason === '') {
            throw new InvalidArgumentException(AdminLocale::__('A non-empty reason is required when confirming the voucher is still active at the carrier.', 'gr-commerce-suite'));
        }

        $row = $this->repository->findById($voucherId);
        if ($row === null) {
            return false;
        }
        $orderId = (int) $row['order_id'];
        $token = VoucherOperationLock::acquire($orderId);
        try {
            $row = $this->repository->findById($voucherId);
            if ($row === null || VoucherState::tryFrom((string) $row['state']) !== VoucherState::Created) {
                return false;
            }
            $order = function_exists('wc_get_order') ? wc_get_order($orderId) : null;
            if (!$order instanceof WC_Order || !VoucherCancellationMarker::isPending($order, $voucherId)) {
                return false;
            }
            VoucherCancellationMarker::clear($order, $voucherId);
            $order->add_order_note(sprintf(
                AdminLocale::__('GR Commerce Suite: Operator confirmed the courier still has voucher %1$s active; the pending cancellation marker was cleared. Reason: %2$s', 'gr-commerce-suite'),
                (string) ($row['voucher_no'] ?? ''),
                $trimmedReason
            ));
            $order->save();
            $this->logger->info(sprintf(
                'Operator confirmed voucher #%d (order #%d) is still active; cancellation marker cleared. Reason: %s',
                $voucherId,
                $orderId,
                $trimmedReason
            ));

            return true;
        } finally {
            VoucherOperationLock::release($orderId, $token);
        }
    }

    /** A timeout or dropped connection after transmission may have cancelled the shipment at the carrier. */
    private function isAmbiguousCarrierCall(\Throwable $error): bool
    {
        if ($error instanceof \GRCommerceSuite\Exceptions\Courier\CourierAmbiguousResultException) {
            return true;
        }
        if ($error instanceof \GRCommerceSuite\Exceptions\Courier\CourierTransportException) {
            if ($error->failedBeforeTransmission() !== null) {
                return $error->failedBeforeTransmission() === false;
            }
            return $this->looksLikePostTransmissionTimeout($error->getMessage());
        }

        return $this->looksLikePostTransmissionTimeout($error->getMessage());
    }

    private function looksLikePostTransmissionTimeout(string $message): bool
    {
        $lower = strtolower($message);

        return str_contains($lower, 'timed out')
            || str_contains($lower, 'timeout')
            || str_contains($lower, 'connection reset')
            || str_contains($lower, 'empty reply from server');
    }

    /** @param array<string, mixed> $row */
    private function clearCancelledOrderState(array $row): void
    {
        $order = function_exists('wc_get_order') ? wc_get_order((int) $row['order_id']) : null;
        if (!$order instanceof WC_Order) {
            return;
        }
        $numbers = ShippingOptions::voucherNumbers($row);
        $noteKey = '_grcs_cancelled_voucher_' . (int) $row['id'];
        if (!$order->get_meta($noteKey, true)) {
            $order->add_order_note(sprintf(AdminLocale::__('GR Commerce Suite (%1$s): Voucher %2$s cancelled.', 'gr-commerce-suite'),
                CourierSlug::from((string) $row['courier_slug'])->label(), implode(', ', $numbers)));
            $order->update_meta_data($noteKey, 'yes');
        }
        // Retain table rows/snapshots as history; never clear a newer voucher on repeated cancellation.
        if (in_array((string) $order->get_meta('_grcs_voucher_no', true), $numbers, true)) {
            $order->delete_meta_data('_grcs_voucher_no');
        }
        if ($order->get_meta('_grcs_active_idempotency_key', true) === ($row['idempotency_key'] ?? null)) {
            $order->delete_meta_data('_grcs_active_idempotency_key');
        }
        if (in_array((string) $order->get_meta('_grcs_last_voucher_no', true), $numbers, true)) {
            $order->delete_meta_data('_grcs_last_voucher_no');
            $order->delete_meta_data('_grcs_last_courier');
        }
        $order->save();
    }
}
