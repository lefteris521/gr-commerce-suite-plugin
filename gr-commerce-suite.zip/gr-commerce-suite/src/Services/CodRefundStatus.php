<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Domain\Tracking\TrackingStatus;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Support\Money;
use WC_Order;

/**
 * How a WooCommerce refund relates to a cash-on-delivery order's courier collection.
 *
 * Presentation only: the courier's collection and settlement history and every COD total stay
 * exactly as recorded. This explains a refund next to that history, and warns when an active
 * voucher would still have the courier collect more cash than the order now owes.
 */
final class CodRefundStatus
{
    /**
     * @param list<array<string, mixed>> $vouchers The order's voucher rows (any state).
     * collected_cents sums recorded amounts only; it can be a partial total when other rows are unknown.
     * reconciled means at least one recorded collection is reconciled, not that every voucher is settled.
     * @return array{refunded_cents: int, full: bool, collected_cents: int|null, reconciled: bool, note: string, warning: string}
     */
    public static function describe(WC_Order $order, array $vouchers): array
    {
        $refunded = self::cents((float) $order->get_total_refunded());
        $total = self::cents((float) $order->get_total());
        $result = ['refunded_cents' => $refunded, 'full' => $refunded > 0 && $refunded >= $total,
            'collected_cents' => null, 'reconciled' => false, 'note' => '', 'warning' => ''];
        if ($refunded <= 0 || $order->get_payment_method() !== 'cod') {
            return $result;
        }

        $active = null;
        $activeCount = 0;
        $hasUnknownCollection = false;
        $needsVoucherReview = false;
        foreach ($vouchers as $voucher) {
            if (($voucher['state'] ?? '') !== 'created') {
                continue;
            }
            $active ??= $voucher;
            $activeCount++;
            if (($voucher['cod_collected'] ?? null) !== null && (string) $voucher['cod_collected'] !== '') {
                $result['collected_cents'] = (int) $result['collected_cents'] + Money::fromDecimalString((string) $voucher['cod_collected'])->cents();
                $result['reconciled'] = $result['reconciled'] || (int) ($voucher['cod_reconciled'] ?? 0) === 1;
            } else {
                $hasUnknownCollection = true;
                $needsVoucherReview = $needsVoucherReview || (
                    (int) ($voucher['cod_reconciled'] ?? 0) !== 1
                    && Money::fromDecimalString((string) ($voucher['cod_amount'] ?? '0.00'))->cents() > 0
                    && !in_array($voucher['tracking_status'] ?? '', ['delivered', 'returning', 'returned'], true)
                );
            }
        }

        $refundText = sprintf($result['full']
            ? AdminLocale::__('Fully refunded (€%s).', 'gr-commerce-suite')
            : AdminLocale::__('Partially refunded (€%s).', 'gr-commerce-suite'), Money::fromCents($refunded)->toDecimalString());

        if ($result['collected_cents'] !== null) {
            $result['note'] = $refundText . ' ' . sprintf(AdminLocale::__('The courier collected €%s, which stays in the COD records; the refund was paid to the customer separately.', 'gr-commerce-suite'),
                Money::fromCents($result['collected_cents'])->toDecimalString());
            if ($hasUnknownCollection) {
                $result['note'] .= ' ' . AdminLocale::__('Other vouchers have no recorded collection; their amounts remain unknown and are not included in this recorded total.', 'gr-commerce-suite');
            }
            if ($needsVoucherReview) {
                // Refunds have no voucher allocation: flag review without deriving a collectible balance.
                $result['warning'] = $result['note'] . ' ' . AdminLocale::__('Review each active voucher before delivery: the refund is not allocated to individual vouchers. Confirm the collection amount with the courier.', 'gr-commerce-suite');
            }
            return $result;
        }

        if ($activeCount > 1) {
            // No first-row inference about delivery, returns or a per-voucher refund balance.
            $result['note'] = $refundText . ' ' . AdminLocale::__('No courier cash collection is recorded for this order.', 'gr-commerce-suite');
            if ($needsVoucherReview) {
                $result['warning'] = $result['note'] . ' ' . AdminLocale::__('Review each active voucher before delivery: the refund is not allocated to individual vouchers. Confirm the collection amount with the courier.', 'gr-commerce-suite');
            }
            return $result;
        }

        $expected = $active !== null ? Money::fromDecimalString((string) ($active['cod_amount'] ?? '0.00'))->cents() : 0;
        $balance = max(0, $total - $refunded);
        if ((int) ($active['cod_reconciled'] ?? 0) === 1) {
            $result['note'] = $refundText . ' ' . AdminLocale::__('No courier cash collection is recorded for this order.', 'gr-commerce-suite');
        } elseif ($expected > 0 && ($active['tracking_status'] ?? '') === 'delivered') {
            $result['note'] = $refundText . ' ' . sprintf(AdminLocale::__('The parcel was delivered, so the courier probably collected €%s; that remittance has not been recorded yet.', 'gr-commerce-suite'),
                Money::fromCents($expected)->toDecimalString());
        } elseif ($expected > $balance && in_array($active['tracking_status'] ?? '', ['returning', 'returned'], true)) {
            $result['note'] = $refundText . ' ' . AdminLocale::__('The parcel is coming back to you, so the courier will not collect the voucher amount.', 'gr-commerce-suite');
        } elseif ($expected > $balance) {
            // The next step depends on whether the voucher can still be cancelled from the order screen.
            $result['warning'] = $refundText . ' ' . sprintf(TrackingStatus::notYetShipped((string) ($active['tracking_status'] ?? 'pending'))
                ? AdminLocale::__('The active voucher still asks the courier to collect €%1$s, but the order now owes €%2$s. Cancel the voucher, or reissue it with the correct amount, before delivery.', 'gr-commerce-suite')
                : AdminLocale::__('The active voucher still asks the courier to collect €%1$s, but the order now owes €%2$s. The parcel is already with the courier: contact them to change the amount or stop delivery.', 'gr-commerce-suite'),
                Money::fromCents($expected)->toDecimalString(), Money::fromCents($balance)->toDecimalString());
        } else {
            $result['note'] = $refundText . ' ' . AdminLocale::__('No courier cash collection is recorded for this order.', 'gr-commerce-suite');
        }
        return $result;
    }

    private static function cents(float $amount): int
    {
        return (int) round($amount * 100);
    }
}
