<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Support\Lock;
use RuntimeException;

/** Short order-wide guard, backed by an atomic option mutex (transients alone are not atomic). */
final class VoucherOperationLock
{
    public static function acquire(int $orderId): string
    {
        $name = 'voucher_order_' . $orderId;
        if (!Lock::acquire($name, 30)) {
            throw new RuntimeException(__('A voucher operation is already in progress for this order. Please wait a moment.', 'gr-commerce-suite'));
        }
        $key = 'grcs_voucher_lock_' . $orderId;
        try {
            if (get_transient($key) !== false) {
                throw new RuntimeException(__('A voucher operation is already in progress for this order. Please wait a moment.', 'gr-commerce-suite'));
            }
            $token = bin2hex(random_bytes(16));
            set_transient($key, $token, 30);
            return $token;
        } catch (\Throwable $error) {
            Lock::release($name);
            throw $error;
        }
    }

    public static function release(int $orderId, string $token): void
    {
        if (get_transient('grcs_voucher_lock_' . $orderId) === $token) {
            delete_transient('grcs_voucher_lock_' . $orderId);
        }
        Lock::release('voucher_order_' . $orderId);
    }
}
