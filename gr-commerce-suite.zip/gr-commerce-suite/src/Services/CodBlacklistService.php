<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\I18n\AdminLocale;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Domain\Tracking\TrackingStatus;
use GRCommerceSuite\Database\Repositories\CodBlacklistRepository;
use GRCommerceSuite\Database\PreparedQuery;
use GRCommerceSuite\Database\Repositories\OptionLockRepository;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Jobs\JobDispatcher;
use GRCommerceSuite\Frontend\BoxNowCheckoutPicker;
use GRCommerceSuite\Support\Lock;
use RuntimeException;
use WC_Order;

/**
 * Indexed, non-autoloaded identities keyed by a salted digest (GRCS-008). Records store digests
 * plus masked display values only; legacy unsalted phone/email keys are read as a fallback and
 * moved on touch or by the batched key migration.
 */
final class CodBlacklistService implements HookSubscriberInterface
{
    public const OPTION_PREFIX = 'grcs_cod_blacklist_';
    public const OPTION_NOTICE = 'grcs_cod_blacklist_notice';
    public const RETRY_HOOK = 'grcs/cod/blacklist_retry';
    public const OPTION_RULES = 'grcs_cod_blacklist_rules';
    // Not under a phone_/email_/ip_ prefix, so registry queries and diagnostics never count it.
    public const OPTION_KEY_MIGRATION = 'grcs_cod_blacklist_keymigration';
    public const KEY_MIGRATION_HOOK = 'grcs/cod/blacklist_key_migration';
    public const KEY_VERSION = 2;
    private const KEY_MIGRATION_BATCH = 100;

    /** @return array{strategy: string, min_failures: int, trusted_orders: int, expiry_days: int} */
    public static function rules(): array
    {
        $saved = get_option(self::OPTION_RULES, []);
        return self::sanitizeRules(is_array($saved) ? $saved : []);
    }

    /** @param array<string, mixed> $rules
     * @return array{strategy: string, min_failures: int, trusted_orders: int, expiry_days: int}
     */
    public static function sanitizeRules(array $rules): array
    {
        $strategy = is_string($rules['strategy'] ?? null) ? $rules['strategy'] : '';
        return [
            'strategy' => in_array($strategy, ['phone_email_ip', 'phone_email', 'phone', 'email'], true)
                ? $strategy : 'phone_email_ip',
            'min_failures' => max(1, min(10, (int) ($rules['min_failures'] ?? 1))),
            'trusted_orders' => max(0, min(10000, (int) ($rules['trusted_orders'] ?? 0))),
            'expiry_days' => max(1, min(3650, (int) ($rules['expiry_days'] ?? 90))),
        ];
    }

    /** @return array<string, string> */
    public static function reasons(bool $admin = false): array
    {
        $translate = $admin ? [AdminLocale::class, '__'] : '__';
        return [
            'REFUSED' => $translate('Άρνηση Παραλαβής', 'gr-commerce-suite'),
            'WRONG_ADDRESS' => $translate('Λάθος Διεύθυνση', 'gr-commerce-suite'),
            'RECIPIENT_NOT_FOUND' => $translate('Δεν Βρέθηκε', 'gr-commerce-suite'),
            'RETURNED' => $translate('Επιστροφή', 'gr-commerce-suite'),
            'FAILED_DELIVERY' => $translate('Αποτυχία Παράδοσης', 'gr-commerce-suite'),
        ];
    }

    /** Canonicalize IPv4/IPv6, then retain only a keyed digest (also accepts a stored digest). */
    public static function hashIp(string $ip): string
    {
        if (preg_match('/^[a-f0-9]{64}$/D', $ip) === 1) {
            return $ip;
        }
        if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
            return '';
        }
        $packed = inet_pton($ip);
        return $packed === false ? '' : hash_hmac('sha256', $packed, wp_salt('auth'));
    }

    /**
     * Keyed digest of a phone/email/IP. A stored digest passes through only for trusted callers
     * (admin registry round-trips, stored records); checkout input is always hashed, so a
     * customer typing a digest never matches someone else's entry.
     */
    public static function identityDigest(string $type, string $value, bool $acceptDigest = false): string
    {
        // Checked before normalizing: normalizePhone() would strip a digest's leading "0030".
        if ($acceptDigest && self::isDigest($value)) {
            return $value;
        }
        if ($type === 'ip') {
            return self::hashIp($value);
        }
        $value = match ($type) {
            'phone' => self::normalizePhone($value), 'email' => self::normalizeEmail($value), default => '',
        };
        // wp_salt() is pluggable and always loaded before hooks run; the guard only serves non-WordPress contexts.
        return $value === '' ? '' : hash_hmac('sha256', $value, function_exists('wp_salt') ? wp_salt('auth') : '');
    }

    private static function isDigest(string $value): bool
    {
        return preg_match('/^[a-f0-9]{64}$/D', $value) === 1;
    }

    /** Non-reversible display form kept for the admin registry. */
    public static function maskIdentity(string $type, string $value): string
    {
        if ($type === 'phone') {
            $value = self::normalizePhone($value);
            return strlen($value) > 4 ? substr($value, 0, 2) . str_repeat('*', strlen($value) - 4) . substr($value, -2) : '****';
        }
        if ($type === 'ip') {
            if (filter_var($value, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $parts = explode('.', $value);
                return $parts[0] . '.' . $parts[1] . '.*.*';
            }
            return '***';
        }
        $value = self::normalizeEmail($value);
        $at = strrpos($value, '@');
        return $at === false || $at === 0 ? '***' : substr($value, 0, 1) . '***' . substr($value, $at);
    }

    /**
     * Replace raw phone/email (current and legacy fields) with digests plus masked display copies.
     * @param array<string, mixed> $record
     * @return array<string, mixed>
     */
    private static function scrub(array $record, string $type): array
    {
        if ($record === [] || ($record['kv'] ?? 0) === self::KEY_VERSION) {
            return $record;
        }
        foreach (['phone', 'email'] as $field) {
            $raw = is_string($record[$field] ?? null) ? trim($record[$field]) : '';
            if ($raw === '' && $type === $field && is_string($record['value'] ?? null)) {
                $raw = trim($record['value']);
            }
            if ($raw !== '' && !self::isDigest($raw)) {
                $record[$field . '_masked'] = self::maskIdentity($field, $raw);
            }
            $record[$field] = $raw === '' ? '' : self::identityDigest($field, $raw, true);
        }
        $record['ip'] = self::hashIp(is_string($record['ip'] ?? null) ? $record['ip'] : '');
        $record['value'] = $type === 'ip' ? self::hashIp(is_string($record['value'] ?? null) ? $record['value'] : '')
            : $record[$type];
        $record['kv'] = self::KEY_VERSION;
        return $record;
    }

    public static function clientIp(): string
    {
        return class_exists(\WC_Geolocation::class) ? \WC_Geolocation::get_ip_address() : '';
    }

    public function __construct(
        private readonly ?VoucherRepository $repository = null,
        private readonly ?JobDispatcher $jobs = null,
    ) {
    }

    public function register(): void
    {
        LicenseManager::assertLicensed();
        $this->registerCheckoutHooks();
        add_action('grcs/tracking/status_changed', [$this, 'handleTrackingStatusChanged'], 10, 4);
        add_action('grcs/tracking/updated', [$this, 'handleVoucherTrackingUpdated'], 10, 2);
        add_action(self::RETRY_HOOK, [$this, 'handleRetry']);
        add_action(self::KEY_MIGRATION_HOOK, [$this, 'handleKeyMigration']);
        add_action('admin_init', [$this, 'scheduleKeyMigration']);
    }

    public function registerCheckoutHooks(): void
    {
        add_filter('woocommerce_available_payment_gateways', [$this, 'filterPaymentGateways'], 100);
        add_action('woocommerce_checkout_process', [$this, 'validateCheckout']);
        // Validate final billing details too (including Store API checkout).
        add_action('woocommerce_checkout_create_order', [$this, 'validateOrderPayment'], 20);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'validateOrderPayment'], 20, 2);
    }

    public static function normalizePhone(string $phone): string
    {
        $phone = preg_replace('/[\s.()\-]+/u', '', trim($phone)) ?? '';
        // "30 69..." typed without "+" must hash to the same 10-digit identity.
        return preg_replace('/^(?:\+30|0030|30(?=[0-9]{10}$))/D', '', $phone) ?? '';
    }

    public function handleVoucherTrackingUpdated(int $voucherId, TrackingStatus $status): void
    {
        LicenseManager::assertLicensed();
        if (!in_array($status, [TrackingStatus::Returned, TrackingStatus::DeliveryFailed], true) || $this->repository === null) {
            return;
        }
        $row = $this->repository->findById($voucherId);
        if ($row !== null && ($row['state'] ?? '') === 'created') {
            $this->handleTrackingStatusChanged($voucherId, '', $status, (int) $row['order_id']);
        }
    }

    public static function normalizeEmail(string $email): string
    {
        return strtolower(trim($email));
    }

    /** @param array<string, mixed> $payload */
    public function handleRetry(array $payload): void
    {
        $this->handleTrackingStatusChanged(
            (int) $payload['voucher_id'],
            '',
            (string) $payload['status'],
            (int) $payload['order_id']
        );
    }

    /**
     * @param bool $acceptDigest true only for trusted callers passing a stored digest
     * @return array<string, mixed>
     */
    public function getRecord(string $type, string $value, bool $acceptDigest = false): array
    {
        LicenseManager::assertLicensed();
        $key = $this->key($type, $value, $acceptDigest);
        if ($key === '') {
            return [];
        }
        $record = $this->storedRecord($key);
        if ($record !== [] || !$this->legacyKeysMayExist()) {
            return $this->resolve($record, $type);
        }
        $legacy = $this->storedRecord($this->legacyKey($type, $value));
        if ($legacy === []) {
            // A concurrent migration may have written the keyed copy and deleted the legacy one
            // between the two reads; re-read the keyed name from the database before allowing COD.
            return $this->resolve($this->freshRecord($key), $type);
        }
        // Rewrite on touch; a busy lock still returns the legacy record so it keeps blocking.
        if (!Lock::acquire($key, 30)) {
            return $this->resolve($legacy, $type);
        }
        try {
            return $this->migrateLegacy($type, $value, true, $acceptDigest);
        } finally {
            Lock::release($key);
        }
    }

    /** @return array<string, mixed> */
    private function storedRecord(string $key): array
    {
        $record = $key !== '' ? get_option($key, []) : [];
        return is_array($record) ? $record : [];
    }

    /**
     * Uncached read: this request's notoptions cache would hide a row another request just wrote.
     * @return array<string, mixed>
     */
    private function freshRecord(string $key): array
    {
        $raw = OptionLockRepository::get($key);
        if ($raw === null) {
            return $this->storedRecord($key);
        }
        $record = maybe_unserialize($raw);
        return is_array($record) ? $record : [];
    }

    /**
     * Scrub a record. While its raw linked phone/email are still in hand, move their legacy keys
     * first: once callers carry only digests, a legacy key can no longer be derived, and a fresh
     * keyed record would shadow (and later delete) a still-blocking legacy one.
     * @param array<string, mixed> $record
     * @return array<string, mixed>
     */
    private function resolve(array $record, string $type, bool $linked = true): array
    {
        if ($linked && $record !== [] && ($record['kv'] ?? 0) !== self::KEY_VERSION && $this->legacyKeysMayExist()) {
            foreach (['phone', 'email'] as $field) {
                $raw = is_string($record[$field] ?? null) ? trim($record[$field]) : '';
                if ($field === $type || $raw === '' || self::isDigest($raw)
                    || $this->storedRecord($this->legacyKey($field, $raw)) === []) {
                    continue;
                }
                $key = $this->key($field, $raw);
                // Non-blocking and one level deep; a busy linked key moves on its own next touch.
                if ($key !== '' && Lock::acquire($key, 30)) {
                    try {
                        $this->migrateLegacy($field, $raw, false);
                    } finally {
                        Lock::release($key);
                    }
                }
            }
        }
        return self::scrub($record, $type);
    }

    /**
     * Move a legacy unsalted record to its keyed name. Caller holds the new key's lock.
     * @return array<string, mixed> the authoritative record (new key if present, otherwise legacy)
     */
    private function migrateLegacy(string $type, string $value, bool $linked = true, bool $acceptDigest = false): array
    {
        $key = $this->key($type, $value, $acceptDigest);
        $legacyKey = $this->legacyKey($type, $value);
        $current = $this->storedRecord($key);
        $legacy = $this->storedRecord($legacyKey);
        if ($current !== []) {
            if ($legacy !== []) {
                delete_option($legacyKey); // The keyed record already supersedes it.
            }
            return $this->resolve($current, $type, $linked);
        }
        if ($legacy === []) {
            return [];
        }
        $record = $this->resolve($legacy, $type, $linked);
        update_option($key, $record, false);
        // Delete only after the keyed copy is confirmed, so the customer is never briefly unblocked.
        if ($this->storedRecord($key) !== []) {
            delete_option($legacyKey);
        }
        return $record;
    }

    /** False only once the batch finished with nothing left behind; the state option is autoloaded. */
    private function legacyKeysMayExist(): bool
    {
        $state = $this->migrationState();
        return empty($state['done']) || (int) ($state['skipped'] ?? 0) > 0;
    }

    /**
     * Migration state; a completed run counts as unfinished once the plugin version changes, since a
     * downgraded release may have written legacy keys again. The cursor is kept: re-created legacy
     * rows get new option_ids, so the resumed scan only covers rows written after the last run.
     * @return array<string, mixed>
     */
    private function migrationState(): array
    {
        $state = get_option(self::OPTION_KEY_MIGRATION, []);
        $state = is_array($state) ? $state : [];
        if (!empty($state['done']) && ($state['version'] ?? null) !== self::pluginVersion()) {
            $state['done'] = false;
        }
        return $state;
    }

    private static function pluginVersion(): string
    {
        return defined('GRCS_VERSION') ? (string) constant('GRCS_VERSION') : '';
    }

    /** Pre-GRCS-008 name (unsalted SHA-256 of the normalized identity); derivable only from raw input. */
    private function legacyKey(string $type, string $value): string
    {
        if (!in_array($type, ['phone', 'email'], true)) {
            return '';
        }
        $value = $type === 'phone' ? self::normalizePhone($value) : self::normalizeEmail($value);
        if ($value === '' || self::isDigest($value)) {
            return '';
        }
        return self::OPTION_PREFIX . $type . '_' . hash('sha256', $value);
    }

    public function scheduleKeyMigration(): void
    {
        if ($this->jobs === null || !empty($this->migrationState()['done'])) {
            return;
        }
        $this->jobs->scheduleSingle(time() + 60, self::KEY_MIGRATION_HOOK, []);
    }

    /** @param array<string, mixed> $payload */
    public function handleKeyMigration(array $payload = []): void
    {
        $this->runKeyMigration($payload);
    }

    /**
     * One resumable batch of the legacy key migration (cursor on option_id, global lock).
     * Rows whose raw identity cannot be recovered stay in place; they keep blocking via the
     * legacy-key fallback and move on the next touch.
     * @param array<string, mixed> $payload
     * @return array{migrated: int, skipped: int, done: bool}
     */
    public function runKeyMigration(array $payload = []): array
    {
        global $wpdb;
        $result = ['migrated' => 0, 'skipped' => 0, 'done' => false];
        if (!empty($this->migrationState()['done'])) {
            return ['done' => true] + $result;
        }
        if (!$wpdb instanceof \wpdb || !Lock::acquire(self::OPTION_KEY_MIGRATION, 300)) {
            return $result;
        }
        try {
            // Re-read under the lock: a run that finished meanwhile moved the cursor.
            $state = $this->migrationState();
            $cursor = (int) ($state['cursor'] ?? 0);
            $rows = $wpdb->get_results(PreparedQuery::prepare(
                $wpdb,
                'SELECT option_id, option_name FROM %i WHERE option_id > %d'
                . ' AND (option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s)'
                . ' ORDER BY option_id ASC LIMIT %d',
                $wpdb->options,
                $cursor,
                $wpdb->esc_like(self::OPTION_PREFIX . 'phone_') . '%',
                $wpdb->esc_like(self::OPTION_PREFIX . 'email_') . '%',
                $wpdb->esc_like(self::OPTION_PREFIX . 'ip_') . '%',
                self::KEY_MIGRATION_BATCH
            ), 'ARRAY_A');
            $rows = is_array($rows) ? $rows : [];
            $complete = count($rows) < self::KEY_MIGRATION_BATCH;
            foreach ($rows as $row) {
                if (!is_array($row) || !is_numeric($row['option_id'] ?? null) || !is_string($row['option_name'] ?? null)) {
                    continue;
                }
                $outcome = $this->migrateRow($row['option_name']);
                if ($outcome === 'busy') {
                    $complete = false; // Retry this row next batch.
                    break;
                }
                $cursor = (int) $row['option_id'];
                if ($outcome !== 'current') {
                    ++$result[$outcome];
                }
            }
            $state = ['cursor' => $cursor, 'done' => $complete,
                'migrated' => (int) ($state['migrated'] ?? 0) + $result['migrated'],
                'skipped' => (int) ($state['skipped'] ?? 0) + $result['skipped'], 'version' => self::pluginVersion()];
            update_option(self::OPTION_KEY_MIGRATION, $state, true);
            $result['done'] = $complete;
        } finally {
            Lock::release(self::OPTION_KEY_MIGRATION);
        }
        if (!$result['done'] && $this->jobs !== null) {
            // Not unique: this action is still running; the global lock already prevents overlap.
            $this->jobs->scheduleSingle(time() + 30, self::KEY_MIGRATION_HOOK, [], false);
        }
        return $result;
    }

    /** @return 'migrated'|'skipped'|'current'|'busy' */
    private function migrateRow(string $name): string
    {
        $record = $this->storedRecord($name);
        if ($record === [] || ($record['kv'] ?? 0) === self::KEY_VERSION) {
            return 'current';
        }
        $type = str_starts_with($name, self::OPTION_PREFIX . 'phone_') ? 'phone'
            : (str_starts_with($name, self::OPTION_PREFIX . 'email_') ? 'email' : 'ip');
        if ($type === 'ip') {
            // IP names were already keyed; only the value carries raw phone/email.
            if (!Lock::acquire($name, 30)) {
                return 'busy';
            }
            try {
                $current = $this->storedRecord($name);
                if ($current !== []) {
                    update_option($name, $this->resolve($current, 'ip'), false);
                }
            } finally {
                Lock::release($name);
            }
            return ($this->storedRecord($name)['kv'] ?? 0) === self::KEY_VERSION ? 'migrated' : 'skipped';
        }
        $raw = '';
        foreach ([$record[$type] ?? null, $record['value'] ?? null] as $candidate) {
            if ($raw === '' && is_string($candidate) && trim($candidate) !== '' && !self::isDigest(trim($candidate))) {
                $raw = trim($candidate);
            }
        }
        // Only move a row whose stored identity provably produced its name. Others stay under their
        // legacy name (still found by the fallback) but lose any raw phone/email in their value.
        if ($raw === '' || $this->legacyKey($type, $raw) !== $name) {
            if (!Lock::acquire($name, 30)) {
                return 'busy';
            }
            try {
                $current = $this->storedRecord($name);
                if ($current !== []) {
                    update_option($name, $this->resolve($current, $type), false);
                }
            } finally {
                Lock::release($name);
            }
            return 'skipped';
        }
        $key = $this->key($type, $raw);
        if (!Lock::acquire($key, 30)) {
            return 'busy';
        }
        try {
            $this->migrateLegacy($type, $raw);
        } finally {
            Lock::release($key);
        }
        // A failed write must stay counted: skipped > 0 keeps the legacy fallback switched on.
        return $this->storedRecord($name) === [] ? 'migrated' : 'skipped';
    }

    public function isBlacklisted(string $phone, string $email, string $ip = '', int $customerId = 0): bool
    {
        $start = hrtime(true);
        $blocked = $this->checkBlacklisted($phone, $email, $ip, $customerId);
        (new DiagnosticLogger())->record($blocked ? 'WARNING' : 'INFO', 'BLACKLIST', 'Blacklist check completed.',
            ['action' => 'blacklist_check', 'duration_ms' => (hrtime(true) - $start) / 1e6,
                'response_data' => ['blocked' => $blocked]]);
        return $blocked;
    }

    private function checkBlacklisted(string $phone, string $email, string $ip, int $customerId): bool
    {
        LicenseManager::assertLicensed();
        $rules = self::rules();
        $identities = ['phone' => $phone, 'email' => $email, 'ip' => $ip];
        $types = match ($rules['strategy']) {
            'phone' => ['phone'], 'email' => ['email'], 'phone_email' => ['phone', 'email'],
            default => ['phone', 'email', 'ip'],
        };
        $blocked = false;
        // A merchant whitelist always wins, even if the strategy later changes.
        foreach ($identities as $type => $value) {
            if ($value === '') {
                continue;
            }
            $record = $this->getRecord($type, $value);
            if (!empty($record['whitelisted'])) {
                return false;
            }
            $matches = $type !== 'ip' || $this->ipRecordMatchesCustomer($record, $phone, $email);
            $blocked = $blocked || ($matches && in_array($type, $types, true) && $this->recordBlocks($record));
        }
        if ($blocked && $customerId > 0 && $rules['trusted_orders'] > 0) {
            $history = wc_get_orders(['customer_id' => $customerId, 'status' => 'completed',
                'limit' => 1, 'paginate' => true, 'return' => 'ids']);
            if (is_object($history) && isset($history->total) && (int) $history->total >= $rules['trusted_orders']) {
                return false;
            }
        }
        return $blocked;
    }

    /**
     * An order's IP is context, not a customer identity (shared Wi-Fi / CGNAT).
     * @param array<string, mixed> $record
     */
    private function ipRecordMatchesCustomer(array $record, string $phone, string $email): bool
    {
        // Digests on both sides; unscrubbed legacy rows still hold the raw identity, which digests the same way.
        $linkedPhone = self::identityDigest('phone', is_string($record['phone'] ?? null) ? trim($record['phone']) : '', true);
        $linkedEmail = self::identityDigest('email', is_string($record['email'] ?? null) ? trim($record['email']) : '', true);
        if (($linkedPhone !== '' && $linkedPhone === self::identityDigest('phone', $phone))
            || ($linkedEmail !== '' && $linkedEmail === self::identityDigest('email', $email))) {
            return true;
        }
        // Retain explicit standalone network bans. Courier-generated records have failure events;
        // ambiguous old records with no linked identity must not become automatic network bans.
        return $linkedPhone === '' && $linkedEmail === '' && isset($record['refusals'])
            && $record['refusals'] === [] && empty($record['refusal_count']);
    }

    /** @param array<string, mixed> $record */
    public function recordBlocks(array $record): bool
    {
        if (empty($record['blocked']) || !empty($record['whitelisted'])) {
            return false;
        }
        if (isset($record['expires_at']) && (int) $record['expires_at'] <= time()) {
            return false;
        }
        return (int) ($record['failures'] ?? max(1, (int) ($record['refusal_count'] ?? 1))) >= self::rules()['min_failures'];
    }

    /**
     * Currently blacklisted phones/emails for the admin overview (newest first).
     *
     * `value` is `null` for records created before the normalized value was stored alongside
     * the hashed key; such entries can still be managed via "Check Customer".
     *
     * @return list<array{type: string, value: ?string, refusal_count: int}>
     */
    public function listBlacklisted(int $limit = 200): array
    {
        LicenseManager::assertLicensed();
        $rows = CodBlacklistRepository::findByPrefixes(
            self::OPTION_PREFIX . 'phone_',
            self::OPTION_PREFIX . 'email_',
            $limit
        );

        $entries = [];
        foreach ($rows as $row) {
            $record = function_exists('maybe_unserialize') ? maybe_unserialize($row['option_value']) : null;
            if (!is_array($record) || !$this->recordBlocks($record)) {
                continue;
            }
            $type = str_starts_with($row['option_name'], self::OPTION_PREFIX . 'phone_') ? 'phone' : 'email';
            $value = isset($record['value']) && is_string($record['value']) && $record['value'] !== ''
                ? $record['value']
                : null;
            $entries[] = [
                'type' => $type,
                'value' => $value,
                'refusal_count' => (int) ($record['refusal_count'] ?? 0),
            ];
        }

        return $entries;
    }

    /**
     * @param array<string, mixed> $details
     * @param bool $fromRegistry true only for the admin registry, whose rows post stored digests back
     */
    public function setCustomer(string $phone, string $email, bool $blocked, array $details = [], bool $fromRegistry = false): void
    {
        LicenseManager::assertLicensed();
        $this->writeCustomer($phone, $email, $blocked, $details + ['whitelisted' => false], null, false, $fromRegistry);
    }

    /**
     * @param array<string, mixed> $details
     * @param bool $fromRegistry true only for the admin registry, whose rows post stored digests back
     */
    public function whitelistCustomer(string $phone, string $email, bool $whitelisted, array $details = [], bool $fromRegistry = false): void
    {
        LicenseManager::assertLicensed();
        $this->writeCustomer($phone, $email, false, $details + ['whitelisted' => $whitelisted], null, true, $fromRegistry);
    }

    /** Save notes without changing the blocking/whitelist state or renewing expiry. */
    public function saveNote(string $phone, string $email, string $notes, string $ip = ''): void
    {
        LicenseManager::assertLicensed();
        $this->writeCustomer($phone, $email, false, ['notes' => $notes, 'ip' => $ip], null, true);
    }

    /** @param array<string, mixed> $details */
    private function writeCustomer(string $phone, string $email, bool $blocked, array $details = [], ?string $event = null, bool $preserveState = false, bool $fromRegistry = false): void
    {
        // Lookups keep the raw input (legacy keys derive from it); records only ever receive digests.
        $lookups = ['phone' => trim($phone), 'email' => trim($email), 'ip' => self::hashIp((string) ($details['ip'] ?? ''))];
        // Which lookups are trusted stored digests (registry input, or identities carried from a record).
        $trusted = ['phone' => $fromRegistry && self::isDigest($lookups['phone']),
            'email' => $fromRegistry && self::isDigest($lookups['email']), 'ip' => true];
        $identities = [];
        $masks = [];
        foreach ($lookups as $type => $value) {
            $identities[$type] = self::identityDigest($type, $value, $trusted[$type]);
            if ($type !== 'ip' && $identities[$type] !== '' && !$trusted[$type]) {
                $masks[$type . '_masked'] = self::maskIdentity($type, $value);
            }
        }
        // Carry linked identities into one-click actions, including actions made from an email lookup.
        foreach ($identities as $type => $value) {
            if ($value === '') {
                continue;
            }
            $existing = $this->getRecord($type, $lookups[$type], $trusted[$type]);
            if ($event !== null && isset($existing['refusals'][(int) ($details['legacy_voucher_id'] ?? 0)])) {
                return; // Legacy voucher-level tombstones also protect identities first seen after upgrading.
            }
            foreach ($identities as $other => $identity) {
                if ($identity === '' && is_string($existing[$other] ?? null) && $existing[$other] !== '') {
                    $identities[$other] = $lookups[$other] = $existing[$other];
                    $trusted[$other] = true;
                }
                if ($other !== 'ip' && !isset($masks[$other . '_masked']) && is_string($existing[$other . '_masked'] ?? null)
                    && $identities[$other] === $existing[$other]) {
                    $masks[$other . '_masked'] = $existing[$other . '_masked'];
                }
            }
        }
        unset($details['phone'], $details['email'], $details['phone_masked'], $details['email_masked'], $details['value']);
        $details = array_merge($details, $identities, $masks);
        foreach ($lookups as $type => $value) {
            if ($identities[$type] !== '') {
                $this->updateRecord($type, $value, $blocked, $event, $details, $preserveState, $trusted[$type]);
            }
        }
    }

    /** @return array{added: int, invalid: int} */
    public function bulkImport(string $text, string $reason, bool $whitelisted): array
    {
        LicenseManager::assertLicensed();
        $lines = preg_split('/\R/u', trim($text)) ?: [];
        if (count($lines) > 100 || strlen($text) > 30000) {
            throw new RuntimeException(__('Import up to 100 lines at a time.', 'gr-commerce-suite'));
        }
        $result = ['added' => 0, 'invalid' => 0];
        foreach ($lines as $line) {
            $parts = array_map('trim', explode(',', $line));
            $phone = '';
            $email = '';
            $valid = count($parts) <= 2;
            foreach ($parts as $part) {
                if ($part === '') {
                    continue;
                }
                if (filter_var($part, FILTER_VALIDATE_EMAIL) !== false && $email === '') {
                    $email = $part;
                } elseif (preg_match('/^\d{10}$/D', self::normalizePhone($part)) === 1 && $phone === '') {
                    $phone = $part;
                } else {
                    $valid = false;
                }
            }
            if (!$valid || ($phone === '' && $email === '')) {
                ++$result['invalid'];
                continue;
            }
            $this->setCustomer($phone, $email, !$whitelisted, ['reason' => $reason, 'whitelisted' => $whitelisted]);
            ++$result['added'];
        }
        return $result;
    }

    /** @return list<array<string, mixed>> */
    public function listEntries(string $search = '', string $courier = '', string $reason = '', string $status = ''): array
    {
        LicenseManager::assertLicensed();
        // Records hold digests, so a full phone/email search matches by digest (no partial matching).
        if (preg_match('/^[+0-9\s.()\-]+$/D', $search) === 1) {
            $search = self::identityDigest('phone', $search);
        } elseif (filter_var(trim($search), FILTER_VALIDATE_EMAIL) !== false) {
            $search = self::identityDigest('email', $search);
        }
        $entries = [];
        $offset = 0;
        do {
            $rows = CodBlacklistRepository::findEntries($search, $courier, $reason, $status, $offset);
            foreach ($rows as $row) {
                $record = maybe_unserialize($row['option_value']);
                if (!is_array($record) || (empty($record['blocked']) && empty($record['whitelisted']))) {
                    continue;
                }
                if (empty($record['whitelisted']) && isset($record['expires_at']) && (int) $record['expires_at'] <= time()) {
                    continue;
                }
                $type = str_starts_with($row['option_name'], self::OPTION_PREFIX . 'phone_') ? 'phone'
                    : (str_starts_with($row['option_name'], self::OPTION_PREFIX . 'email_') ? 'email' : 'ip');
                // Legacy rows may have an empty identity field alongside the normalized value.
                if (trim((string) ($record[$type] ?? '')) === '') {
                    $record[$type] = $record['value'] ?? '';
                }
                $record = self::scrub($record, $type);
                $key = (string) ($record['phone'] ?? '') . '|' . (string) ($record['email'] ?? '') . '|' . (string) ($record['ip'] ?? '');
                // Keep the newest copy of each linked customer across identity batches.
                $key = $key !== '||' ? $key : $row['option_name'];
                if (!isset($entries[$key])) {
                    $entries[$key] = $record;
                }
            }
            $offset += count($rows);
        } while (count($rows) === 600);
        return array_values($entries);
    }

    public function handleTrackingStatusChanged(
        int $voucherId,
        TrackingStatus|string $oldStatus,
        TrackingStatus|string $newStatus,
        int $orderId,
    ): void {
        LicenseManager::assertLicensed();
        $status = $newStatus instanceof TrackingStatus ? $newStatus->value : $newStatus;
        if (
            !in_array(
                mb_strtolower(
                    trim($status),
                    'UTF-8'
                ),
                ['returned',
                'refused',
                'delivery_failed',
                'failed_delivery',
                'wrong_address',
                'recipient_not_found',
                'επιστροφή',
                'άρνηση παραλαβής'],
                true
            )
        ) {
            return;
        }
        $order = wc_get_order($orderId);
        if (!$order instanceof WC_Order || $voucherId <= 0 || $order->get_payment_method() !== 'cod') {
            return;
        }
        try {
            $row = $this->repository?->findById($voucherId);
            $reason = match (mb_strtolower(trim($status), 'UTF-8')) {
                'refused', 'άρνηση παραλαβής' => 'REFUSED',
                'wrong_address' => 'WRONG_ADDRESS',
                'recipient_not_found' => 'RECIPIENT_NOT_FOUND',
                'delivery_failed', 'failed_delivery' => 'FAILED_DELIVERY',
                default => 'RETURNED',
            };
            $event = hash('sha256', $orderId . '|' . (string) ($row['voucher_no'] ?? $voucherId) . '|' . $reason);
            $this->writeCustomer($order->get_billing_phone(), $order->get_billing_email(), true, [
                'ip' => (string) $order->get_customer_ip_address(),
                'customer_name' => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
                'postal_code' => $order->get_billing_postcode(),
                'courier' => match ($row['courier_slug'] ?? '') {
                'acs' => 'ACS', 'boxnow' => 'BOX NOW', default => 'MANUAL'
                },
                'reason' => $reason,
                'legacy_voucher_id' => $voucherId,
            ], $event);
        } catch (RuntimeException $e) {
            if ($this->jobs === null) {
                throw $e;
            }
            $this->jobs->scheduleSingle(
                time() + 30,
                self::RETRY_HOOK,
                ['voucher_id' => $voucherId,
                 'status' => $status,
                'order_id' => $orderId]
            );
        }
    }

    /**
     * @param array<string, mixed> $gateways
     * @return array<string, mixed>
     */
    public function filterPaymentGateways(array $gateways): array
    {
        if (
            !BoxNowCheckoutPicker::isCheckoutRequest() ||
             !isset($gateways['cod']) ||
             (is_admin() &&
             !wp_doing_ajax())
        ) {
            return $gateways;
        }
        LicenseManager::assertLicensed();
        $customer = function_exists('WC') ? WC()->customer : null;
        $phone = $customer ? (string) $customer->get_billing_phone() : '';
        $email = $customer ? (string) $customer->get_billing_email() : '';
        $posted = wp_unslash($_POST);
        if (isset($_POST['post_data']) && is_string($_POST['post_data'])) {
            wp_parse_str(wp_unslash($_POST['post_data']), $posted);
        }
        // Explicit empty fields must replace stale session data.
        if (isset($posted['billing_phone']) && is_string($posted['billing_phone'])) {
            $phone = $posted['billing_phone'];
        }
        if (isset($posted['billing_email']) && is_string($posted['billing_email'])) {
            $email = $posted['billing_email'];
        }
        $customerId = function_exists('get_current_user_id') ? get_current_user_id() : 0;
        if ($this->isBlacklisted($phone, $email, self::clientIp(), $customerId)) {
            unset($gateways['cod']);
            $notice = (string) get_option(self::OPTION_NOTICE, '');
            if ($notice !== '' && function_exists('wc_add_notice') && !wc_has_notice($notice, 'notice')) {
                wc_add_notice(esc_html($notice), 'notice');
            }
        }
        return $gateways;
    }

    public function validateCheckout(): void
    {
        $posted = wp_unslash($_POST);
        if (($posted['payment_method'] ?? '') !== 'cod') {
            return;
        }
        LicenseManager::assertLicensed();
        $phone = is_string($posted['billing_phone'] ?? null) ? $posted['billing_phone'] : '';
        $email = is_string($posted['billing_email'] ?? null) ? $posted['billing_email'] : '';
        if ($this->isBlacklisted($phone, $email, self::clientIp(), get_current_user_id())) {
            wc_add_notice($this->blockedMessage(), 'error');
        }
    }

    private function blockedMessage(): string
    {
        $notice = (string) get_option(self::OPTION_NOTICE, '');
        return $notice !== '' ? $notice : __('Η αντικαταβολή δεν είναι διαθέσιμη. Παρακαλώ επιλέξτε άλλον τρόπο πληρωμής.', 'gr-commerce-suite');
    }

    public function validateOrderPayment(WC_Order $order, mixed $request = null): void
    {
        LicenseManager::assertLicensed();
        if (
            (is_object($request) && method_exists($request, 'get_param')
                ? $request->get_param('payment_method') : $order->get_payment_method()) === 'cod'
            && $this->isBlacklisted(
                $order->get_billing_phone(),
                $order->get_billing_email(),
                (string) $order->get_customer_ip_address() ?: self::clientIp(),
                function_exists('get_current_user_id') ? get_current_user_id() : 0
            )
        ) {
            \GRCommerceSuite\Support\CheckoutValidation::fail('grcs_cod_blocked', $this->blockedMessage());
        }
    }

    private function key(string $type, string $value, bool $acceptDigest = false): string
    {
        if (!in_array($type, ['phone', 'email', 'ip'], true)) {
            return '';
        }
        // Same shape as the existing IP names: sha256 over the keyed digest.
        $digest = self::identityDigest($type, $value, $acceptDigest);
        return $digest === '' ? '' : self::OPTION_PREFIX . $type . '_' . hash('sha256', $digest);
    }

    /** @param array<string, mixed> $details */
    private function updateRecord(string $type, string $value, bool $blocked, ?string $event = null, array $details = [], bool $preserveState = false, bool $acceptDigest = false): void
    {
        $key = $this->key($type, $value, $acceptDigest);
        if ($key === '') {
            return;
        }
        if (!Lock::acquire($key, 30)) {
            throw new RuntimeException(__('Customer record is busy. Please try again.', 'gr-commerce-suite'));
        }
        try {
            // Migrate before the duplicate-event check so repeated polls still rewrite a legacy key.
            $record = $this->legacyKeysMayExist() ? $this->migrateLegacy($type, $value, true, $acceptDigest)
                : self::scrub($this->storedRecord($key), $type);
            $refusals = is_array($record['refusals'] ?? null) ? $record['refusals'] : [];
            if ($event !== null && (isset($refusals[$event]) || isset($refusals[(int) ($details['legacy_voucher_id'] ?? 0)]))) {
                return; // Repeated polls/webhooks must not count twice or undo a manual removal.
            }
            if ($event !== null) {
                $refusals[$event] = true;
            }
            unset($details['legacy_voucher_id']);
            $expired = isset($record['expires_at']) && (int) $record['expires_at'] <= time();
            $failures = (int) ($record['failures'] ?? ($record['refusal_count'] ?? 0));
            if ($event !== null) {
                $failures = ($expired ? 0 : $failures) + 1;
            } elseif ($blocked && !$preserveState) {
                $failures = max($failures, self::rules()['min_failures']);
            }
            $record = array_merge($record, $details, [
                'blocked' => $preserveState ? (bool) ($record['blocked'] ?? false) : $blocked,
                'refusals' => $refusals,
                'refusal_count' => count($refusals),
                'failures' => $failures,
                'expires_at' => $preserveState ? ($record['expires_at'] ?? time()) : time() + self::rules()['expiry_days'] * 86400,
                'whitelisted' => (bool) ($details['whitelisted'] ?? $record['whitelisted'] ?? false),
                // Digest (never the raw identity) so the admin registry can round-trip remove/whitelist.
                'value' => self::identityDigest($type, $value, $acceptDigest),
                'kv' => self::KEY_VERSION,
            ]);
            foreach (['customer_name', 'postal_code', 'notes'] as $field) {
                $record[$field] = sanitize_text_field((string) ($record[$field] ?? ''));
            }
            $record['courier'] = in_array($record['courier'] ?? '', ['ACS', 'BOX NOW'], true) ? $record['courier'] : 'MANUAL';
            $record['reason'] = isset(self::reasons()[(string) ($record['reason'] ?? '')]) ? $record['reason'] : 'FAILED_DELIVERY';
            update_option($key, $record, false);
        } finally {
            Lock::release($key);
        }
    }
}
