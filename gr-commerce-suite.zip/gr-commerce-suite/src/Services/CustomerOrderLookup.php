<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use Automattic\WooCommerce\Utilities\OrderUtil;
use GRCommerceSuite\Support\PhoneNormalizer;
use InvalidArgumentException;
use RuntimeException;
use WC_Order;

/**
 * Read-only, bounded queries against the active WooCommerce order datastore.
 *
 * @phpstan-type LookupResult array{orders: list<WC_Order>, total: int, pages: int}
 */
final class CustomerOrderLookup
{
    public const PAGE_SIZE = 20;

    /** @return array{orders: list<WC_Order>, total: int, pages: int} */
    public function search(string $mode, string $term, int $page = 1): array
    {
        $term = trim($term);
        if ($term === '' || mb_strlen($term) > 160) {
            throw new InvalidArgumentException(__('Enter a search value of up to 160 characters.', 'gr-commerce-suite'));
        }

        if ($mode === 'order') {
            return $this->orderNumber(ltrim($term, '#'), $page);
        }
        if ($mode === 'email') {
            if (!is_email($term)) {
                throw new InvalidArgumentException(__('Enter a complete billing email address.', 'gr-commerce-suite'));
            }
            return $this->query(['billing_email' => sanitize_email($term)], $page);
        }
        if ($mode === 'phone') {
            $phone = PhoneNormalizer::toE164($term);
            if ($phone === '') {
                throw new InvalidArgumentException(__('Enter a valid billing phone number, including the country code for international numbers.', 'gr-commerce-suite'));
            }
            return $this->fields([
                ['field' => 'billing_phone', 'value' => self::phonePattern($phone), 'compare' => 'REGEXP'],
            ], $page);
        }
        if ($mode !== 'name' || mb_strlen($term) < 2) {
            throw new InvalidArgumentException(__('Enter at least two characters of the customer name.', 'gr-commerce-suite'));
        }

        $tokens = preg_split('/\s+/u', $term, -1, PREG_SPLIT_NO_EMPTY) ?: [];
        if (count($tokens) > 6) {
            throw new InvalidArgumentException(__('Search using up to six name parts.', 'gr-commerce-suite'));
        }
        $fields = ['relation' => 'AND'];
        foreach ($tokens as $token) {
            $fields[] = [
                'relation' => 'OR',
                ['field' => 'billing_first_name', 'value' => $token, 'compare' => 'LIKE'],
                ['field' => 'billing_last_name', 'value' => $token, 'compare' => 'LIKE'],
            ];
        }
        return $this->fields($fields, $page);
    }

    /**
     * Never join identities by name or phone. Staff explicitly choose account or email.
     *
     * @return LookupResult
     */
    public function history(WC_Order $anchor, string $scope, int $page = 1): array
    {
        if ($scope === 'account' && $anchor->get_customer_id() > 0) {
            return $this->query(['customer_id' => $anchor->get_customer_id()], $page);
        }
        if ($scope === 'email' && is_email($anchor->get_billing_email())) {
            return $this->query(['billing_email' => $anchor->get_billing_email()], $page);
        }
        // Both datastores honour `post__in`; `include` is silently ignored and would return every order.
        return $this->query(['post__in' => [$anchor->get_id()]], $page);
    }

    /** Match canonical digits while tolerating historical spacing, brackets and country prefixes. */
    public static function phonePattern(string $e164): string
    {
        $separator = '[[:space:]().-]*';
        $digits = str_starts_with($e164, '+30') ? substr($e164, 3) : substr($e164, 1);
        $prefix = str_starts_with($e164, '+30')
            ? '([+]?' . $separator . '3' . $separator . '0' . $separator
                . '|0' . $separator . '0' . $separator . '3' . $separator . '0' . $separator . ')?'
            : '([+]' . $separator . '|0' . $separator . '0' . $separator . ')';
        return '^' . $separator . $prefix . implode($separator, str_split($digits)) . $separator . '$';
    }

    /**
     * @param array<array-key, mixed> $fields
     * @return LookupResult
     */
    private function fields(array $fields, int $page): array
    {
        if (OrderUtil::custom_orders_table_usage_is_enabled()) {
            return $this->query(['field_query' => $fields], $page);
        }
        return $this->query(['grcs_customer360_meta' => $this->legacyFields($fields)], $page);
    }

    /**
     * @param array<array-key, mixed> $fields
     * @return array<array-key, mixed>
     */
    private function legacyFields(array $fields): array
    {
        $meta = [];
        foreach ($fields as $key => $value) {
            if ($key === 'relation') {
                $meta[$key] = $value;
            } elseif (isset($value['field'])) {
                $meta[] = ['key' => '_' . $value['field'], 'value' => $value['value'], 'compare' => $value['compare']];
            } else {
                $meta[] = $this->legacyFields($value);
            }
        }
        return $meta;
    }

    /** @return LookupResult */
    private function orderNumber(string $number, int $page): array
    {
        if ($number === '') {
            throw new InvalidArgumentException(__('Enter an order ID or number.', 'gr-commerce-suite'));
        }
        $id = ctype_digit($number) ? (int) $number : 0;
        $direct = $id > 0 ? $this->query(['post__in' => [$id]], 1) : ['orders' => [], 'total' => 0];
        // WooCommerce's core order number is its ID. These are common sequential-number snapshots.
        // Extensions can supply their own persisted order-number keys without fetching all IDs.
        $keys = apply_filters('grcs_customer360_order_number_meta_keys', ['_order_number', '_order_number_formatted']);
        $meta = ['relation' => 'OR'];
        foreach (is_array($keys) ? array_slice($keys, 0, 10) : [] as $key) {
            if (is_string($key) && $key !== '') {
                $meta[] = ['key' => $key, 'value' => $number, 'compare' => '='];
            }
        }
        $result = count($meta) > 1
            ? $this->query([
                OrderUtil::custom_orders_table_usage_is_enabled() ? 'meta_query' : 'grcs_customer360_meta' => $meta,
                'exclude' => $id > 0 ? [$id] : [],
            ], $page)
            : ['orders' => [], 'total' => 0, 'pages' => 0];
        if ($page <= 1) {
            $result['orders'] = array_merge($direct['orders'], $result['orders']);
        }
        $result['total'] += $direct['total'];
        $result['pages'] = max($result['pages'], $direct['total'] > 0 ? 1 : 0);
        return $result;
    }

    /**
     * Adapt only this module's private query variable; remove the hook even on a datastore error.
     *
     * @param array<string, mixed> $args
     * @return LookupResult
     */
    private function query(array $args, int $page): array
    {
        /**
         * @param array<string, mixed> $query
         * @param array<string, mixed> $vars
         * @return array<string, mixed>
         */
        $adapter = static function (array $query, array $vars): array {
            if (!empty($vars['grcs_customer360_meta'])) {
                $query['meta_query'][] = $vars['grcs_customer360_meta'];
            }
            return $query;
        };
        add_filter('woocommerce_order_data_store_cpt_get_orders_query', $adapter, 10, 2);
        try {
            $result = wc_get_orders(array_merge([
                'type' => 'shop_order',
                'status' => array_keys(wc_get_order_statuses()),
                'limit' => self::PAGE_SIZE,
                'page' => max(1, $page),
                'paginate' => true,
                'orderby' => ['date' => 'DESC', 'ID' => 'DESC'],
                'order' => 'DESC',
                'return' => 'objects',
            ], $args));
        } finally {
            remove_filter('woocommerce_order_data_store_cpt_get_orders_query', $adapter, 10);
        }
        if (!is_object($result) || !isset($result->orders, $result->total, $result->max_num_pages) || !is_array($result->orders)) {
            throw new RuntimeException(__('Unexpected WooCommerce paginated query result.', 'gr-commerce-suite'));
        }
        return [
            'orders' => array_values(array_filter($result->orders, static fn(mixed $order): bool => $order instanceof WC_Order)),
            'total' => (int) $result->total,
            'pages' => (int) $result->max_num_pages,
        ];
    }
}
