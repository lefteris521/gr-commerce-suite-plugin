<?php

declare(strict_types=1);

namespace GRCommerceSuite\Services;

use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Cod\CodSettlementStatus;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Support\Money;

/**
 * Reconciles courier-reported COD remittances cent-for-cent against expected `cod_amount` (SPEC.md §10).
 *
 * Updates `cod_collected`, `cod_reconciled`, `cod_reconciled_at`, and `cod_settlement_ref`.
 */
final readonly class CodReconciliationService
{
    public function __construct(
        private VoucherRepository $repository,
        private CourierRegistry $courierRegistry,
        private LoggerInterface $logger,
    ) {
    }

    /**
     * Reconcile a chunk of up to 100 voucher IDs for a given courier.
     *
     * @param non-empty-list<int> $voucherIds
     */
    public function reconcileChunk(CourierSlug $courier, array $voucherIds): void
    {
        // Scheduled work on existing vouchers runs unlicensed (owner decision 2026-11-03); only issuance is licence-gated.
        $rowsByVoucherNo = [];
        $voucherNos = [];

        foreach ($voucherIds as $id) {
            $row = $this->repository->findById($id);
            if ($row === null) {
                continue;
            }

            $voucherNo = trim((string) ($row['voucher_no'] ?? ''));
            if ($voucherNo === '') {
                continue;
            }

            $rowsByVoucherNo[$voucherNo] = $row;
            $voucherNos[] = $voucherNo;
        }

        if ($voucherNos === []) {
            return;
        }

        $provider = $this->courierRegistry->get($courier);
        $batchResults = $provider->reconcileCodBatch($voucherNos);
        $this->logger->debug(
            'COD settlement batch checked.',
            ['courier' => $courier->value,
            'count' => count($voucherNos)]
        );

        foreach ($rowsByVoucherNo as $voucherNo => $row) {
            if (!isset($batchResults[$voucherNo])) {
                continue;
            }

            $result = $batchResults[$voucherNo];
            $voucherId = (int) $row['id'];
            $orderId = (int) $row['order_id'];
            $expectedCents = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents();

            if ($result->status === CodSettlementStatus::Settled) {
                $collectedCents = $result->collectedAmountCents ?? 0;
                $settledAtUtc = $result->settledAt?->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s')
                    ?? gmdate('Y-m-d H:i:s');

                if ($collectedCents === $expectedCents) {
                    $updated = $this->repository->updateCodReconciliation(
                        id: $voucherId,
                        collectedAmountCents: $collectedCents,
                        reconciled: true,
                        settlementRef: $result->settlementRef,
                        reconciledAtUtc: $settledAtUtc,
                    );
                    if (!$updated) {
                        continue;
                    }

                    if (function_exists('wc_get_order')) {
                        $order = wc_get_order($orderId);
                        if (
                            is_object($order) &&
                             method_exists(
                                 $order,
                                 'update_meta_data'
                             ) &&
                             method_exists(
                                 $order,
                                 'save'
                             )
                        ) {
                            $order->update_meta_data('_grcs_cod_reconciled_at', $settledAtUtc);
                            $order->save();
                        }
                    }

                    if (function_exists('do_action')) {
                        do_action('grcs/cod/reconciled', $voucherId, $result);
                    }
                } else {
                    $updated = $this->repository->updateCodReconciliation(
                        id: $voucherId,
                        collectedAmountCents: $collectedCents,
                        reconciled: false,
                        settlementRef: $result->settlementRef,
                        reconciledAtUtc: null,
                    );
                    if (!$updated) {
                        continue;
                    }

                    if (function_exists('do_action')) {
                        do_action('grcs/cod/mismatch', $voucherId, $expectedCents, $collectedCents);
                    }
                }
            } elseif ($result->status === CodSettlementStatus::CollectedNotSettled) {
                // Skip observations with no financial facts to preserve existing repository evidence
                if ($result->collectedAmountCents === null && $result->settlementRef === null) {
                    continue;
                }
                $this->repository->updateCodReconciliation(
                    id: $voucherId,
                    collectedAmountCents: $result->collectedAmountCents,
                    reconciled: false,
                    settlementRef: $result->settlementRef,
                    reconciledAtUtc: null,
                );
            }
        }
    }
}
