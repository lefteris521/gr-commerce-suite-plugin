<?php

declare(strict_types=1);

namespace GRCommerceSuite\Sandbox;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Contracts\VoucherStateTrackerInterface;
use GRCommerceSuite\Couriers\AcsProvider;
use GRCommerceSuite\Couriers\BoxNowProvider;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Pdf\PdfMerger;
use GRCommerceSuite\Services\LicenseManager;
use Throwable;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Local WP-REST Mock Sandbox Controller & HTTP Interceptor (SPEC.md §8.5, Phase 1).
 *
 * When Sandbox Mode is enabled:
 *  1. Registers local WP-REST endpoints under `grcs/v1/sandbox/...` for ACS and BOX NOW.
 *  2. Intercepts outbound `wp_remote_request()` calls to ACS (`ACSAutoRest`) and BOX NOW (`/api/v1/...`)
 *     via the `pre_http_request` filter so voucher creation, post-transmission timeout handling
 *     (`state = 'unknown'`), APM locker lookup, and sample PDF label generation work 100% offline
 *     without live courier credentials.
 */
final class MockCourierRestController implements HookSubscriberInterface
{
    public const REST_NAMESPACE = 'grcs/v1';
    public const MOCK_REST_NAMESPACE = 'grcs-mock/v1';

    private ?bool $sandboxOverride = null;

    private bool $simulateTimeout = false;

    public function __construct(
        private readonly ?VoucherStateTrackerInterface $stateTracker = null,
    ) {
    }

    public function register(): void
    {
        if (function_exists('add_action')) {
            add_action('rest_api_init', [$this, 'registerRoutes']);
        }

        if (function_exists('add_filter')) {
            add_filter('pre_http_request', [$this, 'interceptHttpRequest'], 10, 3);
        }
    }

    /**
     * Programmatically enable or disable Sandbox Mode (useful for offline tests).
     */
    public function setSandboxEnabled(?bool $enabled): void
    {
        $this->sandboxOverride = $enabled;
    }

    /**
     * Programmatically enable or disable post-transmission timeout simulation (`state = 'unknown'`).
     */
    public function setSimulateTimeout(bool $simulate): void
    {
        $this->simulateTimeout = $simulate;
    }

    /**
     * Determine whether Sandbox Mode is currently active.
     */
    public function isSandboxEnabled(): bool
    {
        if ($this->sandboxOverride !== null) {
            return $this->sandboxOverride;
        }

        return (new LicenseManager())->isSandboxEnabled();
    }

    /**
     * Register local WP-REST sandbox routes under `grcs/v1/sandbox/...` (SPEC.md §15.3).
     */
    public function registerRoutes(): void
    {
        if (!function_exists('register_rest_route')) {
            return;
        }

        $this->registerSandboxRoute(
            '/sandbox/acs',
            [
                'methods' => 'POST',
                'callback' => [$this, 'handleAcsRestRequest'],
                'permission_callback' => [$this, 'checkSandboxPermission'],
            ]
        );

        $this->registerSandboxRoute(
            '/sandbox/boxnow/auth-sessions',
            [
                'methods' => 'POST',
                'callback' => [$this, 'handleBoxNowAuthRestRequest'],
                'permission_callback' => [$this, 'checkSandboxPermission'],
            ]
        );

        $this->registerSandboxRoute(
            '/sandbox/boxnow/destinations',
            [
                'methods' => 'GET',
                'callback' => [$this, 'handleBoxNowDestinationsRestRequest'],
                'permission_callback' => [$this, 'checkSandboxPermission'],
            ]
        );

        $this->registerSandboxRoute(
            '/sandbox/boxnow/delivery-requests',
            [
                'methods' => 'POST',
                'callback' => [$this, 'handleBoxNowDeliveryRestRequest'],
                'permission_callback' => [$this, 'checkSandboxPermission'],
            ]
        );

        $this->registerSandboxRoute(
            '/sandbox/boxnow/parcels/(?P<id>[A-Za-z0-9_-]+)/label\.pdf',
            [
                'methods' => 'GET',
                'callback' => [$this, 'handleBoxNowLabelRestRequest'],
                'permission_callback' => [$this, 'checkSandboxPermission'],
            ]
        );

        $this->registerSandboxRoute(
            '/sandbox/boxnow/parcels/(?P<id>[A-Za-z0-9_-]+)',
            [
                'methods' => 'GET',
                'callback' => [$this, 'handleBoxNowTrackingRestRequest'],
                'permission_callback' => [$this, 'checkSandboxPermission'],
            ]
        );
    }

    /**
     * Permission callback for local WP-REST sandbox routes (SPEC.md §15.3).
     */
    public function checkSandboxPermission(): bool|WP_Error
    {
        if ($this->isSandboxEnabled() && LicenseManager::isLicensed() && current_user_can('manage_woocommerce')) {
            return true;
        }

        return new WP_Error(
            'grcs_sandbox_disabled',
            __('Sandbox Mode is disabled.', 'gr-commerce-suite'),
            ['status' => 403]
        );
    }

    /**
     * Preserve existing sandbox URLs while exposing the dedicated mock namespace.
     *
     * @param array<string, mixed> $args
     */
    private function registerSandboxRoute(string $route, array $args): void
    {
        if ($route === '' || $route === '0') {
            return;
        }
        register_rest_route(self::REST_NAMESPACE, $route, $args);
        $mockRoute = substr($route, strlen('/sandbox'));
        if ($mockRoute !== '' && $mockRoute !== '0') {
            register_rest_route(self::MOCK_REST_NAMESPACE, $mockRoute, $args);
        }
    }

    /**
     * Intercept outbound WordPress HTTP calls (`pre_http_request`) when Sandbox Mode is active.
     *
     * @param false|array<string, mixed>|WP_Error $preempt
     * @param array<string, mixed>                $parsedArgs
     * @return false|array<string, mixed>|WP_Error
     */
    public function interceptHttpRequest(mixed $preempt, array $parsedArgs, string $url): mixed
    {
        if ($preempt !== false || !$this->isSandboxEnabled()) {
            return $preempt;
        }

        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        $allowedHosts = [
            parse_url(AcsProvider::ENDPOINT_URL, PHP_URL_HOST),
            parse_url(BoxNowProvider::PRODUCTION_BASE_URL, PHP_URL_HOST),
            parse_url(BoxNowProvider::STAGING_BASE_URL, PHP_URL_HOST),
        ];
        $localSandbox = function_exists('home_url') && $host === parse_url(home_url(), PHP_URL_HOST)
            && str_contains($url, '/grcs/v1/sandbox/');
        if (!in_array($host, $allowedHosts, true) && !$localSandbox) {
            return $preempt;
        }

        $rawBody = isset($parsedArgs['body']) && is_string($parsedArgs['body']) ? $parsedArgs['body'] : '';
        $headers = isset($parsedArgs['headers']) && is_array($parsedArgs['headers']) ? $parsedArgs['headers'] : [];

        // 1. Intercept ACS Courier REST API v2.0 (`ACSAutoRest`)
        if (str_contains($url, 'ACSRestServices/api/ACSAutoRest') || str_contains($url, '/grcs/v1/sandbox/acs')) {
            if ($this->shouldSimulateTimeout($headers, $rawBody, $url)) {
                return $this->buildTimeoutWpError(CourierSlug::Acs, $rawBody);
            }

            $payload = $this->decodeJsonBody($rawBody);
            $responseBody = $this->buildAcsMockResponse($payload);

            return $this->buildWpHttpJsonResponse(200, $responseBody);
        }

        // 2. Intercept BOX NOW OAuth2 (`/api/v1/auth-sessions`)
        if (
            str_contains(
                $url,
                BoxNowProvider::PATH_AUTH_SESSIONS
            ) ||
             str_contains(
                 $url,
                 '/sandbox/boxnow/auth-sessions'
             )
        ) {
            return $this->buildWpHttpJsonResponse(200, $this->buildBoxNowAuthResponse());
        }

        // 3. Intercept BOX NOW APM Locker Lookup (`/api/v1/destinations`)
        if (
            str_contains(
                $url,
                BoxNowProvider::PATH_DESTINATIONS
            ) ||
             str_contains(
                 $url,
                 '/sandbox/boxnow/destinations'
             )
        ) {
            return $this->buildWpHttpJsonResponse(200, $this->buildBoxNowDestinationsResponse());
        }

        // 4. Intercept BOX NOW Parcel Creation (`/api/v1/delivery-requests`)
        if (
            str_contains(
                $url,
                BoxNowProvider::PATH_DELIVERY_REQUESTS
            ) ||
             str_contains(
                 $url,
                 '/sandbox/boxnow/delivery-requests'
             )
        ) {
            if ($this->shouldSimulateTimeout($headers, $rawBody, $url)) {
                return $this->buildTimeoutWpError(CourierSlug::BoxNow, $rawBody);
            }

            $payload = $this->decodeJsonBody($rawBody);
            $responseBody = $this->buildBoxNowDeliveryResponse($payload);

            return $this->buildWpHttpJsonResponse(200, $responseBody);
        }

        // 5. Intercept BOX NOW PDF Label Retrieval (`/api/v1/parcels/{id}/label.pdf`)
        if (preg_match('#/parcels/([^/]+)/label\.pdf#', $url, $matches) === 1) {
            $parcelId = rawurldecode($matches[1]);
            $pdfBytes = PdfMerger::generateSampleLabelPdf([$parcelId], 'BOX NOW SANDBOX', $this->labelFormat($url));

            return [
                'headers' => [
                    'content-type' => 'application/pdf',
                ],
                'body' => $pdfBytes,
                'response' => [
                    'code' => 200,
                    'message' => 'OK',
                ],
                'cookies' => [],
                'filename' => null,
            ];
        }

        // 6. Intercept BOX NOW Parcel Cancel (`/api/v1/parcels/{id}:cancel`)
        if (preg_match('#/parcels/([^/:]+):cancel#', $url, $matches) === 1) {
            return $this->buildWpHttpJsonResponse(200, ['status' => 'cancelled', 'id' => rawurldecode($matches[1])]);
        }

        // 7. Intercept BOX NOW Parcel Tracking (`/api/v1/parcels/{id}`)
        if (preg_match('#/parcels/([^/?]+)$#', $url, $matches) === 1) {
            $parcelId = rawurldecode($matches[1]);

            return $this->buildWpHttpJsonResponse(200, $this->buildBoxNowParcelTrackingResponse($parcelId));
        }

        return false;
    }

    /**
     * WP-REST callback for `POST /grcs/v1/sandbox/acs`.
     */
    public function handleAcsRestRequest(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $rawBody = (string) $request->get_body();
        $headers = [
            'x-grcs-sandbox-timeout' => (string) $request->get_header('x-grcs-sandbox-timeout'),
        ];

        if ($this->shouldSimulateTimeout($headers, $rawBody, '/grcs/v1/sandbox/acs')) {
            return $this->buildTimeoutWpError(CourierSlug::Acs, $rawBody);
        }

        $payload = $this->decodeJsonBody($rawBody);

        return new WP_REST_Response($this->buildAcsMockResponse($payload), 200);
    }

    /**
     * WP-REST callback for `POST /grcs/v1/sandbox/boxnow/auth-sessions`.
     */
    public function handleBoxNowAuthRestRequest(): WP_REST_Response
    {
        return new WP_REST_Response($this->buildBoxNowAuthResponse(), 200);
    }

    /**
     * WP-REST callback for `GET /grcs/v1/sandbox/boxnow/destinations`.
     */
    public function handleBoxNowDestinationsRestRequest(): WP_REST_Response
    {
        return new WP_REST_Response($this->buildBoxNowDestinationsResponse(), 200);
    }

    /**
     * WP-REST callback for `POST /grcs/v1/sandbox/boxnow/delivery-requests`.
     */
    public function handleBoxNowDeliveryRestRequest(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $rawBody = (string) $request->get_body();
        $headers = [
            'x-grcs-sandbox-timeout' => (string) $request->get_header('x-grcs-sandbox-timeout'),
        ];

        if ($this->shouldSimulateTimeout($headers, $rawBody, '/grcs/v1/sandbox/boxnow/delivery-requests')) {
            return $this->buildTimeoutWpError(CourierSlug::BoxNow, $rawBody);
        }

        $payload = $this->decodeJsonBody($rawBody);

        return new WP_REST_Response($this->buildBoxNowDeliveryResponse($payload), 200);
    }

    /**
     * WP-REST callback for `GET /grcs/v1/sandbox/boxnow/parcels/{id}/label.pdf`.
     */
    public function handleBoxNowLabelRestRequest(WP_REST_Request $request): WP_REST_Response
    {
        $parcelId = (string) ($request->get_param('id') ?? 'BN-SANDBOX-001');
        $pdfBytes = PdfMerger::generateSampleLabelPdf([$parcelId], 'BOX NOW SANDBOX', is_string($request->get_param('format')) ? $request->get_param('format') : 'thermal');

        $response = new WP_REST_Response($pdfBytes, 200);
        $response->header('Content-Type', 'application/pdf');

        return $response;
    }

    /**
     * WP-REST callback for `GET /grcs/v1/sandbox/boxnow/parcels/{id}`.
     */
    public function handleBoxNowTrackingRestRequest(WP_REST_Request $request): WP_REST_Response
    {
        $parcelId = (string) ($request->get_param('id') ?? 'BN-SANDBOX-001');

        return new WP_REST_Response($this->buildBoxNowParcelTrackingResponse($parcelId), 200);
    }

    /**
     * Build mock `ACSAutoRest` response payload for any supported `ACSAlias`.
     *
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    public function buildAcsMockResponse(array $payload): array
    {
        $alias = (string) ($payload['ACSAlias'] ?? '');
        $input = isset($payload['ACSInputParameters']) && is_array($payload['ACSInputParameters'])
            ? $payload['ACSInputParameters']
            : [];

        return match ($alias) {
            AcsProvider::ALIAS_CREATE_VOUCHER => $this->buildAcsCreateVoucherResponse($input),
            AcsProvider::ALIAS_PRINT_VOUCHER_V2 => $this->buildAcsPrintVoucherResponse($input),
            AcsProvider::ALIAS_DELETE_VOUCHER => $this->buildAcsDeleteVoucherResponse($input),
            AcsProvider::ALIAS_TRACKING_SUMMARY => $this->buildAcsTrackingResponse($input),
            AcsProvider::ALIAS_ISSUE_PICKUP_LIST => $this->buildAcsIssuePickupListResponse($input),
            default => [
                'ACSOutputResponce' => [
                    'ACSErrorOutput' => [
                        'Error_Message' => sprintf('Unsupported sandbox ACSAlias: %s', $alias),
                    ],
                    'ACSValueOutput' => [],
                ],
            ],
        };
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    private function buildAcsCreateVoucherResponse(array $input): array
    {
        $ref = (string) ($input['Reference_Key1'] ?? $input['Relevant_Code'] ?? '1001');
        $hashDigits = substr(preg_replace('/\D+/', '', (string) crc32($ref)) ?? '1234567890', 0, 10);
        $voucherNo = '79' . str_pad($hashDigits, 10, '0', STR_PAD_LEFT);

        return [
            'ACSOutputResponce' => [
                'ACSErrorOutput' => [
                    'Error_Message' => '',
                ],
                'ACSValueOutput' => [
                    [
                        'Voucher_No' => $voucherNo,
                        'Error_Message' => '',
                    ],
                ],
            ],
        ];
    }

    private function labelFormat(string $url): string
    {
        parse_str((string) parse_url($url, PHP_URL_QUERY), $query);
        $format = $query['format'] ?? 'thermal';
        return is_string($format) && in_array($format, ['a4', 'a6', 'thermal'], true) ? $format : 'thermal';
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    private function buildAcsPrintVoucherResponse(array $input): array
    {
        $voucherNo = trim((string) ($input['Voucher_No'] ?? '790000000001'));
        $printType = (int) ($input['Print_Type'] ?? 2);
        $format = $printType === 1 ? 'thermal' : ($printType === 3 ? 'a6' : 'a4');

        $pdfBytes = PdfMerger::generateSampleLabelPdf(
            [$voucherNo !== '' ? $voucherNo : '790000000001'],
            'ACS SANDBOX',
            $format
        );

        return [
            'ACSOutputResponce' => [
                'ACSErrorOutput' => [
                    'Error_Message' => '',
                ],
                'ACSValueOutput' => [
                    [
                        'Voucher_No' => $voucherNo,
                        'PDF_Base64' => base64_encode($pdfBytes),
                        'Error_Message' => '',
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    private function buildAcsDeleteVoucherResponse(array $input): array
    {
        $voucherNo = trim((string) ($input['Voucher_No'] ?? ''));

        return [
            'ACSOutputResponce' => [
                'ACSErrorOutput' => [
                    'Error_Message' => '',
                ],
                'ACSValueOutput' => [
                    [
                        'Voucher_No' => $voucherNo,
                        'Deleted' => 1,
                        'Error_Message' => '',
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    private function buildAcsTrackingResponse(array $input): array
    {
        $voucherNo = trim((string) ($input['Voucher_No'] ?? '790000000001'));

        return [
            'ACSOutputResponce' => [
                'ACSErrorOutput' => [
                    'Error_Message' => '',
                ],
                'ACSTableOutput' => [
                    'Table_Data' => [
                        [
                            'voucher_no' => $voucherNo,
                            'checkpoint_date_time' => gmdate('Y-m-d H:i:s'),
                            'checkpoint_station' => 'ATHENS HUB',
                            'checkpoint_code' => '4',
                            'checkpoint_description' => 'ΠΑΡΑΔΟΘΗΚΕ (SANDBOX)',
                            'delivery_flag' => '4',
                        ],
                    ],
                ],
                'ACSValueOutput' => [
                    [
                        'Voucher_No' => $voucherNo,
                    ],
                ],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $input
     * @return array<string, mixed>
     */
    private function buildAcsIssuePickupListResponse(array $input): array
    {
        $pickupDate = (string) ($input['Pickup_Date'] ?? gmdate('Y-m-d'));

        return [
            'ACSOutputResponce' => [
                'ACSErrorOutput' => [
                    'Error_Message' => '',
                ],
                'ACSValueOutput' => [
                    [
                        'Mass_Number' => 'PL-' . str_replace('-', '', $pickupDate) . '-01',
                        'Pickup_Date' => $pickupDate,
                        'Error_Message' => '',
                    ],
                ],
                'ACSTableOutput' => [
                    'Table_Data' => [],
                ],
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function buildBoxNowAuthResponse(): array
    {
        return [
            'access_token' => 'grcs-sandbox-boxnow-bearer-token',
            'token_type' => 'Bearer',
            'expires_in' => 3600,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function buildBoxNowDestinationsResponse(): array
    {
        return [
            'data' => [
                [
                    'id' => '1001',
                    'name' => 'BOX NOW Syntagma Locker',
                    'addressLine1' => 'Ermou 10',
                    'postalCode' => '10563',
                    'city' => 'Athina',
                    'lat' => 37.9755,
                    'lng' => 23.7348,
                ],
                [
                    'id' => '2001',
                    'name' => 'BOX NOW Thessaloniki Tsimiski Locker',
                    'addressLine1' => 'Tsimiski 45',
                    'postalCode' => '54623',
                    'city' => 'Thessaloniki',
                    'lat' => 40.6323,
                    'lng' => 22.9437,
                ],
            ],
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private function buildBoxNowDeliveryResponse(array $payload): array
    {
        $orderNumber = (string) ($payload['orderNumber'] ?? '1001');
        $hashDigits = substr(preg_replace('/\D+/', '', (string) crc32($orderNumber)) ?? '9876543210', 0, 8);
        $parcelId = 'BN' . str_pad($hashDigits, 8, '0', STR_PAD_LEFT);

        return [
            'id' => 'req-' . $parcelId,
            'parcels' => array_map(static fn(int $piece): array => [
                'id' => $piece === 1 ? $parcelId : $parcelId . '-' . $piece,
            ], range(1, max(1, min(100, is_array($payload['items'] ?? null) ? count($payload['items']) : 1)))),
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function buildBoxNowParcelTrackingResponse(string $parcelId): array
    {
        return [
            'id' => $parcelId,
            'state' => 'in-final-destination',
            'stateLabel' => 'Ready for pickup at BOX NOW locker (Sandbox)',
            'updatedAt' => gmdate('Y-m-d\TH:i:s\Z'),
            'events' => [
                [
                    'type' => 'in-final-destination',
                    'description' => 'Parcel placed in locker',
                    'locationId' => '1001',
                    'time' => gmdate('Y-m-d\TH:i:s\Z'),
                ],
            ],
        ];
    }

    /**
     * Determine whether the sandbox request should simulate a post-transmission read timeout (`state = 'unknown'`).
     *
     * @param array<string, mixed> $headers
     */
    private function shouldSimulateTimeout(array $headers, string $rawBody, string $url): bool
    {
        if ($this->simulateTimeout) {
            return true;
        }

        if (str_contains($url, 'simulate_timeout=1') || str_contains($url, 'timeout=1')) {
            return true;
        }

        foreach ($headers as $k => $v) {
            if (
                strtolower((string) $k) === 'x-grcs-sandbox-timeout' &&
                 ((string) $v === '1' ||
                 strtolower((string) $v) === 'true')
            ) {
                return true;
            }
        }

        if (
            str_contains($rawBody, 'SIMULATE_TIMEOUT')
            || str_contains($rawBody, '[TIMEOUT]')
            || str_contains($rawBody, '"simulate_timeout":true')
        ) {
            return true;
        }

        if (function_exists('get_option')) {
            $opt = get_option('grcs_sandbox_simulate_timeout', null);
            if ($opt !== null) {
                return $opt === 'yes' || $opt === true || $opt === '1' || $opt === 1;
            }

            $settings = get_option('grcs_settings', []);
            if (is_array($settings)) {
                $flag = $settings['sandbox_simulate_timeout'] ?? 'no';
                if ($flag === 'yes' || $flag === true || $flag === '1' || $flag === 1) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Build a simulated post-transmission read timeout `WP_Error` and notify the state tracker so the
     * voucher row transitions to `state = 'unknown'` (SPEC.md §7).
     */
    private function buildTimeoutWpError(CourierSlug $courier, string $rawBody): WP_Error
    {
        $errorMessage = sprintf(
            'cURL error 28: Operation timed out after 15000 milliseconds with 0 bytes ' .
                'received (%s Sandbox post-transmission timeout; voucher state = %s)',
            $courier->label(),
            VoucherState::Unknown->value
        );

        if ($this->stateTracker !== null) {
            $decoded = $this->decodeJsonBody($rawBody);
            $orderId = $this->extractOrderIdFromSandboxPayload($decoded);
            if ($orderId > 0) {
                $this->stateTracker->markUnknownOnTimeout(
                    orderId: $orderId,
                    courier: $courier,
                    errorMessage: $errorMessage,
                );
            }
        }

        return new WP_Error('http_request_timeout', $errorMessage);
    }

    /**
     * @param array<string, mixed> $decoded
     */
    private function extractOrderIdFromSandboxPayload(array $decoded): int
    {
        if (isset($decoded['ACSInputParameters']) && is_array($decoded['ACSInputParameters'])) {
            $rel = (string) ($decoded['ACSInputParameters']['Relevant_Code'] ?? '');
            if (ctype_digit($rel)) {
                return (int) $rel;
            }
        }

        if (
            isset($decoded['items']) &&
             is_array($decoded['items']) &&
             isset($decoded['items'][0]) &&
             is_array($decoded['items'][0])
        ) {
            $itemId = (string) ($decoded['items'][0]['id'] ?? '');
            if (ctype_digit($itemId)) {
                return (int) $itemId;
            }
        }

        return 0;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function buildWpHttpJsonResponse(int $statusCode, array $data): array
    {
        $json = function_exists('wp_json_encode')
            ? (string) wp_json_encode($data)
            : json_encode($data, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);

        return [
            'headers' => [
                'content-type' => 'application/json; charset=utf-8',
            ],
            'body' => $json,
            'response' => [
                'code' => $statusCode,
                'message' => $statusCode === 200 ? 'OK' : 'Error',
            ],
            'cookies' => [],
            'filename' => null,
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function decodeJsonBody(string $rawBody): array
    {
        if (trim($rawBody) === '') {
            return [];
        }

        try {
            $decoded = json_decode($rawBody, true, 512, JSON_THROW_ON_ERROR);

            return is_array($decoded) ? $decoded : [];
        } catch (Throwable) {
            return [];
        }
    }
}
