<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Services\DiagnosticLogger;
use GRCommerceSuite\Services\SystemDiagnostics;

final class DiagnosticsPanel implements HookSubscriberInterface
{
    public function register(): void
    {
        add_action('admin_post_grcs_diagnostics', [$this, 'handleAction']);
        add_action('admin_post_grcs_classic_checkout', [$this, 'switchCheckout']);
    }

    public function switchCheckout(): void
    {
        if (!self::canAccess()) {
            wp_die(AdminLocale::esc_html__('Permission denied.', 'gr-commerce-suite'), 403);
        }
        check_admin_referer('grcs_classic_checkout');
        $this->ensureClassicPages();
        wp_safe_redirect(admin_url('admin.php?page=' . CodReconciliationPage::MENU_SLUG . '&tab=diagnostics'));
        exit;
    }

    /** Verify both pages before changing either; preserve unrelated page content. */
    public function ensureClassicPages(): void
    {
        $pages = [];
        foreach (['cart', 'checkout'] as $type) {
            $id = wc_get_page_id($type);
            $page = $id > 0 ? get_post($id) : null;
            if (!$page instanceof \WP_Post || !current_user_can('edit_post', $id)) {
                wp_die(AdminLocale::esc_html__('Both Cart and Checkout pages must exist and be editable before switching to Classic Mode.', 'gr-commerce-suite'), 403);
            }
            $pages[$type] = $page;
        }
        if ($pages['cart']->ID === $pages['checkout']->ID) {
            wp_die(AdminLocale::esc_html__('Cart and Checkout must use separate pages.', 'gr-commerce-suite'), 400);
        }
        $updates = [];
        foreach ($pages as $type => $page) {
            $shortcode = 'woocommerce_' . $type;
            $content = $this->classicPageContent($page->post_content, $type);
            if (!has_shortcode($content, $shortcode) || has_block('woocommerce/' . $type, $content)) {
                wp_die(AdminLocale::esc_html__('Could not prepare the Classic Cart and Checkout pages.', 'gr-commerce-suite'));
            }
            if ($content === $page->post_content) {
                continue;
            }
            $updates[$page->ID] = $content;
        }
        $updated = [];
        foreach ($pages as $page) {
            if (!isset($updates[$page->ID])) {
                continue;
            }
            $result = wp_update_post(['ID' => $page->ID, 'post_content' => $updates[$page->ID]], true);
            if (is_wp_error($result) || $result === 0) {
                // Best-effort rollback keeps a failed second update from leaving mixed page modes.
                foreach ($updated as $original) {
                    wp_update_post(['ID' => $original->ID, 'post_content' => $original->post_content], true);
                }
                wp_die(AdminLocale::esc_html__('Could not switch both Cart and Checkout pages. Review the pages and retry.', 'gr-commerce-suite'));
            }
            $updated[] = $page;
        }
    }

    private function classicPageContent(string $content, string $type): string
    {
        $replace = function (array $blocks) use (&$replace, $type): array {
            foreach ($blocks as &$block) {
                // A classic-shortcode block already renders the page; convert it rather than appending a second one.
                if (($block['blockName'] ?? '') === 'woocommerce/' . $type
                    || (($block['blockName'] ?? '') === 'woocommerce/classic-shortcode' && ($block['attrs']['shortcode'] ?? 'cart') === $type)) {
                    $block = ['blockName' => 'core/shortcode', 'attrs' => [], 'innerBlocks' => [],
                        'innerHTML' => '[woocommerce_' . $type . ']', 'innerContent' => ['[woocommerce_' . $type . ']']];
                } elseif (!empty($block['innerBlocks'])) {
                    $block['innerBlocks'] = $replace($block['innerBlocks']);
                }
            }
            return $blocks;
        };
        if (has_block('woocommerce/' . $type, $content) || has_block('woocommerce/classic-shortcode', $content)) {
            $content = serialize_blocks($replace(parse_blocks($content)));
        }
        return has_shortcode($content, 'woocommerce_' . $type) ? $content : $content . "\n[woocommerce_" . $type . ']';
    }

    public static function canAccess(): bool
    {
        return current_user_can('manage_woocommerce') || current_user_can('grcs_manage_settings');
    }

    public function handleAction(): void
    {
        if (!self::canAccess()) {
            wp_die(AdminLocale::esc_html__('Permission denied.', 'gr-commerce-suite'), 403);
        }
        check_admin_referer('grcs_diagnostics');
        $logger = new DiagnosticLogger();
        if (($_POST['diagnostic_operation'] ?? '') === 'clear') {
            $logger->clear();
            wp_safe_redirect(admin_url('admin.php?page=' . CodReconciliationPage::MENU_SLUG . '&tab=diagnostics'));
            exit;
        }
        nocache_headers();
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="grcs-debug-log.txt"');
        $environment = (new SystemDiagnostics())->environment();
        foreach (['PHP', 'PHP security status', 'PHP security details', 'PHP security warning'] as $metric) {
            if (isset($environment[$metric])) {
                echo $metric . ': ' . $environment[$metric] . "\n";
            }
        }
        echo "\n";
        echo $logger->report(true); // Plain text attachment; all persisted content is masked.
        exit;
    }

    public static function render(): void
    {
        if (!self::canAccess()) {
            return;
        }
        $logger = new DiagnosticLogger();
        $report = $logger->generate_system_report();
        $phpSecurity = $report['Environment'];
        echo '<div class="grcs-card"><h2>' . AdminLocale::esc_html__('Environment Health Checks', 'gr-commerce-suite') . '</h2><div class="grcs-table-wrap"><table class="widefat striped"><thead><tr><th>' . AdminLocale::esc_html__('Metric', 'gr-commerce-suite') . '</th><th>' . AdminLocale::esc_html__('Status', 'gr-commerce-suite') . '</th></tr></thead><tbody>';
        foreach (array_merge($report['Environment'], $report['Required Extensions'], $report['WooCommerce & HPOS']) as $name => $value) {
            if (in_array($name, ['PHP security status', 'PHP security details', 'PHP security warning'], true)) {
                continue;
            }
            $value = is_array($value) ? ($value === [] ? 'None' : implode(', ', $value)) : (string) $value;
            if ($name === 'Checkout Mode') {
                $classic = $value === 'Classic Checkout ([woocommerce_checkout])';
                echo '<tr><th scope="row">' . AdminLocale::esc_html__('Checkout Mode', 'gr-commerce-suite') . '</th><td><span class="grcs-log-level" style="'
                    . ($classic ? 'background:#dcfce7;color:#166534' : 'background:#fef3c7;color:#92400e')
                    . '">' . esc_html(AdminLocale::display($value)) . '</span>';
                if (($value === 'Block Checkout' || has_block('woocommerce/cart', wc_get_page_id('cart')))
                    && current_user_can('edit_post', wc_get_page_id('checkout'))
                    && current_user_can('edit_post', wc_get_page_id('cart'))) {
                    echo '<p>' . AdminLocale::esc_html__('Classic Cart and Checkout are recommended for courier maps, COD filtering and invoice fields. Both pages will be switched together.', 'gr-commerce-suite') . '</p>'
                        . '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
                    wp_nonce_field('grcs_classic_checkout');
                    echo '<input type="hidden" name="action" value="grcs_classic_checkout" />'
                        . '<button class="button button-primary">'
                        . AdminLocale::esc_html__('Switch Checkout to Classic Mode (Recommended)', 'gr-commerce-suite') . '</button></form>';
                }
                echo '</td></tr>';
                continue;
            }
            echo '<tr><th scope="row">' . esc_html(AdminLocale::display((string) $name)) . '</th><td>' . esc_html(AdminLocale::display($value));
            if ($name === 'PHP') {
                $style = match ($phpSecurity['PHP security status']) {
                    'Patched' => 'background:#dcfce7;color:#166534',
                    'Update recommended' => 'background:#fef3c7;color:#92400e',
                    default => 'background:#f3f4f6;color:#4b5563',
                };
                echo ' <span class="grcs-log-level" style="' . esc_attr($style) . '">' . esc_html(AdminLocale::display($phpSecurity['PHP security status'])) . '</span>'
                    . '<br><small>' . esc_html(AdminLocale::display($phpSecurity['PHP security details'])) . '</small>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
        if (isset($phpSecurity['PHP security warning'])) {
            echo '<div class="notice notice-warning inline"><p>' . esc_html(AdminLocale::display($phpSecurity['PHP security warning'])) . '</p></div>';
        }
        echo '<div class="grcs-btn-row"><button type="button" class="button button-primary" data-grcs-copy="#grcs-diagnostic-report">'
            . AdminLocale::esc_html__('Copy Diagnostic Report for Support', 'gr-commerce-suite') . '</button>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('grcs_diagnostics');
        echo '<input type="hidden" name="action" value="grcs_diagnostics" />'
            . '<button class="button" name="diagnostic_operation" value="download">' . AdminLocale::esc_html__('Download Debug Log (.txt)', 'gr-commerce-suite') . '</button> '
            . '<button class="button" name="diagnostic_operation" value="clear">' . AdminLocale::esc_html__('Clear Logs', 'gr-commerce-suite') . '</button></form></div>'
            . '<textarea id="grcs-diagnostic-report" class="grcs-diagnostic-report" readonly aria-label="' . AdminLocale::esc_attr__('Diagnostic report', 'gr-commerce-suite') . '">'
            . esc_html($logger->report(false, $report)) . '</textarea></div>';
        echo '<div class="grcs-card"><h2>' . AdminLocale::esc_html__('System Log / Καταγραφή Συστήματος', 'gr-commerce-suite') . '</h2>'
            . '<div class="grcs-filter-bar"><label>' . AdminLocale::esc_html__('Level', 'gr-commerce-suite') . ' <select data-grcs-log-level><option value="">' . AdminLocale::esc_html__('All', 'gr-commerce-suite') . '</option>';
        foreach (['INFO', 'WARNING', 'ERROR', 'CRITICAL'] as $level) {
            echo '<option value="' . esc_attr($level) . '">' . esc_html(AdminLocale::display($level)) . '</option>';
        }
        echo '</select></label><label>' . AdminLocale::esc_html__('Context', 'gr-commerce-suite') . ' <select data-grcs-log-context><option value="">' . AdminLocale::esc_html__('All', 'gr-commerce-suite') . '</option>';
        $events = array_reverse($logger->safeEvents());
        $contexts = array_unique(array_map(static fn(array $e): string => (string) ($e['context'] ?? ''), $events));
        foreach ($contexts as $context) {
            echo '<option value="' . esc_attr($context) . '">' . esc_html(AdminLocale::display($context)) . '</option>';
        }
        echo '</select></label></div><div class="grcs-table-wrap"><table class="widefat striped"><thead><tr><th>UTC</th><th>' . AdminLocale::esc_html__('Level', 'gr-commerce-suite') . '</th><th>' . AdminLocale::esc_html__('Context', 'gr-commerce-suite') . '</th><th>' . AdminLocale::esc_html__('Message', 'gr-commerce-suite') . '</th></tr></thead><tbody>';
        foreach ($events as $event) {
            $level = (string) ($event['level'] ?? 'INFO');
            $context = (string) ($event['context'] ?? 'SYSTEM');
            echo '<tr data-grcs-log-row data-level="' . esc_attr($level) . '" data-context="' . esc_attr($context) . '"><td>'
                . esc_html((string) ($event['timestamp'] ?? '')) . '</td><td><span class="grcs-log-level grcs-log-level--' . esc_attr(strtolower($level)) . '">'
                . esc_html(AdminLocale::display($level)) . '</span></td><td>' . esc_html(AdminLocale::display($context)) . '</td><td>'
                . esc_html(AdminLocale::display((string) ($event['message'] ?? ''))) . '<details><summary>' . AdminLocale::esc_html__('Details', 'gr-commerce-suite') . '</summary><pre>'
                . esc_html((string) json_encode($event, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) . '</pre></details></td></tr>';
        }
        if ($events === []) {
            echo '<tr><td colspan="4">' . AdminLocale::esc_html__('No events recorded.', 'gr-commerce-suite') . '</td></tr>';
        }
        echo '</tbody></table></div></div>';
    }
}
