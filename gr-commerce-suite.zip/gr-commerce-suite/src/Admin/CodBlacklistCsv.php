<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Services\CodBlacklistService;

/** UTF-8 customer registry download, shared with the protected admin-post handler. */
final class CodBlacklistCsv
{
    /**
     * @param resource $stream
     * @param list<array<string, mixed>> $entries
     */
    public static function write($stream, array $entries): void
    {
        // Excel needs a BOM to recognize Greek names and reasons as UTF-8.
        fwrite($stream, "\xEF\xBB\xBF");
        // Phone/email export only their masked copies; raw identities are no longer stored (GRCS-008).
        $columns = ['customer_name' => AdminLocale::__('Customer', 'gr-commerce-suite'), 'phone_masked' => AdminLocale::__('Phone', 'gr-commerce-suite'), 'email_masked' => AdminLocale::__('Email', 'gr-commerce-suite'), 'ip' => 'IP',
            'postal_code' => AdminLocale::__('Postal Code', 'gr-commerce-suite'), 'courier' => AdminLocale::__('Courier', 'gr-commerce-suite'), 'reason' => AdminLocale::__('Reason', 'gr-commerce-suite'),
            'status' => AdminLocale::__('Status', 'gr-commerce-suite'), 'failures' => AdminLocale::__('Failures', 'gr-commerce-suite'), 'expires_at' => AdminLocale::__('Expires', 'gr-commerce-suite'), 'notes' => AdminLocale::__('Notes', 'gr-commerce-suite')];
        fputcsv($stream, array_values($columns), ',', '"', '');
        foreach ($entries as $entry) {
            $entry['status'] = !empty($entry['whitelisted']) ? AdminLocale::__('Whitelisted', 'gr-commerce-suite') : AdminLocale::__('Blacklisted', 'gr-commerce-suite');
            $entry['failures'] = $entry['failures'] ?? $entry['refusal_count'] ?? 0;
            $entry['expires_at'] = !empty($entry['whitelisted']) || empty($entry['expires_at'])
                ? '' : wp_date('Y-m-d', (int) $entry['expires_at']);
            $row = [];
            foreach ($columns as $key => $label) {
                $value = (string) ($entry[$key] ?? ($key === 'courier' ? 'MANUAL' : ''));
                if ($key === 'ip' && $value !== '') {
                    $value = CodBlacklistService::maskIdentity('ip', $value);
                }
                // Prevent customer-controlled cells from being evaluated as spreadsheet formulas.
                $row[] = preg_match('/^[\s\x00-\x20]*[=+@-]|^[\t\r\n]/u', $value) === 1 ? "'" . $value : $value;
            }
            fputcsv($stream, $row, ',', '"', '');
        }
    }
}
