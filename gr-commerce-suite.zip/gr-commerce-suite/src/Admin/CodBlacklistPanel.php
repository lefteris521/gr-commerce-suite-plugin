<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Services\CodBlacklistService;

/** Presentation of the blacklist workspace; mutations keep the page's existing nonce and route. */
final class CodBlacklistPanel
{
    public static function render(CodBlacklistService $blacklist): void
    {
        echo '<div class="grcs-cod-blacklist">';
        self::table($blacklist);
        self::customerForm($blacklist);
        self::rules();
        echo '<section class="grcs-card"><h2 class="grcs-card__title">'
            . AdminLocale::esc_html__('How It Works / Πώς Λειτουργεί', 'gr-commerce-suite') . '</h2><ol class="grcs-how-it-works">';
        foreach (
            [AdminLocale::__('Παράδοση', 'gr-commerce-suite'), AdminLocale::__('Αποτυχία COD', 'gr-commerce-suite'),
            AdminLocale::__('Καταχώρηση', 'gr-commerce-suite'), AdminLocale::__('Επόμενη Παραγγελία', 'gr-commerce-suite')] as $step
        ) {
            echo '<li>' . esc_html($step) . '</li>';
        }
        echo '</ol><p class="grcs-help">' . AdminLocale::esc_html__('Matching customers use card or bank payment until expiry, unless trusted or whitelisted.', 'gr-commerce-suite') . '</p></section>';
        echo '</div>';
    }

    private static function formStart(): void
    {
        echo '<form method="post"><input type="hidden" name="grcs_cod_action" value="blacklist" />'
            . '<input type="hidden" name="' . esc_attr(CodReconciliationPage::NONCE_FIELD) . '" value="'
            . esc_attr(wp_create_nonce(CodReconciliationPage::NONCE_ACTION_BLACKLIST)) . '" />';
    }

    private static function heading(string $title): void
    {
        echo '<summary class="grcs-card-heading"><span class="grcs-icon-badge dashicons dashicons-shield" aria-hidden="true"></span>'
            . esc_html($title) . '</summary>';
    }

    private static function label(string $id, string $label, string $help): void
    {
        echo '<label for="' . esc_attr($id) . '">' . esc_html($label)
            . ' <span class="grcs-tip" tabindex="0" role="img" data-tip="' . esc_attr($help) . '" aria-label="' . esc_attr($help) . '">?</span></label>';
    }

    private static function rules(): void
    {
        $rules = CodBlacklistService::rules();
        echo '<details class="grcs-card-drawer grcs-card">';
        self::heading(AdminLocale::__('Matching & Exemption Rules / Κανόνες Αντιστοίχισης', 'gr-commerce-suite'));
        echo '<div class="grcs-card-content">';
        self::formStart();
        echo '<div class="grcs-form-grid"><div class="grcs-field">';
        self::label('grcs-rule-strategy', AdminLocale::__('Matching Strategy', 'gr-commerce-suite'), AdminLocale::__('Block COD when a selected phone or email matches. IP matches require a linked phone or email, except explicit standalone IP bans. Whitelists always take priority.', 'gr-commerce-suite'));
        echo '<select id="grcs-rule-strategy" name="blacklist_rules[strategy]">';
        foreach (AdminWorkspace::strategies() as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($rules['strategy'], $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></div>';
        foreach (
            [
            'min_failures' => [AdminLocale::__('Minimum Failures / Ελάχιστες Αποτυχίες', 'gr-commerce-suite'), 1, 10, AdminLocale::__('Distinct failures required before COD is blocked. Manual blacklist additions block immediately.', 'gr-commerce-suite')],
            'trusted_orders' => [AdminLocale::__('Trusted Customer Exemption / Εξαίρεση Αξιόπιστων Πελατών', 'gr-commerce-suite'), 0, 10000, AdminLocale::__('Completed orders for the signed-in customer required for exemption. Zero disables automatic exemption; guest billing email alone never grants trust.', 'gr-commerce-suite')],
            'expiry_days' => [AdminLocale::__('Automatic Expiry / Περίοδος Λήξης Ημέρες', 'gr-commerce-suite'), 1, 3650, AdminLocale::__('Entries expire after this many days without a new failure. Repeated syncs do not renew expiry.', 'gr-commerce-suite')],
            ] as $key => [$label, $min, $max, $help]
        ) {
            echo '<div class="grcs-field">';
            self::label('grcs-rule-' . $key, $label, $help);
            echo '<input type="number" id="grcs-rule-' . esc_attr($key) . '" name="blacklist_rules[' . esc_attr($key)
                . ']" min="' . esc_attr((string) $min) . '" max="' . esc_attr((string) $max) . '" step="1" required value="'
                . esc_attr((string) $rules[$key]) . '" /></div>';
        }
        echo '</div><div class="grcs-form-actions"><button class="button button-primary" name="blacklist_operation" value="rules">'
            . AdminLocale::esc_html__('Save Rules', 'gr-commerce-suite') . '</button></div></form></div></details>';
    }

    private static function reasonSelect(): void
    {
        echo '<select name="blacklist_reason" aria-label="' . AdminLocale::esc_attr__('Reason / Αιτία', 'gr-commerce-suite') . '">';
        foreach (CodBlacklistService::reasons(true) as $value => $label) {
            echo '<option value="' . esc_attr($value) . '">' . esc_html($label) . '</option>';
        }
        echo '</select>';
    }

    private static function customerForm(CodBlacklistService $blacklist): void
    {
        echo '<details class="grcs-card-drawer grcs-card">';
        self::heading(AdminLocale::__('Μαύρη Λίστα Αντικαταβολών / Customer Management', 'gr-commerce-suite'));
        echo '<div class="grcs-card-content">';
        self::formStart();
        echo '<div class="grcs-form-grid">';
        foreach (
            ['phone' => [AdminLocale::__('Phone', 'gr-commerce-suite'), 'tel', AdminLocale::__('Greek telephone, with or without +30 / 0030.', 'gr-commerce-suite')],
            'email' => [AdminLocale::__('Email', 'gr-commerce-suite'), 'email', AdminLocale::__('Customer billing email.', 'gr-commerce-suite')],
            'customer_name' => [AdminLocale::__('Customer Name', 'gr-commerce-suite'), 'text', AdminLocale::__('Name shown on the order.', 'gr-commerce-suite')],
            'postal_code' => [AdminLocale::__('Postal Code', 'gr-commerce-suite'), 'text', AdminLocale::__('Customer delivery postal code.', 'gr-commerce-suite')],
            'notes' => [AdminLocale::__('Notes / Σημείωση', 'gr-commerce-suite'), 'text', AdminLocale::__('Private merchant note for this record.', 'gr-commerce-suite')],
            ] as $key => [$label, $type, $help]
        ) {
            $value = is_string($_POST['blacklist_' . $key] ?? null) ? wp_unslash($_POST['blacklist_' . $key]) : '';
            echo '<div class="grcs-field">';
            self::label('grcs-blacklist-' . $key, $label, $help);
            echo '<input id="grcs-blacklist-' . esc_attr($key) . '" name="blacklist_' . esc_attr($key) . '" type="'
                . esc_attr($type) . '" value="' . esc_attr($value) . '" /></div>';
        }
        echo '<div class="grcs-field"><label>' . AdminLocale::esc_html__('Reason / Αιτία', 'gr-commerce-suite') . '</label>';
        self::reasonSelect();
        echo '</div></div><p><label><input type="checkbox" name="blacklist_whitelisted" value="1" /> '
            . AdminLocale::esc_html__('Add as Whitelist / Προσθήκη ως Whitelist', 'gr-commerce-suite') . '</label></p><div class="grcs-form-actions">';
        foreach (
            ['check' => AdminLocale::__('Check Customer', 'gr-commerce-suite'), 'add' => AdminLocale::__('Blacklist Customer', 'gr-commerce-suite'),
            'whitelist' => AdminLocale::__('Whitelist', 'gr-commerce-suite'), 'remove' => AdminLocale::__('Remove from Blacklist', 'gr-commerce-suite')] as $value => $label
        ) {
            echo '<button class="button" name="blacklist_operation" value="' . esc_attr($value) . '">' . esc_html($label) . '</button>';
        }
        echo '</div>';
        if (isset($_POST['blacklist_phone']) || isset($_POST['blacklist_email'])) {
            foreach (['phone', 'email'] as $type) {
                $value = is_string($_POST['blacklist_' . $type] ?? null) ? wp_unslash($_POST['blacklist_' . $type]) : '';
                if ($value !== '') {
                    $record = $blacklist->getRecord($type, $value);
                    echo '<p role="status">' . esc_html($value . ' — ' . (!empty($record['whitelisted']) ? AdminLocale::__('Whitelisted', 'gr-commerce-suite')
                        : ($blacklist->recordBlocks($record) ? AdminLocale::__('Blacklisted', 'gr-commerce-suite') : AdminLocale::__('Allowed', 'gr-commerce-suite')))
                        . ' · ' . sprintf(AdminLocale::__('Refusals: %d', 'gr-commerce-suite'), (int) ($record['refusal_count'] ?? 0))
                        . ' · ' . sprintf(AdminLocale::__('Failures: %d', 'gr-commerce-suite'), (int) ($record['failures'] ?? 0))) . '</p>';
                }
            }
        }
        echo '</form><hr class="grcs-card__divider" />';
        self::formStart();
        echo '<div class="grcs-field">';
        self::label('grcs-blacklist-notice', AdminLocale::__('Checkout notice (leave empty to disable)', 'gr-commerce-suite'), AdminLocale::__('Polite explanation shown when COD is unavailable.', 'gr-commerce-suite'));
        echo '<input id="grcs-blacklist-notice" name="blacklist_notice" value="' . esc_attr((string) get_option(CodBlacklistService::OPTION_NOTICE, '')) . '" /></div>'
            . '<div class="grcs-form-actions"><button class="button" name="blacklist_operation" value="notice">' . AdminLocale::esc_html__('Save Notice', 'gr-commerce-suite') . '</button></div></form></div></details>';
        echo '<details class="grcs-card-drawer grcs-card"><summary class="grcs-card-heading">'
            . AdminLocale::esc_html__('Bulk Import / Μαζική Εισαγωγή', 'gr-commerce-suite') . '</summary><div class="grcs-card-content">';
        self::formStart();
        echo '<p class="grcs-help">' . AdminLocale::esc_html__('Paste up to 100 lines: phone, email, or phone, email on each line.', 'gr-commerce-suite') . '</p>';
        echo '<div class="grcs-field"><label for="grcs-blacklist-import">' . AdminLocale::esc_html__('Customer identities', 'gr-commerce-suite') . '</label>'
            . '<textarea id="grcs-blacklist-import" name="blacklist_import" rows="8" maxlength="30000" required placeholder="' . AdminLocale::esc_attr__('6971234567, customer@example.gr', 'gr-commerce-suite') . '"></textarea></div><div class="grcs-field">';
        self::reasonSelect();
        echo '</div><p><label><input type="checkbox" name="blacklist_whitelisted" value="1" /> '
            . AdminLocale::esc_html__('Add as Whitelist / Προσθήκη ως Whitelist', 'gr-commerce-suite') . '</label></p>'
            . '<button class="button button-primary" name="blacklist_operation" value="import">' . AdminLocale::esc_html__('Import Entries', 'gr-commerce-suite') . '</button></form></div></details>';
    }

    /** @return array{search: string, courier: string, reason: string, status: string} */
    public static function filters(): array
    {
        $get = static fn(string $key): string => is_string($_GET[$key] ?? null) ? sanitize_text_field(wp_unslash($_GET[$key])) : '';
        $reason = $get('blacklist_filter');
        return ['search' => $get('blacklist_search'), 'courier' => $get('blacklist_courier'),
            'reason' => $reason === 'whitelist' ? '' : $reason,
            'status' => $get('blacklist_status') ?: ($reason === 'whitelist' ? 'whitelisted' : '')];
    }

    private static function table(CodBlacklistService $blacklist): void
    {
        $filters = self::filters();
        $entries = $blacklist->listEntries($filters['search'], $filters['courier'], $filters['reason'], $filters['status']);
        $whitelisted = count(array_filter($entries, static fn(array $entry): bool => !empty($entry['whitelisted'])));
        echo '<section class="grcs-card grcs-blacklist-registry" data-grcs-registry><h2 class="grcs-card__title">' . AdminLocale::esc_html__('Blacklist & Whitelist Registry', 'gr-commerce-suite') . '</h2>'
            . '<p class="grcs-help">' . AdminLocale::esc_html__('Up to 200 matching customers are shown. CSV includes all matches. Expired records are excluded.', 'gr-commerce-suite') . '</p>'
            . '<form method="get" class="grcs-filter-bar"><input type="hidden" name="page" value="' . esc_attr(CodReconciliationPage::MENU_SLUG) . '" /><input type="hidden" name="tab" value="blacklist" />'
            . '<input type="hidden" name="' . esc_attr(CodReconciliationPage::NONCE_FIELD) . '" value="' . esc_attr(wp_create_nonce(CodReconciliationPage::NONCE_ACTION_BLACKLIST_EXPORT)) . '" />'
            . '<input type="search" name="blacklist_search" value="' . esc_attr($filters['search']) . '" aria-label="' . AdminLocale::esc_attr__('Search phone, email, or name', 'gr-commerce-suite') . '" placeholder="' . AdminLocale::esc_attr__('Search phone, email, or name...', 'gr-commerce-suite') . '" />';
        foreach (
            ['blacklist_courier' => ['' => AdminLocale::__('All Couriers', 'gr-commerce-suite'), 'ACS' => 'ACS', 'BOX NOW' => 'BOX NOW', 'MANUAL' => 'MANUAL'],
            'blacklist_filter' => ['' => AdminLocale::__('All Reasons', 'gr-commerce-suite')] + CodBlacklistService::reasons(true),
            'blacklist_status' => ['' => AdminLocale::__('All Statuses', 'gr-commerce-suite'), 'blacklisted' => AdminLocale::__('Blacklisted', 'gr-commerce-suite'),
                'whitelisted' => AdminLocale::__('Whitelisted', 'gr-commerce-suite')]] as $name => $options
        ) {
            $key = match ($name) { 'blacklist_courier' => 'courier', 'blacklist_filter' => 'reason', default => 'status' };
            $label = match ($key) {
                'courier' => AdminLocale::__('Courier filter', 'gr-commerce-suite'), 'reason' => AdminLocale::__('Reason filter', 'gr-commerce-suite'),
                default => AdminLocale::__('Whitelist status', 'gr-commerce-suite'),
            };
            echo '<select name="' . esc_attr($name) . '" aria-label="' . esc_attr($label) . '">';
            foreach ($options as $value => $label) {
                echo '<option value="' . esc_attr($value) . '"' . selected($filters[$key], $value, false) . '>' . esc_html($label) . '</option>';
            }
            echo '</select>';
        }
        echo '<button class="button" type="submit">' . AdminLocale::esc_html__('Filter', 'gr-commerce-suite') . '</button>'
            . '<button class="button" type="submit" name="action" value="grcs_cod_export_blacklist" formaction="' . esc_url(admin_url('admin-post.php')) . '">'
            . AdminLocale::esc_html__('Export Blacklist (CSV)', 'gr-commerce-suite') . '</button></form>'
            . '<p class="grcs-help" data-grcs-registry-feedback role="status" data-loading="' . AdminLocale::esc_attr__('Searching customers…', 'gr-commerce-suite')
            . '" data-error="' . AdminLocale::esc_attr__('Search could not refresh. Use Filter to try again.', 'gr-commerce-suite') . '"></p>'
            . '<div data-grcs-registry-results><div class="grcs-registry-counts" role="status" aria-live="polite">'
            . '<span class="grcs-pill grcs-pill--red">' . esc_html(sprintf(AdminLocale::_n('%d blacklisted customer', '%d blacklisted customers', count($entries) - $whitelisted, 'gr-commerce-suite'), count($entries) - $whitelisted)) . '</span>'
            . '<span class="grcs-pill grcs-pill--green">' . esc_html(sprintf(AdminLocale::_n('%d whitelisted customer', '%d whitelisted customers', $whitelisted, 'gr-commerce-suite'), $whitelisted)) . '</span></div>'
            . '<div class="grcs-table-wrap"><table class="widefat grcs-table"><thead><tr>';
        foreach (
            [AdminLocale::__('Customer', 'gr-commerce-suite'), AdminLocale::__('Courier', 'gr-commerce-suite'), AdminLocale::__('Reason', 'gr-commerce-suite'),
            AdminLocale::__('Failures', 'gr-commerce-suite'), AdminLocale::__('Expires', 'gr-commerce-suite'), AdminLocale::__('Actions', 'gr-commerce-suite')] as $label
        ) {
            echo '<th>' . esc_html($label) . '</th>';
        }
        echo '</tr></thead><tbody>';
        foreach (array_slice($entries, 0, 200) as $entry) {
            $white = !empty($entry['whitelisted']);
            echo '<tr' . ($white ? ' class="grcs-whitelisted"' : '') . '><td>';
            $name = trim((string) ($entry['customer_name'] ?? ''));
            echo '<strong>' . esc_html($name !== '' ? $name : '—') . '</strong>';
            echo '<div class="grcs-customer-identifiers">';
            // Phone/email are stored as digests (GRCS-008); show the masked copy, post back the digest below.
            foreach (['phone_masked' => AdminLocale::__('📞 Phone: ', 'gr-commerce-suite'), 'email_masked' => AdminLocale::__('✉️ Email: ', 'gr-commerce-suite'), 'ip' => '🌐 IP: ', 'postal_code' => AdminLocale::__('ΤΚ: ', 'gr-commerce-suite')] as $field => $prefix) {
                $value = trim((string) ($entry[$field] ?? ''));
                if ($field === 'ip' && $value !== '') {
                    $value = CodBlacklistService::maskIdentity('ip', $value);
                }
                if ($value !== '' || $field !== 'postal_code') {
                    echo '<span class="grcs-identity-chip">' . esc_html($prefix . ($value !== '' ? $value : '—')) . '</span>';
                }
            }
            echo '</div>'
                . '<p class="grcs-help">' . esc_html((string) ($entry['notes'] ?? '')) . '</p></td><td><span class="grcs-pill grcs-pill--'
                . esc_attr(($entry['courier'] ?? '') === 'BOX NOW' ? 'green' : 'blue') . '">' . esc_html((string) ($entry['courier'] ?? 'MANUAL')) . '</span></td><td>';
            $reasonKey = (string) ($entry['reason'] ?? 'FAILED_DELIVERY');
            $color = match ($reasonKey) {
                'REFUSED' => 'red', 'WRONG_ADDRESS', 'RECIPIENT_NOT_FOUND' => 'amber', default => 'gray'
            };
            echo '<span class="grcs-pill grcs-pill--' . esc_attr($white ? 'green' : $color) . '">' . esc_html($white ? AdminLocale::__('Whitelisted', 'gr-commerce-suite')
                : (CodBlacklistService::reasons(true)[$reasonKey] ?? $reasonKey)) . '</span></td><td>'
                . esc_html((string) ($entry['failures'] ?? $entry['refusal_count'] ?? 0)) . '</td><td>'
                . esc_html($white ? '—' : (isset($entry['expires_at']) ? (wp_date('d/m/Y', (int) $entry['expires_at']) ?: '—') : '—')) . '</td><td>';
            self::formStart();
            foreach (['phone', 'email', 'ip'] as $type) {
                echo '<input type="hidden" name="blacklist_' . esc_attr($type) . '" value="' . esc_attr((string) ($entry[$type] ?? '')) . '" />';
            }
            echo '<button class="button button-small" name="blacklist_operation" value="' . ($white ? 'unwhitelist' : 'whitelist')
                . '" aria-label="' . esc_attr($white ? AdminLocale::__('Remove Whitelist', 'gr-commerce-suite') : AdminLocale::__('Whitelist', 'gr-commerce-suite')) . '">⭐</button> '
                . '<button class="button button-small" name="blacklist_operation" value="remove" aria-label="' . AdminLocale::esc_attr__('Remove', 'gr-commerce-suite') . '">🗑️</button></form></td></tr>';
        }
        if ($entries === []) {
            echo '<tr><td colspan="6" class="grcs-empty">' . AdminLocale::esc_html__('No entries match these filters.', 'gr-commerce-suite') . '</td></tr>';
        }
        echo '</tbody></table></div></div></section>';
    }
}
