<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Contracts\HookSubscriberInterface;

/**
 * Enqueues the shared admin stylesheet (`assets/css/admin-ui.css`) and progressive-enhancement
 * script (`assets/js/admin-ui.js`) strictly on GR Commerce Suite screens:
 *
 *  - WooCommerce → COD Reconciliation (`woocommerce_page_grcs-cod-reconciliation`)
 *  - WooCommerce → Customer 360° (`woocommerce_page_grcs-customer-360`)
 *  - WooCommerce → Settings → GR Commerce Suite (`page=wc-settings&tab=gr_commerce_suite`)
 *
 * The order metabox stylesheet is enqueued by {@see OrderMetaboxAndBulkActions::enqueueAdminAssets()}
 * using the same handle so it is never printed twice.
 */
final class AdminUiAssets implements HookSubscriberInterface
{
    public const STYLE_HANDLE = 'grcs-admin-ui';

    public const SCRIPT_HANDLE = 'grcs-admin-ui';

    public const BODY_CLASS = 'grcs-admin-screen';

    public const SETTINGS_TAB = 'gr_commerce_suite';

    public function register(): void
    {
        if (!function_exists('add_action') || !function_exists('add_filter')) {
            return;
        }

        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_filter('admin_body_class', [$this, 'filterBodyClass']);
    }

    /**
     * Whether the current admin request renders one of the plugin's own screens.
     */
    public function isPluginScreen(string $hook = ''): bool
    {
        if (in_array($hook, [CodReconciliationPage::SCREEN_ID, Customer360Page::SCREEN_ID], true)) {
            return true;
        }

        $page = $this->queryArg('page');
        if (in_array($page, [CodReconciliationPage::MENU_SLUG, Customer360Page::MENU_SLUG], true)) {
            return true;
        }

        return $page === 'wc-settings' && $this->queryArg('tab') === self::SETTINGS_TAB;
    }

    public function enqueue(string $hook = ''): void
    {
        if (!$this->isPluginScreen($hook)) {
            return;
        }

        self::enqueueStyle();

        if (!function_exists('wp_enqueue_script')) {
            return;
        }

        wp_enqueue_script(
            self::SCRIPT_HANDLE,
            self::assetUrl('assets/js/admin-ui.js'),
            ['jquery'],
            self::version(),
            true
        );

        if (function_exists('wp_localize_script')) {
            wp_localize_script(self::SCRIPT_HANDLE, 'grcsAdminUi', [
                'i18n' => [
                    'copied' => AdminLocale::__('Copied!', 'gr-commerce-suite'),
                    'copyFailed' => AdminLocale::__('Press Ctrl+C to copy', 'gr-commerce-suite'),
                    'enabled' => AdminLocale::__('Enabled', 'gr-commerce-suite'),
                    'disabled' => AdminLocale::__('Disabled', 'gr-commerce-suite'),
                    'awaitingCredentials' => AdminLocale::__('Awaiting credentials', 'gr-commerce-suite'),
                ],
            ]);
        }
    }

    /**
     * Enqueue only the stylesheet (shared with the order metabox).
     */
    public static function enqueueStyle(): void
    {
        if (!function_exists('wp_enqueue_style')) {
            return;
        }

        wp_enqueue_style(self::STYLE_HANDLE, self::assetUrl('assets/css/admin-ui.css'), [], self::version());
    }

    public function filterBodyClass(mixed $classes): string
    {
        $classes = is_string($classes) ? $classes : '';
        if (!$this->isPluginScreen()) {
            return $classes;
        }

        return trim($classes . ' ' . self::BODY_CLASS);
    }

    private static function assetUrl(string $relativePath): string
    {
        $pluginFile = defined('GRCS_PLUGIN_FILE') ? (string) constant('GRCS_PLUGIN_FILE') : __FILE__;

        return function_exists('plugins_url') ? plugins_url($relativePath, $pluginFile) : $relativePath;
    }

    private static function version(): string
    {
        return defined('GRCS_VERSION') ? (string) constant('GRCS_VERSION') : '1.0.0';
    }

    private function queryArg(string $key): string
    {
        $raw = $_GET[$key] ?? '';
        if (!is_string($raw)) {
            return '';
        }

        return strtolower((string) preg_replace('/[^a-zA-Z0-9_\-]/', '', $raw));
    }
}
