<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Modules\EmbeddedIntegrations;
use GRCommerceSuite\Modules\ModuleRegistry;

/** Shared configuration entry for implementations actually shipped and booted by the suite. */
final class EmbeddedIntegrationPanel
{
    public static function stateLabel(string $state): string
    {
        $labels = [
            'available' => ['Included in GR Commerce Suite', 'Περιλαμβάνεται στο GR Commerce Suite'],
            'pending' => ['Reload to start the enabled integration', 'Ανανεώστε για να ξεκινήσει η ενεργή διασύνδεση'],
            'missing_bundle' => ['Integration files are missing from this suite package', 'Λείπουν τα αρχεία διασύνδεσης από το πακέτο της σουίτας'],
            'unavailable' => ['Integration could not start; check the suite log and PHP requirements', 'Η διασύνδεση δεν ξεκίνησε· ελέγξτε το αρχείο καταγραφής και τις απαιτήσεις PHP'],
            'off_status' => ['Disabled for new work; existing records are retained', 'Ανενεργό για νέες εργασίες· οι υπάρχουσες εγγραφές διατηρούνται'],
        ];
        return ($labels[$state] ?? $labels['unavailable'])[AdminLocale::locale() === 'el' ? 1 : 0];
    }

    public static function render(string $key, string $settingsUrl, string $label, string $settingsCapability = 'manage_woocommerce'): void
    {
        if (!ModuleRegistry::isEnabled($key) || !current_user_can('manage_woocommerce')) {
            return;
        }
        $info = EmbeddedIntegrations::status($key);
        $el = AdminLocale::locale() === 'el';
        echo '<tr><td colspan="2"><p role="status" data-grcs-embedded-state="' . esc_attr($info['state']) . '"><strong>'
            . esc_html(self::stateLabel($info['state'])) . '</strong></p>';
        echo '<p>' . esc_html($label . ' ' . $info['version']) . '</p>';
        echo '<p>' . esc_html($el ? 'Δεν χρειάζεται ξεχωριστή εγκατάσταση πρόσθετου. Καταχωρίστε τους κωδικούς και ρυθμίστε τις λειτουργίες στην ενσωματωμένη σελίδα ρυθμίσεων.'
            : 'No separate plugin installation is needed. Enter credentials and configure the integration on its built-in settings page.') . '</p>';
        if ($info['source'] === 'external') {
            echo '<p>' . esc_html($el ? 'Χρησιμοποιείται η ήδη ενεργή ξεχωριστή εγκατάσταση ώστε να μη φορτωθεί δεύτερο αντίγραφο.'
                : 'The existing active standalone copy is being used to avoid loading a second copy.') . '</p>';
        }
        if ($info['state'] === 'available' && current_user_can($settingsCapability)) {
            echo '<p><a class="button button-primary" href="' . esc_url($settingsUrl) . '">'
                . esc_html($el ? 'Ρυθμίσεις ' . $label : 'Configure ' . $label) . '</a></p>';
        } elseif ($info['state'] === 'pending') {
            echo '<p><a class="button" href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite')) . '">'
                . esc_html($el ? 'Ανανέωση ρυθμίσεων' : 'Reload settings') . '</a></p>';
        }
        if (in_array($key, [ModuleRegistry::COURIER_CENTER], true)) {
            echo '<p>' . esc_html($el ? 'Επιλέξτε την υλοποίηση BOX NOW για νέες αποστολές στη σελίδα Modules. Το ιστορικό και το tracking των εγγενών αποστολών παραμένουν στην υπάρχουσα υλοποίηση.'
                : 'Choose the BOX NOW implementation for new shipments on the Modules page. Existing native shipment history and tracking keep their current owner.') . '</p>';
        }
        echo '<p>' . esc_html($el ? 'Η φόρτωση κώδικα δεν επαληθεύει τους κωδικούς ή τη σύνδεση. Ολοκληρώστε τις δοκιμές του παρόχου πριν από πραγματικές συναλλαγές.'
            : 'Loading the implementation does not verify credentials or connectivity. Complete provider testing before live transactions.') . '</p></td></tr>';
    }
}
