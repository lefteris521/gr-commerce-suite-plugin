<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Couriers\AcsProvider;
use GRCommerceSuite\Couriers\BoxNowProvider;
use GRCommerceSuite\Couriers\GenikiProvider;
use GRCommerceSuite\Modules\Geniki\GenikiSettings;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Security\CredentialVault;
use GRCommerceSuite\Services\LicenseManager;
use Throwable;

/** A read-only credential probe; never creates parcels or saves submitted secrets. */
final class CourierConnectionTest implements HookSubscriberInterface
{
    public const NONCE_ACTION = 'grcs_test_courier_connection';
    private ?bool $sandboxOverride = null;

    public function __construct(
        private readonly HttpClientInterface $http,
        private readonly CredentialVault $vault,
    ) {
    }

    public function register(): void
    {
        LicenseManager::assertLicensed();
        add_action('wp_ajax_grcs_test_courier_connection', [$this, 'handleAjax']);
    }

    public function sandboxEnabled(bool $enabled): bool
    {
        return $this->sandboxOverride ?? $enabled;
    }

    /** @param array<string, mixed> $data */
    private function sendJsonError(array $data, int $status): void
    {
        wp_send_json_error($data, $status);
    }

    public function handleAjax(): void
    {
        LicenseManager::assertLicensed();
        if (!current_user_can('manage_woocommerce') || !check_ajax_referer(self::NONCE_ACTION, 'security', false)) {
            $this->sendJsonError(
                ['message' => AdminLocale::__(
                    'Permission or security nonce verification failed.',
                    'gr-commerce-suite'
                )],
                403
            );
            return;
        }
        $slug = is_string($_POST['courier'] ?? null) ? CourierSlug::tryFrom($_POST['courier']) : null;
        if ($slug === null) {
            $this->sendJsonError(['message' => AdminLocale::__('Select a supported courier.', 'gr-commerce-suite')], 400);
            return;
        }
        if (!\GRCommerceSuite\Modules\ModuleRegistry::courierEnabled($slug)) {
            $this->sendJsonError(['message' => AdminLocale::__('This module is turned off. Turn it on in GR Commerce Suite > Modules to test the connection.', 'gr-commerce-suite')], 400);
            return;
        }
        $keys = match ($slug) {
            CourierSlug::Acs => ['api_key', 'company_id', 'company_password', 'user_id', 'user_password', 'billing_code'],
            CourierSlug::BoxNow => ['client_id', 'client_secret', 'origin_location_id'],
            CourierSlug::Geniki => array_keys(GenikiSettings::vaultOptionMap()),
        };
        $submitted = is_array($_POST['credentials'] ?? null) ? $_POST['credentials'] : [];
        $credentials = $this->vault->getForCourier($slug);
        foreach ($keys as $key) {
            $option = $slug === CourierSlug::Geniki ? GenikiSettings::vaultOptionMap()[$key] : 'grcs_' . $slug->value . '_' . $key;
            if (array_key_exists($key, $submitted)) {
                $value = is_string($submitted[$key]) ? trim(wp_unslash($submitted[$key])) : '';
                if ($slug !== CourierSlug::Geniki || $value !== '' || !in_array($key, CredentialVault::SECRET_FIELDS['geniki'], true)) {
                    $credentials[$key] = $value;
                }
            } else {
                $value = get_option($option, $credentials[$key] ?? '');
                $credentials[$key] = is_string($value) ? trim($value) : '';
            }
        }
        if (isset($_POST['sandbox_mode'])) {
            $this->sandboxOverride = $_POST['sandbox_mode'] === 'yes';
        }
        add_filter('grcs/sandbox/enabled', [$this, 'sandboxEnabled'], PHP_INT_MAX);
        $sandbox = false;
        try {
            $sandbox = (new LicenseManager())->isSandboxEnabled();
            if (!$sandbox) {
                $required = match ($slug) {
                    CourierSlug::Acs => ['api_key', 'company_id', 'company_password', 'user_id', 'user_password'],
                    CourierSlug::BoxNow => ['client_id', 'client_secret'],
                    CourierSlug::Geniki => ['username', 'password', 'application_key'],
                };
                foreach ($required as $key) {
                    if ($credentials[$key] === '') {
                        $this->sendJsonError(
                            ['message' => AdminLocale::__(
                                'Fill in all courier authentication fields first.',
                                'gr-commerce-suite'
                            )],
                            422
                        );
                        return;
                    }
                }
            }
            $provider = match ($slug) {
                CourierSlug::Acs => new AcsProvider($this->http, $credentials),
                CourierSlug::BoxNow => new BoxNowProvider($this->http, $credentials),
                CourierSlug::Geniki => new GenikiProvider($this->http, $credentials),
            };
            $success = $provider->testConnection();
            $message = $success && $slug === CourierSlug::Geniki
                ? AdminLocale::__('Geniki authentication successful for the selected environment.', 'gr-commerce-suite')
                : ($success
                ? ($sandbox ? AdminLocale::__(
                    'Sandbox connection successful. Live credentials were not tested.',
                    'gr-commerce-suite'
                ) : AdminLocale::__(
                    'Courier authentication successful.',
                    'gr-commerce-suite'
                ))
                : AdminLocale::__(
                    'Connection failed. Check credentials, courier availability and Sandbox timeout settings.',
                    'gr-commerce-suite'
                ));
        } catch (Throwable) {
            $success = false;
            $message = AdminLocale::__('Connection failed. Please check your courier settings and try again.', 'gr-commerce-suite');
        } finally {
            remove_filter('grcs/sandbox/enabled', [$this, 'sandboxEnabled'], PHP_INT_MAX);
            $this->sandboxOverride = null;
        }
        if ($success) {
            wp_send_json_success(['message' => $message, 'sandbox' => $sandbox]);
        } else {
            $this->sendJsonError(['message' => $message], 422);
        }
    }
}
