<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;

use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Feed\SkroutzXmlGenerator;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Modules\Geniki\GenikiSettings;
use GRCommerceSuite\Modules\CourierCenter\CourierCenterModule;
use GRCommerceSuite\Security\CredentialVault;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\ShippingOptions;
use GRCommerceSuite\Services\VoucherStatusRule;
use GRCommerceSuite\Frontend\BankTransferAccounts;
use GRCommerceSuite\Frontend\BoxNowCheckoutPicker;
use GRCommerceSuite\Frontend\CheckoutPaymentRules;
use GRCommerceSuite\Frontend\GreekInvoiceCheckout;
use RuntimeException;
use WC_Admin_Settings;
use WC_Settings_Page;

/**
 * WooCommerce Settings Tab (`gr_commerce_suite`) for GR Commerce Suite (SPEC.md §13, §15.2).
 *
 * Loaded lazily via the `woocommerce_get_settings_pages` filter after WooCommerce
 * initializes `\WC_Settings_Page` so that `Class 'WC_Settings_Page' not found` fatals
 * can never occur during `plugins_loaded`.
 */
final class SettingsPage extends WC_Settings_Page
{
    public const PAGE_ID = 'gr_commerce_suite';

    public const OPTION_LICENSE_KEY = LicenseManager::OPTION_LICENSE_KEY;
    public const OPTION_LICENSE_STATUS = LicenseManager::OPTION_LICENSE_STATUS;

    public const OPTION_SANDBOX_MODE = 'grcs_sandbox_mode';
    public const OPTION_SANDBOX_TIMEOUT = 'grcs_sandbox_simulate_timeout';

    public const OPTION_ACS_API_KEY = 'grcs_acs_api_key';
    public const OPTION_ACS_COMPANY_ID = 'grcs_acs_company_id';
    public const OPTION_ACS_COMPANY_PASSWORD = 'grcs_acs_company_password';
    public const OPTION_ACS_USER_ID = 'grcs_acs_user_id';
    public const OPTION_ACS_USER_PASSWORD = 'grcs_acs_user_password';
    public const OPTION_ACS_BILLING_CODE = 'grcs_acs_billing_code';

    public const OPTION_BOXNOW_CLIENT_ID = 'grcs_boxnow_client_id';
    public const OPTION_BOXNOW_CLIENT_SECRET = 'grcs_boxnow_client_secret';
    public const OPTION_BOXNOW_ORIGIN_LOCATION_ID = 'grcs_boxnow_origin_location_id';

    public const OPTION_SKROUTZ_FEED_ENABLED = 'grcs_skroutz_feed_enabled';
    public const OPTION_SKROUTZ_MARKUP_PERCENT = SkroutzXmlGenerator::OPTION_MARKUP_PERCENT;

    /** Section keys rendered as individual cards (order matches the sub-navigation). */
    private const SECTION_KEYS = ['license', 'modules', 'general', 'acs', 'boxnow', 'geniki', 'courier_center', 'invoice', 'bank', 'skroutz'];

    public const MODULES_FIELD_TYPE = 'grcs_modules';

    /** Settings sections that belong to a module and disappear (view, fields, save) while it is off. */
    private const MODULE_SECTIONS = ['acs' => ModuleRegistry::ACS, 'boxnow' => ModuleRegistry::BOXNOW, 'geniki' => ModuleRegistry::GENIKI, 'courier_center' => ModuleRegistry::COURIER_CENTER, 'skroutz' => ModuleRegistry::SKROUTZ];

    private static function sectionAvailable(string $key): bool
    {
        return !isset(self::MODULE_SECTIONS[$key]) || ModuleRegistry::isEnabled(self::MODULE_SECTIONS[$key]);
    }

    public function __construct()
    {
        $this->id = self::PAGE_ID;
        $this->label = AdminLocale::__('GR Commerce Suite', 'gr-commerce-suite');

        parent::__construct();
        add_filter('woocommerce_admin_settings_sanitize_option_' . AdminLocale::OPTION,
            [AdminLocale::class, 'sanitize']);
        add_filter('woocommerce_admin_settings_sanitize_option_' . VoucherStatusRule::OPTION,
            [VoucherStatusRule::class, 'sanitize']);

        // WooCommerce settings API hooks for the custom bank-accounts table field.
        add_action('woocommerce_admin_field_' . BankTransferAccounts::FIELD_TYPE, [BankTransferAccounts::class, 'renderSettingsField']);
        add_action('woocommerce_admin_field_' . self::MODULES_FIELD_TYPE, [$this, 'renderModulesField']);
        (new CourierCenterModule())->register();
        add_filter('woocommerce_admin_settings_sanitize_option_' . BankTransferAccounts::OPTION_ACCOUNTS, [BankTransferAccounts::class, 'sanitizeSettingsField'], 10, 3);
        add_filter('woocommerce_admin_settings_sanitize_option_' . BankTransferAccounts::OPTION_FEE_WARNING, [BankTransferAccounts::class, 'sanitizeWarning']);
    }

    /**
     * Define subsections on the GR Commerce Suite WooCommerce settings tab.
     *
     * @return array<string, string>
     */
    // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps
    protected function get_own_sections(): array
    {
        return array_filter([
            '' => AdminLocale::__('All Settings', 'gr-commerce-suite'),
            'license' => AdminLocale::__('License Activation', 'gr-commerce-suite'),
            'modules' => AdminLocale::__('Modules', 'gr-commerce-suite'),
            'general' => AdminLocale::__('General / Sandbox Mode', 'gr-commerce-suite'),
            'acs' => AdminLocale::__('ACS Courier', 'gr-commerce-suite'),
            'boxnow' => AdminLocale::__('BOX NOW', 'gr-commerce-suite'),
            'geniki' => AdminLocale::__('Geniki Taxydromiki', 'gr-commerce-suite'),
            'courier_center' => CourierCenterModule::definition()['label'],
            'invoice' => AdminLocale::__('Receipt / Invoice (Τιμολόγιο)', 'gr-commerce-suite'),
            'bank' => AdminLocale::__('Τραπεζικοί Λογαριασμοί (Τραπεζική Κατάθεση)', 'gr-commerce-suite'),
            'skroutz' => AdminLocale::__('Skroutz XML Feed', 'gr-commerce-suite'),
        ], static fn(string $label, string $key): bool => self::sectionAvailable($key), ARRAY_FILTER_USE_BOTH);
    }

    /**
     * Return settings array for the requested section.
     *
     * When `$section_id` is `''` (the default landing view on `tab=gr_commerce_suite`),
     * all sections are returned together so merchants can configure Sandbox Mode, ACS,
     * BOX NOW, and the Skroutz XML Feed from a single screen or via sub-section links.
     *
     * @param string $section_id
     * @return array<int, array<string, mixed>>
     */
    // phpcs:ignore PSR1.Methods.CamelCapsMethodName.NotCamelCaps
    protected function get_settings_for_section_core($section_id): array
    {
        $section = strtolower(trim((string) $section_id));

        // A disabled module contributes NO fields. WooCommerce saves exactly this list, and an absent checkbox is saved as
        // "no", so hidden fields must not be part of it or an "All Settings" save would rewrite the module's stored values.
        $fields = match (true) {
            isset(self::MODULE_SECTIONS[$section]) && !self::sectionAvailable($section) => [],
            $section === 'license' => $this->getLicenseSettings(),
            $section === 'modules' => $this->getModulesSettings(),
            $section === 'general' => $this->getGeneralSettings(),
            $section === 'acs' => $this->getAcsSettings(),
            $section === 'boxnow' => $this->getBoxNowSettings(),
            $section === 'geniki' => GenikiSettings::fields(),
            $section === 'courier_center' => CourierCenterModule::fields(),
            $section === 'invoice' => $this->getInvoiceSettings(),
            $section === 'bank' => $this->getBankSettings(),
            $section === 'skroutz' => $this->getSkroutzSettings(),
            default => array_merge(
                $this->getLicenseSettings(),
                $this->getModulesSettings(),
                $this->getGeneralSettings(),
                self::sectionAvailable('acs') ? $this->getAcsSettings() : [],
                self::sectionAvailable('boxnow') ? $this->getBoxNowSettings() : [],
                self::sectionAvailable('geniki') ? GenikiSettings::fields() : [],
                self::sectionAvailable('courier_center') ? CourierCenterModule::fields() : [],
                $this->getInvoiceSettings(),
                $this->getBankSettings(),
                self::sectionAvailable('skroutz') ? $this->getSkroutzSettings() : [],
            ),
        };
        $vault = new CredentialVault();
        $aade = $vault->getAade();
        $credentials = [
            'acs' => $vault->getForCourier(CourierSlug::Acs),
            'boxnow' => $vault->getForCourier(CourierSlug::BoxNow),
            'geniki' => $vault->getForCourier(CourierSlug::Geniki),
        ];
        foreach ($fields as &$field) {
            foreach (GenikiSettings::vaultOptionMap() as $key => $option) {
                if (($field['id'] ?? '') === $option) {
                    $field['value'] = in_array($key, CredentialVault::SECRET_FIELDS['geniki'], true) ? '' : ($credentials['geniki'][$key] ?? ($field['default'] ?? ''));
                    if (in_array($key, CredentialVault::SECRET_FIELDS['geniki'], true)) {
                        $field['placeholder'] = AdminLocale::__('Leave blank to keep the saved secret', 'gr-commerce-suite');
                    }
                }
            }
            if (!in_array($field['type'] ?? '', ['title', 'sectionend'], true) && !isset($field['desc_tip']) && !isset($field['desc'])) {
                // WooCommerce owns the native Dashicon, label positioning and tipTip bubble.
                // A visible `desc` is never copied into desc_tip: WooCommerce would print it twice
                // (checkbox label + description paragraph, or description + identical tooltip).
                $field['desc_tip'] = AdminLocale::__('Current activation result for the license key entered above.', 'gr-commerce-suite');
            }
            if (($field['id'] ?? '') === GreekInvoiceCheckout::OPTION_PASSWORD) {
                $field['value'] = '';
                $field['placeholder'] = AdminLocale::__('Leave blank to keep saved password', 'gr-commerce-suite');
            }
            if (($field['id'] ?? '') === GreekInvoiceCheckout::OPTION_USERNAME) {
                $field['value'] = $aade['username'];
            }
            foreach (CredentialVault::SECRET_FIELDS as $courier => $keys) {
                foreach ($keys as $key) {
                    if (($field['id'] ?? '') === 'grcs_' . $courier . '_' . $key) {
                        $field['value'] = $courier === 'geniki' ? '' : ($credentials[$courier][$key] ?? '');
                        $field['type'] = 'password';
                    }
                }
            }
        }
        unset($field);
        return $fields;
    }

    /**
     * Render settings fields and the Skroutz XML Feed status/trigger panel.
     *
     * Each settings section is wrapped in its own card (`[data-grcs-section]`) so the
     * sub-navigation can switch sections instantly on the "All Settings" view while every
     * field stays in the DOM (save semantics of the `''` section are unchanged).
     */
    public function output(): void
    {
        global $current_section;

        $section = is_string($current_section) ? strtolower(trim($current_section)) : '';

        $isLicensed = LicenseManager::isLicensed();

        echo '<div class="grcs-ui grcs-admin-wrap grcs-settings-ui" data-grcs-current-section="' . esc_attr($section) . '">';
        AdminWorkspace::header(AdminLocale::__('Settings / Ρυθμίσεις', 'gr-commerce-suite'));
        AdminWorkspace::navigation('settings');

        $this->renderLicenseStatusBanner($isLicensed, $section);

        if (isset($_GET['grcs_skroutz_queued'])) {
            echo '<div class="notice notice-success"><p>' . AdminLocale::esc_html__('XML feed generation queued. See Diagnostics & Logs for progress.', 'gr-commerce-suite') . '</p></div>';
        }

        if (isset($_GET['grcs_skroutz_generated'])) {
            echo '<div class="notice notice-success is-dismissible"><p>'
                . AdminLocale::esc_html__('Skroutz XML feed generated successfully.', 'gr-commerce-suite')
                . '</p></div>';
        }

        $renderSections = in_array($section, self::SECTION_KEYS, true) ? [$section] : self::SECTION_KEYS;
        $renderSections = array_values(array_filter($renderSections, static fn(string $key): bool => self::sectionAvailable($key)));
        $showConnectionPanel = $isLicensed && in_array($section, ['', 'general', 'acs', 'boxnow', 'geniki'], true) && ModuleRegistry::anyCourierEnabled();

        // Pin both columns to the first grid row, directly below the status banner.
        echo '<div class="grcs-workspace grcs-settings-workspace"><main class="grcs-main">';
        foreach ($renderSections as $key) {
            echo '<details open class="grcs-card grcs-settings-section" id="grcs-settings-section-' . esc_attr($key)
                . '" data-grcs-section="' . esc_attr($key) . '"><summary class="grcs-card-heading">'
                . '<span class="grcs-icon-badge dashicons dashicons-admin-settings" aria-hidden="true"></span>'
                . esc_html($this->get_own_sections()[$key]) . '</summary><div class="grcs-card-content">';

            if (in_array($key, ['acs', 'boxnow'], true)) {
                $this->renderCredentialsFaq($key);
            }
            $settings = $this->get_settings_for_section($key);
            // Keep the legacy status option in the settings API, but render its value only in the banner.
            $settings = array_values(array_filter(
                $settings,
                static fn(array $field): bool => ($field['id'] ?? '') !== self::OPTION_LICENSE_STATUS
            ));
            if (class_exists(WC_Admin_Settings::class)) {
                WC_Admin_Settings::output_fields($settings);
            }

            if ($key === 'skroutz' && $isLicensed && ($section === '' || $section === 'skroutz')) {
                $this->renderSkroutzFeedActionPanel();
            }
            if ($key === 'geniki' && $isLicensed) {
                echo '<p><a class="button" href="' . esc_url(\GRCommerceSuite\Modules\Geniki\MerchantFinalization::url()) . '">'
                    . AdminLocale::esc_html__('Review account-wide Geniki finalization', 'gr-commerce-suite') . '</a></p>';
            }

            echo '</div></details>';

            $lastCourierSection = ModuleRegistry::isEnabled(ModuleRegistry::GENIKI) ? 'geniki'
                : (ModuleRegistry::isEnabled(ModuleRegistry::BOXNOW) ? 'boxnow' : 'acs');
            if ($showConnectionPanel && (($section === '' && $key === $lastCourierSection) || ($section !== '' && $key === $section))) {
                $this->renderConnectionTestPanel($section);
            }
        }

        echo '</main>';
        AdminWorkspace::sidebar('settings');
        echo '</div></div>';
    }

    /**
     * Render branch and partner onboarding instructions above courier credentials.
     */
    private function renderCredentialsFaq(string $courier): void
    {
        $summary = $courier === 'acs'
            ? AdminLocale::__('📌 How to obtain your ACS Web Services credentials (FAQ)', 'gr-commerce-suite')
            : AdminLocale::__('📌 How to obtain your BOX NOW API credentials (FAQ)', 'gr-commerce-suite');
        $text = $courier === 'acs'
            ? AdminLocale::__('Do I need credentials from ACS Courier? Yes. Contact your local ACS branch, call (0030) 210-8190000, or email info@acscourier.gr to request ACS Web Services (ACSAutoRest) credentials and your Billing Code (Κωδικός Χρέωσης).', 'gr-commerce-suite')
            : AdminLocale::__('How do I get BOX NOW API credentials? Email info@boxnow.gr or contact your BOX NOW account manager to request your Partner API Client ID, Client Secret, and Warehouse Location ID.', 'gr-commerce-suite');
        echo '<div class="grcs-card__header"><details class="grcs-faq-box"><summary>'
            . esc_html($summary) . '</summary><p>' . esc_html($text) . '</p></details></div>';
    }

    private function renderLicenseStatusBanner(bool $isLicensed, string $section): void
    {
        $status = (new LicenseManager())->merchantStatus();
        $tone = $isLicensed ? ($status['state'] === LicenseManager::STATE_ACTIVE ? 'active' : 'attention') : 'locked';

        echo '<div class="grcs-status-banner grcs-status-banner--' . esc_attr($tone) . '" data-grcs-license-state="' . esc_attr($status['state']) . '">'
            . '<div class="grcs-status-banner__body">'
            . '<p class="grcs-status-banner__label">' . AdminLocale::esc_html__('License Status', 'gr-commerce-suite') . '</p>'
            . '<span class="grcs-license-status" role="status">' . esc_html($status['label']) . '</span>'
            . '<p class="grcs-status-banner__desc">' . esc_html($status['description']) . '</p>'
            . '</div>';

        if ($status['action'] !== '' && $section !== 'license' && function_exists('admin_url')) {
            $licenseUrl = admin_url('admin.php?page=wc-settings&tab=' . self::PAGE_ID . '&section=license');
            echo '<a class="button ' . ($isLicensed ? '' : 'button-primary') . '" href="' . esc_url($licenseUrl) . '">'
                . esc_html($status['action']) . '</a>';
        }

        echo '</div>';
    }

    /**
     * Persist settings via WooCommerce Settings API and synchronize `grcs_settings` and `CredentialVault`.
     */
    public function save(): void
    {
        if (!(current_user_can('manage_woocommerce') || current_user_can('grcs_manage_settings'))) {
            wp_die(AdminLocale::esc_html__('Permission denied.', 'gr-commerce-suite'), 403);
        }

        check_admin_referer('woocommerce-settings');

        global $current_section;

        $section = is_string($current_section) ? strtolower(trim($current_section)) : '';
        if (!self::sectionAvailable($section)) {
            return; // a hidden module section never saves anything
        }
        if (in_array($section, ['', 'acs', 'boxnow', 'geniki', 'invoice'], true) && !CredentialVault::encryptionAvailable()) {
            WC_Admin_Settings::add_error(AdminLocale::__(CredentialVault::ENCRYPTION_UNAVAILABLE, 'gr-commerce-suite'));
            return;
        }
        $settings = $this->get_settings_for_section($section);

        if (class_exists(WC_Admin_Settings::class)) {
            // AADE password bypasses generic option storage so plaintext is never persisted.
            $settings = array_values(array_filter(
                $settings,
                static fn(array $field): bool => !in_array(
                    $field['id'] ?? '',
                    [GreekInvoiceCheckout::OPTION_PASSWORD, GreekInvoiceCheckout::OPTION_USERNAME, ...array_values(GenikiSettings::vaultOptionMap())],
                    true
                ) && ($field['type'] ?? '') !== self::MODULES_FIELD_TYPE
            ));
            // WooCommerce trims textarea input before sanitization, even when the posted key is missing.
            // Normalize only those inputs; keep field defaults and all other save semantics intact.
            $data = $_POST;
            foreach ($settings as $field) {
                if (($field['type'] ?? '') === 'textarea' && isset($field['id']) && is_string($field['id'])) {
                    $name = $field['field_name'] ?? $field['id'];
                    if (is_string($name) && !str_contains($name, '[') && !isset($data[$name])) {
                        $data[$name] = '';
                    }
                }
            }
            WC_Admin_Settings::save_fields($settings, $data);
        }


        if ($section === '' || $section === 'invoice') {
            $password = $_POST[GreekInvoiceCheckout::OPTION_PASSWORD] ?? '';
            $username = $_POST[GreekInvoiceCheckout::OPTION_USERNAME] ?? null;
            if (is_string($password) && is_string($username)) {
                $vault = new CredentialVault();
                $vault->saveAade(sanitize_text_field(wp_unslash($username)), wp_unslash($password));
            }
        }

        $this->syncSavedOptions($section);

        // Modules have their own whitelisted save, applied LAST: the fields above were saved and synced for the modules that
        // were on when this form was rendered, so a module switched on or off in the same request is never half-saved.
        // The marker proves the Modules form was actually on the page.
        if (($section === '' || $section === 'modules') && isset($_POST['grcs_modules_form'])) {
            $posted = isset($_POST['grcs_modules']) && is_array($_POST['grcs_modules']) ? wp_unslash($_POST['grcs_modules']) : [];
            ModuleRegistry::save($posted);
        }
        // An explicit settings save also settles a publication a killed worker left half-swapped. It works while
        // the feed switch or the whole module is off because recovery only certifies or rolls back, never generates.
        $publicationFailure = get_option(SkroutzXmlGenerator::OPTION_PUBLICATION_FAILURE, []);
        if (is_array($publicationFailure) && !empty($publicationFailure['partial'])) {
            (new SkroutzXmlGenerator())->settleInterruptedPublication();
        }
        \GRCommerceSuite\Shipping\ShippingContext::flushShippingCache();

        if ($section !== '' && function_exists('do_action')) {
            do_action('woocommerce_update_options_' . $this->id . '_' . $section);
        }
    }

    /**
     * Modules section: one custom field, rendered as a list of switch cards and saved by {@see ModuleRegistry::save()}.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getModulesSettings(): array
    {
        $el = AdminLocale::locale() === 'el';
        return [['type' => self::MODULES_FIELD_TYPE, 'id' => 'grcs_modules_ui'], [
            'type' => 'select', 'id' => \GRCommerceSuite\Modules\EmbeddedIntegrations::BOXNOW_OWNER,
            'title' => $el ? 'Υλοποίηση BOX NOW για νέες αποστολές' : 'BOX NOW implementation for new shipments',
            'default' => 'native',
            'options' => ['native' => 'GRCS BOX NOW', 'courier_center' => 'Courier Center BOX NOW'],
            'desc' => $el ? 'Ενεργοποιήστε το αντίστοιχο module. Η αλλαγή δεν διαγράφει ιστορικό και δεν σταματά το tracking παλιών εγγενών αποστολών.'
                : 'Enable the corresponding module. Changing the owner preserves history and native tracking for existing shipments.',
        ]];
    }

    /**
     * Cards with one switch each. Warnings are read-only counts, never blocking: a toggle changes no stored data.
     *
     * @param array<string, mixed> $field
     */
    public function renderModulesField(array $field = []): void
    {
        $work = ['open' => [], 'cod_unreconciled' => 0];
        try {
            $work = VoucherRepository::fromGlobals()->countOpenWork();
        } catch (\Throwable) {
            // The screen still works without the counts.
        }
        $texts = [
            ModuleRegistry::ACS => AdminLocale::__('%d ACS voucher(s) are still in progress. Their tracking and COD checks stop while ACS is off.', 'gr-commerce-suite'),
            ModuleRegistry::BOXNOW => AdminLocale::__('%d BOX NOW voucher(s) are still in progress. Their tracking stops while BOX NOW is off.', 'gr-commerce-suite'),
            ModuleRegistry::COD_AUTO => AdminLocale::__('%d delivered COD voucher(s) are waiting to be reconciled. Reconcile them by CSV or turn this back on.', 'gr-commerce-suite'),
        ];
        $counts = [
            ModuleRegistry::ACS => (int) ($work['open'][CourierSlug::Acs->value] ?? 0),
            ModuleRegistry::BOXNOW => (int) ($work['open'][CourierSlug::BoxNow->value] ?? 0),
            ModuleRegistry::COD_AUTO => (int) $work['cod_unreconciled'],
        ];
        echo '<tr valign="top" class="grcs-modules-row"><td colspan="2" class="forminp">';
        echo '<input type="hidden" name="grcs_modules_form" value="1" />';
        echo '<p class="grcs-modules-intro">' . AdminLocale::esc_html__('Turn on only what you use. A module that is off stays completely quiet: no background work, no requests, no notices. Your orders, vouchers and settings are never deleted.', 'gr-commerce-suite') . '</p>';
        echo '<ul class="grcs-modules">';
        foreach (ModuleRegistry::definitions() as $key => $definition) {
            $parent = $definition['parent'] ?? null;
            $locked = $parent !== null && !ModuleRegistry::isEnabled($parent);
            $on = ModuleRegistry::isEnabled($key);
            $requested = ModuleRegistry::isRequested($key);
            $id = 'grcs-module-' . $key;
            echo '<li class="grcs-module' . ($on ? ' is-on' : '') . '">';
            echo '<div class="grcs-module__text"><label for="' . esc_attr($id) . '" class="grcs-module__name">'
                . esc_html($definition['label']) . '</label>'
                . '<span class="grcs-module__desc">' . esc_html($definition['description']) . '</span>';
            echo '<span class="grcs-module__off">' . esc_html(AdminLocale::__('If off:', 'gr-commerce-suite') . ' ' . $definition['off']) . '</span>';
            if ($on && ($counts[$key] ?? 0) > 0) {
                echo '<span class="grcs-module__warn" role="note">' . esc_html(sprintf($texts[$key], $counts[$key])) . '</span>';
            }
            if ($locked) {
                echo '<span class="grcs-module__warn" role="note">' . AdminLocale::esc_html__('Requires the Skroutz XML feed module.', 'gr-commerce-suite') . '</span>';
            }
            if ($on && $key === ModuleRegistry::KLARNA) {
                echo '<p><a href="' . esc_url(\GRCommerceSuite\Modules\Klarna\KlarnaModule::settingsUrl()) . '">'
                    . AdminLocale::esc_html__('Klarna payment settings (WooCommerce > Payments)', 'gr-commerce-suite') . '</a></p>';
            }
            if ($on && $key === ModuleRegistry::COURIER_CENTER) {
                echo '<p><a href="' . esc_url(CourierCenterModule::setupUrl()) . '">'
                    . esc_html(\GRCommerceSuite\Modules\CourierCenter\Text::get('setup')) . '</a></p>';
            }
            if (!$on && $key === ModuleRegistry::SKROUTZ) {
                $publicationFailure = get_option(SkroutzXmlGenerator::OPTION_PUBLICATION_FAILURE, []);
                if (is_array($publicationFailure) && !empty($publicationFailure['partial'])) {
                    echo '<span class="grcs-module__warn" role="note">' . AdminLocale::esc_html__('The last publication was interrupted, so the public XML and ZIP may be from different generations. Save the settings to settle it before using either URL; this never generates a new feed.', 'gr-commerce-suite') . '</span>';
                }
                $feedFile = (new SkroutzXmlGenerator())->getFinalFilePath();
                if (is_file($feedFile)) {
                    $stamp = (int) filemtime($feedFile);
                    $when = function_exists('wp_date') ? (string) wp_date('j/n/Y H:i', $stamp) : gmdate('j/n/Y H:i', $stamp);
                    echo '<span class="grcs-module__warn" role="note">' . esc_html(sprintf(
                        AdminLocale::__('The last published feed is still online at %1$s (last updated %2$s). It is no longer updated, so its prices and stock will go out of date. Remove this URL at Skroutz if you stopped selling there.', 'gr-commerce-suite'),
                        SkroutzXmlGenerator::getPublicFeedUrl(),
                        $when
                    )) . '</span>';
                }
            }
            echo '</div><label class="grcs-switch">';
            if ($parent !== null) {
                // Disabled controls are omitted by browsers. Preserve their choice, including a no-JS parent re-enable.
                echo '<input type="hidden" id="' . esc_attr($id . '-fallback') . '" name="grcs_modules[' . esc_attr($key) . ']" value="'
                    . ($locked && $requested ? '1' : '0') . '" />';
            }
            echo '<input type="checkbox" role="switch" id="' . esc_attr($id) . '" name="grcs_modules[' . esc_attr($key) . ']" value="1"'
                . ($requested ? ' checked' : '') . ($locked ? ' disabled' : '') . ' /><span class="grcs-switch__track" aria-hidden="true"></span></label>';
            echo '</li>';
        }
        echo '</ul></td></tr>';
    }

    /**
     * License Activation section fields.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getLicenseSettings(): array
    {
        $licenseManager = new LicenseManager();
        $isActive = $licenseManager->isLicenseActive();
        $statusLabel = $isActive
            ? AdminLocale::__('Active', 'gr-commerce-suite')
            : AdminLocale::__('Invalid/Expired', 'gr-commerce-suite');

        return [
            [
                'title' => AdminLocale::__('License Activation', 'gr-commerce-suite'),
                'type' => 'title',
                'desc' => AdminLocale::__(
                    'Enter your commercial license key to activate GR Commerce Suite.',
                    'gr-commerce-suite'
                ),
                'id' => 'grcs_license_section_title',
            ],
            [
                'title' => AdminLocale::__('License Key', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Enter the license key from your GR Commerce Suite purchase confirmation email.', 'gr-commerce-suite'),
                'id' => self::OPTION_LICENSE_KEY,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                // Kept for storage/back-compat; visually hidden because the banner at the top
                // of the settings tab is the single source of truth for license status.
                'title' => AdminLocale::__('License Status', 'gr-commerce-suite'),
                'id' => self::OPTION_LICENSE_STATUS,
                'type' => 'text',
                'value' => $statusLabel,
                'default' => $statusLabel,
                'custom_attributes' => [
                    'readonly' => 'readonly',
                ],
            ],
            [
                'type' => 'sectionend',
                'id' => 'grcs_license_section_end',
            ],
        ];
    }

    /**
     * General / Sandbox Mode section fields.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getGeneralSettings(): array
    {
        return [
            [
                'title' => AdminLocale::__('General / Sandbox Mode', 'gr-commerce-suite'),
                'type' => 'title',
                'desc' => AdminLocale::__(
                    'Use Sandbox Test Mode to test ACS Courier and BOX NOW voucher creation, '
                    . 'APM locker selection, and PDF label printing offline without live API credentials.',
                    'gr-commerce-suite'
                ),
                'id' => 'grcs_general_section_title',
            ],
            [
                'title' => AdminLocale::__('Interface Language', 'gr-commerce-suite'),
                'id' => AdminLocale::OPTION,
                'type' => 'select', 'default' => 'auto',
                'options' => [
                    'auto' => AdminLocale::__('Automatic — Follow WordPress administrator language', 'gr-commerce-suite'),
                    'el' => 'Ελληνικά', 'en_US' => 'English',
                ],
                'desc' => AdminLocale::__('Applies only to GR Commerce Suite administration. Save changes to apply. Other languages fall back to English.', 'gr-commerce-suite'),
            ],
            [
                'title' => AdminLocale::__('Enable Sandbox / Test Mode', 'gr-commerce-suite'),
                'desc' => AdminLocale::__(
                    'Test voucher creation and PDF label printing offline using simulated courier responses '
                    . '(no live API credentials required).',
                    'gr-commerce-suite'
                ),
                'id' => self::OPTION_SANDBOX_MODE,
                'type' => 'checkbox',
                'default' => 'yes',
            ],
            [
                'title' => AdminLocale::__('Simulate Post-Transmission Timeout', 'gr-commerce-suite'),
                'desc' => AdminLocale::__(
                    'Simulate HTTP timeout after transmission in Sandbox Mode (transitions voucher state to unknown)',
                    'gr-commerce-suite'
                ),
                'id' => self::OPTION_SANDBOX_TIMEOUT,
                'type' => 'checkbox',
                'default' => 'no',
                'row_class' => 'grcs-sandbox-timeout-row'
                    . (get_option(self::OPTION_SANDBOX_MODE, 'yes') === 'yes' ? '' : ' grcs-row-hidden'),
            ],
            ['type' => 'sectionend', 'id' => 'grcs_general_section_end'],
            ['title' => AdminLocale::__('Shipping & Automation Defaults', 'gr-commerce-suite'),
                'type' => 'title', 'id' => 'grcs_shipping_defaults'],
            [
                'title' => AdminLocale::__('Hide generic free shipping beside courier rates', 'gr-commerce-suite'),
                'id' => \GRCommerceSuite\Shipping\ShippingContext::HIDE_GENERIC_FREE_SHIPPING,
                'type' => 'checkbox', 'default' => 'no',
                'desc' => AdminLocale::__('Hide WooCommerce Free Shipping only in packages offering ACS or BOX NOW. Local Pickup and other methods remain available.', 'gr-commerce-suite'),
            ],
            [
                'title' => AdminLocale::__('Sender Name on Voucher', 'gr-commerce-suite'),
                'id' => ShippingOptions::SENDER, 'type' => 'text',
                'default' => (string) get_option('blogname', ''),
                'desc' => AdminLocale::__('Printed as ΑΠΟΣΤΟΛΕΑΣ on courier vouchers. Enter your warehouse or trading name; leave empty to use the store name from WordPress Settings → General.', 'gr-commerce-suite'),
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Default Parcel Weight (kg)', 'gr-commerce-suite'),
                'id' => ShippingOptions::WEIGHT, 'type' => 'number', 'default' => '1.0',
                'custom_attributes' => ['min' => '0.01', 'step' => '0.01'],
                'desc' => AdminLocale::__('Fallback weight in kilograms when products have no calculated weight. Use your typical packed parcel weight; order weight overrides take priority.', 'gr-commerce-suite'),
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Auto-Issue Voucher on Order Complete', 'gr-commerce-suite'),
                'id' => ShippingOptions::AUTO_ISSUE, 'type' => 'checkbox', 'default' => 'no',
                'desc' => AdminLocale::__('Issue a voucher with saved courier and parcel options when an order transitions to Completed. Existing active or uncertain vouchers are skipped to prevent duplicates.', 'gr-commerce-suite'),
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Auto-Update Order Status on Tracking Sync', 'gr-commerce-suite'),
                'id' => ShippingOptions::AUTO_STATUS, 'type' => 'checkbox', 'default' => 'no',
                'desc' => AdminLocale::__('Mark delivered orders Completed during tracking sync and note Refused/Returned parcels (Άρνηση Παραλαβής). COD refusals also use the existing COD Blacklist protection.', 'gr-commerce-suite'),
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Voucher creation by order status', 'gr-commerce-suite'),
                'id' => VoucherStatusRule::OPTION, 'type' => 'select', 'default' => VoucherStatusRule::FREE,
                'options' => [
                    VoucherStatusRule::FREE => AdminLocale::__('Free — warn on unpaid, confirm on cancelled/refunded/failed', 'gr-commerce-suite'),
                    VoucherStatusRule::STRICT => AdminLocale::__('Strict — only Processing, Completed (and COD Pending/On hold)', 'gr-commerce-suite'),
                ],
                'desc' => AdminLocale::__('Free: any order status, but cancelled, refunded or failed orders need confirmation (bulk and scheduled retries skip them). Strict: other statuses are refused.', 'gr-commerce-suite'),
                'desc_tip' => true,
            ],
            ['type' => 'sectionend', 'id' => 'grcs_shipping_defaults_end'],
        ];
    }

    /** @return array<int, array<string, mixed>> */
    public function getInvoiceSettings(): array
    {
        return [
            ['title' => AdminLocale::__('Receipt / Invoice (Απόδειξη ή Τιμολόγιο)', 'gr-commerce-suite'),
                'type' => 'title', 'id' => 'grcs_invoice_title'],
            ['title' => AdminLocale::__('Enable Receipt / Invoice (Τιμολόγιο) Selector at Checkout', 'gr-commerce-suite'),
                'id' => GreekInvoiceCheckout::OPTION_ENABLED, 'type' => 'checkbox', 'default' => 'yes',
                'desc' => AdminLocale::__('Collect Greek invoice details and validate the nine-digit ΑΦΜ checksum.', 'gr-commerce-suite')],
            ['title' => AdminLocale::__('AADE Username', 'gr-commerce-suite'), 'id' => GreekInvoiceCheckout::OPTION_USERNAME,
                'type' => 'text', 'default' => '', 'desc' => AdminLocale::__('Optional RgWsPublic2 special access username issued by AADE for business registry lookup.', 'gr-commerce-suite')],
            ['title' => AdminLocale::__('AADE Password', 'gr-commerce-suite'), 'id' => GreekInvoiceCheckout::OPTION_PASSWORD,
                'type' => 'password', 'default' => '', 'desc' => AdminLocale::__('Optional RgWsPublic2 special access password; encrypted at rest. Leave blank to keep it. Manual entry works when lookup is unavailable.', 'gr-commerce-suite')],
            ['title' => AdminLocale::__('Store ΑΦΜ (AADE caller)', 'gr-commerce-suite'), 'id' => GreekInvoiceCheckout::OPTION_STORE_AFM,
                'type' => 'text', 'default' => '', 'class' => 'grcs-store-afm',
                'custom_attributes' => ['inputmode' => 'numeric', 'maxlength' => '9', 'pattern' => '[0-9]{9}'],
                'desc' => AdminLocale::__('Your nine-digit Greek ΑΦΜ, sent as afm_called_by. Sandbox mode or missing AADE credentials uses simulated business details. Configure all three fields and disable Sandbox for live lookups.', 'gr-commerce-suite')],
            ['title' => AdminLocale::__('Απενεργοποίηση Αντικαταβολής στα Τιμολόγια (Μόνο Τραπεζική Κατάθεση / Κάρτα)', 'gr-commerce-suite'),
                'id' => CheckoutPaymentRules::OPTION_INVOICE_DISABLE_COD, 'type' => 'checkbox', 'default' => 'yes',
                'desc' => AdminLocale::__('When the customer selects Τιμολόγιο, Cash on Delivery is removed at checkout and the customer pays with another enabled method, such as bank transfer with account details or a card gateway. If no other method is enabled, invoice customers cannot pay and Setup status warns you.', 'gr-commerce-suite')],
            ['type' => 'sectionend', 'id' => 'grcs_invoice_end'],
        ];
    }

    /** @return array<int, array<string, mixed>> */
    public function getBankSettings(): array
    {
        return [
            ['title' => AdminLocale::__('Τραπεζικοί Λογαριασμοί (Τραπεζική Κατάθεση)', 'gr-commerce-suite'), 'type' => 'title',
                'desc' => AdminLocale::__('Accounts offered inside WooCommerce Direct Bank Transfer (Κατάθεση σε Τράπεζα). The customer picks a bank at checkout and sees its beneficiary, IBAN and SWIFT/BIC.', 'gr-commerce-suite'),
                'id' => 'grcs_bank_title'],
            ['title' => AdminLocale::__('Λογαριασμοί', 'gr-commerce-suite'), 'id' => BankTransferAccounts::OPTION_ACCOUNTS,
                'type' => BankTransferAccounts::FIELD_TYPE, 'default' => [],
                'desc' => AdminLocale::__('Tick a bank to offer it at checkout. Enabled rows need a valid IBAN (mod-97 checked), a SWIFT/BIC and the account beneficiary.', 'gr-commerce-suite')],
            ['title' => AdminLocale::__('Επιβάρυνση εξόδων εμβάσματος άλλης τράπεζας στον πελάτη (εντολή OUR)', 'gr-commerce-suite'),
                'id' => BankTransferAccounts::OPTION_CUSTOMER_FEES, 'type' => 'checkbox', 'default' => 'yes',
                'desc' => AdminLocale::__('Show the interbank fee warning and require the customer to acknowledge it before placing a bank transfer order.', 'gr-commerce-suite')],
            ['title' => AdminLocale::__('Κείμενο προειδοποίησης εξόδων', 'gr-commerce-suite'),
                'id' => BankTransferAccounts::OPTION_FEE_WARNING, 'type' => 'textarea',
                // Empty means "default", which follows the storefront language; the placeholder shows that default.
                'default' => '', 'placeholder' => BankTransferAccounts::defaultWarning(), 'css' => 'width:400px;max-width:100%;min-height:80px;',
                'desc' => AdminLocale::__('Shown at checkout, on the order received page and in the customer email. Leave empty to use the default text.', 'gr-commerce-suite')],
            ['type' => 'sectionend', 'id' => 'grcs_bank_end'],
        ];
    }

    /**
     * ACS Courier Credentials section fields.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getAcsSettings(): array
    {
        return [
            [
                'title' => AdminLocale::__('ACS Courier Credentials', 'gr-commerce-suite'),
                'type' => 'title',
                'desc' => AdminLocale::__(
                    'Enter your ACS Courier REST API v2.0 (ACSAutoRest) credentials.',
                    'gr-commerce-suite'
                ),
                'id' => 'grcs_acs_section_title',
            ],
            [
                'title' => AdminLocale::__('API Key', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Your 36-character ACSAutoRest API Key provided by ACS IT Department.', 'gr-commerce-suite'),
                'id' => self::OPTION_ACS_API_KEY,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Company ID', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Provided by your local ACS branch for Web Services authentication.', 'gr-commerce-suite'),
                'id' => self::OPTION_ACS_COMPANY_ID,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Company Password', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Provided by your local ACS branch for Web Services authentication.', 'gr-commerce-suite'),
                'id' => self::OPTION_ACS_COMPANY_PASSWORD,
                'type' => 'password',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('User ID', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Your myACS / Web Services user login credentials.', 'gr-commerce-suite'),
                'id' => self::OPTION_ACS_USER_ID,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('User Password', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Your myACS / Web Services user login credentials.', 'gr-commerce-suite'),
                'id' => self::OPTION_ACS_USER_PASSWORD,
                'type' => 'password',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Billing Code', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Your commercial contract billing code (Κωδικός Χρέωσης, e.g., ΕΠ123456) shown on your ACS invoices.', 'gr-commerce-suite'),
                'id' => self::OPTION_ACS_BILLING_CODE,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'type' => 'sectionend',
                'id' => 'grcs_acs_section_end',
            ],
        ];
    }

    /**
     * BOX NOW Credentials section fields.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getBoxNowSettings(): array
    {
        return [
            [
                'title' => AdminLocale::__('Box Now Credentials', 'gr-commerce-suite'),
                'type' => 'title',
                'desc' => AdminLocale::__(
                    'Enter your BOX NOW Partner API OAuth2 credentials and origin warehouse/locker location ID.',
                    'gr-commerce-suite'
                ),
                'id' => 'grcs_boxnow_section_title',
            ],
            [
                'title' => AdminLocale::__('Client ID', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('OAuth2 API credentials provided by Box Now partner onboarding.', 'gr-commerce-suite'),
                'id' => self::OPTION_BOXNOW_CLIENT_ID,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Client Secret', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('OAuth2 API credentials provided by Box Now partner onboarding.', 'gr-commerce-suite'),
                'id' => self::OPTION_BOXNOW_CLIENT_SECRET,
                'type' => 'password',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Partner Warehouse Location ID', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Your origin warehouse/station ID provided by Box Now (default: 1 for sandbox testing).', 'gr-commerce-suite'),
                'id' => self::OPTION_BOXNOW_ORIGIN_LOCATION_ID,
                'type' => 'text',
                'default' => '1',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('BOX NOW shipping methods', 'gr-commerce-suite'),
                'desc' => AdminLocale::__(
                    'Legacy mappings: comma-separated exact rate IDs, e.g. flat_rate:3. Native grcs_boxnow and legacy boxnow, box_now, box-now IDs are detected automatically. Adding mappings does not create shipping-zone methods.',
                    'gr-commerce-suite'
                ),

                'id' => BoxNowCheckoutPicker::OPTION_SHIPPING_METHODS,
                'type' => 'text',
                'default' => '',
            ],
            [
                'title' => AdminLocale::__('BOX NOW map Partner ID', 'gr-commerce-suite'),
                'id' => BoxNowCheckoutPicker::OPTION_PARTNER_ID, 'type' => 'text', 'default' => '',
                'desc' => AdminLocale::__('Public map Partner ID supplied by BOX NOW (optional for the official widget). This is not the OAuth Client ID or Client Secret. Live selections also require working Partner API credentials for server verification.', 'gr-commerce-suite'),
            ],
            [
                'title' => AdminLocale::__('Επιτρέψτε BOX NOW Pay on the Go (πληρωμή με σύνδεσμο, όχι μετρητά)', 'gr-commerce-suite'),
                'id' => \GRCommerceSuite\Shipping\CheckoutShippingValidation::BOXNOW_ALLOW_COD, 'type' => 'checkbox', 'default' => 'no',
                'desc' => AdminLocale::__('Enable only after BOX NOW confirms Pay on the Go is activated for your contract. Uses paymentMode=cod and amountToBeCollected. Customers pay online through a BOX NOW payment link before opening the locker; no cash or locker POS. Disabled by default.', 'gr-commerce-suite'),
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('BOX NOW payment gateway IDs', 'gr-commerce-suite'),
                'id' => \GRCommerceSuite\Shipping\CheckoutShippingValidation::BOXNOW_PAYMENTS, 'type' => 'text', 'default' => '',
                'desc' => AdminLocale::__('Legacy setting, no longer used to restrict payment availability. Configure availability in each payment gateway. Available bank/card gateways remain available for BOX NOW; WooCommerce cod follows the Pay on the Go setting above. A contracted BOX NOW collection service requires its own enabled, compatible gateway integration.', 'gr-commerce-suite'),
            ],
            [
                'type' => 'sectionend',
                'id' => 'grcs_boxnow_section_end',
            ],
        ];
    }

    public function renderConnectionTestPanel(string $section = ''): void
    {
        LicenseManager::assertLicensed();
        // Markup contract used by assets/js/settings-connection.js: the button and its
        // `.grcs-connection-result` are siblings inside a `.grcs-connection-tests` container.
        echo '<div class="grcs-card grcs-connection-tests" data-grcs-sections="general acs boxnow geniki" data-nonce="' .
             esc_attr(wp_create_nonce(CourierConnectionTest::NONCE_ACTION))
            . '" data-url="' . esc_url(admin_url('admin-ajax.php')) . '">'
            . '<div class="grcs-card__header"><div><h2 class="grcs-card__title">'
            . AdminLocale::esc_html__('Test Courier Connection', 'gr-commerce-suite') . '</h2>'
            . '<p class="grcs-card__subtitle">'
            . AdminLocale::esc_html__(
                'Verify the credentials entered above (including unsaved changes) against the courier API.',
                'gr-commerce-suite'
            )
            . '</p></div></div><div class="grcs-connection-list">';
        $descriptions = [
            'acs' => AdminLocale::__('ACS Courier REST API v2.0 (ACSAutoRest)', 'gr-commerce-suite'),
            'boxnow' => AdminLocale::__('BOX NOW Partner API (OAuth2)', 'gr-commerce-suite'),
            'geniki' => AdminLocale::__('Geniki Web API V2 (selected environment)', 'gr-commerce-suite'),
        ];
        foreach (['acs' => 'ACS', 'boxnow' => 'BOX NOW', 'geniki' => 'Geniki Taxydromiki'] as $slug => $label) {
            if (in_array($section, ['acs', 'boxnow', 'geniki'], true) && $section !== $slug) {
                continue;
            }
            if (!self::sectionAvailable($slug)) {
                continue;
            }
            echo '<div class="grcs-connection-row" data-grcs-courier-row="' . esc_attr($slug) . '">'
                . '<div class="grcs-connection-row__info"><strong>' . esc_html($label) . '</strong>'
                . '<span>' . esc_html($descriptions[$slug]) . '</span></div>'
                . '<div class="grcs-connection-row__action">'
                . '<button type="button" class="button grcs-test-connection" data-courier="' . esc_attr($slug) . '">'
                . esc_html(sprintf(AdminLocale::__('Test %s Connection', 'gr-commerce-suite'), $label))
                . '</button> <span class="grcs-connection-result" role="status" aria-live="polite"></span>'
                . '</div></div>';
        }
        echo '</div></div>';
        if (function_exists('wp_enqueue_script')) {
            wp_enqueue_script(
                'grcs-settings-connection',
                plugins_url(
                    'assets/js/settings-connection.js',
                    GRCS_PLUGIN_FILE
                ),
                ['jquery'],
                GRCS_VERSION,
                true
            );
            wp_localize_script('grcs-settings-connection', 'grcsConnection', [
                'i18n' => ['failed' => AdminLocale::__('Connection failed. Please try again.', 'gr-commerce-suite')],
            ]);
        }
    }

    /**
     * Skroutz & BestPrice XML Feed section fields.
     *
     * @return array<int, array<string, mixed>>
     */
    public function getSkroutzSettings(): array
    {
        return [
            [
                'title' => AdminLocale::__('Skroutz XML Feed', 'gr-commerce-suite'),
                'type' => 'title',
                'desc' => AdminLocale::__(
                    'Generate your product catalogue for Skroutz.gr. '
                    . 'Your public feed URL and manual generation controls are shown below.',
                    'gr-commerce-suite'
                ),
                'id' => 'grcs_skroutz_section_title',
            ],
            [
                'title' => AdminLocale::__('Enable XML Feed', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Enable Skroutz XML Feed generation', 'gr-commerce-suite'),
                'id' => self::OPTION_SKROUTZ_FEED_ENABLED,
                'type' => 'checkbox',
                'default' => 'yes',
            ],
            [
                'title' => AdminLocale::__('Automatic Refresh', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Regenerate the Skroutz XML feed automatically every 12 hours', 'gr-commerce-suite'),
                'id' => SkroutzXmlGenerator::OPTION_AUTO_REFRESH,
                'type' => 'checkbox',
                'default' => 'yes',
            ],
            [
                'title' => AdminLocale::__('Global Price Markup (%)', 'gr-commerce-suite'),
                'desc' => AdminLocale::__(
                    'Optional percentage markup applied to product prices in the Skroutz XML feed (e.g. 5 for +5%).',
                    'gr-commerce-suite'
                ),
                'id' => self::OPTION_SKROUTZ_MARKUP_PERCENT,
                'type' => 'number',
                'default' => '0',
                'custom_attributes' => [
                    'step' => '0.01',
                    'min' => '-100',
                    'max' => '500',
                ],
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Default Availability Text (In Stock)', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Text shown for available products, e.g. Άμεσα Διαθέσιμο or Παράδοση 1 έως 3 ημέρες. Leave blank to use the default.', 'gr-commerce-suite'),
                'id' => SkroutzXmlGenerator::OPTION_AVAILABILITY,
                'type' => 'text',
                'default' => SkroutzXmlGenerator::DEFAULT_AVAILABILITY,
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Custom Size Attribute Slugs', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Optional size attribute slug, such as pa_dimensions. Separate alternatives with commas. Leave blank to detect Greek and English size attributes automatically.', 'gr-commerce-suite'),
                'id' => SkroutzXmlGenerator::OPTION_SIZE_ATTRIBUTE,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Custom Color Attribute Slugs', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Optional color attribute slug, such as pa_shade. Separate alternatives with commas. Leave blank for automatic detection.', 'gr-commerce-suite'),
                'id' => SkroutzXmlGenerator::OPTION_COLOR_ATTRIBUTE,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Custom Brand Attribute Slugs', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Optional brand attribute, taxonomy or metadata key. Separate alternatives with commas. Leave blank for automatic detection.', 'gr-commerce-suite'),
                'id' => SkroutzXmlGenerator::OPTION_BRAND_ATTRIBUTE,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Default Manufacturer / Brand', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Used when a product has no brand. Leave blank to use the store name.', 'gr-commerce-suite'),
                'id' => SkroutzXmlGenerator::OPTION_DEFAULT_MANUFACTURER,
                'type' => 'text',
                'default' => '',
                'desc_tip' => true,
            ],
            [
                'title' => AdminLocale::__('Include Out-of-Stock Products', 'gr-commerce-suite'),
                'desc' => AdminLocale::__('Include unavailable products and color groups. Size lists still show only in-stock sizes.', 'gr-commerce-suite'),
                'id' => SkroutzXmlGenerator::OPTION_INCLUDE_OUT_OF_STOCK,
                'type' => 'checkbox',
                'default' => 'no',
                'desc_tip' => true,
            ],
            [
                'type' => 'sectionend',
                'id' => 'grcs_skroutz_section_end',
            ],
        ];
    }

    /**
     * Resolve the public URL to `wp-content/uploads/gr-commerce-suite/skroutz.xml`.
     */
    public function getPublicFeedUrl(): string
    {
        return SkroutzXmlGenerator::getPublicFeedUrl();
    }

    /**
     * Resolve the action URL to trigger immediate Skroutz XML feed generation.
     */
    public function getGenerateFeedTriggerUrl(): string
    {
        $base = function_exists('admin_url')
            ? admin_url('admin-post.php?action=grcs_generate_skroutz_xml')
            : 'admin-post.php?action=grcs_generate_skroutz_xml';

        if (function_exists('wp_nonce_url')) {
            return wp_nonce_url($base, SkroutzXmlGenerator::NONCE_ACTION_GENERATE);
        }

        return $base;
    }

    /**
     * Render the public XML feed URL and immediate generation button inside the settings screen.
     */
    private function renderSkroutzFeedActionPanel(): void
    {
        $feedUrl = $this->getPublicFeedUrl();
        $triggerUrl = $this->getGenerateFeedTriggerUrl();
        ?>
        <div class="grcs-skroutz-feed-panel grcs-feed-panel">
            <?php AdminWorkspace::feedStatus(); ?>
            <?php if (ModuleRegistry::isEnabled(ModuleRegistry::BESTPRICE)) : ?>
            <p class="grcs-help grcs-bestprice-preview"><?php AdminLocale::esc_html_e('BestPrice is available for local preview only. No BestPrice feed is published. Do not submit the Skroutz URL to BestPrice.', 'gr-commerce-suite'); ?></p>
            <?php endif; ?>
            <div class="grcs-field">
                <label class="grcs-field__label" for="grcs-feed-url-settings">
                    <?php AdminLocale::esc_html_e('Public Skroutz XML Feed URL', 'gr-commerce-suite'); ?>
                    <span class="grcs-tip" tabindex="0" role="img" data-tip="<?php echo AdminLocale::esc_attr__('Submit this URL only in your Skroutz Merchants dashboard.', 'gr-commerce-suite'); ?>" aria-label="<?php echo AdminLocale::esc_attr__('Submit this URL only in your Skroutz Merchants dashboard.', 'gr-commerce-suite'); ?>">?</span>
                </label>
                <div class="grcs-copy-field">
                    <input type="text"
                           id="grcs-feed-url-settings"
                           value="<?php echo esc_attr($feedUrl); ?>"
                           readonly="readonly"
                           aria-readonly="true" />
                    <button type="button" class="button" data-grcs-copy="#grcs-feed-url-settings">
                        <?php AdminLocale::esc_html_e('Copy Feed URL', 'gr-commerce-suite'); ?>
                    </button>
                    <a class="button" href="<?php echo esc_url($feedUrl); ?>" target="_blank" rel="noopener noreferrer">
                        <?php AdminLocale::esc_html_e('Open', 'gr-commerce-suite'); ?>
                    </a>
                </div>
                <p class="grcs-help">
                    <?php
                    AdminLocale::esc_html_e(
                        'Submit this URL only in your Skroutz Merchants dashboard.',
                        'gr-commerce-suite'
                    );
                    ?>
                </p>
            </div>
            <div class="grcs-btn-row">
                <a href="<?php echo esc_url($triggerUrl); ?>"
                   id="grcs-generate-skroutz-feed-btn"
                   class="button button-primary">
                    <?php AdminLocale::esc_html_e('Generate Skroutz XML Feed Now', 'gr-commerce-suite'); ?>
                </a>
            </div>
        </div>
        <?php
    }

    /**
     * Synchronize individual WooCommerce setting options into `grcs_settings` and `CredentialVault`.
     */
    private function syncSavedOptions(string $section): void
    {
        if (!function_exists('get_option') || !function_exists('update_option')) {
            return;
        }

        $settings = get_option('grcs_settings', []);
        if (!is_array($settings)) {
            $settings = [];
        }

        if ($section === '' || $section === 'general') {
            $sandboxMode = (string) get_option(self::OPTION_SANDBOX_MODE, 'yes');
            $sandboxTimeout = (string) get_option(self::OPTION_SANDBOX_TIMEOUT, 'no');
            $settings['sandbox_mode'] = $sandboxMode === 'yes' ? 'yes' : 'no';
            $settings['sandbox_simulate_timeout'] = $sandboxTimeout === 'yes' ? 'yes' : 'no';
            update_option('grcs_settings', $settings, true);
        }

        if ($section === '' || $section === 'license' || $section === 'general') {
            $licenseKey = trim((string) get_option(self::OPTION_LICENSE_KEY, ''));
            $isValid = LicenseManager::isLicensed();
            $statusLabel = $isValid ? 'Active' : 'Invalid/Expired';
            update_option(self::OPTION_LICENSE_STATUS, $statusLabel, true);
            $settings['license_key'] = $licenseKey;
            $settings['license_status'] = $statusLabel;
        }

        if (($section === '' && self::sectionAvailable('skroutz')) || $section === 'skroutz') {
            $feedEnabled = (string) get_option(self::OPTION_SKROUTZ_FEED_ENABLED, 'yes');
            $markupRaw = get_option(self::OPTION_SKROUTZ_MARKUP_PERCENT, '0');
            $settings['skroutz_feed_enabled'] = $feedEnabled === 'yes' ? 'yes' : 'no';
            $settings['skroutz_markup_percentage'] = is_numeric($markupRaw) ? (float) $markupRaw : 0.0;
        }

        update_option('grcs_settings', $settings, true);

        $vault = new CredentialVault();

        if (($section === '' && self::sectionAvailable('geniki')) || $section === 'geniki') {
            $credentials = $vault->getForCourier(CourierSlug::Geniki);
            foreach (GenikiSettings::vaultOptionMap() as $key => $option) {
                $submitted = $_POST[$option] ?? null;
                if (!is_string($submitted)) {
                    continue;
                }
                $value = trim(wp_unslash($submitted));
                if (in_array($key, CredentialVault::SECRET_FIELDS['geniki'], true) && $value === '') {
                    continue;
                }
                if ($key === 'environment' && !in_array($value, ['live', 'sandbox'], true)) {
                    throw new RuntimeException(AdminLocale::__('Invalid Geniki environment.', 'gr-commerce-suite'));
                }
                $credentials[$key] = $value;
            }
            if (!$vault->saveForCourier(CourierSlug::Geniki, $credentials)) {
                throw new RuntimeException(AdminLocale::__('Could not save the encrypted Geniki credentials.', 'gr-commerce-suite'));
            }
            $vault->removePlaintextSecrets(CourierSlug::Geniki);
        }

        if (($section === '' && self::sectionAvailable('acs')) || $section === 'acs') {
            $existingAcs = $vault->getForCourier(CourierSlug::Acs);
            $acsCreds = array_merge($existingAcs, [
                'api_key' => trim((string) get_option(self::OPTION_ACS_API_KEY, $existingAcs['api_key'] ?? '')),
                'company_id' => trim((string) get_option(self::OPTION_ACS_COMPANY_ID, '')),
                'company_password' => trim((string) get_option(
                    self::OPTION_ACS_COMPANY_PASSWORD,
                    $existingAcs['company_password'] ?? ''
                )),
                'user_id' => trim((string) get_option(self::OPTION_ACS_USER_ID, '')),
                'user_password' => trim((string) get_option(
                    self::OPTION_ACS_USER_PASSWORD,
                    $existingAcs['user_password'] ?? ''
                )),
                'billing_code' => trim((string) get_option(self::OPTION_ACS_BILLING_CODE, '')),
            ]);
            if (!$vault->saveForCourier(CourierSlug::Acs, $acsCreds)) {
                throw new RuntimeException(AdminLocale::__('Could not save the encrypted ACS credentials.', 'gr-commerce-suite'));
            }
            $vault->removePlaintextSecrets(CourierSlug::Acs);
        }

        if (($section === '' && self::sectionAvailable('boxnow')) || $section === 'boxnow') {
            $existingBoxNow = $vault->getForCourier(CourierSlug::BoxNow);
            $boxNowCreds = array_merge($existingBoxNow, [
                'client_id' => trim((string) get_option(self::OPTION_BOXNOW_CLIENT_ID, '')),
                'client_secret' => trim((string) get_option(
                    self::OPTION_BOXNOW_CLIENT_SECRET,
                    $existingBoxNow['client_secret'] ?? ''
                )),
                'origin_location_id' => trim((string) get_option(self::OPTION_BOXNOW_ORIGIN_LOCATION_ID, '1')),
            ]);
            if (!$vault->saveForCourier(CourierSlug::BoxNow, $boxNowCreds)) {
                throw new RuntimeException(AdminLocale::__('Could not save the encrypted BOX NOW credentials.', 'gr-commerce-suite'));
            }
            $vault->removePlaintextSecrets(CourierSlug::BoxNow);
        }
    }
}
