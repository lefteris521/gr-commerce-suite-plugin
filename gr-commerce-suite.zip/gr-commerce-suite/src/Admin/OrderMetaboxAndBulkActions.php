<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;

use DateTimeImmutable;
use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Couriers\AcsProvider;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Voucher\VoucherResult;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Frontend\BoxNowCheckoutPicker;
use GRCommerceSuite\Pdf\PdfMerger;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\ShippingOptions;
use GRCommerceSuite\Domain\Tracking\TrackingStatus;
use GRCommerceSuite\Services\CodBlacklistService;
use GRCommerceSuite\Services\CodRefundStatus;
use GRCommerceSuite\Services\VoucherCancellationMarker;
use GRCommerceSuite\Services\VoucherService;
use GRCommerceSuite\Services\VoucherStatusRule;
use GRCommerceSuite\Shipping\CourierSelection;
use GRCommerceSuite\Support\Logger;
use GRCommerceSuite\Support\Money;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Utils\GreekDataNormalizer;
use Throwable;
use WC_Order;
use WP_Post;

/**
 * WooCommerce Admin Order UI & Bulk Actions (SPEC.md §3 C-2, §13).
 *
 * Provides:
 * 1. 100% WooCommerce HPOS compatible Single Order Metabox (`woocommerce_page_wc-orders` & `shop_order`):
 *    - Courier selection (ACS, BOX NOW, Geniki Taxydromiki).
 *    - Parcel count (`Pieces`), weight (kg) with 0.50 kg ACS minimum, and COD (`Antikatavoli`) amount.
 *    - Direct actions: "Issue Voucher", "Print Label (Thermal / A4)", and "Cancel Voucher".
 * 2. HPOS & Legacy Bulk Actions and Custom Voucher Column on the Orders Table:
 *    - "GRCS: Issue Courier Vouchers (Bulk)"
 *    - "GRCS: Print Merged PDF Vouchers"
 *    - "GRCS: Issue Daily Pickup List (Kleisimo Imeras)"
 * 3. Checkout BOX NOW APM locker selection & order meta persistence.
 * 4. Secure AJAX handlers and PDF label streaming via `admin-post.php?action=grcs_print`.
 */
final class OrderMetaboxAndBulkActions implements HookSubscriberInterface
{
    public const NONCE_ACTION_ORDER = 'grcs_admin_order_nonce';
    public const NONCE_ACTION_PRINT = 'grcs_admin_print_nonce';

    public const BULK_ACTION_ISSUE = 'grcs_bulk_issue_vouchers';
    public const BULK_ACTION_PRINT = 'grcs_bulk_print_vouchers';
    public const BULK_ACTION_PICKUP = 'grcs_bulk_daily_pickup';

    private readonly LoggerInterface $logger;

    /** @var array<int, true> Avoid a second attempt when lazy runtime registration joins the current hook. */
    private array $autoIssueHandled = [];

    /** @var (callable(int): list<array<string, mixed>>)|null */
    private $voucherFinder = null;

    /** @var (callable(WC_Order, CourierSlug): VoucherResult)|null */
    private $voucherCreator = null;

    /** @var (callable(int): bool)|null */
    private $voucherCanceller = null;

    public function __construct(
        private readonly ?VoucherService $voucherService = null,
        private readonly ?VoucherRepository $voucherRepository = null,
        private readonly ?CourierRegistry $courierRegistry = null,
        ?LoggerInterface $logger = null,
        private readonly ?PdfMerger $pdfMerger = null,
        private readonly ?CodBlacklistService $blacklist = null,
    ) {
        $this->logger = $logger ?? new Logger('gr-commerce-suite');
    }

    public function setVoucherFinder(?callable $finder): void
    {
        $this->voucherFinder = $finder;
    }

    public function setVoucherCreator(?callable $creator): void
    {
        $this->voucherCreator = $creator;
    }

    public function setVoucherCanceller(?callable $canceller): void
    {
        $this->voucherCanceller = $canceller;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function getVouchersForOrder(int $orderId): array
    {
        if ($this->voucherFinder !== null) {
            return ($this->voucherFinder)($orderId);
        }

        return $this->voucherRepository !== null ? $this->voucherRepository->findByOrderId($orderId) : [];
    }

    public function createVoucherForOrder(WC_Order $order, CourierSlug $courier, bool $confirmedRiskyStatus = false): VoucherResult
    {
        LicenseManager::assertLicensed();

        if ($this->voucherCreator !== null) {
            return ($this->voucherCreator)($order, $courier);
        }

        if ($this->voucherService === null) {
            throw new \RuntimeException(AdminLocale::__('VoucherService is not configured.', 'gr-commerce-suite'));
        }

        return $this->voucherService->createForOrder($order, $courier, $confirmedRiskyStatus);
    }

    /**
     * Status-rule hints for the Issue Voucher button (UI only; the server guard in VoucherLockService decides).
     *
     * @return array{confirm: string, block: string}
     */
    private function issueStatusHints(WC_Order $order, ?CourierSlug $courier): array
    {
        $statusName = function_exists('wc_get_order_status_name') ? wc_get_order_status_name($order->get_status()) : $order->get_status();
        if (VoucherStatusRule::mode() === VoucherStatusRule::STRICT) {
            return ['confirm' => '', 'block' => (string) VoucherStatusRule::refusal($order, $courier ?? CourierSlug::Acs)];
        }
        if (VoucherStatusRule::isRisky($order) || VoucherStatusRule::isUnpaid($order)) {
            return [
                'confirm' => sprintf(AdminLocale::__('This order is "%s". Create the voucher anyway?', 'gr-commerce-suite'), $statusName),
                'block' => '',
            ];
        }

        return ['confirm' => '', 'block' => ''];
    }

    /**
     * All active vouchers (created/unknown/reserved) on an order that is cancelled, refunded or failed.
     *
     * @param list<array<string, mixed>> $vouchers
     * @return list<array{id: int, courier: string, voucher_no: string, row: array<string, mixed>}>
     */
    public static function findActiveVoucherOnDeadOrder(WC_Order $order, array $vouchers): array
    {
        return VoucherStatusRule::isRisky($order) ? self::activeVoucherRows($vouchers) : [];
    }

    /**
     * @param list<array<string, mixed>> $vouchers
     * @return list<array{id: int, courier: string, voucher_no: string, row: array<string, mixed>}>
     */
    private static function activeVoucherRows(array $vouchers): array
    {
        $active = [];
        foreach ($vouchers as $row) {
            if (in_array((string) ($row['state'] ?? ''), ['created', 'unknown', 'reserved'], true)) {
                $slug = CourierSlug::tryFrom((string) ($row['courier_slug'] ?? ''));
                $active[] = [
                    'id' => (int) ($row['id'] ?? 0),
                    'courier' => $slug !== null ? $slug->label() : (string) ($row['courier_slug'] ?? ''),
                    'voucher_no' => (string) ($row['voucher_no'] ?? ''),
                    'row' => $row,
                ];
            }
        }

        return $active;
    }

    /**
     * Dead order (cancelled/refunded/failed) with active vouchers: at most one note per voucher row, ever.
     * Never cancels at the courier, never calls a courier. Always-on hook (Plugin::boot).
     */
    public function noteActiveVoucherOnDeadOrder(int $orderId, string $from = '', string $to = '', mixed $order = null): void
    {
        if (!in_array($to, VoucherStatusRule::RISKY_STATUSES, true)) {
            return;
        }
        $order = $order instanceof WC_Order ? $order : (function_exists('wc_get_order') ? wc_get_order($orderId) : null);
        if (!$order instanceof WC_Order) {
            return;
        }
        $this->noteVoucherRows($order, self::findActiveVoucherOnDeadOrder($order, $this->getVouchersForOrder($orderId)));
    }

    /**
     * @param list<array{id: int, courier: string, voucher_no: string, row: array<string, mixed>}> $rows
     */
    private function noteVoucherRows(WC_Order $order, array $rows): void
    {
        $dirty = false;
        foreach ($rows as $active) {
            $key = '_grcs_dead_order_voucher_noted_' . $active['id'];
            if ((string) $order->get_meta($key, true) !== '') {
                continue;
            }
            $order->update_meta_data($key, gmdate('c'));
            $row = $active['row'];
            if (
                ($row['state'] ?? '') === 'created' && !empty($row['voucher_no'])
                && TrackingStatus::notYetShipped((string) ($row['tracking_status'] ?? 'pending'))
            ) {
                $order->add_order_note(sprintf(
                    AdminLocale::__('GR Commerce Suite: Order cancelled/refunded with active unshipped voucher %s. DO NOT hand this parcel to the courier. Cancel the voucher before pickup.', 'gr-commerce-suite'),
                    implode(', ', ShippingOptions::voucherNumbers($row))
                ));
            } else {
                $order->add_order_note(sprintf(
                    AdminLocale::__('Order has an active %1$s voucher %2$s: cancel it at the courier if the parcel must not ship.', 'gr-commerce-suite'),
                    $active['courier'],
                    $active['voucher_no']
                ));
            }
            $dirty = true;
        }
        if ($dirty) {
            $order->save();
        }
    }

    public function cancelVoucherById(int $voucherId): bool
    {
        // Existing vouchers stay cancellable without a licence (owner decision 2026-11-03).
        if ($this->voucherCanceller !== null) {
            return ($this->voucherCanceller)($voucherId);
        }

        if ($this->voucherService === null) {
            throw new \RuntimeException(AdminLocale::__('VoucherService is not configured.', 'gr-commerce-suite'));
        }

        return $this->voucherService->cancelVoucherById($voucherId);
    }

    /**
     * Register HPOS, legacy admin, and checkout hooks (SPEC.md §13, §14).
     */
    public function register(): void
    {
        if (!function_exists('add_action') || !function_exists('add_filter')) {
            return;
        }

        // An expired/missing licence blocks NEW issuance only; view, print and cancel of existing
        // vouchers keep working (owner decision 2026-11-03). Create paths gate themselves.
        $licensed = LicenseManager::isLicensed();

        // 1. Single Order Metabox for HPOS and legacy screens
        add_action('add_meta_boxes', [$this, 'registerMetabox'], 10, 2);

        // 2. Enqueue Admin JavaScript and Styles
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdminAssets']);

        // 3. AJAX Actions for interactive Metabox actions
        add_action('wp_ajax_grcs_issue_voucher', [$this, 'handleAjaxIssueVoucher']);
        add_action('wp_ajax_grcs_save_parcel_options', [$this, 'handleAjaxSaveParcelOptions']);
        add_action('woocommerce_order_status_completed', [$this, 'autoIssueCompleted'], 10, 2);
        // Dead-order voucher note is hooked always-on in Plugin::boot() (storefront payment callbacks too).
        // Tracking of existing vouchers (order auto-complete) is read-only and survives licence expiry.
        add_action('grcs/tracking/updated', [$this, 'syncOrderStatus'], 20, 2);
        if ($licensed) {
            add_action('grcs/voucher/created', [$this, 'saveShipmentSnapshot'], 10, 3);
        }
        add_action('wp_ajax_grcs_cancel_voucher', [$this, 'handleAjaxCancelVoucher']);
        add_action('wp_ajax_grcs_resolve_cancel_pending', [$this, 'handleAjaxResolveCancelPending']);

        // 4. PDF Print streaming endpoint via admin-post.php
        add_action('admin_post_grcs_print', [$this, 'handlePrintPdf']);

        // 5. Bulk actions on Orders List Table (HPOS: woocommerce_page_wc-orders, Legacy: edit-shop_order)
        add_filter('bulk_actions-woocommerce_page_wc-orders', [$this, 'registerBulkActions']);
        add_filter('bulk_actions-edit-shop_order', [$this, 'registerBulkActions']);

        add_filter('handle_bulk_actions-woocommerce_page_wc-orders', [$this, 'handleBulkActions'], 10, 3);
        add_filter('handle_bulk_actions-edit-shop_order', [$this, 'handleBulkActions'], 10, 3);

        // 6. Custom Voucher column on Orders List Table (HPOS + Legacy)
        add_filter('manage_woocommerce_page_wc-orders_columns', [$this, 'registerOrdersTableColumns'], 20);
        add_filter('manage_edit-shop_order_columns', [$this, 'registerOrdersTableColumns'], 20);
        add_action('manage_woocommerce_page_wc-orders_custom_column', [$this, 'renderOrdersTableColumn'], 10, 2);
        add_action('manage_shop_order_posts_custom_column', [$this, 'renderOrdersTableColumn'], 10, 2);

        // 7. Admin Notices for Bulk Actions
        add_action('admin_notices', [$this, 'renderBulkActionNotices']);
        add_action('admin_notices', [$this, 'renderLicenceCreateNotice']);

        if ($licensed) {
            add_action('wp_ajax_grcs_blacklist_customer', [$this, 'handleAjaxBlacklistCustomer']);
        }
        add_action('woocommerce_process_shop_order_meta', [$this, 'saveAdminLocker'], 10, 2);

        // 8. Today's pickup list, reachable from the orders screen where fulfilment happens.
        add_action('woocommerce_order_list_table_extra_tablenav', [$this, 'renderPickupListLink'], 10, 2);
        add_action('manage_posts_extra_tablenav', [$this, 'renderPickupListLink']);
    }

    /**
     * Link to the daily pickup list above the orders table (HPOS passes the order type first; legacy passes only $which).
     */
    public function renderPickupListLink(string $orderTypeOrWhich, string $which = ''): void
    {
        $legacy = $which === '';
        $which = $legacy ? $orderTypeOrWhich : $which;
        if ($which !== 'top' || (!$legacy && $orderTypeOrWhich !== 'shop_order')
            || ($legacy && (($GLOBALS['typenow'] ?? '') !== 'shop_order'))
            || !current_user_can('manage_woocommerce') || !LicenseManager::isLicensed()) {
            return;
        }
        echo '<a class="button grcs-orders-pickup-link" href="'
            . esc_url(admin_url('admin.php?page=' . CodReconciliationPage::MENU_SLUG . '&tab=pickup'))
            . '">' . AdminLocale::esc_html__('Daily Pickup List (Λίστα Παραλαβής)', 'gr-commerce-suite') . '</a>';
    }

    /**
     * Registers custom "Courier Voucher" column in WooCommerce Orders table.
     *
     * @param array<string, string> $columns
     * @return array<string, string>
     */
    public function registerOrdersTableColumns(array $columns): array
    {
        $columns['grcs_voucher'] = AdminLocale::__('GR Commerce / Voucher', 'gr-commerce-suite');

        return $columns;
    }

    /**
     * Short "?" tooltip for Orders-list row notes (F-9); WooCommerce help tip when available.
     */
    private static function helpTip(string $text): string
    {
        if (function_exists('wc_help_tip')) {
            return wc_help_tip($text);
        }

        return '<span class="dashicons dashicons-editor-help" title="' . esc_attr($text) . '"></span>';
    }

    /**
     * Renders custom "Courier Voucher" column cell on HPOS and legacy Orders table.
     */
    public function renderOrdersTableColumn(string $column, mixed $postOrOrder): void
    {
        if ($column !== 'grcs_voucher') {
            return;
        }

        $order = $this->resolveOrder($postOrOrder);
        if (!$order instanceof WC_Order) {
            echo '—';
            return;
        }

        $orderId = (int) $order->get_id();
        $vouchers = $this->getVouchersForOrder($orderId);

        $activeVoucher = null;
        foreach ($vouchers as $v) {
            if (($v['state'] ?? '') === VoucherState::Created->value) {
                $activeVoucher = $v;
                break;
            }
        }
        if ($activeVoucher === null && $vouchers !== []) {
            $activeVoucher = $vouchers[0];
        }

        $courier = CourierSlug::tryFrom((string) ($activeVoucher['courier_slug']
            ?? $order->get_meta('_grcs_preferred_courier', true))) ?? $this->detectCourierFromShipping($order);
        $state = (string) ($activeVoucher['state'] ?? '');
        $cancelPending = $activeVoucher !== null
            && VoucherCancellationMarker::isPending($order, (int) ($activeVoucher['id'] ?? 0));
        $issued = $state === VoucherState::Created->value && !$cancelPending;
        $canIssue = !$cancelPending && LicenseManager::isLicensed() && ModuleRegistry::anyCourierEnabled() && $order->get_status() !== 'trash' && ($activeVoucher === null || in_array($state, ['cancelled', 'failed'], true));
        $number = (string) ($activeVoucher['voucher_no'] ?? '');
        echo '<div class="grcs-ui grcs-metabox-wrapper grcs-order-quick" data-order-id="' . esc_attr((string) $orderId) . '">';
        echo '<span class="grcs-pill grcs-pill--blue">' . esc_html($courier?->label() ?? AdminLocale::__('Select courier', 'gr-commerce-suite')) . '</span> ';
        $trackingUrl = $issued && $courier !== null ? $this->buildTrackingUrl($number, $courier) : '';
        if ($number !== '' && $trackingUrl !== '') {
            echo '<a class="grcs-voucher-link" target="_blank" rel="noopener noreferrer" href="'
                . esc_url($trackingUrl) . '">' . esc_html($number) . '</a> ';
        } elseif ($number !== '') {
            echo '<span class="grcs-voucher-number">' . esc_html($number) . '</span> ';
        }
        $status = $issued ? (string) ($activeVoucher['tracking_status'] ?? 'pending') : ($state !== '' ? $state : 'unissued');
        echo '<span class="grcs-pill grcs-pill--gray">' . esc_html($cancelPending
            ? AdminLocale::__('Cancellation pending', 'gr-commerce-suite')
            : AdminLocale::status($status)) . '</span>';
        if ($this->blacklist !== null) {
            $risk = $this->blacklist->isBlacklisted(
                $order->get_billing_phone(),
                $order->get_billing_email(),
                (string) $order->get_customer_ip_address(),
                (int) $order->get_customer_id()
            );
            $riskLabel = $risk ? AdminLocale::__('COD Risk / Σε Μαύρη Λίστα', 'gr-commerce-suite') : AdminLocale::__('Clean Customer / Καθαρός', 'gr-commerce-suite');
            echo '<span class="grcs-pill grcs-pill--' . ($risk ? 'red' : 'green') . ' grcs-risk-shield" title="'
                . esc_attr($riskLabel) . '" aria-label="' . esc_attr($riskLabel) . '">🛡️ ' . esc_html($risk ? AdminLocale::__('COD Risk', 'gr-commerce-suite') : AdminLocale::__('Clean', 'gr-commerce-suite')) . '</span>';
        }
        echo '<div class="grcs-btn-row">';
        if ($issued && $number !== '' && $courier !== null) {
            foreach (['a4' => 'A4', 'thermal' => AdminLocale::__('Thermal', 'gr-commerce-suite')] as $format => $label) {
                echo '<a class="button button-small" target="_blank" rel="noopener noreferrer" href="'
                    . esc_url($this->buildPrintUrl($number, $courier->value, $format)) . '">' . esc_html($label) . '</a>';
            }
            if ($trackingUrl !== '') {
                echo '<a class="button button-small" target="_blank" rel="noopener noreferrer" href="'
                    . esc_url($trackingUrl) . '">' . AdminLocale::esc_html__('Trace', 'gr-commerce-suite') . '</a>';
            }
            echo '<button type="button" class="button button-small grcs-cancel-voucher-btn" data-voucher-id="'
                . esc_attr((string) ($activeVoucher['id'] ?? 0)) . '">' . AdminLocale::esc_html__('Cancel', 'gr-commerce-suite') . '</button>';
        } elseif ($canIssue) {
            $hints = $this->issueStatusHints($order, $courier);
            if ($hints['block'] !== '') {
                echo '<span class="description" data-grcs-status-rule="strict">' . AdminLocale::esc_html__('Blocked (Strict rule)', 'gr-commerce-suite') . ' ' . self::helpTip($hints['block']) . '</span>';
            } else {
                echo '<button type="button" class="button button-small grcs-issue-voucher-btn"'
                    . ($hints['confirm'] !== '' ? ' data-grcs-confirm="' . esc_attr($hints['confirm']) . '" data-grcs-confirm-status="' . esc_attr($order->get_status()) . '"' : '') . '>'
                    . AdminLocale::esc_html__('Issue Voucher', 'gr-commerce-suite') . '</button>';
            }
        }
        foreach (self::findActiveVoucherOnDeadOrder($order, $vouchers) as $deadVoucher) {
            $deadOrderMsg = sprintf(
                AdminLocale::__('Order has an active %1$s voucher %2$s: cancel it at the courier if the parcel must not ship.', 'gr-commerce-suite'),
                $deadVoucher['courier'],
                $deadVoucher['voucher_no']
            );
            echo '<span class="description" data-grcs-dead-order-voucher="1">' . AdminLocale::esc_html__('Active voucher on dead order', 'gr-commerce-suite') . ' ' . self::helpTip($deadOrderMsg) . '</span>';
        }
        echo '</div><details class="grcs-parcel-options"><summary>' . AdminLocale::esc_html__('Parcel options', 'gr-commerce-suite') . '</summary>';
        echo '<label>' . AdminLocale::esc_html__('Courier Provider', 'gr-commerce-suite') . '<select name="grcs_courier">';
        if ($courier === null) {
            echo '<option value="">' . AdminLocale::esc_html__('Select courier', 'gr-commerce-suite') . '</option>';
        }
        foreach (CourierSlug::cases() as $choice) {
            // New vouchers only for enabled couriers; the order's current courier stays selectable so history is not hidden.
            if (!ModuleRegistry::courierEnabled($choice) && $choice !== $courier) {
                continue;
            }
            echo '<option value="' . esc_attr($choice->value) . '"' . selected($courier->value ?? '', $choice->value, false) . '>'
                . esc_html($choice->label()) . '</option>';
        }
        echo '</select></label>';
        echo '<label>' . AdminLocale::esc_html__('Parcel Count (Τεμάχια)', 'gr-commerce-suite')
            . '<input name="grcs_parcels" type="number" min="1" max="100" step="1" value="'
            . esc_attr((string) ShippingOptions::parcelCount($order)) . '" /></label>';
        echo '<label>' . AdminLocale::esc_html__('Weight Override (kg)', 'gr-commerce-suite')
            . '<input name="grcs_weight" type="number" min="0.01" step="0.01" value="'
            . esc_attr((string) $order->get_meta('_grcs_custom_weight', true)) . '" placeholder="'
            . esc_attr(number_format(ShippingOptions::weightKg($order), 2, '.', '')) . '" title="'
            . esc_attr(html_entity_decode($this->weightHelp($order), ENT_QUOTES, 'UTF-8')) . '" /></label>';
        if (ModuleRegistry::isEnabled(ModuleRegistry::BOXNOW) || (string) $order->get_meta('_grcs_boxnow_locker_id', true) !== '') {
            echo '<label class="grcs-boxnow-locker-field">' . AdminLocale::esc_html__('Box Now Locker ID', 'gr-commerce-suite') . '<input name="grcs_boxnow_locker_id" value="'
                . esc_attr((string) $order->get_meta('_grcs_boxnow_locker_id', true)) . '" /></label>';
        }
        if (ModuleRegistry::isEnabled(ModuleRegistry::ACS)) {
            $this->renderAcsOptions($order);
        }
        echo '<button type="button" class="button button-small grcs-save-options">'
            . AdminLocale::esc_html__('Save parcel options', 'gr-commerce-suite') . '</button></details>';
        echo '<div class="grcs-metabox-feedback" role="status" aria-live="polite"></div></div>';
    }

    /**
     * Render BOX NOW APM locker selector on WooCommerce Checkout.
     */
    public function renderCheckoutBoxNowLockerField(): void
    {
        LicenseManager::assertLicensed();
        $label = AdminLocale::__('BOX NOW APM Locker Selection (Optional / For BOX NOW Shipping)', 'gr-commerce-suite');
        $noneOpt = AdminLocale::__('— No Locker (Home / Courier Delivery) —', 'gr-commerce-suite');
        ?>
        <div id="grcs-boxnow-locker-checkout-field" style="margin: 16px 0; padding: 12px; border: 1px solid #dcdcde;">
            <label for="grcs_boxnow_locker_id" style="display: block; font-weight: 600; margin-bottom: 6px;">
                <?php echo esc_html($label); ?>
            </label>
            <select name="grcs_boxnow_locker_id" id="grcs_boxnow_locker_id" style="width: 100%; max-width: 420px;">
                <option value=""><?php echo esc_html($noneOpt); ?></option>

            </select>
        </div>
        <?php
    }

    /**
     * Persist selected BOX NOW APM locker ID and preferred courier during Classic Checkout.
     *
     * @param array<string, mixed> $data
     */
    public function saveCheckoutBoxNowLockerMeta(WC_Order $order, array $data = []): void
    {
        (new \GRCommerceSuite\Frontend\BoxNowCheckoutPicker($this->courierRegistry ?? new CourierRegistry()))
            ->saveClassic($order, $data);
    }

    /**
     * Persist BOX NOW APM locker ID and preferred courier during Store API / Blocks Checkout.
     */
    public function saveStoreApiBoxNowLockerMeta(WC_Order $order, mixed $request = null): void
    {
        (new \GRCommerceSuite\Frontend\BoxNowCheckoutPicker($this->courierRegistry ?? new CourierRegistry()))
            ->saveStoreApi($order, $request);
    }

    /**
     * Registers the Courier Shipping metabox on both HPOS and legacy shop-order screens (SPEC.md §13).
     */
    public function registerMetabox(string $postTypeOrScreen, mixed $postOrOrder = null): void
    {
        $hposScreen = function_exists('wc_get_page_screen_id')
            ? wc_get_page_screen_id('shop-order')
            : 'woocommerce_page_wc-orders';

        $screens = array_unique([$hposScreen, 'shop_order', 'woocommerce_page_wc-orders']);

        foreach ($screens as $screen) {
            add_meta_box(
                'grcs_courier_shipping_metabox',
                AdminLocale::__('GR Commerce: Courier Shipping & Vouchers', 'gr-commerce-suite'),
                [$this, 'renderMetabox'],
                $screen,
                'side',
                'high'
            );
        }
    }

    /**
     * Enqueues the admin JavaScript (`assets/js/admin-orders.js`) on WooCommerce order screens.
     */
    public function enqueueAdminAssets(string $hook): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $hposScreen = function_exists('wc_get_page_screen_id')
            ? wc_get_page_screen_id('shop-order')
            : 'woocommerce_page_wc-orders';

        $isOrderScreen = $hook === $hposScreen
            || str_contains($hook, 'wc-orders')
            || str_contains($hook, 'shop_order')
            || ($screen !== null && $screen->post_type === 'shop_order')
            || (isset($_GET['page']) && $_GET['page'] === 'wc-orders');

        if (!$isOrderScreen) {
            return;
        }

        AdminUiAssets::enqueueStyle();

        $pluginFile = defined('GRCS_PLUGIN_FILE') ? (string) constant('GRCS_PLUGIN_FILE') : __FILE__;
        $pluginUrl = function_exists('plugins_url') ? plugins_url('', $pluginFile) : '';
        $version = defined('GRCS_VERSION') ? (string) constant('GRCS_VERSION') : '1.0.0';

        if (function_exists('wp_enqueue_script')) {
            wp_enqueue_script(
                'grcs-admin-orders',
                $pluginUrl . '/assets/js/admin-orders.js',
                ['jquery'],
                $version,
                true
            );

            $confirmMsg = AdminLocale::__(
                'Are you sure you want to cancel this courier voucher? / '
                . 'Είστε σίγουροι ότι θέλετε να ακυρώσετε το voucher;',
                'gr-commerce-suite'
            );

            wp_localize_script('grcs-admin-orders', 'grcsAdminOrders', [
                'ajaxUrl' => function_exists('admin_url') ? admin_url('admin-ajax.php') : '',
                'printUrl' => function_exists('admin_url') ? admin_url('admin-post.php?action=grcs_print') : '',
                'nonce' => function_exists('wp_create_nonce') ? wp_create_nonce(self::NONCE_ACTION_ORDER) : '',
                'i18n' => [
                    'issuing' => AdminLocale::__('Issuing voucher...', 'gr-commerce-suite'),
                    'cancelling' => AdminLocale::__('Cancelling voucher...', 'gr-commerce-suite'),
                    'confirmCancel' => $confirmMsg,
                    'confirmResolveCancel' => AdminLocale::__(
                        'Confirm this carrier state? It will be recorded on the order and cannot be undone from here.',
                        'gr-commerce-suite'
                    ),
                    'reasonRequired' => AdminLocale::__('A reason is required.', 'gr-commerce-suite'),
                    'resolvingCancel' => AdminLocale::__('Recording the cancellation state...', 'gr-commerce-suite'),
                    'copied' => AdminLocale::__('Copied', 'gr-commerce-suite'),
                    'copyFailed' => AdminLocale::__('Copy failed', 'gr-commerce-suite'),
                    'errorGeneric' => AdminLocale::__(
                        'An error occurred while communicating with the courier.',
                        'gr-commerce-suite'
                    ),
                ],
            ]);
        }
    }

    /**
     * Renders the single order metabox UI (SPEC.md §13).
     *
     * @param WP_Post|WC_Order|mixed $postOrOrder
     */
    public function renderMetabox(mixed $postOrOrder): void
    {
        $order = $this->resolveOrder($postOrOrder);
        if (!$order instanceof WC_Order) {
            echo '<p>' . AdminLocale::esc_html__('Order could not be loaded.', 'gr-commerce-suite') . '</p>';
            return;
        }

        $orderId = (int) $order->get_id();
        $vouchers = $this->getVouchersForOrder($orderId);

        // Active/latest voucher
        $activeVoucher = null;
        foreach ($vouchers as $v) {
            if (isset($v['state']) && $v['state'] === VoucherState::Created->value) {
                $activeVoucher = $v;
                break;
            }
        }
        if ($activeVoucher === null && !empty($vouchers)) {
            $activeVoucher = $vouchers[0];
        }
        $hasActiveVoucher = $activeVoucher !== null && ($activeVoucher['state'] ?? '') === VoucherState::Created->value;
        // A cancellation may already have reached the courier: such a row must not be presented as active
        // or printable, even though its local state is still `created`.
        $cancelPendingVoucher = null;
        if ($hasActiveVoucher && VoucherCancellationMarker::isPending($order, (int) ($activeVoucher['id'] ?? 0))) {
            $cancelPendingVoucher = $activeVoucher;
            $activeVoucher = null;
            $hasActiveVoucher = false;
        }
        $unresolvedVoucher = null;
        if (!$hasActiveVoucher) {
            foreach ($vouchers as $v) {
                if (in_array((string) ($v['state'] ?? ''), [VoucherState::Unknown->value, VoucherState::Reserved->value], true)) {
                    $unresolvedVoucher = $v;
                    break;
                }
            }
        }
        $hasUnresolvedVoucher = $unresolvedVoucher !== null;

        // Determine defaults
        $preferredCourier = (string) $order->get_meta('_grcs_preferred_courier', true);
        if ($preferredCourier === '' && $activeVoucher !== null && isset($activeVoucher['courier_slug'])) {
            $preferredCourier = (string) $activeVoucher['courier_slug'];
        }
        if ($preferredCourier === '') {
            $preferredCourier = $this->detectCourierFromShipping($order)->value ?? '';
        }

        if (!in_array($preferredCourier, ['acs', 'boxnow', 'geniki'], true)) {
            $preferredCourier = '';
        }
        $parcels = ShippingOptions::parcelCount($order);

        $weightStr = (string) $order->get_meta('_grcs_custom_weight', true);

        // Cash on delivery amount: order total if payment method is COD, else 0.00
        $customCod = $order->get_meta('_grcs_custom_cod_amount', true);
        if ($customCod !== '' && $customCod !== null) {
            $codAmountStr = GreekDataNormalizer::formatDecimalString((string) $customCod, 0.00);
        } else {
            $isCod = $this->isCodPaymentMethod($order);
            $codAmountStr = $isCod
                ? GreekDataNormalizer::formatDecimalString((string) $order->get_total(), 0.00)
                : '0.00';
        }

        $nonce = function_exists('wp_create_nonce') ? wp_create_nonce(self::NONCE_ACTION_ORDER) : '';
        $hdrStyle = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;';
        $badgeStyle = 'display:inline-block;padding:2px 8px;border-radius:3px;font-size:11px;'
            . 'font-weight:600;text-transform:uppercase;background:#e7f5ea;color:#1e7e34;';
        ?>
        <div class="grcs-metabox-wrapper">
            <?php
            foreach (self::findActiveVoucherOnDeadOrder($order, $vouchers) as $deadOrderVoucher) {
                echo '<p class="grcs-mb-refund grcs-mb-refund--attention" data-grcs-dead-order-voucher="1">' . esc_html(sprintf(
                    AdminLocale::__('Order has an active %1$s voucher %2$s: cancel it at the courier if the parcel must not ship.', 'gr-commerce-suite'),
                    $deadOrderVoucher['courier'],
                    $deadOrderVoucher['voucher_no']
                )) . '</p>';
            }
            ?>
            <?php if (current_user_can('manage_woocommerce') && current_user_can('edit_shop_orders') && current_user_can('edit_shop_order', $orderId)) : ?>
                <p><a class="button" href="<?php echo esc_url(Customer360Page::orderHistoryUrl($orderId)); ?>"><?php AdminLocale::esc_html_e('Customer 360°', 'gr-commerce-suite'); ?></a></p>
            <?php endif; ?>
            <input type="hidden" name="grcs_locker_nonce" value="<?php echo esc_attr($nonce); ?>" />
            <input type="hidden" id="grcs_order_id" value="<?php echo esc_attr((string) $orderId); ?>" />
            <input type="hidden" id="grcs_order_nonce" value="<?php echo esc_attr($nonce); ?>" />
            <div class="grcs-mb-tabs" role="tablist" aria-label="<?php echo AdminLocale::esc_attr__('Courier and customer risk', 'gr-commerce-suite'); ?>">
                <button type="button" id="grcs-mb-tab-courier" role="tab" aria-controls="grcs-mb-panel-courier" aria-selected="true" data-grcs-mb-tab="courier">📦 <?php AdminLocale::esc_html_e('Voucher & Courier', 'gr-commerce-suite'); ?></button>
                <button type="button" id="grcs-mb-tab-risk" role="tab" aria-controls="grcs-mb-panel-risk" aria-selected="false" data-grcs-mb-tab="risk">🛡️ <?php AdminLocale::esc_html_e('COD Blacklist', 'gr-commerce-suite'); ?></button>
            </div>
            <section id="grcs-mb-panel-courier" role="tabpanel" aria-labelledby="grcs-mb-tab-courier" data-grcs-mb-panel="courier">
            <?php if ((new LicenseManager())->isSandboxEnabled()) : ?>
                <p class="grcs-mb-sandbox"><?php AdminLocale::esc_html_e('Test mode: vouchers, labels and cancellations here are simulated. Nothing is sent to ACS or BOX NOW.', 'gr-commerce-suite'); ?></p>
                <?php if (ModuleRegistry::isEnabled(ModuleRegistry::GENIKI) || $preferredCourier === 'geniki') : ?>
                    <p><?php AdminLocale::esc_html_e('Geniki uses its carrier sandbox endpoint in test mode; Geniki operations are sent to that test account.', 'gr-commerce-suite'); ?></p>
                <?php endif; ?>
            <?php elseif (!$hasActiveVoucher) : ?>
                <?php
                // Same saved-credential check as Setup status; say so before the merchant tries to issue a voucher.
                $genikiCredentials = (new \GRCommerceSuite\Security\CredentialVault())->getForCourier(CourierSlug::Geniki);
                if (ModuleRegistry::isEnabled(ModuleRegistry::GENIKI) && ($preferredCourier === '' || $preferredCourier === 'geniki')
                    && (trim($genikiCredentials['username'] ?? '') === '' || trim($genikiCredentials['password'] ?? '') === '' || trim($genikiCredentials['application_key'] ?? '') === '')) {
                    echo '<p>' . AdminLocale::esc_html__('Geniki credentials are incomplete.', 'gr-commerce-suite') . ' <a href="'
                        . esc_url(admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite&section=geniki')) . '">'
                        . AdminLocale::esc_html__('Add credentials', 'gr-commerce-suite') . '</a></p>';
                }
                foreach (['acs' => ['ACS Courier', 'grcs_acs_company_id'], 'boxnow' => ['BOX NOW', 'grcs_boxnow_client_id']] as $section => [$courierName, $credentialOption]) {
                    if (ModuleRegistry::isEnabled($section) && ($preferredCourier === '' || $preferredCourier === $section) && (string) get_option($credentialOption, '') === '') {
                        echo '<p class="grcs-mb-refund grcs-mb-refund--warning">' . esc_html(sprintf(AdminLocale::__('%s credentials are not set up, so vouchers for this courier cannot be issued yet.', 'gr-commerce-suite'), $courierName))
                            . ' <a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite&section=' . $section)) . '">' . AdminLocale::esc_html__('Add credentials', 'gr-commerce-suite') . '</a></p>';
                    }
                }
                ?>
            <?php endif; ?>
            <?php
            // Prepaid orders (bank transfer, card) still waiting for money: say so before a parcel is booked.
            // Informational only; the merchant decides, and issuing stays available.
            if (!$hasActiveVoucher && !$this->isCodPaymentMethod($order) && $order->has_status(['pending', 'on-hold']) && (float) $order->get_total() > 0) {
                echo '<p class="grcs-mb-refund grcs-mb-refund--attention" data-grcs-awaiting-payment="1"><strong>'
                    . AdminLocale::esc_html__('Payment not received yet.', 'gr-commerce-suite') . '</strong> '
                    . esc_html(sprintf(AdminLocale::__('This order is waiting for %1$s of %2$s. When the money arrives, mark the order as Processing and then issue the voucher.', 'gr-commerce-suite'),
                        $order->get_payment_method_title() !== '' ? $order->get_payment_method_title() : AdminLocale::__('payment', 'gr-commerce-suite'),
                        html_entity_decode(wp_strip_all_tags(wc_price((float) $order->get_total(), ['currency' => $order->get_currency()])), ENT_QUOTES, 'UTF-8')))
                    . '</p>';
            }
            ?>

            <?php if ($hasActiveVoucher) : ?>
                <?php
                $voucherNo = (string) ($activeVoucher['voucher_no'] ?? '');
                $courierVal = (string) ($activeVoucher['courier_slug'] ?? 'acs');
                $courierSlug = CourierSlug::tryFrom($courierVal) ?? CourierSlug::Acs;
                $trackingStatus = (string) ($activeVoucher['tracking_status'] ?? 'pending');
                $isPrinted = !empty($activeVoucher['is_printed']);

                $thermalPrintUrl = $this->buildPrintUrl($voucherNo, $courierSlug->value, 'thermal');
                $a4PrintUrl = $this->buildPrintUrl($voucherNo, $courierSlug->value, 'a4');
                $trackingUrl = $this->buildTrackingUrl($voucherNo, $courierSlug);
                $codFmt = number_format((float) ($activeVoucher['cod_amount'] ?? 0), 2, '.', '');
                $cancelBtnStyle = 'font-size: 11px; color: #b32d2e; text-decoration: none; cursor: pointer;';
                $activeVoucherId = (string) ($activeVoucher['id'] ?? '');
                ?>
                <div class="grcs-active-voucher">
                    <div style="<?php echo esc_attr($hdrStyle); ?>">
                        <span style="font-weight: 600; color: #1d2327;">
                            <?php echo esc_html($courierSlug->label()); ?>
                        </span>
                        <span style="<?php echo esc_attr($badgeStyle); ?>">
                            <?php echo esc_html(AdminLocale::status($trackingStatus)); ?>
                        </span>
                    </div>

                    <div style="margin-bottom: 8px;">
                        <span style="color: #646970; font-size: 12px;">
                            <?php AdminLocale::esc_html_e('Voucher No:', 'gr-commerce-suite'); ?>
                        </span>
                        <strong style="font-size: 14px; font-family: monospace; margin-left: 4px;">
                            <?php echo esc_html($voucherNo); ?>
                        </strong>
                        <button type="button" class="button-link grcs-copy-voucher" data-copy="<?php echo esc_attr($voucherNo); ?>"
                                aria-label="<?php echo esc_attr(sprintf(AdminLocale::__('Copy voucher number %s', 'gr-commerce-suite'), $voucherNo)); ?>"><?php
                            AdminLocale::esc_html_e('Copy', 'gr-commerce-suite');
                        ?></button>
                        <?php if ($trackingUrl !== '') : ?>
                            <a href="<?php echo esc_url($trackingUrl); ?>"
                               target="_blank"
                               rel="noopener noreferrer"
                               style="font-size: 12px; margin-left: 6px; text-decoration: none;">
                                &#128269; <?php AdminLocale::esc_html_e('Trace', 'gr-commerce-suite'); ?>
                            </a>
                        <?php endif; ?>
                    </div>

                    <?php if ($courierSlug === CourierSlug::Geniki) : ?>
                        <ul><?php foreach (ShippingOptions::voucherNumbers($activeVoucher) as $parcelNumber) : ?>
                            <?php if ($parcelNumber === $voucherNo) { continue; } ?>
                            <li><code><?php echo esc_html($parcelNumber); ?></code>
                                <a target="_blank" rel="noopener noreferrer" href="<?php echo esc_url($this->buildTrackingUrl($parcelNumber, $courierSlug)); ?>"><?php AdminLocale::esc_html_e('Trace', 'gr-commerce-suite'); ?></a>
                            </li>
                        <?php endforeach; ?></ul>
                    <?php endif; ?>
                    <div style="font-size: 12px; color: #646970; margin-bottom: 10px;">
                        <span>
                            <?php printf(AdminLocale::esc_html__('COD: €%s', 'gr-commerce-suite'), esc_html($codFmt)); ?>
                        </span>
                        <span style="margin: 0 4px;">&bull;</span>
                        <span>
                            <?php
                            echo $isPrinted
                                ? AdminLocale::esc_html__('Printed &#10003;', 'gr-commerce-suite')
                                : AdminLocale::esc_html__('Unprinted', 'gr-commerce-suite');
                            ?>
                        </span>
                    </div>

                    <p>
                        <?php echo $this->codSettlementSummary($activeVoucher); // Escaped by the helper. ?>
                        <?php if (current_user_can('manage_woocommerce') && $this->expectedCodCents($activeVoucher) > 0) : ?>
                            <br><a href="<?php echo esc_url(admin_url('admin.php?page=' . CodReconciliationPage::MENU_SLUG . '&tab=reconciliation&courier=' . $courierSlug->value . '&voucher_id=' . rawurlencode($activeVoucherId)) . '#grcs-cod-voucher-' . rawurlencode($activeVoucherId)); ?>"><?php AdminLocale::esc_html_e('COD Reconciliation', 'gr-commerce-suite'); ?></a>
                        <?php endif; ?>
                    </p>
                    <?php
                    try {
                        $refund = CodRefundStatus::describe($order, $vouchers);
                    } catch (Throwable) {
                        $refund = ['note' => '', 'warning' => '']; // Informational; never break the courier box.
                    }
                    ?>
                    <?php if ($refund['warning'] !== '') : ?>
                        <p class="grcs-mb-refund grcs-mb-refund--warning" role="alert"><?php echo esc_html($refund['warning']); ?></p>
                    <?php elseif ($refund['note'] !== '') : ?>
                        <p class="grcs-mb-refund"><?php echo esc_html($refund['note']); ?></p>
                    <?php endif; ?>
                    <div class="grcs-mb-button-grid">
                        <a href="<?php echo esc_url($thermalPrintUrl); ?>"
                           target="_blank"
                           class="button button-secondary">
                            <?php AdminLocale::esc_html_e('Print Thermal', 'gr-commerce-suite'); ?>
                        </a>
                        <a href="<?php echo esc_url($a4PrintUrl); ?>"
                           target="_blank"
                           class="button button-secondary">
                            <?php AdminLocale::esc_html_e('Print A4', 'gr-commerce-suite'); ?>
                        </a>
                    </div>

                    <?php // Same "not yet moving" rule as warnUnshippedVouchers(): once the courier has the parcel, a cancel can only fail. ?>
                    <?php if (TrackingStatus::notYetShipped($trackingStatus)) : ?>
                        <div style="margin-top: 6px; text-align: right;">
                            <button type="button"
                                    class="button-link-delete grcs-cancel-voucher-btn"
                                    data-voucher-id="<?php echo esc_attr($activeVoucherId); ?>"
                                    style="<?php echo esc_attr($cancelBtnStyle); ?>">
                                &#10006; <?php AdminLocale::esc_html_e('Cancel Voucher', 'gr-commerce-suite'); ?>
                            </button>
                        </div>
                    <?php elseif ($trackingStatus === TrackingStatus::Delivered->value) : ?>
                        <p class="grcs-mb-help"><?php AdminLocale::esc_html_e('This parcel has been delivered, so the voucher is final.', 'gr-commerce-suite'); ?></p>
                    <?php else : ?>
                        <p class="grcs-mb-help"><?php AdminLocale::esc_html_e('The courier already has this parcel, so the voucher can no longer be cancelled here. Contact the courier to stop or return it.', 'gr-commerce-suite'); ?></p>
                    <?php endif; ?>
                </div>
            <?php elseif ($cancelPendingVoucher !== null) : ?>
                <?php
                $pCourier = CourierSlug::tryFrom((string) ($cancelPendingVoucher['courier_slug'] ?? 'acs')) ?? CourierSlug::Acs;
                $pNumber = (string) ($cancelPendingVoucher['voucher_no'] ?? '');
                $pVoucherId = (int) ($cancelPendingVoucher['id'] ?? 0);
                $pAt = (string) (VoucherCancellationMarker::pending($order, $pVoucherId)['at_utc'] ?? '');
                $pAtTs = $pAt !== '' ? strtotime($pAt) : false;
                $pAgeMinutes = $pAtTs !== false ? max(0, (int) floor((time() - $pAtTs) / 60)) : -1;
                ?>
                <div class="grcs-cancel-pending grcs-mb-refund grcs-mb-refund--warning" role="alert">
                    <div style="<?php echo esc_attr($hdrStyle); ?>">
                        <strong><?php echo esc_html($pCourier->label()); ?></strong>
                        <span class="grcs-pill grcs-pill--amber"><?php AdminLocale::esc_html_e('Cancellation pending', 'gr-commerce-suite'); ?></span>
                    </div>
                    <p style="margin: 0 0 6px;">
                        <?php echo esc_html(sprintf(
                            AdminLocale::__('Cancellation was sent for voucher %1$s, but the courier confirmation was not recorded. It is not printable or active until the courier state is confirmed. Check the courier portal before doing anything else.', 'gr-commerce-suite'),
                            $pNumber
                        )); ?>
                    </p>
                    <?php if ($pAt !== '') : ?>
                        <p class="grcs-mb-help" style="margin: 0;"><?php echo esc_html(sprintf(
                            AdminLocale::__('Cancellation requested %1$d minutes ago (at %2$s UTC).', 'gr-commerce-suite'),
                            $pAgeMinutes,
                            $pAt
                        )); ?></p>
                    <?php endif; ?>
                    <?php if ($this->canManageVouchers()) : ?>
                        <div class="grcs-cancel-pending-actions" style="margin-top: 8px; border-top: 1px solid #dcdcde; padding-top: 8px;">
                            <p style="margin: 0 0 6px;"><?php AdminLocale::esc_html_e('Resolve only after checking the courier portal. Every action requires a reason and is logged on the order.', 'gr-commerce-suite'); ?></p>
                            <label for="grcs_cancel_pending_reason_<?php echo esc_attr((string) $pVoucherId); ?>" style="display:block; margin-bottom: 4px;">
                                <?php AdminLocale::esc_html_e('Reason (required)', 'gr-commerce-suite'); ?>
                            </label>
                            <input type="text"
                                   id="grcs_cancel_pending_reason_<?php echo esc_attr((string) $pVoucherId); ?>"
                                   class="grcs-cancel-pending-reason"
                                   value=""
                                   style="width: 100%; max-width: 480px; margin-bottom: 6px;" />
                            <div class="grcs-mb-button-grid">
                                <button type="button" class="button button-secondary grcs-resolve-cancel-pending"
                                        data-resolve="retry" data-voucher-id="<?php echo esc_attr((string) $pVoucherId); ?>">
                                    <?php AdminLocale::esc_html_e('Retry cancellation', 'gr-commerce-suite'); ?>
                                </button>
                                <button type="button" class="button button-secondary grcs-resolve-cancel-pending"
                                        data-resolve="cancelled" data-voucher-id="<?php echo esc_attr((string) $pVoucherId); ?>">
                                    <?php AdminLocale::esc_html_e('Courier confirms it is cancelled', 'gr-commerce-suite'); ?>
                                </button>
                                <button type="button" class="button button-secondary grcs-resolve-cancel-pending"
                                        data-resolve="active" data-voucher-id="<?php echo esc_attr((string) $pVoucherId); ?>">
                                    <?php AdminLocale::esc_html_e('Courier confirms it is still active', 'gr-commerce-suite'); ?>
                                </button>
                            </div>
                            <div class="grcs-metabox-feedback" role="status" aria-live="polite" style="margin-top: 6px; font-size: 12px; display: none;"></div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php elseif ($hasUnresolvedVoucher) : ?>
                <?php
                $uId = (string) ($unresolvedVoucher['id'] ?? '');
                $uState = (string) ($unresolvedVoucher['state'] ?? 'unknown');
                $uCourierVal = (string) ($unresolvedVoucher['courier_slug'] ?? 'acs');
                $uCourier = CourierSlug::tryFrom($uCourierVal) ?? CourierSlug::Acs;
                $uError = AdminLocale::display((string) ($unresolvedVoucher['last_error'] ?? ''));
                ?>
                <div class="grcs-unresolved-voucher grcs-mb-refund grcs-mb-refund--warning" role="alert">
                    <div style="<?php echo esc_attr($hdrStyle); ?>">
                        <strong><?php echo esc_html($uCourier->label()); ?></strong>
                        <span class="grcs-pill grcs-pill--amber"><?php echo esc_html(AdminLocale::status($uState)); ?></span>
                    </div>
                    <p style="margin: 0 0 6px;">
                        <?php
                        echo esc_html($uState === VoucherState::Unknown->value
                            ? sprintf(
                                AdminLocale::__('A previous %1$s voucher request (#%2$s) did not return a clear confirmation and is marked Unknown to prevent a duplicate shipment. Confirm whether the courier created it, then link the voucher number or clear the failed attempt before issuing a new voucher.', 'gr-commerce-suite'),
                                $uCourier->label(),
                                $uId
                            )
                            : sprintf(
                                AdminLocale::__('A %1$s voucher request (#%2$s) is currently in progress (Reserved). Wait for it to finish before issuing another voucher.', 'gr-commerce-suite'),
                                $uCourier->label(),
                                $uId
                            ));
                        ?>
                    </p>
                    <?php if ($uError !== '') : ?>
                        <p class="grcs-mb-help" style="margin: 0 0 6px;"><?php echo esc_html($uError); ?></p>
                    <?php endif; ?>
                    <?php if ($uState === VoucherState::Unknown->value && current_user_can('manage_woocommerce')) : ?>
                        <?php if (LicenseManager::isLicensed()) : ?>
                            <p style="margin: 0;">
                                <a class="button button-small" href="<?php echo esc_url(admin_url('admin.php?page=' . CodReconciliationPage::MENU_SLUG . '&tab=reconciliation&courier=' . $uCourier->value) . '#grcs-unknown-voucher-' . rawurlencode($uId)); ?>">
                                    <?php AdminLocale::esc_html_e('Review & resolve voucher', 'gr-commerce-suite'); ?>
                                </a>
                            </p>
                        <?php else : ?>
                            <p class="grcs-mb-help" style="margin: 0;"><?php echo esc_html(self::licenceCreateOffMessage()); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php $this->renderEarlierVouchers($vouchers, $hasActiveVoucher ? $activeVoucher : ($cancelPendingVoucher ?? $unresolvedVoucher)); ?>

            <!-- Interactive Creation / Update Form -->
            <?php
            // Once the courier has the parcel the voucher cannot be cancelled, so a replacement form would
            // only repeat "cancel first" under a note saying it cannot be cancelled. Hide it until then.
            $reissueLocked = $cancelPendingVoucher !== null
                || ($hasActiveVoucher && !TrackingStatus::notYetShipped((string) ($activeVoucher['tracking_status'] ?? 'pending')));
            ?>
            <?php if (!LicenseManager::isLicensed()) : ?>
                <p class="grcs-mb-refund grcs-mb-refund--warning grcs-licence-create-off" role="status"><?php echo esc_html(self::licenceCreateOffMessage()); ?></p>
            <?php elseif (!$reissueLocked) : ?>
            <?php if ($hasActiveVoucher || $hasUnresolvedVoucher) : ?>
                <details class="grcs-reissue-drawer">
                    <summary><?php
                        echo $hasActiveVoucher
                            ? AdminLocale::esc_html__('Cancel the active voucher before issuing a replacement', 'gr-commerce-suite')
                            : AdminLocale::esc_html__('Resolve the uncertain voucher request before issuing a replacement', 'gr-commerce-suite');
                    ?></summary>
            <?php endif; ?>
            <div class="grcs-voucher-form">
                <div class="grcs-mb-field">
                    <label for="grcs_courier_select">
                        <?php AdminLocale::esc_html_e('Courier Provider', 'gr-commerce-suite'); ?>:
                    </label>
                    <select id="grcs_courier_select" name="grcs_courier">
                        <?php if ($preferredCourier === '') : ?>
                            <option value=""><?php AdminLocale::esc_html_e('Select courier', 'gr-commerce-suite'); ?></option>
                        <?php endif; ?>
                        <?php foreach (CourierSlug::cases() as $choice) : ?>
                            <?php if (ModuleRegistry::courierEnabled($choice) || $preferredCourier === $choice->value) : ?>
                                <option value="<?php echo esc_attr($choice->value); ?>" <?php selected($preferredCourier, $choice->value); ?>><?php echo esc_html($choice->label()); ?></option>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if (ModuleRegistry::isEnabled(ModuleRegistry::BOXNOW) || (string) $order->get_meta('_grcs_boxnow_locker_id', true) !== '') : ?>
                <div class="grcs-mb-field grcs-boxnow-locker-field">
                    <label for="grcs_boxnow_locker_id"><?php
                        AdminLocale::esc_html_e('Box Now Locker ID', 'gr-commerce-suite');
                    ?></label>
                    <input type="text" id="grcs_boxnow_locker_id" name="grcs_boxnow_locker_id" maxlength="64"
                           value="<?php echo esc_attr((string) $order->get_meta('_grcs_boxnow_locker_id', true)); ?>" />
                    <?php
                    $lockerDetails = $order->get_meta(BoxNowCheckoutPicker::DETAILS_KEY, true);
                    $lockerId = (string) $order->get_meta('_grcs_boxnow_locker_id', true);
                    ?>
                    <?php if (is_array($lockerDetails) && $lockerId !== '' && (string) ($lockerDetails['id'] ?? '') === $lockerId) : ?>
                        <p class="grcs-mb-help grcs-mb-locker"><strong><?php
                            echo esc_html('#' . $lockerId . ' (' . (string) ($lockerDetails['name'] ?? '') . ')');
                        ?></strong><br /><?php
                            echo esc_html(trim((string) ($lockerDetails['address'] ?? '') . ', ' . (string) ($lockerDetails['postcode'] ?? ''), ', '));
                        ?></p>
                    <?php else : ?>
                        <p class="grcs-mb-help"><?php AdminLocale::esc_html_e('Used for BOX NOW deliveries.', 'gr-commerce-suite'); ?></p>
                    <?php endif; ?>
                </div>

                <?php endif; ?>
                <hr class="grcs-mb-divider" />

                <div class="grcs-mb-row">
                    <div class="grcs-mb-field">
                        <label for="grcs_parcels_input">
                            <?php AdminLocale::esc_html_e('Parcel Count (Τεμάχια)', 'gr-commerce-suite'); ?>:
                        </label>
                        <input type="number"
                               id="grcs_parcels_input"
                               name="grcs_parcels"
                               max="100"
                               value="<?php echo esc_attr((string) $parcels); ?>"
                               min="1"
                               step="1" />
                    </div>
                    <div class="grcs-mb-field">
                        <label for="grcs_weight_input">
                            <?php AdminLocale::esc_html_e('Weight Override (kg)', 'gr-commerce-suite'); ?>:
                        </label>
                        <input type="number"
                               id="grcs_weight_input"
                               name="grcs_weight"
                               value="<?php echo esc_attr($weightStr); ?>"
                               placeholder="<?php echo esc_attr(number_format(ShippingOptions::weightKg($order), 2, '.', '')); ?>"
                               aria-describedby="grcs_weight_help"
                               min="0.01"
                               step="0.01" />
                        <p class="grcs-mb-help" id="grcs_weight_help"><?php echo $this->weightHelp($order); ?></p>
                    </div>
                </div>

                <div class="grcs-mb-field">
                    <label for="grcs_cod_input">
                        <?php AdminLocale::esc_html_e('COD Amount (€) / Αντικαταβολή', 'gr-commerce-suite'); ?>:
                    </label>
                    <input type="text"
                           id="grcs_cod_input"
                           name="grcs_cod_amount"
                           value="<?php echo esc_attr($codAmountStr); ?>" />
                </div>

                <?php if (ModuleRegistry::isEnabled(ModuleRegistry::ACS)) {
                    $this->renderAcsOptions($order);
                } ?>
                <?php
                $statusHints = $this->issueStatusHints($order, CourierSlug::tryFrom($preferredCourier));
                if ($statusHints['block'] !== '') {
                    echo '<p class="grcs-mb-refund grcs-mb-refund--attention" data-grcs-status-rule="strict">' . esc_html($statusHints['block']) . '</p>';
                }
                ?>
                <div class="grcs-mb-actions">
                    <button type="button"
                            <?php echo $statusHints['confirm'] !== '' ? 'data-grcs-confirm="' . esc_attr($statusHints['confirm']) . '" data-grcs-confirm-status="' . esc_attr($order->get_status()) . '"' : ''; ?>
                            class="button button-primary grcs-issue-voucher-btn" <?php echo ($hasActiveVoucher || $hasUnresolvedVoucher || !ModuleRegistry::anyCourierEnabled() || $statusHints['block'] !== '') ? 'disabled' : ''; ?>>
                        &#9881; <?php AdminLocale::esc_html_e('Issue Voucher', 'gr-commerce-suite'); ?>
                    </button>
                </div>

                <div class="grcs-metabox-feedback" style="margin-top: 8px; font-size: 12px; display: none;"></div>
            </div>
            <?php if ($hasActiveVoucher || $hasUnresolvedVoucher) : ?>
                </details>
            <?php endif; ?>
            <?php endif; ?>
            </section>
            <?php // The finalization page itself is licence-gated (MerchantFinalization::authorize()); don't link to a refusal. ?>
            <?php if (LicenseManager::isLicensed() && (ModuleRegistry::isEnabled(ModuleRegistry::GENIKI) || $preferredCourier === 'geniki'
                || array_filter($vouchers, static fn(array $row): bool => ($row['courier_slug'] ?? '') === 'geniki') !== [])) : ?>
                <p><a class="button" href="<?php echo esc_url(\GRCommerceSuite\Modules\Geniki\MerchantFinalization::url()); ?>"><?php AdminLocale::esc_html_e('Review account-wide Geniki finalization', 'gr-commerce-suite'); ?></a></p>
            <?php endif; ?>
            <section id="grcs-mb-panel-risk" role="tabpanel" aria-labelledby="grcs-mb-tab-risk" data-grcs-mb-panel="risk">
                <?php $this->renderRiskControls($order); ?>
                <div class="grcs-metabox-feedback" role="status" aria-live="polite"></div>
            </section>
        </div>
        <?php
    }

    /** Escaped sentence saying where the voucher weight comes from, so a guessed weight is never silent. */
    private function weightHelp(WC_Order $order): string
    {
        $weight = ShippingOptions::weightSource($order);
        $kg = number_format($weight['kg'], 2, '.', '');
        $text = match ($weight['source']) {
            'override' => AdminLocale::__('Your override is used instead of the product weights.', 'gr-commerce-suite'),
            'default' => sprintf(AdminLocale::__('No product in this order has a weight, so the default parcel weight from GR Commerce settings (%s kg) is used.', 'gr-commerce-suite'), $kg),
            default => sprintf(AdminLocale::__('Calculated from product weights: %s kg.', 'gr-commerce-suite'), $kg),
        };
        if ($weight['source'] === 'products' && $weight['missing'] > 0) {
            $text .= ' ' . sprintf(AdminLocale::_n('%d product has no weight, so the parcel may be heavier.', '%d products have no weight, so the parcel may be heavier.', $weight['missing'], 'gr-commerce-suite'), $weight['missing']);
        }
        if ($weight['kg'] < 0.5) {
            $text .= ' ' . AdminLocale::__('The voucher uses at least 0.50 kg.', 'gr-commerce-suite');
        }
        return esc_html($text);
    }

    /** @param array<string, mixed> $voucher */
    private function expectedCodCents(array $voucher): int
    {
        return Money::fromDecimalString((string) ($voucher['cod_amount'] ?? '0.00'))->cents();
    }

    /**
     * Escaped one-line COD settlement status for a voucher. Shows a collected shortfall/excess
     * explicitly so an accepted difference is never hidden behind "Reconciled: Yes".
     *
     * @param array<string, mixed> $voucher
     */
    private function codSettlementSummary(array $voucher): string
    {
        $expected = $this->expectedCodCents($voucher);
        if ($expected === 0) {
            return AdminLocale::esc_html__('Not a cash-on-delivery shipment', 'gr-commerce-suite');
        }
        $collected = isset($voucher['cod_collected']) && (string) $voucher['cod_collected'] !== ''
            ? Money::fromDecimalString((string) $voucher['cod_collected'])->cents() : null;
        $text = AdminLocale::__('COD Collected (€)', 'gr-commerce-suite') . ': '
            . ($collected === null ? '—' : Money::fromCents($collected)->toDecimalString());
        if ($collected !== null && $collected !== $expected) {
            $difference = $collected - $expected;
            $text .= ' (' . sprintf(AdminLocale::__('difference %s', 'gr-commerce-suite'),
                ($difference < 0 ? '−' : '+') . '€' . Money::fromCents(abs($difference))->toDecimalString()) . ')';
        }
        return esc_html($text) . '<br>' . AdminLocale::esc_html__('Reconciled', 'gr-commerce-suite') . ': '
            . ((int) ($voucher['cod_reconciled'] ?? 0) === 1
                ? AdminLocale::esc_html__('Yes', 'gr-commerce-suite') : AdminLocale::esc_html__('No', 'gr-commerce-suite'));
    }

    /**
     * Read-only list of this order's other vouchers (cancelled, failed or superseded), so the
     * order remains the single place to understand every shipment attempt.
     *
     * @param list<array<string, mixed>> $vouchers
     * @param array<string, mixed>|null $active
     */
    private function renderEarlierVouchers(array $vouchers, ?array $active): void
    {
        $earlier = array_values(array_filter($vouchers, static fn(array $v): bool => $active === null || ($v['id'] ?? null) !== ($active['id'] ?? null)));
        if ($earlier === []) {
            return;
        }
        echo '<details class="grcs-mb-history"><summary>'
            . esc_html(sprintf(AdminLocale::__('Earlier vouchers for this order (%d)', 'gr-commerce-suite'), count($earlier)))
            . '</summary><ul>';
        foreach ($earlier as $voucher) {
            $courier = CourierSlug::tryFrom((string) ($voucher['courier_slug'] ?? ''));
            $state = (string) ($voucher['state'] ?? 'unknown');
            $color = match ($state) {
                'created' => 'green',
                'reserved', 'unknown' => 'amber',
                'failed' => 'red',
                default => 'gray',
            };
            $number = (string) ($voucher['voucher_no'] ?? '');
            if ($courier === CourierSlug::Geniki && $number !== '') {
                $number = implode(', ', ShippingOptions::voucherNumbers($voucher));
            }
            // A still-valid voucher is described by where the parcel is; others by why they ended.
            $label = $state === VoucherState::Created->value && (string) ($voucher['tracking_status'] ?? '') !== ''
                ? (string) $voucher['tracking_status'] : $state;
            echo '<li><strong>' . esc_html($courier !== null ? $courier->label() : strtoupper((string) ($voucher['courier_slug'] ?? '')))
                . '</strong> <code>' . esc_html($number !== '' ? $number : '—') . '</code> '
                . '<span class="grcs-pill grcs-pill--' . esc_attr($color) . '">' . esc_html(AdminLocale::status($label)) . '</span>';
            if ($state === VoucherState::Created->value) {
                echo '<br><span class="grcs-mb-help">' . $this->codSettlementSummary($voucher) . '</span>';
            }
            echo '</li>';
        }
        echo '</ul></details>';
    }

    public function renderAcsOptions(WC_Order $order): void
    {
        echo '<div class="grcs-acs-options"><small>' . AdminLocale::esc_html__('ACS delivery services', 'gr-commerce-suite') . '</small>';
        foreach (
            [
            'saturday' => AdminLocale::__('Saturday Delivery (Παράδοση Σάββατο)', 'gr-commerce-suite'),
            'rdo' => AdminLocale::__('RDO (Return Documents / Επιστροφή Δικαιολογητικών)', 'gr-commerce-suite'),
            'rec' => AdminLocale::__('REC (Reception Delivery / Παραλαβή από Κατάστημα)', 'gr-commerce-suite'),
            ] as $key => $label
        ) {
            echo '<label><input type="checkbox" name="grcs_acs_' . esc_attr($key) . '" value="yes"'
                . ($order->get_meta('_grcs_acs_' . $key, true) === 'yes' ? ' checked' : '') . ' /> '
                . esc_html($label) . '</label>';
        }
        echo '</div>';
    }

    /** @param array<string, mixed> $data */
    public function persistParcelOptions(WC_Order $order, array $data, string $prefix = '', bool $includePreferredCourier = true): void
    {
        if (isset($data[$prefix . 'parcels']) && is_scalar($data[$prefix . 'parcels'])) {
            $order->update_meta_data('_grcs_parcel_count', (string) max(1, min(100, (int) $data[$prefix . 'parcels'])));
        }
        if (isset($data[$prefix . 'weight']) && is_scalar($data[$prefix . 'weight'])) {
            $weight = str_replace(',', '.', (string) $data[$prefix . 'weight']);
            $order->update_meta_data('_grcs_custom_weight', is_numeric($weight) && (float) $weight > 0
                && is_finite((float) $weight) ? number_format((float) $weight, 2, '.', '') : '');
        }
        $codKey = $prefix === '' ? 'cod_amount' : 'grcs_cod_amount';
        if (isset($data[$codKey]) && is_scalar($data[$codKey])) {
            $order->update_meta_data('_grcs_custom_cod_amount', GreekDataNormalizer::formatDecimalString((string) $data[$codKey], 0));
        }
        foreach (['saturday', 'rdo', 'rec'] as $key) {
            if (!ModuleRegistry::isEnabled(ModuleRegistry::ACS) || !isset($data[$prefix . 'parcels'])) {
                continue;
            }
            $order->update_meta_data('_grcs_acs_' . $key, ($data['grcs_acs_' . $key] ?? '') === 'yes' ? 'yes' : 'no');
        }
        $courier = $data[$prefix === '' ? 'courier' : 'grcs_courier'] ?? '';
        if ($includePreferredCourier && is_string($courier) && CourierSlug::tryFrom($courier) !== null) {
            $order->update_meta_data('_grcs_preferred_courier', $courier);
        }
    }

    public function handleAjaxSaveParcelOptions(): void
    {
        if (!LicenseManager::isLicensed()) {
            $this->sendJsonError(AdminLocale::__('License Required.', 'gr-commerce-suite'), 403);
            return;
        }
        check_ajax_referer(self::NONCE_ACTION_ORDER, 'security');
        if (!$this->canManageVouchers()) {
            $this->sendJsonError(AdminLocale::__('Permission denied.', 'gr-commerce-suite'), 403);
            return;
        }
        $order = wc_get_order(absint($_POST['order_id'] ?? 0));
        if (!$order instanceof WC_Order) {
            $this->sendJsonError(AdminLocale::__('Order not found.', 'gr-commerce-suite'), 404);
            return;
        }
        $locker = $_POST['locker_id'] ?? null;
        if (is_string($locker)) {
            $locker = trim(wp_unslash($locker));
            if ($locker !== '' && !preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', $locker)) {
                $this->sendJsonError(AdminLocale::__('Invalid Box Now Locker ID.', 'gr-commerce-suite'), 422);
                return;
            }
            $order->update_meta_data('_grcs_boxnow_locker_id', $locker);
        }
        $this->persistParcelOptions($order, $_POST);
        $order->save();
        $this->sendJsonSuccess(['message' => AdminLocale::__('Parcel options saved.', 'gr-commerce-suite')]);
    }

    public function autoIssueCompleted(int $orderId, ?WC_Order $order = null): void
    {
        if (
            isset($this->autoIssueHandled[$orderId]) || !LicenseManager::isLicensed()
            || get_option(ShippingOptions::AUTO_ISSUE, 'no') !== 'yes'
        ) {
            return;
        }
        $order ??= wc_get_order($orderId) ?: null;
        if (!$order instanceof WC_Order) {
            return;
        }
        foreach ($this->getVouchersForOrder($orderId) as $voucher) {
            if (!in_array($voucher['state'] ?? '', ['failed', 'cancelled'], true)) {
                return;
            }
        }
        $this->autoIssueHandled[$orderId] = true;
        try {
            $courier = $this->detectCourierFromShipping($order);
            if ($courier === null || !ModuleRegistry::courierEnabled($courier)) {
                return; // module off: stay silent, no order note
            }
            $this->createVoucherForOrder($order, $courier);
        } catch (Throwable $e) {
            $order->add_order_note(sprintf(AdminLocale::__('Automatic voucher issue failed: %s', 'gr-commerce-suite'), AdminLocale::error($e->getMessage())));
        }
    }

    public function syncOrderStatus(int $voucherId, TrackingStatus $status): void
    {
        if (get_option(ShippingOptions::AUTO_STATUS, 'no') !== 'yes') {
            return;
        }
        $row = $this->voucherRepository?->findById($voucherId);
        if ($row === null || ($row['state'] ?? '') !== 'created') {
            return;
        }
        $order = wc_get_order((int) $row['order_id']);
        if (!$order instanceof WC_Order) {
            return;
        }
        if ($status === TrackingStatus::Delivered && !$order->has_status(['completed', 'cancelled', 'refunded', 'failed'])) {
            $order->update_status('completed', AdminLocale::__('Courier tracking confirms delivery.', 'gr-commerce-suite'));
        }
        if ($status === TrackingStatus::Returned && !$order->get_meta('_grcs_return_note_' . $voucherId, true)) {
            $order->add_order_note(AdminLocale::__('Courier reports Refused/Returned — Άρνηση Παραλαβής. Review COD Blacklist and contact the customer.', 'gr-commerce-suite'));
            $order->update_meta_data('_grcs_return_note_' . $voucherId, 'yes');
            $order->save();
        }
    }

    /** Private merchant warning; never cancel a remote shipment implicitly. */
    public function warnUnshippedVouchers(int $orderId, ?WC_Order $order = null): void
    {
        $order ??= wc_get_order($orderId) ?: null;
        if (!$order instanceof WC_Order) {
            return;
        }
        // Same deduplicated note (one per voucher row); caller already knows the order is dead.
        $this->noteVoucherRows($order, self::activeVoucherRows($this->getVouchersForOrder($orderId)));
    }

    public function saveShipmentSnapshot(int $voucherId, VoucherResult $result, int $orderId): void
    {
        LicenseManager::assertLicensed();
        $order = wc_get_order($orderId);
        if (!$order instanceof WC_Order) {
            return;
        }
        $order->update_meta_data('_grcs_shipment_' . $voucherId, [
            'pieces' => $result->parcelCount,
            'voucher_numbers' => ShippingOptions::resultVoucherNumbers($result),
            'weight' => $result->courier === CourierSlug::BoxNow
                ? max(0.5, ShippingOptions::weightKg($order) / $result->parcelCount) * $result->parcelCount
                : max(0.5, ShippingOptions::weightKg($order)),
            'recipient' => trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name())
                ?: trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
            'address' => $result->lockerId !== null ? AdminLocale::__('Locker #', 'gr-commerce-suite') . $result->lockerId
                : trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() . ' '
                    . $order->get_shipping_city() . ' ' . $order->get_shipping_postcode()),
        ]);
        $order->save();
    }

    public function renderRiskControls(WC_Order $order): void
    {
        if ($this->blacklist === null || !LicenseManager::isLicensed()) {
            return;
        }
        $phone = $order->get_billing_phone();
        $email = $order->get_billing_email();
        $ip = (string) $order->get_customer_ip_address();
        $blocked = $this->blacklist->isBlacklisted($phone, $email, $ip, (int) $order->get_customer_id());
        echo '<div class="grcs-mb-risk">';
        if ($blocked) {
            echo '<p role="alert" class="grcs-mb-alert">'
                . AdminLocale::esc_html__('✖ Blacklisted / Σε Μαύρη Λίστα', 'gr-commerce-suite')
                . '</p>';
        } else {
            echo '<p class="grcs-mb-clean" role="status">' . AdminLocale::esc_html__('✓ Καθαρός / Clean Customer', 'gr-commerce-suite') . '</p>';
        }
        $matched = [];
        foreach (
            ['email' => [$email, AdminLocale::__('Email', 'gr-commerce-suite')], 'phone' => [$phone, AdminLocale::__('Τηλέφωνο', 'gr-commerce-suite')],
            'ip' => [$ip, AdminLocale::__('IP', 'gr-commerce-suite')]] as $type => [$value, $label]
        ) {
            $record = $this->blacklist->getRecord($type, $value);
            $match = $this->blacklist->recordBlocks($record) || !empty($record['whitelisted']);
            if ($match || ($matched === [] && $record !== [])) {
                $matched = $record;
            }
            echo '<span class="grcs-pill grcs-pill--' . ($match ? 'blue' : 'gray') . '">' . ($match ? '✓ ' : '') . esc_html($label) . '</span> ';
        }
        $reason = (string) ($matched['reason'] ?? '');
        if ($reason !== '') {
            echo '<p>' . AdminLocale::esc_html__('Αιτία (Reason)', 'gr-commerce-suite') . ': <span class="grcs-pill grcs-pill--red">'
                . esc_html(CodBlacklistService::reasons(true)[$reason] ?? $reason) . '</span></p>';
        }
        echo '<label for="grcs-risk-note">' . AdminLocale::esc_html__('Σημείωση (Note)', 'gr-commerce-suite') . '</label>'
            . '<input type="text" id="grcs-risk-note" name="grcs_risk_note" value="' . esc_attr((string) ($matched['notes'] ?? '')) . '" />';
        echo '<div class="grcs-mb-button-grid">';
        foreach (
            ['add' => AdminLocale::__('Blacklist', 'gr-commerce-suite'), 'note' => AdminLocale::__('Save Note', 'gr-commerce-suite'),
            'whitelist' => AdminLocale::__('Whitelist', 'gr-commerce-suite'), 'remove' => AdminLocale::__('Remove', 'gr-commerce-suite')] as $operation => $label
        ) {
            echo '<button type="button" class="button grcs-blacklist-customer" data-operation="' . esc_attr($operation)
                . '" data-blocked="' . ($operation === 'add' ? '1' : '0') . '">' . esc_html($label) . '</button>';
        }
        echo '</div></div>';
    }

    public function handleAjaxBlacklistCustomer(): void
    {
        LicenseManager::assertLicensed();
        if (!check_ajax_referer(self::NONCE_ACTION_ORDER, 'security', false)) {
            $this->sendJsonError(AdminLocale::__('Security check failed.', 'gr-commerce-suite'), 403);
            return;
        }
        if (!$this->canManageVouchers() || $this->blacklist === null) {
            $this->sendJsonError(AdminLocale::__('Permission denied.', 'gr-commerce-suite'), 403);
            return;
        }
        $order = wc_get_order(absint($_POST['order_id'] ?? 0));
        if (!$order instanceof WC_Order) {
            $this->sendJsonError(AdminLocale::__('Order not found.', 'gr-commerce-suite'), 404);
            return;
        }
        try {
            $operation = is_string($_POST['operation'] ?? null) ? $_POST['operation'] : '';
            $note = is_string($_POST['notes'] ?? null) ? sanitize_text_field(wp_unslash($_POST['notes'])) : '';
            $details = ['ip' => (string) $order->get_customer_ip_address(), 'notes' => $note,
                'customer_name' => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
                'postal_code' => $order->get_billing_postcode()];
            if ($operation === 'note') {
                $this->blacklist->saveNote($order->get_billing_phone(), $order->get_billing_email(), $note, $details['ip']);
            } elseif ($operation === 'whitelist') {
                $this->blacklist->whitelistCustomer($order->get_billing_phone(), $order->get_billing_email(), true, $details);
            } else {
                $this->blacklist->setCustomer(
                    $order->get_billing_phone(),
                    $order->get_billing_email(),
                    ($_POST['blocked'] ?? '') === '1',
                    $details + ['whitelisted' => false]
                );
            }
            $this->sendJsonSuccess(['message' => AdminLocale::__('Blacklist updated.', 'gr-commerce-suite')]);
        } catch (Throwable $e) {
            $this->sendJsonError(AdminLocale::error($e->getMessage()), 409);
        }
    }

    public function saveAdminLocker(int $orderId, mixed $postOrOrder = null): void
    {
        // Runs on every admin order save: never throw, just skip the issuance inputs when unlicensed.
        if (
            !LicenseManager::isLicensed() || !$this->canManageVouchers() || !isset($_POST['grcs_locker_nonce'], $_POST['grcs_boxnow_locker_id'])
            || !is_string($_POST['grcs_locker_nonce']) || !is_string($_POST['grcs_boxnow_locker_id'])
            || !wp_verify_nonce(wp_unslash($_POST['grcs_locker_nonce']), self::NONCE_ACTION_ORDER)
        ) {
            return;
        }
        $order = $postOrOrder instanceof WC_Order ? $postOrOrder : wc_get_order($orderId);
        $id = trim(wp_unslash($_POST['grcs_boxnow_locker_id']));
        if ($order instanceof WC_Order && ($id === '' || preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', $id))) {
            $order->update_meta_data('_grcs_boxnow_locker_id', $id);
            $this->persistParcelOptions($order, $_POST, 'grcs_');
            $order->save();
        }
    }

    /**
     * AJAX handler to issue a courier voucher from the single order screen.
     */
    public function handleAjaxIssueVoucher(): void
    {
        if (!LicenseManager::isLicensed()) {
            $this->sendJsonError(AdminLocale::__('License Required.', 'gr-commerce-suite'), 403);
            return;
        }

        check_ajax_referer(self::NONCE_ACTION_ORDER, 'security');

        if (!$this->canManageVouchers()) {
            $this->sendJsonError(AdminLocale::__('Permission denied.', 'gr-commerce-suite'), 403);
            return;
        }

        $orderId = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $courierRaw = isset($_POST['courier']) ? sanitize_text_field((string) $_POST['courier']) : 'acs';
        $courier = CourierSlug::tryFrom(strtolower($courierRaw)) ?? CourierSlug::Acs;

        if (!function_exists('wc_get_order')) {
            $this->sendJsonError(AdminLocale::__('WooCommerce order API is not available.', 'gr-commerce-suite'), 500);
            return;
        }

        $order = wc_get_order($orderId);
        if (!$order instanceof WC_Order) {
            $this->sendJsonError(AdminLocale::__('Order not found.', 'gr-commerce-suite'), 404);
            return;
        }

        if (isset($_POST['locker_id']) && is_string($_POST['locker_id'])) {
            $lockerId = trim(wp_unslash($_POST['locker_id']));
            if ($lockerId !== '' && !preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', $lockerId)) {
                $this->sendJsonError(AdminLocale::__('Invalid Box Now Locker ID.', 'gr-commerce-suite'), 422);
                return;
            }
            $order->update_meta_data('_grcs_boxnow_locker_id', $lockerId);
        }
        // Parcel inputs are what this attempt will send, so they are saved first. The courier preference is
        // only saved after a successful issuance: a failed or OFF-module attempt must not rewrite it.
        $this->persistParcelOptions($order, $_POST, '', false);
        $order->save();

        try {
            // Same nonce-checked request; the per-order confirmation never overrides the strict rule (server guard).
            // The OK only covers the status the merchant actually saw: bound to the status at request time.
            $postedStatus = isset($_POST['confirm_status']) && is_string($_POST['confirm_status'])
                ? sanitize_key(wp_unslash($_POST['confirm_status'])) : '';
            $confirmedRisky = $postedStatus !== '' && $postedStatus === $order->get_status();
            $result = $this->createVoucherForOrder($order, $courier, $confirmedRisky);

            $order->update_meta_data('_grcs_preferred_courier', $courier->value);
            $order->save();

            $thermalPrintUrl = $this->buildPrintUrl($result->voucherNo, $courier->value, 'thermal');
            $a4PrintUrl = $this->buildPrintUrl($result->voucherNo, $courier->value, 'a4');

            $this->sendJsonSuccess([
                'voucher_no' => $result->voucherNo,
                'courier' => $courier->value,
                'courier_label' => $courier->label(),
                'tracking_url' => $result->trackingUrl,
                'thermal_print_url' => $thermalPrintUrl,
                'a4_print_url' => $a4PrintUrl,
                'message' => sprintf(
                    AdminLocale::__('Successfully issued %s voucher: %s', 'gr-commerce-suite'),
                    $courier->label(),
                    $result->voucherNo
                ),
            ]);
        } catch (Throwable $e) {
            $this->logger->error(sprintf('Voucher creation failed for order #%d: %s', $orderId, $e->getMessage()));
            $this->sendJsonError(AdminLocale::error($e->getMessage()), 422);
        }
    }

    /**
     * AJAX handler to cancel an active courier voucher.
     */
    public function handleAjaxCancelVoucher(): void
    {
        check_ajax_referer(self::NONCE_ACTION_ORDER, 'security');

        if (!$this->canManageVouchers()) {
            $this->sendJsonError(AdminLocale::__('Permission denied.', 'gr-commerce-suite'), 403);
            return;
        }

        $voucherId = isset($_POST['voucher_id']) ? absint($_POST['voucher_id']) : 0;
        if ($voucherId <= 0) {
            $this->sendJsonError(AdminLocale::__('Invalid voucher ID.', 'gr-commerce-suite'), 400);
            return;
        }

        try {
            $cancelled = $this->cancelVoucherById($voucherId);
            if ($cancelled) {
                $this->sendJsonSuccess(['message' => AdminLocale::__('Voucher cancelled successfully.', 'gr-commerce-suite')]);
            } else {
                $msg = AdminLocale::__('Courier rejected voucher cancellation (it may already be in transit).', 'gr-commerce-suite');
                $this->sendJsonError($msg, 400);
            }
        } catch (Throwable $e) {
            $errLog = sprintf('Voucher cancellation failed for voucher #%d: %s', $voucherId, $e->getMessage());
            $this->logger->error($errLog);
            $this->sendJsonError(AdminLocale::error($e->getMessage()), 422);
        }
    }

    /**
     * Resolve a durable cancellation-pending marker: retry the carrier cancel, or record the operator's
     * confirmation that the shipment is cancelled / still active. Every action needs a reason and is audited.
     */
    public function handleAjaxResolveCancelPending(): void
    {
        check_ajax_referer(self::NONCE_ACTION_ORDER, 'security');
        if (!$this->canManageVouchers()) {
            $this->sendJsonError(AdminLocale::__('Permission denied.', 'gr-commerce-suite'), 403);
            return;
        }
        $voucherId = absint($_POST['voucher_id'] ?? 0);
        $orderId = absint($_POST['order_id'] ?? 0);
        $resolution = is_string($_POST['resolve_action'] ?? null) ? sanitize_key(wp_unslash($_POST['resolve_action'])) : '';
        $reason = is_string($_POST['reason'] ?? null) ? trim(wp_unslash($_POST['reason'])) : '';
        if ($voucherId <= 0 || $orderId <= 0) {
            $this->sendJsonError(AdminLocale::__('Invalid voucher or order ID.', 'gr-commerce-suite'), 400);
            return;
        }
        if (!in_array($resolution, ['retry', 'cancelled', 'active'], true)) {
            $this->sendJsonError(AdminLocale::__('Unknown cancellation resolution action.', 'gr-commerce-suite'), 400);
            return;
        }
        if ($reason === '') {
            $this->sendJsonError(AdminLocale::__('A reason is required for every cancellation-pending resolution.', 'gr-commerce-suite'), 422);
            return;
        }
        $order = wc_get_order($orderId);
        if (!$order instanceof WC_Order) {
            $this->sendJsonError(AdminLocale::__('Order not found.', 'gr-commerce-suite'), 404);
            return;
        }
        $row = $this->voucherRepository?->findById($voucherId);
        if ($row !== null && (int) ($row['order_id'] ?? 0) !== $orderId) {
            $this->sendJsonError(AdminLocale::__('This voucher does not belong to the selected order.', 'gr-commerce-suite'), 400);
            return;
        }

        try {
            if ($resolution === 'retry') {
                $resolved = $this->cancelVoucherById($voucherId);
                $order->add_order_note(sprintf(
                    AdminLocale::__('GR Commerce Suite: operator retried the pending cancellation (%1$s). Carrier result: %2$s.', 'gr-commerce-suite'),
                    $reason,
                    $resolved
                        ? AdminLocale::__('cancelled and recorded locally', 'gr-commerce-suite')
                        : AdminLocale::__('not confirmed; the cancellation-pending marker was kept', 'gr-commerce-suite')
                ));
                $order->save();
                $this->logger->info(sprintf(
                    'Operator retried pending cancellation for voucher #%d (order #%d). Resolved: %s. Reason: %s',
                    $voucherId,
                    $orderId,
                    $resolved ? 'yes' : 'no',
                    $reason
                ));
                if ($resolved) {
                    $this->sendJsonSuccess(['message' => AdminLocale::__('Cancellation confirmed and recorded. The order screen will refresh.', 'gr-commerce-suite')]);
                } else {
                    $this->sendJsonError(AdminLocale::__('The courier did not confirm the cancellation. The marker was kept; check the courier portal, then use one of the two confirmation actions.', 'gr-commerce-suite'), 409);
                }
                return;
            }

            if ($this->voucherService === null) {
                $this->sendJsonError(AdminLocale::__('VoucherService is not configured.', 'gr-commerce-suite'), 500);
                return;
            }
            $resolved = $resolution === 'cancelled'
                ? $this->voucherService->finalizeConfirmedCancellation($voucherId, $reason)
                : $this->voucherService->restoreAfterCancellationRefused($voucherId, $reason);
            if (!$resolved) {
                $this->sendJsonError(AdminLocale::__('The voucher or its cancellation marker changed while resolving it. Reload the order and try again.', 'gr-commerce-suite'), 409);
                return;
            }
            $this->sendJsonSuccess([
                'message' => $resolution === 'cancelled'
                    ? AdminLocale::__('Cancellation recorded and the marker cleared.', 'gr-commerce-suite')
                    : AdminLocale::__('The voucher is active again and can be printed.', 'gr-commerce-suite'),
            ]);
        } catch (Throwable $e) {
            $this->logger->error(sprintf(
                'Cancellation-pending resolution (%s) failed for voucher #%d (order #%d): %s',
                $resolution,
                $voucherId,
                $orderId,
                $e->getMessage()
            ));
            $this->sendJsonError(AdminLocale::error($e->getMessage()), 422);
        }
    }

    /**
     * Streaming PDF label printer handler via `admin-post.php?action=grcs_print` (SPEC.md §13).
     */
    public function handlePrintPdf(): void
    {
        if (!$this->canManageVouchers()) {
            wp_die(AdminLocale::esc_html__('Permission denied.', 'gr-commerce-suite'), '', ['response' => 403]);
        }

        check_admin_referer(self::NONCE_ACTION_PRINT);

        $voucherNo = isset($_GET['voucher_no']) ? sanitize_text_field((string) $_GET['voucher_no']) : '';
        $courierRaw = isset($_GET['courier']) ? sanitize_text_field((string) $_GET['courier']) : '';
        $format = isset($_GET['format']) ? sanitize_text_field((string) $_GET['format']) : 'thermal';

        $courier = CourierSlug::tryFrom(strtolower($courierRaw));
        if ($voucherNo === '' || $courier === null) {
            wp_die(AdminLocale::esc_html__('Invalid voucher number or courier slug.', 'gr-commerce-suite'), 400);
        }
        if (!in_array($format, ['a4', 'a6', 'thermal'], true)) {
            wp_die(AdminLocale::esc_html__('Invalid print format.', 'gr-commerce-suite'), 400);
        }
        if ($this->courierRegistry === null) {
            wp_die(AdminLocale::esc_html__('Courier service is unavailable.', 'gr-commerce-suite'), 503);
        }

        try {
            $pdfContent = $this->createVoucherPdf($courier, $voucherNo, $format);

            if (function_exists('nocache_headers')) {
                nocache_headers();
            }

            $fileName = esc_attr($courier->value . '-' . $voucherNo . '.pdf');
            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="' . $fileName . '"');
            header('Content-Length: ' . (string) strlen($pdfContent));
            echo $pdfContent; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Validated binary PDF response.
            exit;
        } catch (Throwable $e) {
            wp_die(
                esc_html(sprintf(AdminLocale::__('Print error: %s', 'gr-commerce-suite'), AdminLocale::error($e->getMessage()))),
                AdminLocale::esc_html__('Voucher Print Error', 'gr-commerce-suite'),
                ['back_link' => true, 'response' => 409]
            );
        }
    }

    /**
     * Serialize printing with cancellation/reissue and reject unrecorded voucher numbers.
     *
     * @param 'a4'|'a6'|'thermal' $format
     */
    private function createVoucherPdf(CourierSlug $courier, string $voucherNo, string $format): string
    {
        $registry = $this->courierRegistry;
        if ($registry === null) {
            throw new \RuntimeException(AdminLocale::__('Courier service is unavailable.', 'gr-commerce-suite'));
        }
        $row = $this->voucherRepository?->findByVoucherNo($courier, $voucherNo);
        if ($row === null) {
            throw new \RuntimeException(AdminLocale::__('Voucher record not found.', 'gr-commerce-suite'));
        }
        $orderId = (int) $row['order_id'];
        $token = \GRCommerceSuite\Services\VoucherOperationLock::acquire($orderId);
        try {
            $row = $this->voucherRepository->findByVoucherNo($courier, $voucherNo);
            if ($row === null || ($row['state'] ?? '') !== VoucherState::Created->value) {
                throw new \RuntimeException(AdminLocale::__('Voucher is cancelled or inactive and cannot be printed.', 'gr-commerce-suite'));
            }
            $order = wc_get_order($orderId);
            if (!$order instanceof WC_Order) {
                throw new \RuntimeException(AdminLocale::__('Order not found.', 'gr-commerce-suite'));
            }
            if (VoucherCancellationMarker::isPending($order, (int) ($row['id'] ?? 0))) {
                throw new \RuntimeException(AdminLocale::__('A cancellation for this voucher is pending courier confirmation, so it cannot be printed as an active label.', 'gr-commerce-suite'));
            }
            $numbers = ShippingOptions::voucherNumbers($row);
            \GRCommerceSuite\Pdf\VoucherLabelGenerator::rememberOrder($order, $numbers);
            $pdf = $registry->get($courier)->printVoucherPdf($numbers, $format);
            $this->voucherRepository->markPrinted([$voucherNo], $courier);
            return $pdf;
        } finally {
            \GRCommerceSuite\Services\VoucherOperationLock::release($orderId, $token);
        }
    }

    /**
     * Registers GRCS Bulk Actions on the WooCommerce Orders table (SPEC.md §13).
     *
     * @param array<string, string> $actions
     * @return array<string, string>
     */
    public function registerBulkActions(array $actions): array
    {
        // Vouchers and pickup lists are new carrier issuance: licence-gated (owner decision 2026-11-03).
        $licensed = LicenseManager::isLicensed();
        if ($licensed) {
            $actions[self::BULK_ACTION_ISSUE] = AdminLocale::__('GRCS: Issue Courier Vouchers (Bulk)', 'gr-commerce-suite');
        }
        $actions[self::BULK_ACTION_PRINT] = AdminLocale::__('GRCS: Print Merged PDF Vouchers', 'gr-commerce-suite');
        if ($licensed) {
            $actions[self::BULK_ACTION_PICKUP] = AdminLocale::__('GRCS: Issue Daily Pickup List (Kleisimo Imeras)', 'gr-commerce-suite');
        }

        return $actions;
    }

    /**
     * Handles bulk actions executed on WooCommerce Orders table (SPEC.md §13).
     *
     * @param string $redirectUrl
     * @param string $action
     * @param list<int|string> $orderIds
     * @return string
     */
    public function handleBulkActions(string $redirectUrl, string $action, array $orderIds): string
    {
        if ($orderIds === []) {
            return $redirectUrl;
        }

        $numericOrderIds = array_values(array_filter(array_map('absint', $orderIds)));
        if ($numericOrderIds === []) {
            return $redirectUrl;
        }

        if (!$this->canManageVouchers()) {
            return $redirectUrl;
        }

        if (!in_array($action, [self::BULK_ACTION_ISSUE, self::BULK_ACTION_PRINT, self::BULK_ACTION_PICKUP], true)) {
            return $redirectUrl;
        }

        // WooCommerce HPOS and the legacy orders list use different core nonce actions.
        $nonceAction = function_exists('current_filter')
            && current_filter() === 'handle_bulk_actions-edit-shop_order'
            ? 'bulk-posts'
            : 'bulk-orders';
        check_admin_referer($nonceAction);

        if (in_array($action, [self::BULK_ACTION_ISSUE, self::BULK_ACTION_PICKUP], true) && !LicenseManager::isLicensed()) {
            return add_query_arg(['grcs_bulk_license_required' => 1], $redirectUrl);
        }

        return match ($action) {
            self::BULK_ACTION_ISSUE => $this->executeBulkIssue($redirectUrl, $numericOrderIds),
            self::BULK_ACTION_PRINT => $this->executeBulkPrint($redirectUrl, $numericOrderIds),
            default => $this->executeBulkDailyPickup($redirectUrl, $numericOrderIds),
        };
    }

    /**
     * Executes bulk voucher creation across selected orders.
     *
     * @param list<int> $orderIds
     */
    private function executeBulkIssue(string $redirectUrl, array $orderIds): string
    {
        $issued = 0;
        $skipped = 0;
        $failed = 0;
        /** @var list<string> $ruleSkipped "id:status" of orders the status rule refused */
        $ruleSkipped = [];
        /** @var list<string> $warned "id:status" of unpaid orders created in free mode */
        $warned = [];

        foreach ($orderIds as $orderId) {
            if (!function_exists('wc_get_order')) {
                break;
            }

            $order = wc_get_order($orderId);
            if (!$order instanceof WC_Order) {
                $failed++;
                continue;
            }

            // Skip if an active voucher already exists
            $existing = $this->getVouchersForOrder($orderId);
            $hasActive = false;
            foreach ($existing as $v) {
                $st = $v['state'] ?? '';
                if ($st === VoucherState::Created->value || $st === VoucherState::Reserved->value) {
                    $hasActive = true;
                    break;
                }
            }

            if ($hasActive) {
                $skipped++;
                continue;
            }

            $courier = $this->detectCourierFromShipping($order);
            if ($courier === null) {
                $skipped++;
                continue;
            }

            // Bulk never sends a confirmation: RISKY (free) and not-allowed (strict) orders are skipped and listed.
            if (VoucherStatusRule::refusal($order, $courier) !== null) {
                $ruleSkipped[] = $orderId . ':' . $order->get_status();
                continue;
            }

            try {
                $this->createVoucherForOrder($order, $courier);
                $issued++;
                if (VoucherStatusRule::mode() === VoucherStatusRule::FREE && VoucherStatusRule::isUnpaid($order)) {
                    $warned[] = $orderId . ':' . $order->get_status();
                }
            } catch (Throwable $e) {
                $this->logger->error(sprintf('Bulk issue failed for order #%d: %s', $orderId, $e->getMessage()));
                $failed++;
            }
        }

        if (function_exists('add_query_arg')) {
            return add_query_arg([
                'grcs_bulk_issued' => $issued,
                'grcs_bulk_skipped' => $skipped,
                'grcs_bulk_failed' => $failed,
                'grcs_bulk_rule_skipped' => $ruleSkipped === [] ? null : implode(',', $ruleSkipped),
                'grcs_bulk_warned' => $warned === [] ? null : implode(',', $warned),
            ], $redirectUrl);
        }

        return $redirectUrl;
    }

    /**
     * Executes bulk merged PDF voucher printing for selected orders.
     *
     * @param list<int> $orderIds
     */
    private function executeBulkPrint(string $redirectUrl, array $orderIds): string
    {
        $tokens = [];
        $orderIds = array_values(array_unique($orderIds));
        sort($orderIds, SORT_NUMERIC);
        try {
            foreach ($orderIds as $orderId) {
                $tokens[$orderId] = \GRCommerceSuite\Services\VoucherOperationLock::acquire($orderId);
            }
            $result = $this->prepareBulkPrint($redirectUrl, $orderIds);
        } catch (Throwable $error) {
            $this->logger->error('Bulk PDF print failed: ' . $error->getMessage());
            return add_query_arg(['grcs_bulk_print_failed' => 1], $redirectUrl);
        } finally {
            foreach ($tokens as $orderId => $token) {
                \GRCommerceSuite\Services\VoucherOperationLock::release($orderId, $token);
            }
        }
        if (is_string($result)) {
            return $result;
        }
        if (function_exists('nocache_headers')) {
            nocache_headers();
        }
        header('Content-Type: application/pdf');
        header('Content-Disposition: inline; filename="grcs-vouchers-merged-' . gmdate('YmdHis') . '.pdf"');
        header('Content-Length: ' . (string) strlen($result['pdf']));
        echo $result['pdf']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Validated binary PDF response.
        exit;
    }

    /** @param list<int> $orderIds
     * @return string|array{pdf: string} Redirect URL or generated document; caller holds order locks.
     */
    private function prepareBulkPrint(string $redirectUrl, array $orderIds): string|array
    {
        /** @var array<string, non-empty-list<non-empty-string>> $vouchersByCourier */
        $vouchersByCourier = [];

        foreach ($orderIds as $orderId) {
            $rows = $this->getVouchersForOrder($orderId);
            $order = wc_get_order($orderId);
            foreach ($rows as $row) {
                if (
                    ($row['state'] ?? '') === VoucherState::Created->value
                    && is_string($row['voucher_no'] ?? null) && $row['voucher_no'] !== ''
                    // A cancellation may already have reached the courier: never merge that label.
                    && !($order instanceof WC_Order && VoucherCancellationMarker::isPending($order, (int) ($row['id'] ?? 0)))
                ) {
                    $courier = (string) ($row['courier_slug'] ?? 'acs');
                    $numbers = ShippingOptions::voucherNumbers($row);
                    if ($order instanceof WC_Order) {
                        \GRCommerceSuite\Pdf\VoucherLabelGenerator::rememberOrder($order, $numbers);
                    }
                    foreach ($numbers as $number) {
                        $vouchersByCourier[$courier][] = $number;
                    }
                }
            }
        }

        if ($vouchersByCourier === []) {
            return function_exists('add_query_arg')
                ? add_query_arg(['grcs_bulk_print_empty' => 1], $redirectUrl)
                : $redirectUrl;
        }

        $pdfDocuments = [];
        $printedGroups = [];

        foreach ($vouchersByCourier as $courierSlugVal => $vouchers) {
            $slug = CourierSlug::tryFrom($courierSlugVal) ?? CourierSlug::Acs;
            try {
                $provider = $this->courierRegistry !== null ? $this->courierRegistry->get($slug) : null;
                if ($provider !== null) {
                    $pdf = $provider->printVoucherPdf($vouchers, 'thermal');
                    if ($pdf !== '') {
                        $pdfDocuments[] = $pdf;
                        $printedGroups[$courierSlugVal] = $vouchers;
                    }
                }
            } catch (Throwable $e) {
                $err = sprintf('Bulk PDF print failed for courier %s: %s', $courierSlugVal, $e->getMessage());
                $this->logger->error($err);
            }
        }

        if ($pdfDocuments === []) {
            return function_exists('add_query_arg')
                ? add_query_arg(['grcs_bulk_print_failed' => 1], $redirectUrl)
                : $redirectUrl;
        }

        try {
            $merger = $this->pdfMerger ?? new PdfMerger();
            $finalPdf = count($pdfDocuments) === 1 ? $pdfDocuments[0] : $merger->merge($pdfDocuments);
        } catch (Throwable $e) {
            $this->logger->error('Bulk PDF merge failed: ' . $e->getMessage());
            return add_query_arg(['grcs_bulk_print_failed' => 1], $redirectUrl);
        }
        if ($this->voucherRepository !== null) {
            foreach ($printedGroups as $slugValue => $vouchers) {
                $this->voucherRepository->markPrinted($vouchers, CourierSlug::from($slugValue));
            }
        }

        return ['pdf' => $finalPdf];
    }

    /**
     * Executes bulk Daily Pickup List generation (Κλείσιμο Ημέρας / Manifest).
     *
     * @param list<int> $orderIds
     */
    private function executeBulkDailyPickup(string $redirectUrl, array $orderIds): string
    {
        /** @var array<string, list<string>> $vouchersByCourier */
        $vouchersByCourier = [];
        $affectedOrders = [];

        foreach ($orderIds as $orderId) {
            $rows = $this->getVouchersForOrder($orderId);
            foreach ($rows as $row) {
                if (($row['state'] ?? '') === VoucherState::Created->value && !empty($row['voucher_no'])) {
                    $courier = (string) ($row['courier_slug'] ?? 'acs');
                    $vouchersByCourier[$courier][] = (string) $row['voucher_no'];
                    $affectedOrders[$orderId] = true;
                }
            }
        }

        $pickupListNumbers = [];
        $totalCount = 0;

        foreach ($vouchersByCourier as $courierSlugVal => $vouchers) {
            $slug = CourierSlug::tryFrom($courierSlugVal) ?? CourierSlug::Acs;
            $totalCount += count($vouchers);

            $hasAcs = $slug === CourierSlug::Acs
                && $this->courierRegistry !== null
                && $this->courierRegistry->has(CourierSlug::Acs);

            if ($hasAcs) {
                $provider = $this->courierRegistry->get(CourierSlug::Acs);
                if ($provider instanceof AcsProvider || method_exists($provider, 'issuePickupList')) {
                    try {
                        $manifest = $provider->issuePickupList(gmdate('Y-m-d'), $vouchers);
                        $manifestNo = $manifest['pickup_list_no'] ?: 'ACS-' . gmdate('Ymd-Hi');
                        $pickupListNumbers[] = $manifestNo;

                        foreach (array_keys($affectedOrders) as $ordId) {
                            $orderObj = function_exists('wc_get_order') ? wc_get_order($ordId) : null;
                            if ($orderObj instanceof WC_Order) {
                                $orderObj->add_order_note(sprintf(
                                    AdminLocale::__('GR Commerce Suite: Included in Daily Pickup List (Κλείσιμο Ημέρας) #%s.', 'gr-commerce-suite'),
                                    $manifestNo
                                ));
                                $orderObj->save();
                            }
                        }
                    } catch (Throwable $e) {
                        $this->logger->error('ACS Daily Pickup List failed: ' . $e->getMessage());
                    }
                }
            } else {
                // Local pickup summary only. Geniki carrier closing is a separate explicit merchant operation.
                $refNo = strtoupper($courierSlugVal) . '-PICKUP-' . gmdate('Ymd');
                $pickupListNumbers[] = $refNo;

                foreach (array_keys($affectedOrders) as $ordId) {
                    $orderObj = function_exists('wc_get_order') ? wc_get_order($ordId) : null;
                    if ($orderObj instanceof WC_Order) {
                        $orderObj->add_order_note(sprintf(
                            $slug === CourierSlug::Geniki
                                ? AdminLocale::__('GR Commerce Suite: Recorded in local pickup list #%s. Geniki jobs were not finalized; review account-wide finalization separately.', 'gr-commerce-suite')
                                : AdminLocale::__('GR Commerce Suite: Manifested in Daily Pickup List (Κλείσιμο Ημέρας) #%s.', 'gr-commerce-suite'),
                            $refNo
                        ));
                        $orderObj->save();
                    }
                }
            }
        }

        $pickupStr = implode(', ', $pickupListNumbers);

        if (function_exists('add_query_arg')) {
            return add_query_arg([
                'grcs_pickup_issued' => 1,
                'grcs_pickup_no' => $pickupStr,
                'grcs_pickup_count' => $totalCount,
            ], $redirectUrl);
        }

        return $redirectUrl;
    }

    public static function licenceCreateOffMessage(): string
    {
        return AdminLocale::__('GR Commerce Suite: the licence is not active, so new courier vouchers cannot be issued. Existing vouchers can still be viewed, printed and cancelled. Renew or enter the licence key in GR Commerce settings to issue new vouchers.', 'gr-commerce-suite');
    }

    /** Order screens only: explain why "Issue Voucher" is missing while the licence is inactive. */
    public function renderLicenceCreateNotice(): void
    {
        if (LicenseManager::isLicensed() || !current_user_can('manage_woocommerce')) {
            return;
        }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        $hposScreen = function_exists('wc_get_page_screen_id') ? wc_get_page_screen_id('shop-order') : 'woocommerce_page_wc-orders';
        if ($screen === null || !in_array($screen->id, [$hposScreen, 'woocommerce_page_wc-orders', 'shop_order', 'edit-shop_order'], true)) {
            return;
        }
        echo '<div class="notice notice-warning grcs-licence-create-off"><p>' . esc_html(self::licenceCreateOffMessage())
            . ' <a href="' . esc_url(admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite')) . '">'
            . AdminLocale::esc_html__('Licence settings', 'gr-commerce-suite') . '</a></p></div>';
    }

    /**
     * Renders admin notices for completed bulk actions.
     */
    public function renderBulkActionNotices(): void
    {
        if (isset($_GET['grcs_bulk_license_required'])) {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html(self::licenceCreateOffMessage()) . '</p></div>';
        }
        if (isset($_GET['grcs_bulk_print_failed'])) {
            echo '<div class="notice notice-error is-dismissible"><p>'
                . AdminLocale::esc_html__('Courier labels could not be printed. Check Diagnostics & Logs and try again.', 'gr-commerce-suite') . '</p></div>';
        }
        if (isset($_GET['grcs_bulk_issued'])) {
            $issued = absint($_GET['grcs_bulk_issued']);
            $skipped = absint($_GET['grcs_bulk_skipped'] ?? 0);
            $failed = absint($_GET['grcs_bulk_failed'] ?? 0);

            $msgTpl = AdminLocale::__(
                'Bulk Voucher Creation: %d issued, %d skipped (already existing), %d failed.',
                'gr-commerce-suite'
            );

            printf(
                '<div class="notice notice-success is-dismissible"><p><strong>' . AdminLocale::esc_html__('%s', 'gr-commerce-suite') . '</strong> ' . AdminLocale::esc_html__('%s', 'gr-commerce-suite') . '</p></div>',
                AdminLocale::esc_html__('GR Commerce Suite:', 'gr-commerce-suite'),
                esc_html(sprintf($msgTpl, $issued, $skipped, $failed))
            );
            $ruleSkippedArg = $_GET['grcs_bulk_rule_skipped'] ?? '';
            $ruleSkipped = is_string($ruleSkippedArg) ? self::formatBulkOrderList($ruleSkippedArg) : '';
            if ($ruleSkipped !== '') {
                echo '<div class="notice notice-warning is-dismissible"><p>'
                    . esc_html(sprintf(AdminLocale::__('Skipped because of the voucher status rule: %s', 'gr-commerce-suite'), $ruleSkipped)) . '</p></div>';
            }
            $warnedArg = $_GET['grcs_bulk_warned'] ?? '';
            $warned = is_string($warnedArg) ? self::formatBulkOrderList($warnedArg) : '';
            if ($warned !== '') {
                echo '<div class="notice notice-warning is-dismissible"><p>'
                    . esc_html(sprintf(AdminLocale::__('Voucher created for unpaid orders (check payment): %s', 'gr-commerce-suite'), $warned)) . '</p></div>';
            }
        }

        if (isset($_GET['grcs_pickup_issued'])) {
            $pickupNo = sanitize_text_field((string) ($_GET['grcs_pickup_no'] ?? ''));
            $count = absint($_GET['grcs_pickup_count'] ?? 0);

            $pickupTpl = AdminLocale::__(
                'Daily Pickup List (Κλείσιμο Ημέρας) #%s successfully issued for %d parcels.',
                'gr-commerce-suite'
            );

            printf(
                '<div class="notice notice-success is-dismissible"><p><strong>' . AdminLocale::esc_html__('%s', 'gr-commerce-suite') . '</strong> ' . AdminLocale::esc_html__('%s', 'gr-commerce-suite') . '</p></div>',
                AdminLocale::esc_html__('GR Commerce Suite:', 'gr-commerce-suite'),
                esc_html(sprintf($pickupTpl, $pickupNo, $count))
            );
        }

        if (isset($_GET['grcs_bulk_print_empty'])) {
            printf(
                '<div class="notice notice-warning is-dismissible"><p><strong>' . AdminLocale::esc_html__('%s', 'gr-commerce-suite') . '</strong> ' . AdminLocale::esc_html__('%s', 'gr-commerce-suite') . '</p></div>',
                AdminLocale::esc_html__('GR Commerce Suite:', 'gr-commerce-suite'),
                AdminLocale::esc_html__('No active courier vouchers found on the selected orders to print.', 'gr-commerce-suite')
            );
        }
    }

    /** "12:cancelled,15:pending" -> "#12 Cancelled, #15 Pending Payment"; malformed entries are dropped. */
    private static function formatBulkOrderList(string $raw): string
    {
        $parts = [];
        foreach (explode(',', $raw) as $entry) {
            if (!preg_match('/^(\d+):([a-z0-9-]+)$/D', trim($entry), $m)) {
                continue;
            }
            $name = function_exists('wc_get_order_status_name') ? wc_get_order_status_name($m[2]) : $m[2];
            $parts[] = '#' . $m[1] . ' ' . $name;
        }

        return implode(', ', $parts);
    }

    /**
     * Builds a secure print URL for a given voucher and courier.
     */
    public function buildPrintUrl(string $voucherNo, string $courier, string $format = 'thermal'): string
    {
        $nonce = function_exists('wp_create_nonce') ? wp_create_nonce(self::NONCE_ACTION_PRINT) : '';
        $base = function_exists('admin_url') ? admin_url('admin-post.php') : '';

        if (function_exists('add_query_arg')) {
            return add_query_arg([
                'action' => 'grcs_print',
                'voucher_no' => $voucherNo,
                'courier' => $courier,
                'format' => $format,
                '_wpnonce' => $nonce,
            ], $base);
        }

        return sprintf(
            '%s?action=grcs_print&voucher_no=%s&courier=%s&format=%s&_wpnonce=%s',
            $base,
            $voucherNo,
            $courier,
            $format,
            $nonce
        );
    }

    /**
     * Builds public tracking URL for a given courier voucher.
     */
    public function buildTrackingUrl(string $voucherNo, CourierSlug $courier): string
    {
        return \GRCommerceSuite\Services\TrackingService::publicUrl($voucherNo, $courier);
    }

    /**
     * Identify only supported shipping IDs or explicit legacy mappings.
     */
    public function detectCourierFromShipping(WC_Order $order): ?CourierSlug
    {
        return CourierSelection::fromOrder($order);
    }

    /**
     * Checks if order payment method represents Cash on Delivery (Αντικαταβολή).
     */
    public function isCodPaymentMethod(WC_Order $order): bool
    {
        $method = strtolower((string) $order->get_payment_method());
        if ($method === 'cod') {
            return true;
        }

        $title = mb_strtolower((string) $order->get_payment_method_title(), 'UTF-8');
        return str_contains($title, 'αντικαταβολ') || str_contains($title, 'cash on delivery');
    }

    /**
     * Normalizes a post ID, post object, or WC_Order into a WC_Order instance.
     */
    private function resolveOrder(mixed $postOrOrder): ?WC_Order
    {
        if ($postOrOrder instanceof WC_Order) {
            return $postOrOrder;
        }

        if (function_exists('wc_get_order')) {
            $order = wc_get_order($postOrOrder);
            if ($order instanceof WC_Order) {
                return $order;
            }
        }

        return null;
    }

    private function canManageVouchers(): bool
    {
        if (!function_exists('current_user_can')) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('grcs_manage_vouchers');
    }

    /**
     * @param array<string, mixed> $data
     */
    private function sendJsonSuccess(array $data): void
    {
        if (function_exists('wp_send_json_success')) {
            wp_send_json_success($data);
        } else {
            echo json_encode(['success' => true, 'data' => $data]);
            exit;
        }
    }

    private function sendJsonError(string $message, int $statusCode = 400): void
    {
        if (function_exists('wp_send_json_error')) {
            wp_send_json_error(['message' => $message], $statusCode);
        } else {
            http_response_code($statusCode);
            echo json_encode(['success' => false, 'data' => ['message' => $message]]);
            exit;
        }
    }
}
