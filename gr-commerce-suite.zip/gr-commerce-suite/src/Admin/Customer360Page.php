<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Frontend\BankTransferAccounts;
use GRCommerceSuite\Services\CodRefundStatus;
use GRCommerceSuite\Services\CustomerOrderLookup;
use GRCommerceSuite\Services\CustomerPurchaseEvidence;
use GRCommerceSuite\Services\ShippingOptions;
use GRCommerceSuite\Services\TrackingService;
use GRCommerceSuite\Support\Money;
use InvalidArgumentException;
use Throwable;
use WC_Order;
use WC_Order_Item_Product;

/**
 * Private admin presentation. All submissions read existing records; no public endpoints.
 *
 * @phpstan-type LookupState array{mode: string, term: string, match_page: int, anchor: int, scope: string, history_page: int, warranty_order: int, item: int}
 */
final class Customer360Page implements HookSubscriberInterface
{
    public const MENU_SLUG = 'grcs-customer-360';
    public const SCREEN_ID = 'woocommerce_page_grcs-customer-360';
    public const CAPABILITY = 'manage_woocommerce';
    public const NONCE_ACTION = 'grcs_customer360_lookup';
    public const NONCE_FIELD = '_grcs_customer360_nonce';

    public function __construct(
        private readonly CustomerOrderLookup $lookup = new CustomerOrderLookup(),
        private readonly CustomerPurchaseEvidence $evidence = new CustomerPurchaseEvidence(),
        private readonly ?VoucherRepository $vouchers = null,
    ) {
    }

    public function register(): void
    {
        add_action('admin_menu', [$this, 'registerSubmenuPage'], 60);
        add_action('load-' . self::SCREEN_ID, [$this, 'protectResponse']);
    }

    public function registerSubmenuPage(): void
    {
        if (!current_user_can(self::CAPABILITY) || !current_user_can('edit_shop_orders')) {
            return;
        }
        add_submenu_page(
            'woocommerce',
            AdminLocale::__('Customer 360° / Καρτέλα Πελάτη', 'gr-commerce-suite'),
            AdminLocale::__('Customer 360°', 'gr-commerce-suite'),
            self::CAPABILITY,
            self::MENU_SLUG,
            [$this, 'renderPage']
        );
    }

    public function protectResponse(): void
    {
        nocache_headers();
        header('Referrer-Policy: same-origin');
    }

    /** Only an order ID enters the URL; personal search terms remain in POST forms. */
    public static function orderHistoryUrl(int $orderId): string
    {
        return add_query_arg([
            'page' => self::MENU_SLUG,
            'order_id' => $orderId,
            self::NONCE_FIELD => wp_create_nonce(self::NONCE_ACTION),
        ], admin_url('admin.php'));
    }

    public function renderPage(): void
    {
        if (!current_user_can(self::CAPABILITY) || !current_user_can('edit_shop_orders')) {
            wp_die(AdminLocale::esc_html__('Permission denied.', 'gr-commerce-suite'), '', ['response' => 403]);
        }
        echo '<div class="wrap grcs-ui grcs-admin-wrap grcs-customer360">';
        AdminWorkspace::header(AdminLocale::__('Customer 360° / Καρτέλα Πελάτη', 'gr-commerce-suite'));
        AdminWorkspace::navigation('customers');
        echo '<p class="grcs-page-subtitle">'
            . AdminLocale::esc_html__('Read-only purchase lookup for warranty, invoice, shipping and return inquiries.', 'gr-commerce-suite') . '</p>';

        $state = $this->state();
        if ($state['mode'] === 'auto' && trim($state['term']) !== '') {
            // Resolve once, so the form, results and pagination all show the type actually searched.
            $state['mode'] = self::detectMode($state['term']);
        }
        $fromOrder = $_POST === [] && isset($_GET['order_id']);
        if ($fromOrder) {
            $id = $_GET['order_id'];
            $state['anchor'] = is_string($id) && ctype_digit($id) ? (int) $id : 0;
            $state['scope'] = 'order';
        }
        $this->searchForm($state);
        if ($_POST === [] && !$fromOrder) {
            echo '</div>';
            return;
        }
        $nonce = $fromOrder ? ($_GET[self::NONCE_FIELD] ?? '') : $this->text(self::NONCE_FIELD);
        if (!is_string($nonce) || !wp_verify_nonce($nonce, self::NONCE_ACTION)) {
            $this->notice(AdminLocale::__('Security check failed. Submit the search again.', 'gr-commerce-suite'));
            echo '</div>';
            return;
        }
        if ($fromOrder && $state['anchor'] <= 0) {
            $this->notice(AdminLocale::__('Order unavailable or you do not have permission to view it.', 'gr-commerce-suite'));
            echo '</div>';
            return;
        }
        try {
            if ($state['anchor'] > 0) {
                $anchor = $this->readableOrder($state['anchor']);
                if ($anchor === null) {
                    $this->notice(AdminLocale::__('Order unavailable or you do not have permission to view it.', 'gr-commerce-suite'));
                } else {
                    $this->customer($anchor, $state);
                }
            } else {
                $this->matches($state);
            }
        } catch (InvalidArgumentException $error) {
            $this->notice(AdminLocale::error($error->getMessage()));
        } catch (Throwable) {
            // Do not leak database errors or customer identifiers into notices or logs.
            $this->notice(AdminLocale::__('The purchase lookup is temporarily unavailable. Please try again.', 'gr-commerce-suite'));
        }
        echo '</div>';
    }

    /** @return LookupState */
    private function state(): array
    {
        return [
            'mode' => in_array($this->text('mode'), ['auto', 'order', 'name', 'email', 'phone'], true) ? $this->text('mode') : 'auto',
            'term' => $this->text('term'),
            'match_page' => max(1, $this->integer('match_page')),
            'anchor' => $this->integer('anchor'),
            'scope' => in_array($this->text('scope'), ['account', 'email', 'order'], true) ? $this->text('scope') : '',
            'history_page' => max(1, $this->integer('history_page')),
            'warranty_order' => $this->integer('warranty_order'),
            'item' => $this->integer('item'),
        ];
    }

    private function text(string $key): string
    {
        $raw = $_POST[$key] ?? '';
        return is_string($raw) ? sanitize_text_field(wp_unslash($raw)) : '';
    }

    private function integer(string $key): int
    {
        $value = $this->text($key);
        return ctype_digit($value) ? min((int) $value, PHP_INT_MAX) : 0;
    }

    /**
     * Support agents usually have one clue: an email, a phone, an order number or a name.
     * Only the pattern is inspected; the explicit types remain available for ambiguous input.
     *
     * @return 'order'|'name'|'email'|'phone'
     */
    public static function detectMode(string $term): string
    {
        $term = trim($term);
        if (str_contains($term, '@')) {
            return 'email';
        }
        $compact = preg_replace('/[\s().\-]+/u', '', $term) ?? $term;
        if (preg_match('/^#?\d{1,9}$/D', $compact) === 1) {
            return 'order';
        }
        if (preg_match('/^\+?\d{10,15}$/D', $compact) === 1) {
            return 'phone';
        }
        return 'name';
    }

    /** @param LookupState $state */
    private function searchForm(array $state): void
    {
        $this->formStart();
        echo '<section class="grcs-card"><h2 class="grcs-card__title">' . AdminLocale::esc_html__('Find a purchase / Αναζήτηση', 'gr-commerce-suite')
            . '</h2><div class="grcs-customer360-search"><label for="grcs-c360-mode">' . AdminLocale::esc_html__('Search by', 'gr-commerce-suite')
            . '</label><select id="grcs-c360-mode" name="mode">';
        foreach ([
            'auto' => AdminLocale::__('Automatic (detect from what you type)', 'gr-commerce-suite'),
            'order' => AdminLocale::__('Order number / ID', 'gr-commerce-suite'),
            'name' => AdminLocale::__('Customer name', 'gr-commerce-suite'),
            'email' => AdminLocale::__('Billing email', 'gr-commerce-suite'),
            'phone' => AdminLocale::__('Billing phone', 'gr-commerce-suite'),
        ] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($state['mode'], $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select><label class="screen-reader-text" for="grcs-c360-term">' . AdminLocale::esc_html__('Search value', 'gr-commerce-suite')
            . '</label><input id="grcs-c360-term" name="term" type="search" maxlength="160" required value="' . esc_attr($state['term'])
            . '" autocomplete="off"><button class="button button-primary" type="submit">' . AdminLocale::esc_html__('Search', 'gr-commerce-suite')
            . '</button></div><p class="grcs-muted">'
            . AdminLocale::esc_html__('Email matches are exact. Names and shared phone numbers may return several possible customers; confirm the purchase details.', 'gr-commerce-suite')
            . '</p></section></form>';
    }

    /** @param LookupState $state */
    private function matches(array $state): void
    {
        $result = $this->lookup->search($state['mode'], $state['term'], $state['match_page']);
        // An order number that matches exactly one purchase needs no "choose a match" step.
        $single = $result['orders'][0] ?? null;
        if ($state['mode'] === 'order' && $result['total'] === 1 && $single instanceof WC_Order && $this->canRead($single)) {
            $state['anchor'] = $single->get_id();
            $this->customer($single, $state, false);
            return;
        }
        if ($result['total'] === 0) {
            echo '<section class="grcs-card grcs-empty-state"><h2 class="grcs-card__title">' . AdminLocale::esc_html__('No matching purchases', 'gr-commerce-suite') . '</h2><p>'
                . AdminLocale::esc_html__('Check the spelling, or search with another detail the customer can give you: billing email, phone or order number. Email searches need the complete address.', 'gr-commerce-suite')
                . '</p></section>';
            return;
        }
        echo '<section class="grcs-card"><h2 class="grcs-card__title">' . AdminLocale::esc_html__('Possible matches / Πιθανές αντιστοιχίες', 'gr-commerce-suite')
            . '</h2><p>' . esc_html(sprintf(AdminLocale::__('Matching orders: %d. Choose a purchase to inspect its customer history.', 'gr-commerce-suite'), $result['total'])) . '</p>';
        if ($result['orders'] === []) {
            echo '<p>' . AdminLocale::esc_html__('No matching orders on this page.', 'gr-commerce-suite') . '</p>';
        } else {
            echo '<div class="grcs-table-wrap"><table class="widefat grcs-table"><thead><tr>';
            foreach ([AdminLocale::__('Customer / billing contact', 'gr-commerce-suite'), AdminLocale::__('Order', 'gr-commerce-suite'),
                AdminLocale::__('Purchase date', 'gr-commerce-suite'), AdminLocale::__('History', 'gr-commerce-suite')] as $label) {
                echo '<th scope="col">' . esc_html($label) . '</th>';
            }
            echo '</tr></thead><tbody>';
            foreach ($result['orders'] as $order) {
                if (!$this->canRead($order)) {
                    continue;
                }
                echo '<tr><td><strong>' . esc_html($order->get_formatted_billing_full_name() ?: AdminLocale::__('Unnamed customer', 'gr-commerce-suite'))
                    . '</strong><br>' . esc_html($order->get_billing_email()) . '<br>' . esc_html($order->get_billing_phone())
                    . '<br><span class="grcs-muted">' . esc_html($order->get_billing_postcode() . ' ' . $order->get_billing_city())
                    . '</span><br>' . esc_html($order->get_customer_id() > 0
                        ? sprintf(AdminLocale::__('Account #%d', 'gr-commerce-suite'), $order->get_customer_id()) : AdminLocale::__('Guest purchase', 'gr-commerce-suite')) . '</td><td>';
                $this->orderLink($order);
                // The total lets staff tell apart orders from one shared phone ("the 31 € one") before opening any.
                $total = function_exists('wc_price') ? html_entity_decode(wp_strip_all_tags(wc_price((float) $order->get_total(), ['currency' => $order->get_currency()])), ENT_QUOTES, 'UTF-8') : '';
                echo '<br>' . esc_html(AdminLocale::orderStatus($order->get_status()) . ($total !== '' ? ' · ' . $total : '')) . '</td><td>'
                    . esc_html($this->date($order->get_date_created())) . '</td><td>';
                $this->button(AdminLocale::__('View customer', 'gr-commerce-suite'), $state, ['anchor' => $order->get_id(), 'scope' => '', 'history_page' => 1]);
                echo '</td></tr>';
            }
            echo '</tbody></table></div>';
        }
        $this->pagination($state, 'match_page', $result['pages']);
        echo '</section>';
    }

    /** @param LookupState $state */
    private function customer(WC_Order $anchor, array $state, bool $backToMatches = true): void
    {
        $state['scope'] = $state['scope'] ?: ($anchor->get_customer_id() > 0 ? 'account' : (is_email($anchor->get_billing_email()) ? 'email' : 'order'));
        echo '<section class="grcs-card"><div class="grcs-card__header"><h2 class="grcs-card__title">'
            . esc_html($anchor->get_formatted_billing_full_name() ?: AdminLocale::__('Unnamed customer', 'gr-commerce-suite')) . '</h2>';
        if ($backToMatches) {
            $this->button(AdminLocale::__('Back to matches', 'gr-commerce-suite'), $state, ['anchor' => 0, 'warranty_order' => 0, 'item' => 0]);
        }
        echo '</div><dl class="grcs-customer360-facts">';
        $this->fact(AdminLocale::__('Billing email', 'gr-commerce-suite'), $anchor->get_billing_email());
        $this->fact(AdminLocale::__('Billing phone', 'gr-commerce-suite'), $anchor->get_billing_phone());
        $this->fact(AdminLocale::__('Customer account', 'gr-commerce-suite'), $anchor->get_customer_id() > 0 ? '#' . $anchor->get_customer_id() : AdminLocale::__('Guest', 'gr-commerce-suite'));
        $this->fact(AdminLocale::__('Details from order', 'gr-commerce-suite'), '#' . $anchor->get_order_number());
        echo '</dl>';
        $this->formStart();
        $this->hidden($state, ['scope' => null, 'history_page' => 1, 'warranty_order' => 0, 'item' => 0]);
        echo '<label for="grcs-c360-scope">' . AdminLocale::esc_html__('Show order history by', 'gr-commerce-suite') . '</label> '
            . '<select id="grcs-c360-scope" name="scope">';
        $scopes = ['order' => AdminLocale::__('This purchase only', 'gr-commerce-suite')];
        if ($anchor->get_customer_id() > 0) {
            $scopes['account'] = AdminLocale::__('Same customer account', 'gr-commerce-suite');
        }
        if (is_email($anchor->get_billing_email())) {
            $scopes['email'] = AdminLocale::__('Exact billing email', 'gr-commerce-suite');
        }
        foreach ($scopes as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($state['scope'], $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select> <button class="button" type="submit">' . AdminLocale::esc_html__('Show history', 'gr-commerce-suite') . '</button></form>'
            . '<p class="grcs-muted">' . AdminLocale::esc_html__('Shared emails can belong to different people. This history groups existing order records; it does not verify identity. Contact details above come from the selected purchase.', 'gr-commerce-suite') . '</p></section>';

        $result = $this->lookup->history($anchor, $state['scope'], $state['history_page']);
        if ($state['warranty_order'] > 0 || $state['item'] > 0) {
            $order = $this->readableOrder($state['warranty_order']);
            // Recheck membership server-side. Item IDs from another order must never be accepted.
            if ($order !== null && $this->inScope($order, $anchor, $state['scope'])) {
                $item = $order->get_item($state['item']);
                if ($item instanceof WC_Order_Item_Product && $item->get_order_id() === $order->get_id()) {
                    $this->warranty($order, $item);
                } else {
                    $this->notice(AdminLocale::__('Purchase item unavailable.', 'gr-commerce-suite'));
                }
            } else {
                $this->notice(AdminLocale::__('Purchase evidence unavailable for this history.', 'gr-commerce-suite'));
            }
        }
        echo '<h2>' . AdminLocale::esc_html__('Order history / Ιστορικό παραγγελιών', 'gr-commerce-suite') . '</h2><p>'
            . esc_html(sprintf(AdminLocale::__('Orders in this history: %d', 'gr-commerce-suite'), $result['total'])) . '</p>';
        foreach ($result['orders'] as $order) {
            if ($this->canRead($order)) {
                $this->purchase($order, $state);
            }
        }
        if ($result['orders'] === []) {
            echo '<section class="grcs-card"><p>' . AdminLocale::esc_html__('No orders on this page.', 'gr-commerce-suite') . '</p></section>';
        }
        $this->pagination($state, 'history_page', $result['pages']);
    }

    private function inScope(WC_Order $order, WC_Order $anchor, string $scope): bool
    {
        return match ($scope) {
            'account' => $anchor->get_customer_id() > 0 && $order->get_customer_id() === $anchor->get_customer_id(),
            'email' => is_email($anchor->get_billing_email()) && strcasecmp($order->get_billing_email(), $anchor->get_billing_email()) === 0,
            default => $order->get_id() === $anchor->get_id(),
        };
    }

    /** @param LookupState $state */
    private function purchase(WC_Order $order, array $state): void
    {
        echo '<section class="grcs-card"><h3 class="grcs-card__title">';
        $this->orderLink($order);
        echo '</h3><dl class="grcs-customer360-facts">';
        $this->orderFacts($order);
        $this->fact(AdminLocale::__('Total (including tax / shipping)', 'gr-commerce-suite'), $this->money($order, $order->get_total()));
        $this->fact(AdminLocale::__('Refunded total', 'gr-commerce-suite'), $this->money($order, $order->get_total_refunded()));
        echo '</dl><div class="grcs-table-wrap"><table class="widefat grcs-table"><thead><tr>';
        foreach ([AdminLocale::__('Purchased product / variation', 'gr-commerce-suite'), AdminLocale::__('SKU', 'gr-commerce-suite'),
            AdminLocale::__('Quantity / refunded', 'gr-commerce-suite'), AdminLocale::__('Line total / refunded', 'gr-commerce-suite'),
            AdminLocale::__('Purchase evidence', 'gr-commerce-suite')] as $label) {
            echo '<th scope="col">' . esc_html($label) . '</th>';
        }
        echo '</tr></thead><tbody>';
        foreach ($order->get_items('line_item') as $item) {
            if (!$item instanceof WC_Order_Item_Product) {
                continue;
            }
            echo '<tr><td>' . esc_html($item->get_name());
            $this->variation($item);
            echo '</td><td>' . esc_html($this->evidence->sku($item) ?: '—') . '</td><td>'
                . esc_html((string) $item->get_quantity() . ' / ' . abs($order->get_qty_refunded_for_item($item->get_id()))) . '</td><td>'
                . esc_html($this->money($order, (float) $item->get_total() + (float) $item->get_total_tax()) . ' / '
                    . $this->money($order, $this->evidence->refundedTotal($order, $item))) . '</td><td>';
            $this->button(AdminLocale::__('Warranty information', 'gr-commerce-suite'), $state, ['warranty_order' => $order->get_id(), 'item' => $item->get_id()]);
            echo '</td></tr>';
        }
        echo '</tbody></table></div><details class="grcs-customer360-details"><summary>'
            . AdminLocale::esc_html__('Billing, invoice and shipping details', 'gr-commerce-suite') . '</summary><div class="grcs-two-col"><div><h4>'
            . AdminLocale::esc_html__('Billing address', 'gr-commerce-suite') . '</h4>' . wp_kses_post($order->get_formatted_billing_address() ?: '—')
            . '<dl class="grcs-customer360-facts">';
        foreach ([
            '_grcs_document_type' => AdminLocale::__('Document type', 'gr-commerce-suite'),
            '_grcs_vat_number' => AdminLocale::__('VAT number / ΑΦΜ', 'gr-commerce-suite'),
            '_grcs_company_name' => AdminLocale::__('Company', 'gr-commerce-suite'),
            '_grcs_doy' => AdminLocale::__('Tax office / ΔΟΥ', 'gr-commerce-suite'),
        ] as $key => $label) {
            $value = $order->get_meta($key, true);
            if (is_scalar($value) && (string) $value !== '') {
                $this->fact($label, $key === '_grcs_document_type'
                    ? match ((string) $value) {
                        'invoice' => AdminLocale::__('Invoice', 'gr-commerce-suite'),
                        'receipt' => AdminLocale::__('Retail Receipt', 'gr-commerce-suite'),
                        default => (string) $value,
                    }
                    : (string) $value);
            }
        }
        echo '</dl></div><div><h4>' . AdminLocale::esc_html__('Shipping address', 'gr-commerce-suite') . '</h4>'
            . wp_kses_post($order->get_formatted_shipping_address() ?: '—') . '</div></div>';
        $this->tracking($order);
        echo '</details></section>';
    }

    private function warranty(WC_Order $order, WC_Order_Item_Product $item): void
    {
        echo '<section class="grcs-card grcs-card--info" id="grcs-purchase-evidence"><h2 class="grcs-card__title">'
            . AdminLocale::esc_html__('Warranty information / Πληροφορίες εγγύησης', 'gr-commerce-suite') . '</h2><h3>' . esc_html($item->get_name()) . '</h3>';
        $this->variation($item);
        echo '<dl class="grcs-customer360-facts">';
        $this->fact(AdminLocale::__('Order number / ID', 'gr-commerce-suite'), '#' . $order->get_order_number() . ' / ' . $order->get_id());
        $this->fact(AdminLocale::__('Order item ID', 'gr-commerce-suite'), (string) $item->get_id());
        $this->fact(AdminLocale::__('Product / variation ID', 'gr-commerce-suite'), $item->get_product_id() . ' / ' . ($item->get_variation_id() ?: '—'));
        $this->fact(AdminLocale::__('SKU (saved if available, otherwise current)', 'gr-commerce-suite'), $this->evidence->sku($item) ?: '—');
        $this->orderFacts($order);
        $this->fact(AdminLocale::__('Purchased quantity', 'gr-commerce-suite'), (string) $item->get_quantity());
        $this->fact(AdminLocale::__('Refunded quantity', 'gr-commerce-suite'), (string) abs($order->get_qty_refunded_for_item($item->get_id())));
        $this->fact(AdminLocale::__('Line total including tax', 'gr-commerce-suite'), $this->money($order, (float) $item->get_total() + (float) $item->get_total_tax()));
        $this->fact(AdminLocale::__('Line refunds including tax', 'gr-commerce-suite'), $this->money($order, $this->evidence->refundedTotal($order, $item)));
        // Amount-only refunds (e.g. a full refund via status change) are not allocated to lines, so show the order total too.
        $this->fact(AdminLocale::__('Order refunded total (all lines, shipping and amount-only refunds)', 'gr-commerce-suite'), $this->money($order, $order->get_total_refunded()));
        echo '</dl>';
        $this->orderLink($order);
        $metadata = $this->evidence->warranty($item);
        foreach ($metadata as $source => $values) {
            echo '<h3>' . esc_html($source) . '</h3><dl class="grcs-customer360-facts">';
            foreach ($values as $label => $value) {
                $this->fact($label, $value);
            }
            echo '</dl>';
        }
        if ($metadata === []) {
            echo '<p>' . AdminLocale::esc_html__('No supported warranty metadata is recorded for this item or its current product.', 'gr-commerce-suite') . '</p>';
        }
        echo '<p class="grcs-muted">' . AdminLocale::esc_html__('Current catalog metadata may have changed since purchase. Missing metadata does not establish the presence or absence of warranty rights. This view provides purchase evidence only; it does not determine legal warranty entitlement or create a warranty claim.', 'gr-commerce-suite') . '</p></section>';
    }

    private function variation(WC_Order_Item_Product $item): void
    {
        // Saved, public item attributes remain available even if the catalog product was deleted.
        foreach ($item->get_formatted_meta_data('_', true) as $meta) {
            echo '<br><span class="grcs-muted">' . esc_html(wp_strip_all_tags((string) $meta->display_key) . ': '
                . wp_strip_all_tags((string) $meta->display_value)) . '</span>';
        }
    }

    private function orderFacts(WC_Order $order): void
    {
        $this->fact(AdminLocale::__('Purchase date', 'gr-commerce-suite'), $this->date($order->get_date_created()));
        $this->fact(AdminLocale::__('Order status', 'gr-commerce-suite'), AdminLocale::orderStatus($order->get_status()));
        $this->shipmentFact($order);
        $payment =$order->is_paid() ? AdminLocale::__('Paid (WooCommerce)', 'gr-commerce-suite')
            : ($order->needs_payment() ? AdminLocale::__('Awaiting payment', 'gr-commerce-suite') : AdminLocale::__('Payment not confirmed', 'gr-commerce-suite'));
        if ($order->get_payment_method() === 'cod' && !in_array($order->get_status(), ['cancelled', 'failed'], true)) {
            // WooCommerce treats a processing COD order as "paid"; the cash is only received once
            // the courier remits it, which the COD reconciliation records on the voucher. A refund is
            // explained beside that collection rather than replacing it.
            $rows = $this->voucherRows($order);
            $refund = CodRefundStatus::describe($order, $rows);
            $payment = $refund['refunded_cents'] > 0 ? $this->refundWithCodSettlement($order, $rows, $refund)
                : $this->codPaymentStateWithReturnedParcels($order, $rows);
        } elseif ($order->get_status() === 'refunded') {
            $payment = AdminLocale::__('Refunded', 'gr-commerce-suite');
        } elseif ($order->get_payment_method() === 'bacs' && in_array($order->get_status(), ['pending', 'on-hold'], true)) {
            // Same reference the order screen and the customer's instructions show.
            $payment = sprintf(AdminLocale::__('Waiting for bank transfer · reference «%s»', 'gr-commerce-suite'), BankTransferAccounts::reference($order, true));
        }
        $this->fact(AdminLocale::__('Payment status', 'gr-commerce-suite'), $payment);
        $this->fact(AdminLocale::__('Payment method', 'gr-commerce-suite'), $order->get_payment_method_title() ?: '—');
        $this->fact(AdminLocale::__('Payment date recorded', 'gr-commerce-suite'), $this->date($order->get_date_paid()));
    }

    /**
     * "Where is my order?" is the most common support question, so the active voucher's courier,
     * status and tracking link sit with the order facts; earlier vouchers stay in the details below.
     */
    private function shipmentFact(WC_Order $order): void
    {
        $unresolved = null;
        foreach ($this->voucherRows($order) as $row) {
            $courier = CourierSlug::tryFrom((string) ($row['courier_slug'] ?? ''));
            $state = (string) ($row['state'] ?? '');
            if ($state !== 'created' || $courier === null) {
                if ($unresolved === null && in_array($state, ['unknown', 'reserved'], true)) {
                    $unresolved = [$state, $courier?->label() ?? strtoupper((string) ($row['courier_slug'] ?? ''))];
                }
                continue;
            }
            try {
                $number = ShippingOptions::voucherNumbers($row)[0] ?? '';
            } catch (Throwable) {
                $number = '';
            }
            $url = $number !== '' ? TrackingService::publicUrl($number, $courier) : '';
            echo '<div><dt>' . AdminLocale::esc_html__('Shipment', 'gr-commerce-suite') . '</dt><dd>'
                . esc_html($courier->label() . ' · ' . AdminLocale::status((string) ($row['tracking_status'] ?? 'pending')) . ($number !== '' ? ' · ' . $number : ''));
            if ($url !== '') {
                echo ' <a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer">' . AdminLocale::esc_html__('Track shipment', 'gr-commerce-suite') . '</a>';
            }
            echo '</dd></div>';
            return;
        }
        if ($unresolved !== null) {
            [$uState, $uCourier] = $unresolved;
            $this->fact(
                AdminLocale::__('Shipment', 'gr-commerce-suite'),
                $uState === 'unknown'
                    ? sprintf(AdminLocale::__('%s · Unresolved voucher request (requires review before re-issuing)', 'gr-commerce-suite'), $uCourier)
                    : sprintf(AdminLocale::__('%s · Voucher request in progress (Reserved)', 'gr-commerce-suite'), $uCourier)
            );
            return;
        }
        $this->fact(AdminLocale::__('Shipment', 'gr-commerce-suite'), AdminLocale::__('No active voucher', 'gr-commerce-suite'));
    }

    /** @return list<array<string, mixed>> */
    private function voucherRows(WC_Order $order): array
    {
        try {
            return array_values($this->vouchers?->findByOrderId($order->get_id()) ?? []);
        } catch (Throwable) {
            return [];
        }
    }

    /**
     * The refund note or warning, followed by the courier's COD settlement records when they hold
     * something the refund text does not already say.
     *
     * The two are reported separately and never netted: the refund is not subtracted from any courier
     * amount, and no "still collectible" balance is derived from them. Which unsettled voucher a
     * refund relates to is a business decision, so the merchant is asked to check instead.
     *
     * @param list<array<string, mixed>> $rows
     * @param array{refunded_cents: int, note: string, warning: string} $refund
     */
    private function refundWithCodSettlement(WC_Order $order, array $rows, array $refund): string
    {
        $text = $refund['warning'] !== '' ? $refund['warning'] : $refund['note'];

        // A returned voucher with zero or unknown collection is reported separately from remittance.
        [$active, $returned] = $this->separateReturnedUncollected($rows);
        $returnedText = $this->returnedUncollectedText($returned);
        $returnedText = $returnedText !== '' ? ' ' . $returnedText : '';

        $ledger = [];
        $hasRecord = false;
        $hasUnsettled = false;
        foreach ($active as $row) {
            if (($row['state'] ?? '') !== 'created') {
                continue;
            }
            $hasCollected = isset($row['cod_collected']) && trim((string) $row['cod_collected']) !== '';
            $settled = (int) ($row['cod_reconciled'] ?? 0) === 1;
            $ledger[] = $row;
            $hasRecord = $hasRecord || $settled || $hasCollected;
            $hasUnsettled = $hasUnsettled || (!$settled && ($hasCollected || Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents() > 0));
        }
        // With no settlement or courier report yet, the refund note already covers the voucher.
        if (!$hasRecord) {
            return $text . $returnedText;
        }

        $state = $this->codPaymentState($order, $ledger);
        // Exact, fully settled collection adds nothing to "the courier collected …, which stays in the COD records".
        if ($state === AdminLocale::__('Cash on delivery — received from the courier (reconciled)', 'gr-commerce-suite')) {
            return $text . $returnedText;
        }
        $text .= ' ' . $state . (str_ends_with($state, '.') ? '' : '.');
        if ($hasUnsettled) {
            $text .= ' ' . AdminLocale::__('The refund is not deducted from these courier amounts; check any unsettled voucher against what the order now owes.', 'gr-commerce-suite');
        }
        return $text . $returnedText;
    }

    /**
     * Cash-on-delivery status that keeps returned parcels out of the "awaiting remittance" amount when the
     * recorded facts show no cash was collected, without changing {@see self::codPaymentState()}.
     *
     * @param list<array<string, mixed>> $rows
     */
    private function codPaymentStateWithReturnedParcels(WC_Order $order, array $rows): string
    {
        [$active, $returned] = $this->separateReturnedUncollected($rows);
        $returnedText = $this->returnedUncollectedText($returned);
        if ($returnedText === '') {
            return $this->codPaymentState($order, $rows);
        }
        // Nothing but returned parcels left: there is no settlement state to report next to them.
        $hasCodFacts = false;
        foreach ($active as $row) {
            $hasCodFacts = $hasCodFacts || (($row['state'] ?? '') === 'created' && (
                Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents() > 0
                || (isset($row['cod_collected']) && trim((string) $row['cod_collected']) !== '')
                || (int) ($row['cod_reconciled'] ?? 0) === 1
            ));
        }
        if (!$hasCodFacts) {
            return sprintf(AdminLocale::__('Cash on delivery — %s', 'gr-commerce-suite'), $returnedText);
        }
        $state = $this->codPaymentState($order, $active);
        return $state . (str_ends_with($state, '.') ? ' ' : '. ') . $returnedText;
    }

    /**
     * Splits out created vouchers on a returning/returned parcel that are not settled and have no cash recorded:
     * either the courier recorded exactly €0.00 ('zero') or recorded nothing ('unreported'). Neither is money the
     * courier still owes: a recorded zero is not a collection, an absent value is not a zero, and neither is
     * converted into the other. A returned voucher with any positive recorded amount, or one that is already
     * settled (even at €0.00, an accepted settlement), stays in the ordinary ledger untouched: a return never
     * erases cash the courier reported or settled.
     *
     * @param list<array<string, mixed>> $rows
     * @return array{0: list<array<string, mixed>>, 1: array{zero: int, zeroExpected: int, unreported: int, unreportedExpected: int}}
     *         The remaining rows, and the cents of the separated returned vouchers (the only ones counted here).
     */
    private function separateReturnedUncollected(array $rows): array
    {
        $returned = ['zero' => 0, 'zeroExpected' => 0, 'unreported' => 0, 'unreportedExpected' => 0];
        $active = [];
        foreach ($rows as $row) {
            if (($row['state'] ?? '') !== 'created'
                || (int) ($row['cod_reconciled'] ?? 0) === 1
                || !in_array($row['tracking_status'] ?? '', ['returning', 'returned'], true)) {
                $active[] = $row;
                continue;
            }
            $expected = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents();
            $hasCollected = isset($row['cod_collected']) && trim((string) $row['cod_collected']) !== '';
            if (!$hasCollected && $expected > 0) {
                $returned['unreported']++;
                $returned['unreportedExpected'] += $expected;
            } elseif ($hasCollected && Money::fromDecimalString((string) $row['cod_collected'])->cents() === 0) {
                $returned['zero']++;
                $returned['zeroExpected'] += $expected;
            } else {
                $active[] = $row;
            }
        }
        return [$active, $returned];
    }

    /**
     * @param array{zero: int, zeroExpected: int, unreported: int, unreportedExpected: int} $returned
     */
    private function returnedUncollectedText(array $returned): string
    {
        $text = [];
        if ($returned['zero'] > 0) {
            $text[] = sprintf(
                AdminLocale::__('Returned parcel(s): the courier recorded €%1$s collected of €%2$s expected, so no remittance is awaited for them (they stay open in COD Reconciliation).', 'gr-commerce-suite'),
                Money::fromCents(0)->toDecimalString(),
                Money::fromCents($returned['zeroExpected'])->toDecimalString()
            );
        }
        if ($returned['unreported'] > 0) {
            $text[] = sprintf(
                AdminLocale::__('Returned parcel(s): no courier collection is recorded (€%s expected). This is not counted as awaiting remittance and is not assumed to be zero; check COD Reconciliation.', 'gr-commerce-suite'),
                Money::fromCents($returned['unreportedExpected'])->toDecimalString()
            );
        }
        return implode(' ', $text);
    }

    /**
     * Cash-on-delivery status for the order, derived from the courier vouchers.
     *
     * Settled (reconciled) and unsettled vouchers are kept in separate buckets so the three amounts
     * add up for recorded settlements: expected = received + accepted difference + unsettled expected.
     * Reconciled rows without collection amounts are stated separately, never imputed as receipts.
     * An accepted shortfall is a settled difference, never money still awaiting remittance, and a
     * courier-reported amount on an unreconciled voucher is not received until it is reconciled.
     *
     * @param list<array<string, mixed>> $rows
     */
    private function codPaymentState(WC_Order $order, array $rows): string
    {
        // A reconciliation flag alone does not establish how much cash was received.
        $unknownSettledCount = 0;
        $unknownSettledExpected = 0;
        $settledCount = 0;
        $settledExpected = 0;
        $settledCollected = 0;
        // Unsettled: cod_reconciled = 0, whether or not the courier has reported an amount yet.
        $unsettledCount = 0;
        $unsettledExpected = 0;
        $reportedCount = 0;
        $reportedExpected = 0;
        $reportedCollected = 0;

        foreach ($rows as $row) {
            if (($row['state'] ?? '') !== 'created') {
                continue;
            }
            $rowExpected = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents();
            $hasCollected = isset($row['cod_collected']) && trim((string) $row['cod_collected']) !== '';
            $rowCollected = $hasCollected ? Money::fromDecimalString((string) $row['cod_collected'])->cents() : 0;
            $rowReconciled = (int) ($row['cod_reconciled'] ?? 0) === 1;

            if ($rowExpected <= 0 && !$hasCollected && !$rowReconciled) {
                continue;
            }

            $effectiveExpected = $rowExpected;
            if ($rowReconciled) {
                if (!$hasCollected) {
                    $unknownSettledCount++;
                    $unknownSettledExpected += $effectiveExpected;
                    continue;
                }
                $settledCount++;
                $settledExpected += $effectiveExpected;
                $settledCollected += $rowCollected;
                continue;
            }
            $unsettledCount++;
            $unsettledExpected += $effectiveExpected;
            if ($hasCollected) {
                $reportedCount++;
                $reportedExpected += $effectiveExpected;
                $reportedCollected += $rowCollected;
            }
        }

        $acceptedDifference = $settledExpected - $settledCollected;
        $append = static fn(string $text, string $clause): string => $text . (str_ends_with($text, '.') ? ' ' : '. ') . $clause;
        $money = static fn(int $cents): string => Money::fromCents(abs($cents))->toDecimalString();
        $unknownText = $unknownSettledCount > 0 ? sprintf(
            AdminLocale::__('Reconciled voucher(s) have no recorded collection (€%s expected). The received amount is unknown and is not assumed to equal the expected amount; review COD Reconciliation.', 'gr-commerce-suite'),
            $money($unknownSettledExpected)
        ) : '';
        $withUnknown = static fn(string $state): string => $unknownText !== '' ? $append($state, $unknownText) : $state;
        if ($unknownSettledCount > 0 && $settledCount === 0 && $unsettledCount === 0) {
            return $unknownText;
        }

        if ($settledCount > 0 && $unsettledCount === 0) {
            if ($acceptedDifference !== 0) {
                return $withUnknown($acceptedDifference > 0
                    ? sprintf(
                        AdminLocale::__('Cash on delivery — received €%1$s of €%2$s expected from the courier (accepted shortfall −€%3$s, reconciled)', 'gr-commerce-suite'),
                        $money($settledCollected),
                        $money($settledExpected),
                        $money($acceptedDifference)
                    )
                    : sprintf(
                        AdminLocale::__('Cash on delivery — received €%1$s of €%2$s expected from the courier (accepted difference +€%3$s, reconciled)', 'gr-commerce-suite'),
                        $money($settledCollected),
                        $money($settledExpected),
                        $money($acceptedDifference)
                    ));
            }
            return $withUnknown(AdminLocale::__('Cash on delivery — received from the courier (reconciled)', 'gr-commerce-suite'));
        }

        // Several vouchers in different settlement states: report the settled and unsettled parts separately.
        if ($unsettledCount > 0 && ($settledCount > 0 || ($reportedCount > 0 && $reportedCount < $unsettledCount))) {
            $text = $settledCount > 0
                ? sprintf(
                    AdminLocale::__('Cash on delivery — partial settlement: received €%1$s of €%2$s expected (€%3$s awaiting courier remittance)', 'gr-commerce-suite'),
                    $money($settledCollected),
                    $money($settledExpected + $unsettledExpected),
                    $money($unsettledExpected)
                )
                : sprintf(
                    AdminLocale::__('Cash on delivery — nothing settled yet: €%s awaiting courier remittance', 'gr-commerce-suite'),
                    $money($unsettledExpected)
                );
            if ($acceptedDifference !== 0) {
                $text = $append($text, sprintf(
                    $acceptedDifference > 0
                        ? AdminLocale::__('Accepted shortfall on settled vouchers: −€%s.', 'gr-commerce-suite')
                        : AdminLocale::__('Accepted difference on settled vouchers: +€%s.', 'gr-commerce-suite'),
                    $money($acceptedDifference)
                ));
            }
            if ($reportedCount > 0) {
                $text = $append($text, sprintf(
                    AdminLocale::__('The courier has reported €%1$s of €%2$s expected on unreconciled vouchers (review in COD Reconciliation).', 'gr-commerce-suite'),
                    $money($reportedCollected),
                    $money($reportedExpected)
                ));
            }
            return $withUnknown($text);
        }

        if ($reportedCount > 0) {
            $collectedEur = $money($reportedCollected);
            $expectedEur = $money($reportedExpected);
            if ($reportedCollected !== $reportedExpected) {
                $diffEur = $money($reportedCollected - $reportedExpected);
                return $withUnknown($reportedCollected < $reportedExpected
                    ? sprintf(
                        AdminLocale::__('Cash on delivery — courier reported €%1$s of €%2$s expected (unresolved shortfall −€%3$s, requires review in COD Reconciliation)', 'gr-commerce-suite'),
                        $collectedEur,
                        $expectedEur,
                        $diffEur
                    )
                    : sprintf(
                        AdminLocale::__('Cash on delivery — courier reported €%1$s of €%2$s expected (unresolved difference +€%3$s, requires review in COD Reconciliation)', 'gr-commerce-suite'),
                        $collectedEur,
                        $expectedEur,
                        $diffEur
                    ));
            }
            return $withUnknown(sprintf(
                AdminLocale::__('Cash on delivery — courier collected €%1$s of €%2$s expected (awaiting settlement reconciliation)', 'gr-commerce-suite'),
                $collectedEur,
                $expectedEur
            ));
        }

        return $withUnknown($order->get_status() === 'completed'
            ? AdminLocale::__('Cash on delivery — awaiting courier remittance', 'gr-commerce-suite')
            : AdminLocale::__('Cash on delivery — to be collected at delivery', 'gr-commerce-suite'));
    }

    private function tracking(WC_Order $order): void
    {
        echo '<h4>' . AdminLocale::esc_html__('Courier / tracking (recorded information)', 'gr-commerce-suite') . '</h4>';
        try {
            $rows = $this->vouchers?->findByOrderId($order->get_id()) ?? [];
        } catch (Throwable) {
            echo '<p class="grcs-muted">' . AdminLocale::esc_html__('Courier records are temporarily unavailable.', 'gr-commerce-suite') . '</p>';
            $rows = [];
        }
        $shown = false;
        foreach ($rows as $row) {
            $courier = CourierSlug::tryFrom((string) ($row['courier_slug'] ?? ''));
            echo '<p>' . esc_html(($courier !== null ? $courier->label() : strtoupper((string) ($row['courier_slug'] ?? ''))) . ' · '
                . AdminLocale::status((string) ($row['state'] ?? '')) . ' · ' . AdminLocale::status((string) ($row['tracking_status'] ?? ''))) . '</p>';
            try {
                $numbers = ShippingOptions::voucherNumbers($row);
            } catch (Throwable) {
                // Reserved/failed voucher records can legitimately have no tracking number yet.
                $numbers = [];
            }
            foreach ($numbers as $number) {
                $this->trackingNumber($number, $courier, ($row['state'] ?? '') !== 'cancelled');
                $shown = true;
            }
        }
        if (!$shown) {
            $number = (string) ($order->get_meta('_grcs_last_voucher_no', true) ?: $order->get_meta('_grcs_voucher_no', true));
            if ($number !== '') {
                $courier = CourierSlug::tryFrom((string) ($order->get_meta('_grcs_last_courier', true) ?: $order->get_meta('_grcs_courier', true)));
                $this->trackingNumber($number, $courier, true);
                $shown = true;
            }
        }
        $external = $order->get_meta('_wc_shipment_tracking_items', true);
        foreach (is_array($external) ? $external : [] as $entry) {
            if (is_array($entry) && is_scalar($entry['tracking_number'] ?? null)) {
                $provider = $entry['tracking_provider'] ?? $entry['custom_tracking_provider'] ?? '';
                echo '<p>' . esc_html((is_scalar($provider) ? (string) $provider : '') . ': '
                    . (string) $entry['tracking_number']) . '</p>';
                $shown = true;
            }
        }
        echo '<p>' . AdminLocale::esc_html__('Shipping method:', 'gr-commerce-suite') . ' ' . esc_html($order->get_shipping_method() ?: '—') . '</p>';
        if (!$shown) {
            echo '<p class="grcs-muted">' . AdminLocale::esc_html__('No tracking details recorded.', 'gr-commerce-suite') . '</p>';
        }
    }

    private function trackingNumber(string $number, ?CourierSlug $courier, bool $active): void
    {
        $url = $courier !== null && $active ? TrackingService::publicUrl($number, $courier) : '';
        echo '<p>' . esc_html(($courier !== null ? $courier->label() . ': ' : '') . $number);
        if ($url !== '') {
            echo ' <a href="' . esc_url($url) . '" target="_blank" rel="noopener noreferrer">' . AdminLocale::esc_html__('Track shipment', 'gr-commerce-suite') . '</a>';
        }
        echo '</p>';
    }

    private function readableOrder(int $id): ?WC_Order
    {
        if ($id < 1 || !current_user_can('edit_shop_order', $id)) {
            return null;
        }
        $order = wc_get_order($id);
        return $order instanceof WC_Order && $this->canRead($order) ? $order : null;
    }

    private function canRead(WC_Order $order): bool
    {
        return $order->get_type() === 'shop_order' && $order->get_status() !== 'trash'
            && current_user_can('edit_shop_order', $order->get_id());
    }

    private function orderLink(WC_Order $order): void
    {
        echo '<a href="' . esc_url($order->get_edit_order_url()) . '">'
            . esc_html(sprintf(AdminLocale::__('Open WooCommerce order #%s', 'gr-commerce-suite'), $order->get_order_number())) . '</a>';
    }

    private function date(mixed $date): string
    {
        return $date !== null ? wc_format_datetime($date, wc_date_format() . ' H:i') : '—';
    }

    private function money(WC_Order $order, mixed $amount): string
    {
        return html_entity_decode(wp_strip_all_tags(wc_price($amount, ['currency' => $order->get_currency()])), ENT_QUOTES, 'UTF-8');
    }

    private function fact(string $label, string $value): void
    {
        echo '<div><dt>' . esc_html($label) . '</dt><dd>' . esc_html($value !== '' ? $value : '—') . '</dd></div>';
    }

    private function notice(string $message): void
    {
        echo '<div class="notice notice-warning"><p>' . esc_html($message) . '</p></div>';
    }

    private function formStart(): void
    {
        // Search terms and contact details stay in POST; entry links carry only order IDs and a nonce.
        echo '<form method="post" action="' . esc_url(admin_url('admin.php?page=' . self::MENU_SLUG)) . '">';
        echo '<input type="hidden" name="' . esc_attr(self::NONCE_FIELD) . '" value="' . esc_attr(wp_create_nonce(self::NONCE_ACTION)) . '">';
    }

    /**
     * @param LookupState $state
     * @param array<string, int|string|null> $overrides
     */
    private function hidden(array $state, array $overrides = []): void
    {
        foreach (array_merge($state, $overrides) as $key => $value) {
            if ($value !== null) {
                echo '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr((string) $value) . '">';
            }
        }
    }

    /**
     * @param LookupState $state
     * @param array<string, int|string|null> $overrides
     */
    private function button(string $label, array $state, array $overrides): void
    {
        $this->formStart();
        $this->hidden($state, $overrides);
        echo '<button class="button" type="submit">' . esc_html($label) . '</button></form>';
    }

    /**
     * @param LookupState $state
     * @param 'match_page'|'history_page' $key
     */
    private function pagination(array $state, string $key, int $pages): void
    {
        $page = $state[$key];
        if ($pages < 2 && $page <= 1) {
            return;
        }
        echo '<nav class="grcs-customer360-pagination" aria-label="' . AdminLocale::esc_attr__('Order pages', 'gr-commerce-suite') . '">';
        if ($page > 1) {
            $this->button(AdminLocale::__('Previous', 'gr-commerce-suite'), $state, [$key => $page - 1, 'warranty_order' => 0, 'item' => 0]);
        }
        echo '<span>' . esc_html(sprintf(AdminLocale::__('Page %1$d of %2$d', 'gr-commerce-suite'), $page, max(1, $pages))) . '</span>';
        if ($page < $pages) {
            $this->button(AdminLocale::__('Next', 'gr-commerce-suite'), $state, [$key => $page + 1, 'warranty_order' => 0, 'item' => 0]);
        }
        echo '</nav>';
    }
}
