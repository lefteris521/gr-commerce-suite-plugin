<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\Feed\SkroutzXmlGenerator;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Modules\CourierCenter\CourierCenterModule;
use GRCommerceSuite\Modules\CourierCenter\Text as CourierCenterText;
use GRCommerceSuite\Frontend\BankTransferAccounts;
use GRCommerceSuite\Frontend\CheckoutPaymentRules;
use GRCommerceSuite\Frontend\GreekInvoiceCheckout;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Services\CodBlacklistService;
use GRCommerceSuite\Services\LicenseManager;

/** Shared presentation for merchant-facing plugin pages; contains no operational actions. */
final class AdminWorkspace
{
    /** Links to existing authoritative screens; no parallel order or customer workspace. */
    public static function navigation(string $active): void
    {
        $links = [];
        if (current_user_can('edit_shop_orders')) {
            $links['orders'] = [AdminLocale::__('Orders', 'gr-commerce-suite'),
                \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()
                    ? admin_url('admin.php?page=wc-orders') : admin_url('edit.php?post_type=shop_order')];
        }
        if (current_user_can('manage_woocommerce')) {
            if (current_user_can('edit_shop_orders')) {
                $links['customers'] = [AdminLocale::__('Customer 360°', 'gr-commerce-suite'), admin_url('admin.php?page=' . Customer360Page::MENU_SLUG)];
            }
            // Shipping and money hubs live as tabs of the tools page; data-grcs-hub-tab keeps the
            // current-page marker in step when admin-ui.js switches tabs without a reload.
            $links['pickup'] = [AdminLocale::__('Daily Pickup List (Λίστα Παραλαβής)', 'gr-commerce-suite'), admin_url('admin.php?page=' . CodReconciliationPage::MENU_SLUG . '&tab=pickup'), 'pickup'];
            $links['cod'] = [AdminLocale::__('COD Reconciliation', 'gr-commerce-suite'), admin_url('admin.php?page=' . CodReconciliationPage::MENU_SLUG . '&tab=reconciliation'), 'reconciliation'];
            $links['settings'] = [AdminLocale::__('Settings / Ρυθμίσεις', 'gr-commerce-suite'), admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite')];
        }
        echo '<nav class="grcs-hub-nav" aria-label="' . AdminLocale::esc_attr__('GR Commerce Suite', 'gr-commerce-suite') . '">';
        foreach ($links as $key => $link) {
            echo '<a class="button" href="' . esc_url($link[1]) . '"' . (isset($link[2]) ? ' data-grcs-hub-tab="' . esc_attr($link[2]) . '"' : '')
                . ($key === $active ? ' aria-current="page"' : '') . '>' . esc_html($link[0]) . '</a>';
        }
        echo '</nav>';
    }

    public static function header(string $title): void
    {
        echo '<header class="grcs-app-bar"><div class="grcs-app-bar__identity">'
            . '<span class="grcs-app-icon dashicons dashicons-store" aria-hidden="true"></span>'
            . '<h1 class="grcs-page-title">' . esc_html($title) . '</h1>'
            . '<span class="grcs-version">v' . esc_html(defined('GRCS_VERSION') ? GRCS_VERSION : '1.0.0')
            . '</span></div><span class="grcs-brand">GR COMMERCE SUITE</span></header>';
    }

    /** Feed status line shared by the tools tab and the feed settings, with links to the flagged products. */
    public static function feedStatus(): void
    {
        $status = (new SkroutzXmlGenerator())->statusSummary();
        echo '<p class="grcs-feed-status" data-state="' . esc_attr($status['state']) . '" role="status">' . esc_html($status['text']);
        if (($status['fix'] ?? []) !== []) {
            $links = array_map(static fn(array $link): string => '<a href="' . esc_url($link['url']) . '">'
                . esc_html($link['name'] !== '' ? $link['name'] : AdminLocale::__('(no name)', 'gr-commerce-suite')) . '</a>', $status['fix']);
            echo '<span class="grcs-feed-fix">' . AdminLocale::esc_html__('Start with:', 'gr-commerce-suite') . ' ' . implode(', ', $links) . '</span>';
        }
        echo '</p>';
    }

    /**
     * Shared sidebar. Every page leads with the saved setup status; blacklist rules only
     * accompany the blacklist tool, and courier contact details only the settings screen.
     */
    public static function sidebar(string $context = 'settings', string $activeTab = ''): void
    {
        echo '<aside class="grcs-sidebar" aria-label="' . AdminLocale::esc_attr__('Setup summary and support', 'gr-commerce-suite') . '">';
        self::renderSetupStatus();
        if ($context === 'tools') {
            self::renderBlacklistRules($activeTab === 'blacklist');
        } else {
            self::widgetStart(AdminLocale::__('Help', 'gr-commerce-suite'));
            // Courier help only for the couriers whose module is on.
            if (ModuleRegistry::isEnabled(ModuleRegistry::ACS)) {
                echo '<p><strong>' . AdminLocale::esc_html__('ACS Web Services', 'gr-commerce-suite') . '</strong><br>'
                    . AdminLocale::esc_html__('Request credentials and a Billing Code from your ACS branch.', 'gr-commerce-suite')
                    . '<br><a href="tel:+302108190000">210-8190000</a> · <a href="mailto:info@acscourier.gr">' . AdminLocale::esc_html__('info@acscourier.gr', 'gr-commerce-suite') . '</a></p>';
            }
            if (ModuleRegistry::isEnabled(ModuleRegistry::BOXNOW)) {
                echo '<p><strong>' . AdminLocale::esc_html__('BOX NOW Partner API', 'gr-commerce-suite') . '</strong><br>'
                    . AdminLocale::esc_html__('Request your Client ID, Client Secret and Warehouse Location ID.', 'gr-commerce-suite')
                    . '<br><a href="mailto:info@boxnow.gr">' . AdminLocale::esc_html__('info@boxnow.gr', 'gr-commerce-suite') . '</a></p>';
            }
            if (DiagnosticsPanel::canAccess()) {
                echo '<p><strong>' . AdminLocale::esc_html__('Something not working?', 'gr-commerce-suite') . '</strong><br>'
                    . AdminLocale::esc_html__('Diagnostics show recent courier, checkout and license errors with suggested fixes.', 'gr-commerce-suite')
                    . '<br><a href="' . esc_url(admin_url('admin.php?page=' . CodReconciliationPage::MENU_SLUG . '&tab=diagnostics')) . '">'
                    . AdminLocale::esc_html__('Open Diagnostics & Logs', 'gr-commerce-suite') . '</a></p>';
            }
            echo '</div></section>';
        }
        echo '</aside>';
    }

    /** Saved (not unsaved, in-form) configuration, each row linking to where it is changed. */
    private static function renderSetupStatus(): void
    {
        self::widgetStart(AdminLocale::__('Setup status', 'gr-commerce-suite'));
        $status = self::setupStatus();
        self::renderNextStep($status);
        echo '<ul class="grcs-setup-status">';
        foreach ($status as $key => [$label, $state, $value, $url]) {
            echo '<li data-grcs-setup="' . esc_attr($key) . '"><a href="' . esc_url($url) . '"><span class="grcs-setup-status__label">'
                . esc_html($label) . '</span><span class="grcs-pill grcs-pill--' . esc_attr(['ok' => 'green', 'warn' => 'amber', 'off' => 'gray'][$state])
                . '">' . esc_html($value) . '</span></a></li>';
        }
        echo '</ul></div></section>';
    }

    /**
     * One recommended action above the rows, so a new store is not left choosing between several
     * amber pills. Order follows what blocks selling first; test mode is the last step by design.
     *
     * @param array<string, array{0: string, 1: 'ok'|'warn'|'off', 2: string, 3: string}> $status
     */
    private static function renderNextStep(array $status): void
    {
        $pending = array_keys(array_filter($status, static fn(array $row): bool => $row[1] === 'warn'));
        if ($pending === []) {
            echo '<p class="grcs-setup-next grcs-setup-next--done" data-grcs-setup-next="done"><span aria-hidden="true">✓</span> '
                . AdminLocale::esc_html__('Everything needed to sell and ship is set up.', 'gr-commerce-suite') . '</p>';
            return;
        }
        $order = array_flip(['shipping', 'sender', 'license', 'acs', 'boxnow', 'bank', 'invoice', 'mode', 'xml']);
        usort($pending, static fn(string $a, string $b): int => ($order[$a] ?? 99) <=> ($order[$b] ?? 99));
        $key = $pending[0];
        $license = $key === 'license' ? (new LicenseManager())->merchantStatus() : ['description' => '', 'action' => ''];
        [$why, $action] = match ($key) {
            'shipping' => [ModuleRegistry::isEnabled(ModuleRegistry::ACS) && ModuleRegistry::isEnabled(ModuleRegistry::BOXNOW)
                ? AdminLocale::__('Customers cannot choose ACS or BOX NOW yet. Add a courier to a shipping zone.', 'gr-commerce-suite')
                : sprintf(AdminLocale::__('Customers cannot choose %s yet. Add a courier to a shipping zone.', 'gr-commerce-suite'), ModuleRegistry::isEnabled(ModuleRegistry::ACS) ? 'ACS' : (ModuleRegistry::isEnabled(ModuleRegistry::BOXNOW) ? 'BOX NOW' : 'Geniki Taxydromiki')),
                AdminLocale::__('Open shipping zones', 'gr-commerce-suite')],
            'sender' => [AdminLocale::__('Courier labels print your store address as the sender, and it is not filled in yet.', 'gr-commerce-suite'),
                AdminLocale::__('Add store address', 'gr-commerce-suite')],
            'license' => [(string) $license['description'], $license['action'] !== '' ? (string) $license['action'] : AdminLocale::__('Open license settings', 'gr-commerce-suite')],
            'acs', 'boxnow', 'geniki' => [sprintf(AdminLocale::__('%s is offered at checkout, but vouchers cannot be issued until its credentials are saved.', 'gr-commerce-suite'), $status[$key][0]),
                AdminLocale::__('Add credentials', 'gr-commerce-suite')],
            'bank' => [BankTransferAccounts::setupState()['state'] === 'demo'
                ? AdminLocale::__('[SANDBOX] Μέχρι να αποθηκεύσετε λογαριασμούς εδώ, το checkout εμφανίζει 3 δοκιμαστικούς λογαριασμούς (Πειραιώς, Eurobank, Εθνική).', 'gr-commerce-suite')
                : AdminLocale::__('Bank transfer is switched on but customers cannot see an account to pay into.', 'gr-commerce-suite'),
                AdminLocale::__('Add a bank account', 'gr-commerce-suite')],
            'invoice' => [AdminLocale::__('Customers who ask for an invoice have no way to pay: cash on delivery is not allowed with invoices and no other method is ready.', 'gr-commerce-suite'),
                AdminLocale::__('Open payment methods', 'gr-commerce-suite')],
            'mode' => [ModuleRegistry::isEnabled(ModuleRegistry::GENIKI)
                ? AdminLocale::__('Test mode is on. Geniki sends operations to its carrier test account; ACS and BOX NOW are simulated.', 'gr-commerce-suite')
                : AdminLocale::__('Test mode is on: vouchers are simulated and no parcel is booked. Switch to live once your courier credentials are saved.', 'gr-commerce-suite'),
                AdminLocale::__('Open general settings', 'gr-commerce-suite')],
            'xml' => [(new SkroutzXmlGenerator())->statusSummary()['text'], AdminLocale::__('Open XML feed', 'gr-commerce-suite')],
            default => [$status[$key][0] . ': ' . $status[$key][2], AdminLocale::__('Review', 'gr-commerce-suite')],
        };
        echo '<div class="grcs-setup-next" data-grcs-setup-next="' . esc_attr($key) . '"><p class="grcs-setup-next__title">'
            . esc_html(sprintf(AdminLocale::_n('Next step · %d item to review', 'Next step · %d items to review', count($pending), 'gr-commerce-suite'), count($pending)))
            . '</p><p>' . esc_html($why) . '</p><a class="button button-primary" href="' . esc_url($status[$key][3]) . '">' . esc_html($action) . '</a></div>';
    }

    /**
     * @return array<string, array{0: string, 1: 'ok'|'warn'|'off', 2: string, 3: string}>
     */
    public static function setupStatus(): array
    {
        $settings = static fn(string $section): string => admin_url('admin.php?page=wc-settings&tab=' . SettingsPage::PAGE_ID . '&section=' . $section);
        $sandbox = (new LicenseManager())->isSandboxEnabled();
        $methods = self::courierShippingMethods();
        $offered = array_keys(array_filter($methods));
        // A courier offered to live customers without credentials cannot issue vouchers: flag it.
        $courier = static fn(string $name, string $option, string $section): array => [$name,
            get_option($option, '') !== '' ? 'ok' : (!$sandbox && $methods[$name] ? 'warn' : 'off'),
            get_option($option, '') !== '' ? AdminLocale::__('Credentials saved', 'gr-commerce-suite') : AdminLocale::__('Not set up', 'gr-commerce-suite'), $settings($section)];
        $license = (new LicenseManager())->merchantStatus();
        $status = [
            'license' => [AdminLocale::__('License', 'gr-commerce-suite'), $license['state'] === LicenseManager::STATE_ACTIVE ? 'ok' : 'warn',
                $license['pill'], $settings('license')],
            'mode' => [AdminLocale::__('Courier mode', 'gr-commerce-suite'), $sandbox ? 'warn' : 'ok',
                $sandbox ? (ModuleRegistry::isEnabled(ModuleRegistry::GENIKI) ? AdminLocale::__('Test (Geniki carrier sandbox)', 'gr-commerce-suite') : AdminLocale::__('Test (simulated vouchers)', 'gr-commerce-suite')) : AdminLocale::__('Live', 'gr-commerce-suite'), $settings('general')],
            'acs' => $courier('ACS Courier', 'grcs_acs_company_id', 'acs'),
            'boxnow' => $courier('BOX NOW', 'grcs_boxnow_client_id', 'boxnow'),
            // Printed on every courier label; WooCommerce owns these fields under Settings → General.
            'sender' => [AdminLocale::__('Sender address on labels', 'gr-commerce-suite'),
                self::storeAddressComplete() ? 'ok' : 'warn',
                self::storeAddressComplete() ? AdminLocale::__('Complete', 'gr-commerce-suite') : AdminLocale::__('Missing', 'gr-commerce-suite'),
                admin_url('admin.php?page=wc-settings&tab=general')],
            'shipping' => [AdminLocale::__('Offered at checkout', 'gr-commerce-suite'), $offered !== [] ? 'ok' : 'warn',
                $offered !== [] ? implode(', ', $offered) : AdminLocale::__('No courier shipping method', 'gr-commerce-suite'),
                admin_url('admin.php?page=wc-settings&tab=shipping')],
            'invoice' => self::invoiceStatus($settings('invoice')),
        ];
        if (ModuleRegistry::isEnabled(ModuleRegistry::GENIKI)) {
            $credentials = (new \GRCommerceSuite\Security\CredentialVault())->getForCourier(\GRCommerceSuite\Domain\Shared\CourierSlug::Geniki);
            $ready = trim($credentials['username'] ?? '') !== '' && trim($credentials['password'] ?? '') !== '' && trim($credentials['application_key'] ?? '') !== '';
            $status['geniki'] = ['Geniki Taxydromiki', $ready ? 'ok' : ($methods['Geniki Taxydromiki'] ? 'warn' : 'off'),
                $ready ? AdminLocale::__('Credentials saved', 'gr-commerce-suite') : AdminLocale::__('Not set up', 'gr-commerce-suite'), $settings('geniki')];
        }
        if (ModuleRegistry::isEnabled(ModuleRegistry::COURIER_CENTER) && current_user_can('manage_woocommerce')) {
            $courierCenter = CourierCenterModule::status();
            $status['courier_center'] = [CourierCenterText::get('module'), 'warn',
                CourierCenterText::get($courierCenter['state']), CourierCenterModule::setupUrl()];
        }
        // Judged by what a customer choosing bank transfer is shown, not only by our own account table.
        $bank = BankTransferAccounts::setupState();
        $status['bank'] = [AdminLocale::__('Bank transfer accounts', 'gr-commerce-suite'),
            ['off' => 'off', 'demo' => 'warn', 'ready' => 'ok', 'missing' => 'warn'][$bank['state']],
            match (true) {
                $bank['state'] === 'off' => AdminLocale::__('Bank transfer off', 'gr-commerce-suite'),
                $bank['state'] === 'demo' => AdminLocale::__('Sample accounts (test)', 'gr-commerce-suite'),
                $bank['state'] === 'missing' => AdminLocale::__('Hidden: no account details', 'gr-commerce-suite'),
                $bank['source'] === 'woocommerce' => AdminLocale::__('WooCommerce accounts', 'gr-commerce-suite'),
                $bank['source'] === 'instructions' => AdminLocale::__('IBAN in instructions', 'gr-commerce-suite'),
                default => sprintf(AdminLocale::_n('%d account', '%d accounts', $bank['count'], 'gr-commerce-suite'), $bank['count']),
            }, $settings('bank')];
        $xml = get_option('grcs_skroutz_feed_enabled', 'yes') === 'yes';
        // Follow the published feed, not only the switch, so this row agrees with the feed screen.
        // A feed never generated stays neutral: the switch defaults on for stores that never use it.
        $feed = $xml ? (new SkroutzXmlGenerator())->statusSummary()['state'] : 'off';
        $status['xml'] = [AdminLocale::__('Skroutz XML Feed', 'gr-commerce-suite'), ['off' => 'off', 'never' => 'off', 'attention' => 'warn', 'stale' => 'warn', 'empty' => 'warn'][$feed] ?? 'ok',
            match ($feed) {
                'off' => AdminLocale::__('Disabled', 'gr-commerce-suite'),
                'never' => AdminLocale::__('Not generated yet', 'gr-commerce-suite'),
                'attention' => AdminLocale::__('Products need details', 'gr-commerce-suite'),
                'empty' => AdminLocale::__('No products in feed', 'gr-commerce-suite'),
                'stale' => AdminLocale::__('Out of date', 'gr-commerce-suite'),
                'running' => AdminLocale::__('Generating', 'gr-commerce-suite'),
                default => AdminLocale::__('Enabled', 'gr-commerce-suite'),
            }, $settings('skroutz')];
        foreach ([ModuleRegistry::ACS => 'acs', ModuleRegistry::BOXNOW => 'boxnow', ModuleRegistry::SKROUTZ => 'xml'] as $module => $row) {
            if (!ModuleRegistry::isEnabled($module)) {
                unset($status[$row]);
            }
        }
        if (!ModuleRegistry::anyCourierEnabled()) { // courier-only checks make no sense without a courier
            unset($status['shipping'], $status['mode'], $status['sender']);
        }
        return $status;
    }

    /**
     * Invoice customers lose cash on delivery; with no other usable gateway they cannot pay at all.
     *
     * @return array{0: string, 1: 'ok'|'warn'|'off', 2: string, 3: string}
     */
    private static function invoiceStatus(string $settingsUrl): array
    {
        $label = AdminLocale::__('Invoice at checkout', 'gr-commerce-suite');
        if (get_option(GreekInvoiceCheckout::OPTION_ENABLED, 'yes') !== 'yes') {
            return [$label, 'off', AdminLocale::__('Disabled', 'gr-commerce-suite'), $settingsUrl];
        }
        if (CheckoutPaymentRules::invoiceDisablesCod() && !CheckoutPaymentRules::invoiceHasPaymentMethod()) {
            return [$label, 'warn', AdminLocale::__('No payment method for invoices', 'gr-commerce-suite'), admin_url('admin.php?page=wc-settings&tab=checkout')];
        }
        return [$label, 'ok', AdminLocale::__('Enabled', 'gr-commerce-suite'), $settingsUrl];
    }

    private static function storeAddressComplete(): bool
    {
        foreach (['woocommerce_store_address', 'woocommerce_store_city', 'woocommerce_store_postcode'] as $option) {
            if (trim((string) get_option($option, '')) === '') {
                return false;
            }
        }
        return true;
    }

    /**
     * Enabled GRCS courier methods across all WooCommerce shipping zones (including "rest of the world").
     *
     * @return array{'ACS Courier': bool, 'BOX NOW': bool, 'Geniki Taxydromiki': bool}
     */
    private static function courierShippingMethods(): array
    {
        $found = ['ACS Courier' => false, 'BOX NOW' => false, 'Geniki Taxydromiki' => false];
        if (!class_exists(\WC_Shipping_Zones::class) || !class_exists(\WC_Shipping_Zone::class)) {
            return $found;
        }
        try {
            $zones = array_map(static fn(array $zone): \WC_Shipping_Zone => new \WC_Shipping_Zone((int) $zone['zone_id']), \WC_Shipping_Zones::get_zones());
            $zones[] = new \WC_Shipping_Zone(0);
            foreach ($zones as $zone) {
                foreach ($zone->get_shipping_methods(true) as $method) {
                    $id = (string) $method->id;
                    if ($id === 'grcs_acs') {
                        $found['ACS Courier'] = true;
                    } elseif ($id === 'grcs_boxnow') {
                        $found['BOX NOW'] = true;
                    } elseif ($id === 'grcs_geniki') {
                        $found['Geniki Taxydromiki'] = true;
                    }
                }
            }
        } catch (\Throwable) {
            // Status is informational; never break the page over a zone read.
        }
        return $found;
    }

    /** COD blacklist rule summary and guidance, relevant on the blacklist tool only. */
    private static function renderBlacklistRules(bool $visible): void
    {
        $rules = CodBlacklistService::rules();
        $strategies = self::strategies();
        echo '<section class="grcs-widget" data-grcs-sidebar-tab="blacklist"' . ($visible ? '' : ' hidden') . '><h2 class="grcs-widget__header">'
            . AdminLocale::esc_html__('Blacklist rules in use', 'gr-commerce-suite') . '</h2><div class="grcs-widget__body"><dl class="grcs-config-summary">';
        $summary = [
            'strategy' => [AdminLocale::__('Matching Strategy', 'gr-commerce-suite'), $strategies[$rules['strategy']]],
            'expiry_days' => [AdminLocale::__('Expiry Days', 'gr-commerce-suite'), (string) $rules['expiry_days']],
            'min_failures' => [AdminLocale::__('Min Failures', 'gr-commerce-suite'), (string) $rules['min_failures']],
        ];
        foreach ($summary as $key => [$label, $value]) {
            echo '<div><dt>' . esc_html($label) . '</dt><dd data-grcs-summary="' . esc_attr($key) . '">' . esc_html($value) . '</dd></div>';
        }
        echo '</dl><ul class="grcs-checklist">';
        foreach (
            [AdminLocale::__('Set minimum failures to 2 or more.', 'gr-commerce-suite'), AdminLocale::__('Keep expiry at 90 days.', 'gr-commerce-suite'),
            AdminLocale::__('Whitelist VIP customers you trust.', 'gr-commerce-suite')] as $tip
        ) {
            echo '<li><span aria-hidden="true">✓</span> ' . esc_html($tip) . '</li>';
        }
        echo '</ul></div></section>';
    }

    /** @return array<string, string> */
    public static function strategies(): array
    {
        return [
            'phone_email_ip' => AdminLocale::__('Phone OR Email OR IP (Recommended)', 'gr-commerce-suite'),
            'phone_email' => AdminLocale::__('Phone OR Email', 'gr-commerce-suite'),
            'phone' => AdminLocale::__('Phone Only', 'gr-commerce-suite'),
            'email' => AdminLocale::__('Email Only', 'gr-commerce-suite'),
        ];
    }

    private static function widgetStart(string $title): void
    {
        echo '<section class="grcs-widget"><h2 class="grcs-widget__header">' . esc_html($title) . '</h2><div class="grcs-widget__body">';
    }
}
