<?php

declare(strict_types=1);

namespace GRCommerceSuite\Admin;

use GRCommerceSuite\I18n\AdminLocale;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Feed\SkroutzXmlGenerator;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Reconciliation\CodReconciliationService;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\ShippingOptions;
use GRCommerceSuite\Support\Money;
use DateTimeImmutable;
use DateTimeZone;
use WC_Order;
use GRCommerceSuite\Services\CodBlacklistService;
use GRCommerceSuite\Services\VoucherLockService;
use GRCommerceSuite\Support\Logger;
use Throwable;

/**
 * WooCommerce Admin Submenu Page for Cash-on-Delivery (`Antikatavoli`) Reconciliation
 * and Vouchers / Feed management (SPEC.md §7, §10, §13, §15.1).
 *
 * Screen ID: `woocommerce_page_grcs-cod-reconciliation`
 * Parent Menu: `woocommerce`
 * Capability: `manage_woocommerce`
 */
final class CodReconciliationPage implements HookSubscriberInterface
{
    public const PARENT_SLUG = 'woocommerce';

    public const MENU_SLUG = 'grcs-cod-reconciliation';

    public const SCREEN_ID = 'woocommerce_page_grcs-cod-reconciliation';

    public const REQUIRED_CAPABILITY = 'manage_woocommerce';

    public const NONCE_ACTION_CSV = 'grcs_cod_reconcile_csv_nonce';

    public const NONCE_ACTION_MANUAL = 'grcs_cod_manual_reconcile_nonce';

    public const NONCE_ACTION_UNKNOWN = 'grcs_resolve_unknown_voucher_nonce';

    public const NONCE_FIELD = '_grcs_cod_nonce';
    public const NONCE_ACTION_BLACKLIST = 'grcs_cod_blacklist';
    public const NONCE_ACTION_BLACKLIST_EXPORT = 'grcs_cod_blacklist_export';

    private readonly LoggerInterface $logger;

    /**
     * @var array<string, mixed>|null
     */
    private ?array $lastUploadReport = null;

    private ?string $noticeMessage = null;

    private string $noticeType = 'success';

    public function __construct(
        private readonly CodReconciliationService $reconciliationService,
        private readonly ?VoucherLockService $voucherLockService = null,
        ?LoggerInterface $logger = null,
        private readonly ?VoucherRepository $voucherRepository = null,
        private readonly ?CodBlacklistService $blacklist = null,
    ) {
        $this->logger = $logger ?? new Logger('gr-commerce-suite');
    }

    /**
     * Register WordPress admin menu and form submission hooks (SPEC.md §5.2, §13).
     */
    public function register(): void
    {
        if (!function_exists('add_action')) {
            return;
        }

        add_action('admin_menu', [$this, 'registerSubmenuPage'], 60);
        if (!LicenseManager::isLicensed()) {
            return;
        }

        add_action('admin_post_grcs_cod_upload_csv', [$this, 'handleAdminPostCsvUpload']);
        add_action('admin_post_grcs_cod_manual_reconcile', [$this, 'handleAdminPostManualReconcile']);
        add_action('admin_post_grcs_resolve_unknown_voucher', [$this, 'handleAdminPostResolveUnknown']);
        add_action('admin_post_grcs_cod_export_blacklist', [$this, 'handleAdminPostBlacklistExport']);
    }

    /**
     * Register the submenu page under WooCommerce (`woocommerce_page_grcs-cod-reconciliation`).
     */
    public function registerSubmenuPage(): void
    {
        if (!function_exists('add_submenu_page')) {
            return;
        }

        // One page hosts COD reconciliation, the blacklist, the pickup list, XML feeds and diagnostics,
        // so its menu entry names the whole toolset rather than only reconciliation.
        add_submenu_page(
            self::PARENT_SLUG,
            AdminLocale::__('GR Commerce Tools', 'gr-commerce-suite'),
            AdminLocale::__('GR Commerce Tools', 'gr-commerce-suite'),
            self::REQUIRED_CAPABILITY,
            self::MENU_SLUG,
            [$this, 'renderPage']
        );
    }

    /**
     * Check whether the current user has permission to access COD reconciliation (`manage_woocommerce`).
     */
    public function canAccessReconciliation(): bool
    {
        if (!function_exists('current_user_can')) {
            return false;
        }

        return current_user_can(self::REQUIRED_CAPABILITY);
    }

    /** @param array<string, mixed> $report */
    private function renderUnmatchedRows(array $report): void
    {
        $count = (int) ($report['summary']['unmatched_count'] ?? 0);
        $rows = $report['unmatched'] ?? null;
        if ($count === 0 && ($rows === [] || $rows === null)) {
            return;
        }
        echo '<h3>' . esc_html(AdminLocale::__('Unmatched vouchers', 'gr-commerce-suite')) . '</h3>';
        if (!is_array($rows) || count($rows) !== $count) {
            echo '<p role="alert">' . esc_html(AdminLocale::__('Unmatched voucher details are incomplete. Retain the original CSV statement and re-import it to investigate.', 'gr-commerce-suite')) . '</p>';
        }
        if (!is_array($rows)) {
            return;
        }
        echo '<div class="grcs-table-wrap"><table class="widefat striped grcs-table grcs-cod-unmatched-table"><thead><tr>';
        foreach ([AdminLocale::__('Voucher No', 'gr-commerce-suite'), AdminLocale::__('Collected COD (€)', 'gr-commerce-suite'),
            AdminLocale::__('Payout date (UTC)', 'gr-commerce-suite'), AdminLocale::__('Settlement Ref', 'gr-commerce-suite'),
            AdminLocale::__('Reason', 'gr-commerce-suite'), AdminLocale::__('Order', 'gr-commerce-suite')] as $label) {
            echo '<th scope="col">' . esc_html($label) . '</th>';
        }
        echo '</tr></thead><tbody>';
        $text = static fn(mixed $value): string => is_scalar($value) ? (string) $value : '—';
        foreach ($rows as $row) {
            if (!is_array($row)) {
                echo '<tr><td colspan="6">' . esc_html(AdminLocale::__('Invalid unmatched record. Consult the original CSV statement.', 'gr-commerce-suite')) . '</td></tr>';
                continue;
            }
            // Missing vouchers and conflicting settlements both retain integer cents.
            // Never substitute zero for a missing/corrupt amount in a financial report.
            $amount = is_int($row['collected_cents'] ?? null)
                ? Money::fromCents($row['collected_cents'])->toDecimalString()
                : AdminLocale::__('Amount unavailable — consult CSV', 'gr-commerce-suite');
            $reason = $text($row['reason'] ?? AdminLocale::__('No matching voucher found.', 'gr-commerce-suite'));
            echo '<tr><td>' . esc_html($text($row['voucher_no'] ?? null)) . '</td><td>' . esc_html($amount)
                . '</td><td>' . esc_html($text($row['payout_date'] ?? null)) . '</td><td>'
                . esc_html($text($row['settlement_ref'] ?? null)) . '</td><td>' . esc_html(AdminLocale::display($reason)) . '</td><td>';
            if (is_numeric($row['order_id'] ?? null) && (int) $row['order_id'] > 0) {
                $this->renderOrderIdLink((int) $row['order_id']);
            } else {
                echo '—';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
    }

    public function handleAdminPostBlacklistExport(): void
    {
        LicenseManager::assertLicensed();
        $nonce = is_string($_GET[self::NONCE_FIELD] ?? null) ? wp_unslash($_GET[self::NONCE_FIELD]) : '';
        if (!$this->canAccessReconciliation() || $this->blacklist === null
            || !wp_verify_nonce($nonce, self::NONCE_ACTION_BLACKLIST_EXPORT)) {
            wp_die(AdminLocale::esc_html__('Permission or security nonce verification failed.', 'gr-commerce-suite'), '', ['response' => 403]);
        }

        $filters = CodBlacklistPanel::filters();
        $entries = $this->blacklist->listEntries($filters['search'], $filters['courier'], $filters['reason'], $filters['status']);
        nocache_headers();
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="grcs-blacklist-' . gmdate('Y-m-d') . '.csv"');
        $stream = fopen('php://output', 'wb');
        if ($stream !== false) {
            CodBlacklistCsv::write($stream, $entries);
            fclose($stream);
        }
        exit;
    }

    /**
     * Handle `admin-post.php?action=grcs_cod_upload_csv` submission.
     */
    public function handleAdminPostCsvUpload(): void
    {
        LicenseManager::assertLicensed();

        if (!$this->canAccessReconciliation()) {
            if (function_exists('wp_die')) {
                wp_die(AdminLocale::esc_html__('Permission denied.', 'gr-commerce-suite'), 403);
            }
            return;
        }

        if (!$this->verifyRequestNonce(self::NONCE_ACTION_CSV)) {
            if (function_exists('wp_die')) {
                wp_die(AdminLocale::esc_html__('Security check failed.', 'gr-commerce-suite'), 403);
            }
            return;
        }

        $this->processCsvUploadFromRequest();
        $this->redirectBackToPage($this->noticeType === 'error'
            ? ['grcs_cod_import_failed' => 1] : ['grcs_cod_uploaded' => 1]);
    }

    /**
     * Handle `admin-post.php?action=grcs_cod_manual_reconcile` submission.
     */
    public function handleAdminPostManualReconcile(): void
    {
        LicenseManager::assertLicensed();

        if (!$this->canAccessReconciliation()) {
            if (function_exists('wp_die')) {
                wp_die(AdminLocale::esc_html__('Permission denied.', 'gr-commerce-suite'), 403);
            }
            return;
        }

        if (!$this->verifyRequestNonce(self::NONCE_ACTION_MANUAL)) {
            if (function_exists('wp_die')) {
                wp_die(AdminLocale::esc_html__('Security check failed.', 'gr-commerce-suite'), 403);
            }
            return;
        }

        $voucherId = isset($_POST['voucher_id']) ? $this->sanitizeInt($_POST['voucher_id']) : 0;
        $settlementRef = isset($_POST['settlement_ref'])
            ? $this->sanitizeText((string) $_POST['settlement_ref'])
            : 'MANUAL';

        if ($voucherId > 0) {
            $this->reconciliationService->markManuallyReconciled($voucherId, $settlementRef);
        }

        $this->redirectBackToPage(['grcs_cod_manual_done' => 1]);
    }

    /**
     * Handle `admin-post.php?action=grcs_resolve_unknown_voucher` submission.
     */
    public function handleAdminPostResolveUnknown(): void
    {
        LicenseManager::assertLicensed();

        if (!$this->canAccessReconciliation()) {
            if (function_exists('wp_die')) {
                wp_die(AdminLocale::esc_html__('Permission denied.', 'gr-commerce-suite'), 403);
            }
            return;
        }

        if (!$this->verifyRequestNonce(self::NONCE_ACTION_UNKNOWN)) {
            if (function_exists('wp_die')) {
                wp_die(AdminLocale::esc_html__('Security check failed.', 'gr-commerce-suite'), 403);
            }
            return;
        }

        if ($this->voucherLockService !== null) {
            $voucherId = isset($_POST['voucher_id']) ? $this->sanitizeInt($_POST['voucher_id']) : 0;
            $resolution = isset($_POST['resolution_action'])
                ? $this->sanitizeText((string) $_POST['resolution_action'])
                : 'clear';
            $voucherNo = isset($_POST['voucher_no']) ? $this->sanitizeText((string) $_POST['voucher_no']) : null;
            $clearReason = isset($_POST['clear_reason']) ? $this->sanitizeText((string) $_POST['clear_reason']) : '';
            $confirmedCod = isset($_POST['confirmed_cod']) && $_POST['confirmed_cod'] === 'yes';

            if ($voucherId > 0) {
                try {
                    if ($resolution === 'clear') {
                        $this->voucherLockService->clearUnknownVoucher($voucherId, $clearReason, $confirmedCod);
                    } else {
                        $this->voucherLockService->resolveUnknownVoucherManually($voucherId, $resolution, $voucherNo);
                    }
                } catch (Throwable $e) {
                    $this->logger->error('Failed to resolve unknown voucher: ' . $e->getMessage());
                }
            }
        }

        $this->redirectBackToPage(['grcs_unknown_resolved' => 1]);
    }

    /**
     * Render the WooCommerce -> COD Reconciliation admin page (`woocommerce_page_grcs-cod-reconciliation`).
     */
    public function renderPage(): void
    {
        if (!$this->canAccessReconciliation() && !(($_GET['tab'] ?? '') === 'diagnostics' && DiagnosticsPanel::canAccess())) {
            if (function_exists('wp_die')) {
                $msg = AdminLocale::__('You do not have permission to access COD reconciliation.', 'gr-commerce-suite');
                wp_die(esc_html($msg), 403);
            }
            $denied = AdminLocale::__('Permission denied.', 'gr-commerce-suite');
            echo '<div class="notice notice-error"><p>' . esc_html($denied) . '</p></div>';
            return;
        }

        if (($_GET['tab'] ?? '') === 'diagnostics' && DiagnosticsPanel::canAccess()
            && (!LicenseManager::isLicensed() || !$this->canAccessReconciliation())) {
            echo '<div class="wrap grcs-ui grcs-admin-wrap">';
            AdminWorkspace::header(AdminLocale::__('Diagnostics & Logs (Καταγραφή Συστήματος)', 'gr-commerce-suite'));
            echo '<p><a href="' . esc_url(admin_url('admin.php?page=' . self::MENU_SLUG)) . '">'
                . AdminLocale::esc_html__('Back to Commerce Tools', 'gr-commerce-suite') . '</a></p><div class="grcs-workspace"><main class="grcs-main">';
            DiagnosticsPanel::render();
            echo '</main>';
            AdminWorkspace::sidebar('tools', 'diagnostics');
            echo '</div></div>';
            return;
        }

        if (!LicenseManager::isLicensed()) {
            $settingsUrl = admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite');
            $license = (new LicenseManager())->merchantStatus();
            // Keep the shared header and hub so Orders, Customer 360° and Settings stay one click away.
            echo '<div class="wrap grcs-ui grcs-admin-wrap">';
            AdminWorkspace::header(AdminLocale::__('GR Commerce Tools', 'gr-commerce-suite'));
            AdminWorkspace::navigation('');
            echo '<div class="grcs-card grcs-license-lock"><h2>'
                . AdminLocale::esc_html__('License Required', 'gr-commerce-suite') . '</h2><p>'
                . esc_html($license['description']) . '</p>'
                . '<p><a class="button button-primary" href="' . esc_url($settingsUrl . '&section=license') . '">'
                . esc_html($license['action'] !== '' ? $license['action'] : AdminLocale::__('Open license settings', 'gr-commerce-suite')) . '</a></p></div></div>';
            return;
        }

        // Support inline POST submission directly on the page as well as admin-post.php
        if (isset($_POST['grcs_cod_action'])) {
            $this->handleInlinePostSubmission();
        }

        if (isset($_GET['grcs_skroutz_queued'])) {
            $this->noticeMessage = AdminLocale::__('XML feed generation queued. See Diagnostics & Logs for progress.', 'gr-commerce-suite');
            $this->noticeType = 'success';
        }

        if (isset($_GET['grcs_skroutz_generated'])) {
            $this->noticeMessage = AdminLocale::__('Skroutz XML feed generated successfully.', 'gr-commerce-suite');
            $this->noticeType = 'success';
        }

        $selectedCourierRaw = isset($_GET['courier'])
            ? $this->sanitizeText((string) $_GET['courier'])
            : (isset($_POST['courier']) ? $this->sanitizeText((string) $_POST['courier']) : 'acs');
        $selectedCourier = CourierSlug::tryFrom(strtolower($selectedCourierRaw)) ?? CourierSlug::Acs;

        $overdueDays = isset($_GET['overdue_days'])
            ? max(1, $this->sanitizeInt($_GET['overdue_days']))
            : $this->reconciliationService->getOverdueDaysThreshold();

        $filterCourier = isset($_GET['courier']) && $_GET['courier'] !== ''
            ? CourierSlug::tryFrom(strtolower($this->sanitizeText((string) $_GET['courier'])))
            : null;

        $summary = $this->reconciliationService->getDashboardSummary($filterCourier, $overdueDays);
        $mapping = $this->reconciliationService->getColumnMapping($selectedCourier);

        $csvReport = $this->lastUploadReport;
        if ($_POST === [] && $csvReport === null && isset($_GET['grcs_cod_uploaded']) && function_exists('get_option')) {
            $savedReport = get_option(CodReconciliationService::OPTION_LAST_CSV_REPORT, null);
            if (is_array($savedReport)) {
                $csvReport = $savedReport;
                $this->setCsvReportNotice($savedReport);
            }
        }
        if ($_POST === [] && isset($_GET['grcs_cod_import_failed'])) {
            $this->noticeMessage = AdminLocale::__('CSV import failed. Earlier rows may already be saved. Retain the original statement, correct the problem and retry the same file; identical settlements will not be counted twice.', 'gr-commerce-suite');
            $this->noticeType = 'error';
        }

        $unknownVouchers = $this->voucherLockService !== null
            ? $this->voucherLockService->getUnknownVouchers($filterCourier, 50)
            : [];

        $allVouchers = $this->voucherRepository !== null
            ? $this->voucherRepository->findRecentVouchers(100)
            : [];
        // Order links must still land after approval, including vouchers older than the recent list.
        $targetId = $this->sanitizeInt($_GET['voucher_id'] ?? 0);
        if ($targetId > 0 && !in_array($targetId, array_map('intval', array_column($allVouchers, 'id')), true)) {
            $target = $this->voucherRepository?->findById($targetId);
            if ($target !== null && ($filterCourier === null || ($target['courier_slug'] ?? '') === $filterCourier->value)) {
                $allVouchers[] = $target;
            }
        }
        $anchoredVoucherIds = [];

        $csvNonce = function_exists('wp_create_nonce') ? wp_create_nonce(self::NONCE_ACTION_CSV) : 'grcs_nonce';
        $manualNonce = function_exists('wp_create_nonce') ? wp_create_nonce(self::NONCE_ACTION_MANUAL) : 'grcs_nonce';
        $unknownNonce = function_exists('wp_create_nonce') ? wp_create_nonce(self::NONCE_ACTION_UNKNOWN) : 'grcs_nonce';
        $feedNonce = function_exists('wp_create_nonce')
            ? wp_create_nonce(SkroutzXmlGenerator::NONCE_ACTION_GENERATE)
            : 'grcs_nonce';

        $totExpected = (string) $summary['total_expected_eur'];
        $totVouchers = (string) $summary['total_cod_vouchers'];
        $totReconciled = (string) $summary['total_reconciled_eur'];
        $recCount = (string) $summary['reconciled_count'];
        $totPending = (string) $summary['total_pending_eur'];
        $pendCount = (string) $summary['pending_count'];
        $totDisc = (string) $summary['total_discrepancy_eur'];
        $misCount = (string) $summary['mismatch_count'];
        $ovdCount = (string) $summary['overdue_count'];
        // Approved mismatches explain why expected ≠ reconciled + pending.
        $acceptedCents = (int) ($summary['accepted_difference_cents'] ?? 0);
        $acceptedNote = (int) ($summary['accepted_difference_count'] ?? 0) > 0 && $acceptedCents !== 0
            ? ' · ' . sprintf(
                $acceptedCents > 0
                    ? AdminLocale::__('€%s less than expected was accepted', 'gr-commerce-suite')
                    : AdminLocale::__('€%s more than expected was accepted', 'gr-commerce-suite'),
                Money::fromCents(abs($acceptedCents))->toDecimalString()
            )
            : '';
        // Grouped by job: money (COD settlement and its risk list), shipping, catalogue, support.
        $tabs = [
            'reconciliation' => AdminLocale::__('COD Reconciliation & Audit', 'gr-commerce-suite'),
            'blacklist' => AdminLocale::__('COD Blacklist / Μαύρη Λίστα', 'gr-commerce-suite'),
            'pickup' => AdminLocale::__('Daily Pickup List (Λίστα Παραλαβής)', 'gr-commerce-suite'),
            'xml' => AdminLocale::__('Skroutz XML Feed', 'gr-commerce-suite'),
            'diagnostics' => AdminLocale::__('Diagnostics & Logs (Καταγραφή Συστήματος)', 'gr-commerce-suite'),
        ];
        if (!ModuleRegistry::isEnabled(ModuleRegistry::SKROUTZ)) {
            unset($tabs['xml']);
        }
        $groupStarts = ['pickup', 'xml', 'diagnostics'];
        $defaultTab = isset($_GET['grcs_skroutz_generated']) ? 'xml' : 'reconciliation';
        if (($_POST['grcs_cod_action'] ?? '') === 'blacklist') {
            $defaultTab = 'blacklist';
        }
        $requestedTab = $_GET['tab'] ?? $defaultTab;
        $activeTab = is_string($requestedTab) && isset($tabs[$requestedTab]) ? $requestedTab : $defaultTab;
        $feedUrl = SkroutzXmlGenerator::getPublicFeedUrl();
        ?>
        <div class="wrap grcs-ui grcs-admin-wrap grcs-cod-reconciliation-wrap">
            <?php AdminWorkspace::header(AdminLocale::__('GR Commerce Tools', 'gr-commerce-suite')); ?>
            <?php AdminWorkspace::navigation($activeTab === 'pickup' ? 'pickup' : ($activeTab === 'reconciliation' ? 'cod' : 'tools')); ?>

            <?php if ($this->noticeMessage !== null) : ?>
                <div class="notice notice-<?php echo esc_attr($this->noticeType); ?> is-dismissible">
                    <p><?php echo esc_html($this->noticeMessage); ?></p>
                </div>
            <?php endif; ?>

            <nav class="grcs-tabs" role="tablist" aria-label="<?php echo AdminLocale::esc_attr__('Commerce tools', 'gr-commerce-suite'); ?>">
                <?php foreach ($tabs as $tab => $label) : ?>
                    <a id="grcs-tab-<?php echo esc_attr($tab); ?>"
                       class="grcs-tab<?php echo $activeTab === $tab ? ' is-active' : ''; ?><?php echo in_array($tab, $groupStarts, true) ? ' grcs-tab--group-start' : ''; ?>"
                       href="<?php echo esc_url(admin_url('admin.php?page=' . self::MENU_SLUG . '&tab=' . $tab)); ?>"
                       role="tab" data-grcs-tab="<?php echo esc_attr($tab); ?>"<?php echo $tab === 'diagnostics' ? ' data-grcs-load-page="true"' : ''; ?>
                       aria-controls="grcs-panel-<?php echo esc_attr($tab); ?>"
                       aria-selected="<?php echo $activeTab === $tab ? 'true' : 'false'; ?>"
                       tabindex="<?php echo $activeTab === $tab ? '0' : '-1'; ?>"><?php echo esc_html($label); ?></a>
                <?php endforeach; ?>
            </nav>

            <div class="grcs-workspace"><main class="grcs-main">

            <section id="grcs-panel-pickup" role="tabpanel" aria-labelledby="grcs-tab-pickup"
                     data-grcs-panel="pickup" <?php echo $activeTab !== 'pickup' ? 'hidden' : ''; ?>>
                <?php $this->renderPickupList(); ?>
            </section>

            <section id="grcs-panel-reconciliation" role="tabpanel" aria-labelledby="grcs-tab-reconciliation"
                     data-grcs-panel="reconciliation" <?php echo $activeTab !== 'reconciliation' ? 'hidden' : ''; ?>>
            <h2><?php AdminLocale::esc_html_e('COD Financial Summary', 'gr-commerce-suite'); ?></h2>
            <div class="grcs-kpi-grid">
                <?php
                $kpis = [
                    ['blue', AdminLocale::__('Total Expected COD (€)', 'gr-commerce-suite'), '€' . $totExpected,
                        sprintf(AdminLocale::_n('%s voucher', '%s vouchers', (int) $totVouchers, 'gr-commerce-suite'), $totVouchers)],
                    ['green', AdminLocale::__('Recorded Reconciled COD (€)', 'gr-commerce-suite'), '€' . $totReconciled,
                        sprintf(AdminLocale::__('%s reconciled', 'gr-commerce-suite'), $recCount) . $acceptedNote],
                    ['amber', AdminLocale::__('Unreconciled Expected COD (€)', 'gr-commerce-suite'), '€' . $totPending,
                        sprintf(AdminLocale::__('%s unreconciled vouchers', 'gr-commerce-suite'), $pendCount)],
                    ['red', AdminLocale::__('Flagged Discrepancies (€)', 'gr-commerce-suite'), '€' . $totDisc, ''],
                    ['red', AdminLocale::__('Amount Mismatches', 'gr-commerce-suite'), $misCount, ''],
                    ['amber', AdminLocale::__('Overdue Unpaid', 'gr-commerce-suite'), $ovdCount,
                        sprintf(AdminLocale::__('Delivered more than %d days ago', 'gr-commerce-suite'), $overdueDays)],
                ];
                foreach ($kpis as [$color, $label, $value, $meta]) : ?>
                    <div class="grcs-kpi grcs-kpi--<?php echo esc_attr($color); ?>">
                        <p class="grcs-kpi__label"><?php echo esc_html($label); ?></p>
                        <p class="grcs-kpi__value"><?php echo esc_html($value); ?></p>
                        <p class="grcs-kpi__meta"><?php echo $meta !== '' ? esc_html($meta) : '&nbsp;'; ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
            <p class="grcs-muted"><?php AdminLocale::esc_html_e('Unreconciled expected COD includes returned parcels, unknown collection and unresolved discrepancies. It is not confirmed courier remittance owed. Accepted differences on reconciled vouchers are excluded; customer refunds are not deducted.', 'gr-commerce-suite'); ?></p>
            <?php if ((int) ($summary['unknown_reconciled_count'] ?? 0) > 0) : ?>
                <p class="grcs-muted"><?php echo esc_html(sprintf(
                    AdminLocale::__('Reconciled vouchers with unknown collection: %1$s (€%2$s expected). Their unknown receipts are excluded from the reconciled amount and are not accepted shortfalls.', 'gr-commerce-suite'),
                    (string) $summary['unknown_reconciled_count'],
                    Money::fromCents((int) $summary['unknown_reconciled_expected_cents'])->toDecimalString()
                )); ?></p>
            <?php endif; ?>

            <!-- 2. Courier COD Payout CSV Statement Upload & Custom Column Mapping Form -->
            <div class="grcs-card">
                <h2 class="grcs-card__title">
                    <?php AdminLocale::esc_html_e('Upload Courier COD Payout CSV Statement', 'gr-commerce-suite'); ?>
                </h2>
                <p>
                    <?php
                    AdminLocale::esc_html_e(
                        'Upload the remittance CSV statement from ACS Courier, BOX NOW, or Geniki Taxydromiki '
                        . 'to compare collected amounts with your courier vouchers and order totals.',
                        'gr-commerce-suite'
                    );
                    ?>
                </p>

                <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="grcs_cod_action" value="upload_csv" />
                    <input type="hidden"
                           name="<?php echo esc_attr(self::NONCE_FIELD); ?>"
                           value="<?php echo esc_attr($csvNonce); ?>" />

                    <div class="grcs-form-grid">
                        <div class="grcs-field">
                            <label for="grcs_cod_courier"><?php AdminLocale::esc_html_e('Courier Provider', 'gr-commerce-suite'); ?><?php $this->renderHelpTip(AdminLocale::__('Choose the courier that provided this payout statement; find its name at the top of your remittance report.', 'gr-commerce-suite')); ?></label>
                                    <select id="grcs_cod_courier" name="courier">
                                        <option value="acs" <?php selected($selectedCourier->value, 'acs'); ?>>
                                            ACS Courier
                                        </option>
                                        <option value="boxnow" <?php selected($selectedCourier->value, 'boxnow'); ?>>
                                            BOX NOW
                                        </option>
                                        <option value="geniki" <?php selected($selectedCourier->value, 'geniki'); ?>>
                                            Geniki Taxydromiki
                                        </option>
                                    </select>
                        </div>
                        <div class="grcs-field">
                            <label for="grcs_cod_csv_file"><?php AdminLocale::esc_html_e('Payout CSV File', 'gr-commerce-suite'); ?><?php $this->renderHelpTip(AdminLocale::__('Upload the CSV remittance statement downloaded from your courier account or supplied by your local branch.', 'gr-commerce-suite')); ?></label>
                                    <input type="file" id="grcs_cod_csv_file" name="cod_csv_file" accept=".csv,.txt" />
                        </div>
                        <div class="grcs-field grcs-field--full">
                            <label for="grcs_overdue_days"><?php
                                AdminLocale::esc_html_e('Overdue Unpaid COD Threshold (Days)', 'gr-commerce-suite');
                                $this->renderHelpTip(AdminLocale::__('Flag delivered COD vouchers still unpaid after this many days. Set this to the settlement interval agreed with your courier.', 'gr-commerce-suite'));
                            ?></label>
                            <input type="number" id="grcs_overdue_days" name="overdue_days"
                                   value="<?php echo esc_attr((string) $overdueDays); ?>" min="1" max="365"
                                   class="grcs-input-narrow" />
                            <p class="grcs-help"><?php
                                AdminLocale::esc_html_e('Flag delivered COD vouchers unreconciled after this many days.', 'gr-commerce-suite');
                            ?></p>
                        </div>
                    </div>
                    <details class="grcs-details">
                        <summary><?php AdminLocale::esc_html_e('Advanced CSV Options', 'gr-commerce-suite'); ?></summary>
                        <div class="grcs-details__body">
                            <div class="grcs-field-group">
                                <p class="grcs-field-group__title"><?php
                                    AdminLocale::esc_html_e('Custom Column Mapping', 'gr-commerce-suite');
                                ?></p>
                                <p class="grcs-help"><?php
                                    AdminLocale::esc_html_e('Match these names to the column headings in your courier statement.', 'gr-commerce-suite');
                                ?></p>
                                <div class="grcs-form-grid">
                                    <?php
                                    $mappingLabels = [
                                        'voucher_no' => AdminLocale::__('Voucher Number Column', 'gr-commerce-suite'),
                                        'collected_amount' => AdminLocale::__('Collected Amount Column', 'gr-commerce-suite'),
                                        'settlement_ref' => AdminLocale::__('Settlement Ref Column', 'gr-commerce-suite'),
                                        'payout_date' => AdminLocale::__('Payout Date Column', 'gr-commerce-suite'),
                                    ];
                                    $mappingHelp = [
                                        'voucher_no' => AdminLocale::__('Exact CSV header containing the courier tracking/voucher number, e.g. Voucher_No. Find it in the first row of your courier payout statement.', 'gr-commerce-suite'),
                                        'collected_amount' => AdminLocale::__('Exact CSV header containing the COD amount collected for the shipment in euros, before fees. Find it in your courier payout statement.', 'gr-commerce-suite'),
                                        'settlement_ref' => AdminLocale::__('Exact CSV header containing the payout or settlement reference from your courier remittance statement.', 'gr-commerce-suite'),
                                        'payout_date' => AdminLocale::__('Exact CSV header containing the courier payout date. Find it in the first row of the remittance CSV.', 'gr-commerce-suite'),
                                    ];
                                    foreach ($mappingLabels as $key => $label) : ?>
                                        <div class="grcs-field">
                                            <label for="grcs_map_<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?><?php $this->renderHelpTip($mappingHelp[$key]); ?></label>
                                            <input type="text" id="grcs_map_<?php echo esc_attr($key); ?>"
                                                   name="map_<?php echo esc_attr($key); ?>"
                                                   value="<?php echo esc_attr($mapping[$key]); ?>" />
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="grcs-field">
                                    <label for="grcs_csv_raw_content">
                                        <?php AdminLocale::esc_html_e('Raw CSV Paste', 'gr-commerce-suite'); ?><?php $this->renderHelpTip(AdminLocale::__('Paste the CSV text including its header row instead of uploading a file. Copy it from your courier remittance statement.', 'gr-commerce-suite')); ?>
                                    </label>
                                    <?php $csvPh = 'voucher_no;collected_amount;settlement_ref;payout_date'; ?>
                                    <textarea id="grcs_csv_raw_content"
                                              name="csv_raw_content"
                                              rows="4"
                                              class="large-text code"
                                              placeholder="<?php echo esc_attr($csvPh); ?>"></textarea>
                            </div>
                        </div>
                    </details>

                    <div class="grcs-form-actions">
                        <button type="submit" class="button button-primary">
                            <?php AdminLocale::esc_html_e('Upload & Reconcile CSV Statement', 'gr-commerce-suite'); ?>
                        </button>
                    </div>
                </form>
            </div>

            <?php if (is_array($csvReport) && isset($csvReport['summary']) && is_array($csvReport['summary'])) : ?>
                <?php
                $repSum = $csvReport['summary'];
                $resTpl = AdminLocale::__(
                    'Processed %1$d rows: %2$d Exact Matches (€%3$s), %4$d Amount Mismatches '
                    . '(Discrepancy: €%5$s), %6$d Overdue Unpaid COD, %7$d Unmatched.',
                    'gr-commerce-suite'
                );
                ?>
                <div class="grcs-card grcs-card--info">
                    <h2 class="grcs-card__title">
                        <?php AdminLocale::esc_html_e('Latest CSV Statement Reconciliation Results', 'gr-commerce-suite'); ?>
                    </h2>
                    <p>
                        <?php
                        printf(
                            esc_html($resTpl),
                            (int) ($repSum['total_rows'] ?? 0),
                            (int) ($repSum['exact_match_count'] ?? 0),
                            esc_html((string) ($repSum['total_reconciled_eur'] ?? '0.00')),
                            (int) ($repSum['mismatch_count'] ?? 0),
                            esc_html((string) ($repSum['total_discrepancy_eur'] ?? '0.00')),
                            (int) ($repSum['overdue_count'] ?? 0),
                            (int) ($repSum['unmatched_count'] ?? 0)
                        );
                        ?>
                    </p>
                    <?php $this->renderUnmatchedRows($csvReport); ?>
                </div>
            <?php endif; ?>

            <!-- 3. Flagged Discrepancies: (b) Amount Mismatches (cod_collected != cod_amount) -->
            <div class="grcs-card">
            <div class="grcs-card__header"><h2 class="grcs-card__title">
                <?php
                AdminLocale::esc_html_e(
                    'Flagged Discrepancies — Amount Mismatches',
                    'gr-commerce-suite'
                );
                ?>
            </h2></div>
            <div class="grcs-table-wrap">
            <table class="widefat striped grcs-table grcs-cod-mismatches-table">
                <thead>
                    <tr>
                        <th><?php AdminLocale::esc_html_e('Voucher No', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Courier', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Order ID', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Expected COD (€)', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Collected COD (€)', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Difference (€)', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Settlement Ref', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Action', 'gr-commerce-suite'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($summary['mismatches'] === []) : ?>
                        <tr>
                            <td colspan="8" class="grcs-empty">
                                <?php AdminLocale::esc_html_e('No COD amount mismatches found.', 'gr-commerce-suite'); ?>
                            </td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($summary['mismatches'] as $mismatch) : ?>
                            <?php
                            $mVoucherId = (string) ($mismatch['voucher_id'] ?? 0);
                            $mSetRef = (string) ($mismatch['settlement_ref'] ?? 'MANUAL_APPROVED');
                            ?>
                            <tr id="grcs-cod-voucher-<?php echo esc_attr($mVoucherId); ?>">
                                <?php $anchoredVoucherIds[$mVoucherId] = true; ?>
                                <td><code><?php echo esc_html((string) ($mismatch['voucher_no'] ?? '')); ?></code></td>
                                <td><?php echo esc_html($this->courierLabel($mismatch['courier_slug'] ?? '')); ?></td>
                                <td><?php $this->renderOrderIdLink($mismatch['order_id'] ?? '', true); ?></td>
                                <td>&euro;<?php echo esc_html((string) ($mismatch['expected_eur'] ?? '0.00')); ?></td>
                                <td>&euro;<?php echo esc_html((string) ($mismatch['collected_eur'] ?? '0.00')); ?></td>
                                <td class="grcs-text-danger grcs-num">
                                    <span class="grcs-diff-pill">&euro;<?php
                                        echo esc_html((string) ($mismatch['difference_eur'] ?? '0.00'));
                                    ?></span>
                                </td>
                                <td><?php echo esc_html((string) ($mismatch['settlement_ref'] ?? '—')); ?></td>
                                <td>
                                    <form method="post" class="grcs-inline-form">
                                        <input type="hidden" name="grcs_cod_action" value="manual_reconcile" />
                                        <input type="hidden"
                                               name="<?php echo esc_attr(self::NONCE_FIELD); ?>"
                                               value="<?php echo esc_attr($manualNonce); ?>" />
                                        <input type="hidden"
                                               name="voucher_id"
                                               value="<?php echo esc_attr($mVoucherId); ?>" />
                                        <input type="hidden"
                                               name="settlement_ref"
                                               value="<?php echo esc_attr($mSetRef); ?>" />
                                        <button type="submit" class="button button-small">
                                            <?php AdminLocale::esc_html_e('Approve & Reconcile', 'gr-commerce-suite'); ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            </div></div>

            <!-- 4. Flagged Discrepancies: (c) Overdue Unpaid COD -->
            <div class="grcs-card">
            <div class="grcs-card__header"><h2 class="grcs-card__title">
                <?php
                printf(
                    AdminLocale::esc_html__('Overdue Unpaid COD Vouchers (Delivered > %d Days Ago)', 'gr-commerce-suite'),
                    (int) $overdueDays
                );
                ?>
            </h2></div>
            <div class="grcs-table-wrap">
            <table class="widefat striped grcs-table grcs-cod-overdue-table">
                <thead>
                    <tr>
                        <th><?php AdminLocale::esc_html_e('Voucher No', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Courier', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Order ID', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Expected COD (€)', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Delivered / Tracked At (UTC)', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Days Overdue', 'gr-commerce-suite'); ?></th>
                        <th><?php AdminLocale::esc_html_e('Action', 'gr-commerce-suite'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($summary['overdue_unpaid'] === []) : ?>
                        <tr>
                            <td colspan="7" class="grcs-empty">
                                <?php AdminLocale::esc_html_e('No overdue unpaid COD vouchers found.', 'gr-commerce-suite'); ?>
                            </td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ($summary['overdue_unpaid'] as $overdue) : ?>
                            <?php
                            $oVoucherId = (string) ($overdue['voucher_id'] ?? 0);
                            $oExpected = (string) ($overdue['expected_eur'] ?? '0.00');
                            $oDays = (int) ($overdue['days_overdue'] ?? $overdueDays);
                            ?>
                            <tr<?php if (!isset($anchoredVoucherIds[$oVoucherId])) : ?> id="grcs-cod-voucher-<?php echo esc_attr($oVoucherId); ?>"<?php endif; ?>>
                                <?php $anchoredVoucherIds[$oVoucherId] = true; ?>
                                <td><code><?php echo esc_html((string) ($overdue['voucher_no'] ?? '')); ?></code></td>
                                <td><?php echo esc_html($this->courierLabel($overdue['courier_slug'] ?? '')); ?></td>
                                <td><?php $this->renderOrderIdLink($overdue['order_id'] ?? '', true); ?></td>
                                <td><strong>&euro;<?php echo esc_html($oExpected); ?></strong></td>
                                <td><?php echo esc_html((string) ($overdue['delivered_at'] ?? '')); ?></td>
                                <td class="grcs-text-danger grcs-num">
                                    <?php printf(esc_html(AdminLocale::_n('%d day', '%d days', (int) $oDays, 'gr-commerce-suite')), (int) $oDays); ?>
                                </td>
                                <td>
                                    <form method="post" class="grcs-inline-form">
                                        <input type="hidden" name="grcs_cod_action" value="manual_reconcile" />
                                        <input type="hidden"
                                               name="<?php echo esc_attr(self::NONCE_FIELD); ?>"
                                               value="<?php echo esc_attr($manualNonce); ?>" />
                                        <input type="hidden"
                                               name="voucher_id"
                                               value="<?php echo esc_attr($oVoucherId); ?>" />
                                        <input type="hidden" name="settlement_ref" value="MANUAL_SETTLED" />
                                        <button type="submit" class="button button-small">
                                            <?php AdminLocale::esc_html_e('Mark Reconciled', 'gr-commerce-suite'); ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            </div></div>

            <!-- 5. Issued Courier Vouchers ({prefix}grcs_vouchers Custom Table) -->
                <div class="grcs-card">
                <div class="grcs-card__header"><h2 class="grcs-card__title">
                    <?php
                    AdminLocale::esc_html_e('Issued Courier Vouchers History', 'gr-commerce-suite');
                    ?>
                </h2></div>
                <div class="grcs-table-wrap">
                <table class="widefat striped grcs-table grcs-vouchers-custom-table">
                    <thead>
                        <tr>
                            <th><?php AdminLocale::esc_html_e('ID', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Order ID', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Courier', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Voucher No', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('State', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Tracking Status', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('COD Expected (€)', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('COD Collected (€)', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Reconciled', 'gr-commerce-suite'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($allVouchers === []) : ?>
                            <tr><td colspan="9" class="grcs-empty"><?php
                                AdminLocale::esc_html_e('No courier vouchers have been issued yet.', 'gr-commerce-suite');
                            ?></td></tr>
                        <?php endif; ?>
                        <?php foreach ($allVouchers as $vRow) : ?>
                            <tr<?php if (!isset($anchoredVoucherIds[(string) ($vRow['id'] ?? 0)])) : ?> id="grcs-cod-voucher-<?php echo esc_attr((string) ($vRow['id'] ?? 0)); ?>"<?php endif; ?>>
                                <td>#<?php echo esc_html((string) ($vRow['id'] ?? '')); ?></td>
                                <td><?php $this->renderOrderIdLink($vRow['order_id'] ?? '', true); ?></td>
                                <td><?php echo esc_html($this->courierLabel($vRow['courier_slug'] ?? '')); ?></td>
                                <td><code><?php echo esc_html((string) ($vRow['voucher_no'] ?? '—')); ?></code></td>
                                <?php
                                // Tracking and settlement only apply to a live COD voucher; a cancelled or
                                // failed voucher shows "—" instead of a contradictory "Pending"/"No".
                                $vLive = ($vRow['state'] ?? '') === 'created';
                                $vExpected = Money::fromDecimalString((string) ($vRow['cod_amount'] ?? '0.00'))->cents();
                                $vCollected = ($vRow['cod_collected'] ?? null) !== null
                                    ? Money::fromDecimalString((string) $vRow['cod_collected'])->cents() : null;
                                ?>
                                <td><?php $this->renderStatusPill((string) ($vRow['state'] ?? 'unknown')); ?></td>
                                <td><?php
                                if ($vLive) {
                                    $this->renderStatusPill((string) ($vRow['tracking_status'] ?? 'unknown'));
                                } else {
                                    echo '—';
                                }
                                ?></td>
                                <td>&euro;<?php echo esc_html((string) ($vRow['cod_amount'] ?? '0.00')); ?></td>
                                <td>
                                    <?php
                                    if ($vCollected === null) {
                                        echo '—';
                                    } else {
                                        echo '&euro;' . esc_html(Money::fromCents($vCollected)->toDecimalString());
                                        if ($vCollected !== $vExpected) {
                                            echo ' <span class="grcs-text-danger">(' . esc_html(($vCollected < $vExpected ? '−' : '+') . '€'
                                                . Money::fromCents(abs($vCollected - $vExpected))->toDecimalString()) . ')</span>';
                                        }
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if ($vLive && $vExpected > 0) {
                                        $this->renderStatusPill(!empty($vRow['cod_reconciled']) ? 'yes' : 'no');
                                    } else {
                                        echo '<span title="' . AdminLocale::esc_attr__('Nothing to collect for this voucher', 'gr-commerce-suite') . '">—</span>';
                                    }
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div></div>

            <!-- 7. Unknown Vouchers Resolution Section (if any vouchers are in state = 'unknown') -->
            <?php if ($unknownVouchers !== []) : ?>
                <div class="grcs-card grcs-card--warning">
                <div class="grcs-card__header"><h2 class="grcs-card__title"><?php
                    AdminLocale::esc_html_e('Vouchers Requiring Review', 'gr-commerce-suite');
                ?></h2></div>
                <div class="grcs-table-wrap">
                <table class="widefat striped grcs-table grcs-unknown-vouchers-table">
                    <thead>
                        <tr>
                            <th><?php AdminLocale::esc_html_e('ID', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Order ID', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Courier', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Last Error', 'gr-commerce-suite'); ?></th>
                            <th><?php AdminLocale::esc_html_e('Resolution', 'gr-commerce-suite'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($unknownVouchers as $unknownRow) : ?>
                            <?php
                            $uId = (string) ($unknownRow['id'] ?? 0);
                            $uCourier = $this->courierLabel($unknownRow['courier_slug'] ?? '');
                            $uPlaceholder = AdminLocale::__('Courier Voucher No', 'gr-commerce-suite');
                            ?>
                            <tr id="grcs-unknown-voucher-<?php echo esc_attr($uId); ?>">
                                <td>#<?php echo esc_html($uId); ?></td>
                                <td><?php $this->renderOrderIdLink($unknownRow['order_id'] ?? ''); ?></td>
                                <td><?php echo esc_html($uCourier); ?></td>
                                <td><?php echo esc_html(AdminLocale::display((string) ($unknownRow['last_error'] ?? ''))); ?></td>
                                <td>
                                    <form method="post" class="grcs-inline-form">
                                        <input type="hidden" name="grcs_cod_action" value="resolve_unknown" />
                                        <input type="hidden"
                                               name="<?php echo esc_attr(self::NONCE_FIELD); ?>"
                                               value="<?php echo esc_attr($unknownNonce); ?>" />
                                        <input type="hidden" name="voucher_id" value="<?php echo esc_attr($uId); ?>" />
                                        <input type="text"
                                               name="voucher_no"
                                               placeholder="<?php echo esc_attr($uPlaceholder); ?>"
                                               aria-label="<?php echo esc_attr($uPlaceholder); ?>"
                                               class="regular-text" />
                                        <?php $this->renderHelpTip(AdminLocale::__('Enter the voucher number confirmed in your courier portal or by your local branch before linking an uncertain shipment.', 'gr-commerce-suite')); ?>
                                        <button type="submit"
                                                name="resolution_action"
                                                value="created"
                                                class="button button-small button-primary">
                                            <?php AdminLocale::esc_html_e('Link Voucher', 'gr-commerce-suite'); ?>
                                        </button>
                                        <!-- Clear action requires reason and COD confirmation -->
                                        <input type="hidden" name="voucher_id" value="<?php echo esc_attr($uId); ?>" />
                                        <input type="text"
                                               name="clear_reason"
                                               placeholder="<?php echo esc_attr(AdminLocale::__('Reason for clearing (required)', 'gr-commerce-suite')); ?>"
                                               aria-label="<?php echo esc_attr(AdminLocale::__('Reason for clearing', 'gr-commerce-suite')); ?>"
                                               class="regular-text" style="width: 180px;" required />
                                        <?php
                                        $codAmount = (float) ($unknownRow['cod_amount'] ?? 0);
                                        if ($codAmount > 0) : ?>
                                            <label style="margin-left: 8px; font-size: 12px;">
                                                <input type="checkbox" name="confirmed_cod" value="yes" required />
                                                <?php AdminLocale::esc_html_e('I understand this COD voucher may create a duplicate if the original job surfaces.', 'gr-commerce-suite'); ?>
                                            </label>
                                        <?php endif; ?>
                                        <button type="submit"
                                                name="resolution_action"
                                                value="clear"
                                                class="button button-small"
                                                onclick="return confirm('<?php echo esc_js(AdminLocale::__('Clearing an unknown voucher allows a new voucher to be issued. If the original job exists at the courier, this may create a duplicate COD shipment. Are you sure?', 'gr-commerce-suite')); ?>');">
                                            <?php AdminLocale::esc_html_e('Clear / Mark Failed', 'gr-commerce-suite'); ?>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div></div>
            <?php endif; ?>
            </section>

            <section id="grcs-panel-blacklist" role="tabpanel" aria-labelledby="grcs-tab-blacklist"
                     data-grcs-panel="blacklist" <?php echo $activeTab !== 'blacklist' ? 'hidden' : ''; ?>>
                <?php $this->renderBlacklistSection(); ?>
            </section>

            <?php if (ModuleRegistry::isEnabled(ModuleRegistry::SKROUTZ)) : ?>
            <section id="grcs-panel-xml" role="tabpanel" aria-labelledby="grcs-tab-xml"
                     data-grcs-panel="xml" <?php echo $activeTab !== 'xml' ? 'hidden' : ''; ?>>
                <div class="grcs-card">
                    <div class="grcs-card__header"><div>
                        <h2 class="grcs-card__title"><?php AdminLocale::esc_html_e('Skroutz XML Feed', 'gr-commerce-suite'); ?></h2>
                        <p class="grcs-card__subtitle"><?php
                            AdminLocale::esc_html_e('Generate your product catalogue for Skroutz.gr.', 'gr-commerce-suite');
                        ?></p>
                    </div><a class="button" href="<?php echo esc_url(admin_url('admin.php?page=wc-settings&tab=gr_commerce_suite&section=skroutz')); ?>"><?php
                        AdminLocale::esc_html_e('Feed settings', 'gr-commerce-suite');
                    ?></a></div>
                    <?php AdminWorkspace::feedStatus(); ?>
                    <?php if (ModuleRegistry::isEnabled(ModuleRegistry::BESTPRICE)) : ?>
                    <p class="grcs-help grcs-bestprice-preview"><?php AdminLocale::esc_html_e('BestPrice is available for local preview only. No BestPrice feed is published. Do not submit the Skroutz URL to BestPrice.', 'gr-commerce-suite'); ?></p>
                    <?php endif; ?>
                    <div class="grcs-field">
                        <label for="grcs-feed-url-cod"><?php AdminLocale::esc_html_e('Public Skroutz XML Feed URL', 'gr-commerce-suite');
                        $this->renderHelpTip(AdminLocale::__('Submit this URL only in your Skroutz Merchants dashboard.', 'gr-commerce-suite')); ?></label>
                        <div class="grcs-copy-field">
                            <input type="text" id="grcs-feed-url-cod" value="<?php echo esc_attr($feedUrl); ?>" readonly />
                            <button type="button" class="button" data-grcs-copy="#grcs-feed-url-cod"><?php
                                AdminLocale::esc_html_e('Copy URL', 'gr-commerce-suite');
                            ?></button>
                        </div>
                    </div>
                    <form method="post" class="grcs-form-actions" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="grcs_generate_skroutz_xml" />
                        <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($feedNonce); ?>" />
                        <button type="submit" class="button button-primary"><?php
                            AdminLocale::esc_html_e('Generate Skroutz XML Feed Now', 'gr-commerce-suite');
                        ?></button>
                    </form>
                </div>
            </section>
            <?php endif; ?>
            <section id="grcs-panel-diagnostics" role="tabpanel" aria-labelledby="grcs-tab-diagnostics"
                     data-grcs-panel="diagnostics" <?php echo $activeTab !== 'diagnostics' ? 'hidden' : ''; ?>>
                <?php if ($activeTab === 'diagnostics') {
                    DiagnosticsPanel::render();
                } ?>
            </section>
            </main><?php AdminWorkspace::sidebar('tools', $activeTab); ?></div>
        </div>
        <?php
    }

    private function handleInlinePostSubmission(): void
    {
        $action = $this->sanitizeText((string) ($_POST['grcs_cod_action'] ?? ''));

        if ($action === 'blacklist' && $this->blacklist !== null) {
            $this->handleBlacklistSubmission();
            return;
        }

        if ($action === 'upload_csv') {
            if (!$this->verifyRequestNonce(self::NONCE_ACTION_CSV)) {
                $this->noticeMessage = AdminLocale::__('Security nonce verification failed.', 'gr-commerce-suite');
                $this->noticeType = 'error';
                return;
            }
            $this->processCsvUploadFromRequest();
            return;
        }

        if ($action === 'manual_reconcile') {
            if (!$this->verifyRequestNonce(self::NONCE_ACTION_MANUAL)) {
                $this->noticeMessage = AdminLocale::__('Security nonce verification failed.', 'gr-commerce-suite');
                $this->noticeType = 'error';
                return;
            }
            $voucherId = isset($_POST['voucher_id']) ? $this->sanitizeInt($_POST['voucher_id']) : 0;
            $settlementRef = isset($_POST['settlement_ref'])
                ? $this->sanitizeText((string) $_POST['settlement_ref'])
                : 'MANUAL';
            if ($voucherId > 0 && $this->reconciliationService->markManuallyReconciled($voucherId, $settlementRef)) {
                // Name the voucher and order the merchant knows, not the internal row ID.
                $row = $this->voucherRepository?->findById($voucherId);
                $this->noticeMessage = $row !== null && (string) ($row['voucher_no'] ?? '') !== ''
                    ? sprintf(AdminLocale::__('Voucher %1$s (order #%2$s) marked as reconciled.', 'gr-commerce-suite'),
                        (string) $row['voucher_no'], (string) ($row['order_id'] ?? ''))
                    : sprintf(AdminLocale::__('Voucher #%d marked as reconciled.', 'gr-commerce-suite'), $voucherId);
                $this->noticeType = 'success';
            }
            return;
        }

        if ($action === 'resolve_unknown' && $this->voucherLockService !== null) {
            if (!$this->verifyRequestNonce(self::NONCE_ACTION_UNKNOWN)) {
                $this->noticeMessage = AdminLocale::__('Security nonce verification failed.', 'gr-commerce-suite');
                $this->noticeType = 'error';
                return;
            }
            $voucherId = isset($_POST['voucher_id']) ? $this->sanitizeInt($_POST['voucher_id']) : 0;
            $resolution = isset($_POST['resolution_action'])
                ? $this->sanitizeText((string) $_POST['resolution_action'])
                : 'clear';
            $voucherNo = isset($_POST['voucher_no']) ? $this->sanitizeText((string) $_POST['voucher_no']) : null;

            try {
                $resolved = $voucherId > 0
                    && $this->voucherLockService->resolveUnknownVoucherManually($voucherId, $resolution, $voucherNo);
                if ($resolved) {
                    $this->noticeMessage = sprintf(
                        AdminLocale::__('Unknown voucher #%d resolved.', 'gr-commerce-suite'),
                        $voucherId
                    );
                    $this->noticeType = 'success';
                }
            } catch (Throwable $e) {
                $this->noticeMessage = AdminLocale::error($e->getMessage());
                $this->noticeType = 'error';
            }
        }
    }

    public function handleBlacklistSubmission(): void
    {
        LicenseManager::assertLicensed();
        if (
            !$this->canAccessReconciliation()
            || !$this->verifyRequestNonce(self::NONCE_ACTION_BLACKLIST)
            || $this->blacklist === null
        ) {
            $this->noticeMessage = AdminLocale::__('Permission or security nonce verification failed.', 'gr-commerce-suite');
            $this->noticeType = 'error';
            return;
        }
        $phone = is_string($_POST['blacklist_phone'] ?? null) ? wp_unslash($_POST['blacklist_phone']) : '';
        $email = is_string($_POST['blacklist_email'] ?? null) ? wp_unslash($_POST['blacklist_email']) : '';
        $operation = $_POST['blacklist_operation'] ?? '';
        try {
            $details = [];
            foreach (['ip', 'customer_name', 'postal_code', 'reason', 'notes'] as $field) {
                $details[$field] = is_string($_POST['blacklist_' . $field] ?? null)
                    ? sanitize_text_field(wp_unslash($_POST['blacklist_' . $field])) : '';
            }
            if ($operation === 'add' || $operation === 'remove') {
                $details['whitelisted'] = $operation === 'add' && isset($_POST['blacklist_whitelisted']);
                // Registry rows post stored digests back (GRCS-008); this admin handler is the trusted caller.
                $this->blacklist->setCustomer($phone, $email, $operation === 'add', $details, true);
            } elseif ($operation === 'whitelist' || $operation === 'unwhitelist') {
                $this->blacklist->whitelistCustomer($phone, $email, $operation === 'whitelist', ['ip' => $details['ip']], true);
            } elseif ($operation === 'rules') {
                $rules = is_array($_POST['blacklist_rules'] ?? null) ? wp_unslash($_POST['blacklist_rules']) : [];
                update_option(CodBlacklistService::OPTION_RULES, CodBlacklistService::sanitizeRules($rules), false);
            } elseif ($operation === 'import') {
                $raw = is_string($_POST['blacklist_import'] ?? null) ? wp_unslash($_POST['blacklist_import']) : '';
                $result = $this->blacklist->bulkImport($raw, $details['reason'], isset($_POST['blacklist_whitelisted']));
                $this->noticeMessage = sprintf(AdminLocale::__('Imported %1$d entries; skipped %2$d invalid lines.', 'gr-commerce-suite'), $result['added'], $result['invalid']);
                return;
            } elseif ($operation === 'notice' && is_string($_POST['blacklist_notice'] ?? null)) {
                update_option(
                    CodBlacklistService::OPTION_NOTICE,
                    sanitize_text_field(wp_unslash($_POST['blacklist_notice'])),
                    false
                );
            }
            $this->noticeMessage = AdminLocale::__(
                'Blacklist settings updated. Use Check Customer to view status and refusal counts.',
                'gr-commerce-suite'
            );
        } catch (Throwable $e) {
            $this->noticeMessage = AdminLocale::error($e->getMessage());
            $this->noticeType = 'error';
        }
    }

    public function renderBlacklistSection(): void
    {
        if ($this->blacklist === null || !$this->canAccessReconciliation()) {
            return;
        }
        LicenseManager::assertLicensed();
        CodBlacklistPanel::render($this->blacklist);
    }

    private function renderHelpTip(string $text): void
    {
        echo '<span class="grcs-tip" tabindex="0" role="img" data-tip="' . esc_attr($text) . '" aria-label="' . esc_attr($text) . '">?</span>';
    }

    /** @return array{0: string, 1: string} */
    public static function pickupDateRange(string $date): array
    {
        $zone = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('Europe/Athens');
        $start = DateTimeImmutable::createFromFormat('!Y-m-d', $date, $zone);
        if ($start === false || $start->format('Y-m-d') !== $date) {
            throw new \InvalidArgumentException(AdminLocale::__('Choose a valid date in YYYY-MM-DD format.', 'gr-commerce-suite'));
        }
        $utc = new DateTimeZone('UTC');
        return [$start->setTimezone($utc)->format('Y-m-d H:i:s'),
            $start->modify('+1 day')->setTimezone($utc)->format('Y-m-d H:i:s')];
    }

    public function renderPickupList(): void
    {
        LicenseManager::assertLicensed();
        if (!$this->canAccessReconciliation()) {
            return;
        }
        $today = (function_exists('wp_date') ? wp_date('Y-m-d') : false) ?:  (new DateTimeImmutable('now', new DateTimeZone('Europe/Athens')))->format('Y-m-d');
        $date = is_string($_GET['pickup_date'] ?? null) ? $_GET['pickup_date'] : $today;
        $courierValue = is_string($_GET['pickup_courier'] ?? null) ? $_GET['pickup_courier'] : '';
        $courierValue = CourierSlug::tryFrom($courierValue) !== null ? $courierValue : '';
        echo '<div class="grcs-card grcs-manifest-controls"><h2>'
            . AdminLocale::esc_html__('Daily Pickup List (Λίστα Παραλαβής)', 'gr-commerce-suite') . '</h2>';
        echo '<form method="get"><input type="hidden" name="page" value="' . esc_attr(self::MENU_SLUG) . '" />'
            . '<input type="hidden" name="tab" value="pickup" /><div class="grcs-form-grid"><div class="grcs-field"><label for="grcs-pickup-date">'
            . AdminLocale::esc_html__('Issue date', 'gr-commerce-suite');
        $this->renderHelpTip(AdminLocale::__('Date vouchers were issued, using your WordPress store timezone.', 'gr-commerce-suite'));
        echo '</label><input type="date" id="grcs-pickup-date" name="pickup_date" value="' . esc_attr($date) . '" required /></div>';
        echo '<div class="grcs-field"><label for="grcs-pickup-courier">' . AdminLocale::esc_html__('Courier', 'gr-commerce-suite');
        $this->renderHelpTip(AdminLocale::__('Choose a courier or All for the local driver pickup summary. This does not finalize Geniki jobs.', 'gr-commerce-suite'));
        echo '</label><select id="grcs-pickup-courier" name="pickup_courier">';
        foreach (['' => AdminLocale::__('All', 'gr-commerce-suite'), 'acs' => 'ACS', 'boxnow' => 'BOX NOW', 'geniki' => 'Geniki Taxydromiki'] as $value => $label) {
            echo '<option value="' . esc_attr($value) . '"' . selected($courierValue, $value, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></div></div><div class="grcs-form-actions"><button class="button button-primary" type="submit" name="pickup_show" value="1">'
            . AdminLocale::esc_html__('Get Receipt List / Print Manifest', 'gr-commerce-suite') . '</button></div></form></div>';
        if (!isset($_GET['pickup_show'])) {
            return;
        }
        try {
            [$start, $end] = self::pickupDateRange($date);
        } catch (\InvalidArgumentException $e) {
            echo '<p role="alert">' . esc_html(AdminLocale::error($e->getMessage())) . '</p>';
            return;
        }
        $rows = $this->voucherRepository?->findIssuedBetween($start, $end, CourierSlug::tryFrom($courierValue)) ?? [];
        $this->renderManifest($rows, $date);
    }

    /** @param list<array<string, mixed>> $rows */
    public function renderManifest(array $rows, string $date): void
    {
        LicenseManager::assertLicensed();
        if (!$this->canAccessReconciliation()) {
            return;
        }
        // An empty manifest is shown but never sent to the printer automatically.
        echo '<article class="grcs-card grcs-manifest"' . ($rows === [] ? ' data-grcs-empty' : '') . '><h2>' . AdminLocale::esc_html__('Λίστα Παραλαβής / Daily Pickup Manifest', 'gr-commerce-suite')
            . '</h2><p>' . esc_html(ShippingOptions::senderName() . ' — ' . $date) . '</p>';
        echo '<button type="button" class="button grcs-print-manifest">' . AdminLocale::esc_html__('Print A4 Manifest', 'gr-commerce-suite') . '</button>';
        echo '<table class="widefat grcs-table"><thead><tr>';
        foreach ([AdminLocale::__('Voucher No', 'gr-commerce-suite'), AdminLocale::__('Courier', 'gr-commerce-suite'), AdminLocale::__('Order ID', 'gr-commerce-suite'), AdminLocale::__('Recipient Name', 'gr-commerce-suite'), AdminLocale::__('Address/Locker', 'gr-commerce-suite'), AdminLocale::__('Pieces', 'gr-commerce-suite'), AdminLocale::__('Weight (kg)', 'gr-commerce-suite'), AdminLocale::__('COD Amount (€)', 'gr-commerce-suite')] as $label) {
            echo '<th>' . esc_html($label) . '</th>';
        }
        echo '</tr></thead><tbody>';
        $pieces = 0;
        $cod = 0;
        $codCount = 0;
        foreach ($rows as $row) {
            $order = wc_get_order((int) $row['order_id']);
            $snapshot = $order instanceof WC_Order ? $order->get_meta('_grcs_shipment_' . (int) $row['id'], true) : [];
            $snapshot = is_array($snapshot) ? $snapshot : [];
            $count = (int) ($snapshot['pieces'] ?? ($order instanceof WC_Order ? ShippingOptions::parcelCount($order) : 1));
            $weight = (float) ($snapshot['weight'] ?? ($order instanceof WC_Order ? ShippingOptions::weightKg($order) : 0));
            $recipient = (string) ($snapshot['recipient'] ?? ($order instanceof WC_Order
                ? trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name())
                    ?: trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()) : '—'));
            $address = (string) ($snapshot['address'] ?? ($order instanceof WC_Order
                ? ((string) $order->get_meta('_grcs_boxnow_locker_id', true) !== '' ? AdminLocale::__('Locker #', 'gr-commerce-suite') . $order->get_meta('_grcs_boxnow_locker_id', true)
                    : trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_city() . ' ' . $order->get_shipping_postcode())) : '—'));
            $amount = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0'))->cents();
            $pieces += $count;
            $cod += $amount;
            $codCount += $amount > 0 ? 1 : 0;
            echo '<tr><td>' . esc_html(implode(', ', ShippingOptions::voucherNumbers($row))) . '</td><td>' . esc_html($this->courierLabel($row['courier_slug'] ?? '')) . '</td><td>';
            $this->renderOrderIdLink($row['order_id']);
            foreach ([$recipient, $address, (string) $count, number_format($weight, 2, '.', ''), Money::fromCents($amount)->toDecimalString()] as $value) {
                echo '</td><td>' . esc_html($value);
            }
            echo '</td></tr>';
        }
        if ($rows === []) {
            echo '<tr><td colspan="8">' . AdminLocale::esc_html__('No issued vouchers found for this date and courier.', 'gr-commerce-suite') . '</td></tr>';
        }
        echo '</tbody></table><p class="grcs-manifest-totals">' . esc_html(sprintf(
            AdminLocale::__('Vouchers: %1$d · Total parcels: %2$d · COD shipments: %3$d · Total COD: €%4$s', 'gr-commerce-suite'),
            count($rows),
            $pieces,
            $codCount,
            Money::fromCents($cod)->toDecimalString()
        )) . '</p><p class="grcs-manifest-signature">' . AdminLocale::esc_html__('Courier driver name / signature: ____________________  Pickup time: __________', 'gr-commerce-suite') . '</p></article>';
    }

    private function renderStatusPill(string $status): void
    {
        $color = match ($status) {
            'created', 'delivered', 'yes' => 'green',
            'picked_up', 'in_transit', 'out_for_delivery', 'ready_for_pickup' => 'blue',
            'reserved', 'pending', 'unknown', 'no' => 'amber',
            'failed', 'delivery_failed', 'returning', 'returned', 'exception' => 'red',
            default => 'gray',
        };
        $label = match ($status) {
            'yes' => AdminLocale::__('Yes', 'gr-commerce-suite'),
            'no' => AdminLocale::__('No', 'gr-commerce-suite'),
            default => AdminLocale::status($status),
        };
        echo '<span class="grcs-pill grcs-pill--' . esc_attr($color) . '">' . esc_html($label) . '</span>';
    }

    private function courierLabel(mixed $slug): string
    {
        $courier = is_string($slug) ? CourierSlug::tryFrom(strtolower($slug)) : null;
        return $courier !== null ? $courier->label() : strtoupper(is_scalar($slug) ? (string) $slug : '');
    }

    /**
     * With $refundMarker, a refunded order also gets a "Refunded €X" pill: the courier's COD
     * collection in the row stays as recorded, and the pill keeps the refund from being missed.
     */
    private function renderOrderIdLink(mixed $orderId, bool $refundMarker = false): void
    {
        $id = $this->sanitizeInt($orderId);
        if ($id <= 0) {
            echo '#' . esc_html((string) $orderId);
            return;
        }
        if (!current_user_can('edit_shop_order', $id)) {
            echo '#' . esc_html((string) $id);
            return;
        }

        $url = '';
        $refunded = 0;
        if (function_exists('wc_get_order')) {
            try {
                $order = wc_get_order($id);
                if ($order instanceof WC_Order) {
                    $url = $order->get_edit_order_url();
                }
            } catch (Throwable) {
                $url = '';
            }
            try {
                // Informational only; never let it hide the order link.
                $refunded = $refundMarker && isset($order) && $order instanceof WC_Order ? (int) round((float) $order->get_total_refunded() * 100) : 0;
            } catch (Throwable) {
                $refunded = 0;
            }
        }

        if ($url !== '') {
            echo '<a class="grcs-order-link" href="' . esc_url($url) . '">#' . esc_html((string) $id) . '</a>';
            if ($refunded > 0) {
                echo ' <span class="grcs-pill grcs-pill--amber" title="' . AdminLocale::esc_attr__('Refunded in WooCommerce. The courier COD collection shown here is unchanged; open the order for details.', 'gr-commerce-suite') . '">'
                    . esc_html(sprintf(AdminLocale::__('Refunded €%s', 'gr-commerce-suite'), Money::fromCents($refunded)->toDecimalString())) . '</span>';
            }
            return;
        }

        echo '#' . esc_html((string) $id);
    }

    private function processCsvUploadFromRequest(): void
    {
        $courierRaw = isset($_POST['courier']) ? $this->sanitizeText((string) $_POST['courier']) : 'acs';
        $courier = CourierSlug::tryFrom(strtolower($courierRaw)) ?? CourierSlug::Acs;

        $columnMapping = [
            'voucher_no' => isset($_POST['map_voucher_no'])
                ? $this->sanitizeText((string) $_POST['map_voucher_no'])
                : '',
            'collected_amount' => isset($_POST['map_collected_amount'])
                ? $this->sanitizeText((string) $_POST['map_collected_amount'])
                : '',
            'settlement_ref' => isset($_POST['map_settlement_ref'])
                ? $this->sanitizeText((string) $_POST['map_settlement_ref'])
                : '',
            'payout_date' => isset($_POST['map_payout_date'])
                ? $this->sanitizeText((string) $_POST['map_payout_date'])
                : '',
        ];

        $overdueDays = isset($_POST['overdue_days']) ? max(1, $this->sanitizeInt($_POST['overdue_days'])) : null;

        try {
            if (
                isset($_FILES['cod_csv_file'])
                && is_array($_FILES['cod_csv_file'])
                && isset($_FILES['cod_csv_file']['tmp_name'])
                && is_string($_FILES['cod_csv_file']['tmp_name'])
                && trim($_FILES['cod_csv_file']['tmp_name']) !== ''
            ) {
                $tmpPath = $_FILES['cod_csv_file']['tmp_name'];
                if (
                    ($_FILES['cod_csv_file']['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK
                    || !is_uploaded_file($tmpPath)
                ) {
                    throw new \RuntimeException(
                        AdminLocale::__('The CSV upload did not complete successfully. Please upload it again.', 'gr-commerce-suite')
                    );
                }
                $this->lastUploadReport = $this->reconciliationService->reconcileCsvFile(
                    $tmpPath,
                    $courier,
                    $columnMapping,
                    $overdueDays
                );
            } elseif (
                isset($_POST['csv_raw_content'])
                && is_string($_POST['csv_raw_content'])
                && trim($_POST['csv_raw_content']) !== ''
            ) {
                $this->lastUploadReport = $this->reconciliationService->reconcileCsvContent(
                    wp_unslash($_POST['csv_raw_content']),
                    $courier,
                    $columnMapping,
                    $overdueDays
                );
            } else {
                $this->reconciliationService->saveColumnMapping($courier, $columnMapping);
                if ($overdueDays !== null) {
                    $this->reconciliationService->setOverdueDaysThreshold($overdueDays);
                }
                $this->noticeMessage = AdminLocale::__('COD column mapping and overdue settings saved.', 'gr-commerce-suite');
                $this->noticeType = 'success';
                return;
            }

            $this->setCsvReportNotice($this->lastUploadReport);
        } catch (Throwable $e) {
            $this->logger->error('COD CSV upload reconciliation error: ' . $e->getMessage());
            // Size and header validation fail before any settlement is written; only later failures can leave saved rows.
            $this->noticeMessage = AdminLocale::error($e->getMessage()) . ($e instanceof \InvalidArgumentException ? ''
                : ' ' . AdminLocale::__('Earlier rows may already be saved. Retry the same statement after correcting the problem; identical settlements will not be counted twice.', 'gr-commerce-suite'));
            $this->noticeType = 'error';
        }
    }

    /** @param array<string, mixed> $report */
    private function setCsvReportNotice(array $report): void
    {
        $sum = $report['summary'];
        $doneTpl = AdminLocale::__(
            'CSV reconciliation complete: %1$d exact matches (€%2$s), '
            . '%3$d mismatches (€%4$s difference), %5$d overdue unpaid.',
            'gr-commerce-suite'
        );
        $this->noticeMessage = sprintf(
            $doneTpl,
            (int) $sum['exact_match_count'],
            (string) $sum['total_reconciled_eur'],
            (int) $sum['mismatch_count'],
            (string) $sum['total_discrepancy_eur'],
            (int) $sum['overdue_count']
        );
        $unmatched = (int) ($sum['unmatched_count'] ?? 0);
        if ($unmatched > 0) {
            $this->noticeMessage .= ' ' . sprintf(AdminLocale::_n('%d statement entry needs review in Unmatched vouchers. Its amount is excluded from collected totals.',
                '%d statement entries need review in Unmatched vouchers. These amounts are excluded from collected totals.', $unmatched, 'gr-commerce-suite'), $unmatched);
        }
        $this->noticeType = ((int) $sum['mismatch_count'] > 0 || $unmatched > 0 || (int) $sum['overdue_count'] > 0) ? 'warning' : 'success';
    }

    private function verifyRequestNonce(string $action): bool
    {
        $nonce = isset($_POST[self::NONCE_FIELD])
            ? $this->sanitizeText((string) $_POST[self::NONCE_FIELD])
            : (isset($_POST['_wpnonce']) ? $this->sanitizeText((string) $_POST['_wpnonce']) : '');

        if ($nonce === '') {
            return false;
        }

        if (function_exists('wp_verify_nonce')) {
            return (bool) wp_verify_nonce($nonce, $action);
        }

        return false;
    }

    /**
     * @param array<string, int|string> $queryArgs
     */
    private function redirectBackToPage(array $queryArgs = []): void
    {
        $baseUrl = function_exists('admin_url')
            ? admin_url('admin.php?page=' . self::MENU_SLUG)
            : 'admin.php?page=' . self::MENU_SLUG;

        $targetUrl = function_exists('add_query_arg')
            ? add_query_arg($queryArgs, $baseUrl)
            : $baseUrl;

        if (function_exists('wp_safe_redirect')) {
            wp_safe_redirect($targetUrl);
            exit;
        }
    }

    private function sanitizeText(string $value): string
    {
        if (function_exists('sanitize_text_field')) {
            return sanitize_text_field($value);
        }

        return trim(strip_tags($value));
    }

    private function sanitizeInt(mixed $value): int
    {
        if (function_exists('absint')) {
            return absint($value);
        }

        return is_numeric($value) ? max(0, (int) $value) : 0;
    }
}
