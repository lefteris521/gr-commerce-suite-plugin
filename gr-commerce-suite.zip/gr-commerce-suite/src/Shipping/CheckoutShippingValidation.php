<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Frontend\CheckoutPaymentRules;
use GRCommerceSuite\Support\CheckoutValidation;
use GRCommerceSuite\Support\PhoneNormalizer;
use WC_Order;
use WP_Error;

/** Validate chosen, available rates; a zero price is never a courier identity. */
final class CheckoutShippingValidation implements HookSubscriberInterface
{
    /** Legacy allowlist option; retained for settings compatibility, never used to enable gateways. */
    public const BOXNOW_PAYMENTS = 'grcs_boxnow_payment_methods';
    /** BOX NOW "Pay on the Go": COD vouchers are sent with paymentMode=cod and the amount to collect. */
    public const BOXNOW_ALLOW_COD = 'grcs_boxnow_allow_cod';

    public function register(): void
    {
        add_filter('woocommerce_available_payment_gateways', [$this, 'gateways'], 110);
        add_filter('woocommerce_checkout_fields', [$this, 'checkoutFields'], 20);
        add_filter('woocommerce_billing_fields', [$this, 'billingFields'], 20);
        add_filter('pre_option_woocommerce_checkout_phone_field', [$this, 'phoneFieldVisibility']);
        add_filter('option_woocommerce_checkout_phone_field', [$this, 'phoneFieldVisibility']);
        add_action('woocommerce_after_checkout_validation', [$this, 'classic'], 20, 2);
        add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('wp_enqueue_scripts', [new \GRCommerceSuite\Frontend\CheckoutCharacterWarnings(), 'enqueueAssets']);
        add_action('woocommerce_checkout_create_order', [$this, 'order'], 90, 2);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'order'], 90, 2);
        add_action('woocommerce_after_calculate_totals', [$this, 'clearStaleLocker']);
        add_action('woocommerce_review_order_before_submit', [$this, 'paymentNotes']);
        add_filter('render_block_data', [$this, 'layout']);
    }

    /** Server postcode errors need field feedback after WooCommerce's required-field checks. */
    public function enqueueAssets(): void
    {
        if (!is_checkout() || is_order_received_page() || is_checkout_pay_page() || has_block('woocommerce/checkout')) {
            return;
        }
        wp_enqueue_script('grcs-postcode-feedback', plugins_url('assets/js/postcode-feedback.js', GRCS_PLUGIN_FILE),
            ['jquery', 'wc-checkout'], GRCS_VERSION, true);
    }

    /** Keep native order fields between shipping and payment without editing saved page content.
     * @param array<string, mixed> $block
     * @return array<string, mixed>
     */
    public function layout(array $block): array
    {
        if (($block['blockName'] ?? '') === 'woocommerce/checkout') {
            $required = self::requiresPhone($this->chosen());
            if ($required || $this->hasCourierRate()) {
                $attrs = is_array($block['attrs'] ?? null) ? $block['attrs'] : [];
                $attrs['showPhoneField'] = true;
                if ($required) {
                    $attrs['requirePhoneField'] = true;
                }
                $block['attrs'] = $attrs;
            }
            return $block;
        }
        if (
            ($block['blockName'] ?? '') !== 'woocommerce/checkout-fields-block'
            || !is_array($block['innerBlocks'] ?? null)
        ) {
            return $block;
        }
        $information = null;
        $children = array_values($block['innerBlocks']);
        foreach ($children as $key => $child) {
            if (($child['blockName'] ?? '') === 'woocommerce/checkout-additional-information-block') {
                $information = $key;
                break;
            }
        }
        if ($information === null) {
            return $block;
        }
        $field = $children[$information];
        array_splice($children, $information, 1);
        foreach ($children as $key => $child) {
            if (($child['blockName'] ?? '') === 'woocommerce/checkout-payment-block') {
                array_splice($children, $key, 0, [$field]);
                $block['innerBlocks'] = $children;
                break;
            }
        }
        return $block;
    }

    /**
     * @param array<string, mixed> $fields
     * @return array<string, mixed>
     */
    public function billingFields(array $fields): array
    {
        if (isset($fields['billing_phone']) && is_array($fields['billing_phone']) && self::requiresPhone($this->chosen())) {
            $fields['billing_phone']['required'] = true;
        }
        return $fields;
    }

    /** Current Checkout Blocks read the phone visibility option rather than legacy block attributes. */
    public function phoneFieldVisibility(mixed $value): mixed
    {
        if (self::requiresPhone($this->chosen())) {
            return 'required';
        }
        // Keep an input available when the shopper switches from another method to a courier.
        return $value === 'hidden' && $this->hasCourierRate() ? 'optional' : $value;
    }

    /**
     * @param array<string, mixed> $fields
     * @return array<string, mixed>
     */
    public function checkoutFields(array $fields): array
    {
        if (
            isset($fields['billing']['billing_phone']) && is_array($fields['billing']['billing_phone'])
            && self::requiresPhone($this->chosen())
        ) {
            $fields['billing']['billing_phone']['required'] = true;
        }
        return $fields;
    }

    /** @param array<int|string, mixed> $rates */
    public static function requiresPhone(array $rates): bool
    {
        foreach ($rates as $rate) {
            if (is_string($rate) && CourierSelection::fromEnabledRate($rate) !== null) {
                return true;
            }
        }
        return false;
    }

    /** @param array<int|string, mixed> $rates */
    public static function requiresMobilePhone(array $rates): bool
    {
        foreach ($rates as $rate) {
            if (is_string($rate) && CourierSelection::fromEnabledRate($rate) === CourierSlug::BoxNow) {
                return true;
            }
        }
        return false;
    }

    /** @param array<int|string, mixed> $rates */
    public static function phoneValid(string $phone, array $rates): bool
    {
        if (!self::requiresPhone($rates)) {
            return true;
        }
        return PhoneNormalizer::isValid($phone, self::requiresMobilePhone($rates));
    }

    /** @param array<int|string, mixed> $rates */
    public static function paymentAllowed(string $payment, array $rates): bool
    {
        if ($payment === '') {
            // WooCommerce validates missing payment when the order actually needs payment.
            return true;
        }
        foreach ($rates as $rate) {
            if (!is_string($rate)) {
                return false;
            }
            if (CourierSelection::fromEnabledRate($rate) !== CourierSlug::BoxNow) {
                continue;
            }
            // Collection requires explicit merchant confirmation of the contracted service.
            // Prepaid and dedicated BOX NOW gateways own their availability/Blocks compatibility.
            // A legacy courier allowlist must not remove already-available bank/card gateways.
            if ($payment === 'cod' && get_option(self::BOXNOW_ALLOW_COD, 'no') !== 'yes') {
                return false;
            }
        }
        return true;
    }

    /** @return array<int|string, string> */
    private function chosen(): array
    {
        $wc = function_exists('WC') ? WC() : null;
        if ($wc && $wc->cart && !$wc->cart->needs_shipping()) {
            return [];
        }
        $session = $wc->session ?? null;
        $chosen = $session ? $session->get('chosen_shipping_methods', []) : [];
        return is_array($chosen) ? array_filter($chosen, 'is_string') : [];
    }

    private function hasCourierRate(): bool
    {
        $wc = function_exists('WC') ? WC() : null;
        if (!$wc || !method_exists($wc, 'shipping')
            || ($wc->cart && !$wc->cart->needs_shipping())) {
            return false;
        }
        foreach ($wc->shipping()->get_packages() as $package) {
            if (self::requiresPhone(array_keys($package['rates'] ?? []))) {
                return true;
            }
        }
        return false;
    }

    /**
     * Classic Checkout: before_submit sits inside the #payment fragment WooCommerce refreshes on every
     * shipping/document change, so it can explain why cash on delivery disappeared and tell the
     * page whether the chosen courier needs a phone (the billing field itself is not re-rendered).
     */
    public function paymentNotes(): void
    {
        $rates = $this->chosen();
        echo '<div hidden data-grcs-phone-required="' . (self::requiresPhone($rates) ? 'yes' : 'no') . '"></div>';
        $wc = function_exists('WC') ? WC() : null;
        if (!$wc || !method_exists($wc, 'payment_gateways')) {
            return;
        }
        $gateways = $wc->payment_gateways()->payment_gateways();
        $cod = $gateways['cod'] ?? null;
        if (!is_object($cod) || !property_exists($cod, 'enabled') || $cod->enabled !== 'yes') {
            return;
        }
        $message = null;
        // The same filtered list WooCommerce is about to print; never point the customer at a method that is not there.
        $none = $wc->payment_gateways()->get_available_payment_gateways() === [];
        if (!self::paymentAllowed('cod', $rates)) {
            $message = $none
                ? __('Cash on delivery is not available for BOX NOW locker delivery, and no other payment method is offered for it. Choose a home-delivery courier to pay on delivery.', 'gr-commerce-suite')
                : __('Cash on delivery is not available for BOX NOW locker delivery. Choose another payment method, or a home-delivery courier to pay on delivery.', 'gr-commerce-suite');
        } elseif (CheckoutPaymentRules::invoiceDisablesCod() && CheckoutPaymentRules::documentType() === 'invoice') {
            $message = $none ? CheckoutPaymentRules::invoiceNoPaymentMessage() : CheckoutPaymentRules::invoiceCodMessage();
        }
        if ($message !== null) {
            echo '<p class="woocommerce-info grcs-payment-note" role="status">' . esc_html($message) . '</p>';
        }
    }

    /** @param array<string, mixed> $gateways
     * @return array<string, mixed>
     */
    public function gateways(array $gateways): array
    {
        foreach ($gateways as $id => $gateway) {
            if (!self::paymentAllowed((string) $id, $this->chosen())) {
                unset($gateways[$id]);
            }
        }
        return $gateways;
    }

    /** @param array<string, mixed> $data */
    public function classic(array $data, WP_Error $errors): void
    {
        $rates = is_array($data['shipping_method'] ?? null) ? $data['shipping_method'] : [];
        if (!$this->validSelection($rates)) {
            $errors->add('grcs_shipping_required', __('Choose an available shipping method for every delivery package.', 'gr-commerce-suite'));
        }
        if (is_string($data['payment_method'] ?? null) && !self::paymentAllowed($data['payment_method'], $rates)) {
            $errors->add('grcs_payment_incompatible', __('Choose a payment method supported by the selected courier. Cash on delivery is disabled for BOX NOW.', 'gr-commerce-suite'));
        }
        $address = !empty($data['ship_to_different_address'])
            && get_option('woocommerce_ship_to_destination', 'shipping') !== 'billing' ? 'shipping' : 'billing';
        if (self::requiresPhone($rates) && ($data[$address . '_country'] ?? '') === 'GR'
            && self::greekPostcode($data[$address . '_postcode'] ?? '') === null) {
            $errors->add('grcs_postcode_invalid', self::postcodeErrorMessage(),
                ['id' => $address . '_postcode', 'grcs-postcode' => true]);
        }
        if (self::requiresPhone($rates)) {
            $phone = $this->resolveClassicPhone($data);
            if (!self::phoneValid($phone, $rates)) {
                // The field id lets WooCommerce mark the phone input and show the message beside it.
                // WooCommerce copies billing into shipping_* unless a separate address was chosen.
                $field = !empty($data['ship_to_different_address']) && is_scalar($data['shipping_phone'] ?? null)
                    && trim((string) $data['shipping_phone']) !== '' ? 'shipping_phone' : 'billing_phone';
                $errors->add('grcs_phone_invalid', self::phoneErrorMessage(self::requiresMobilePhone($rates)), ['id' => $field, 'grcs-field' => true]);
            }
        }
    }

    public function order(WC_Order $order, mixed $request = null): void
    {
        if (
            (is_object($request) && method_exists($request, 'get_method')
            && in_array($request->get_method(), ['PUT', 'PATCH'], true))
        ) {
            return;
        }
        $chosen = $this->chosen();
        if (!$this->validSelection($chosen)) {
            CheckoutValidation::fail('grcs_shipping_required', __('Choose an available shipping method for every delivery package.', 'gr-commerce-suite'));
        }
        $orderRates = CourierSelection::orderRates($order);
        $rates = $orderRates !== [] ? $orderRates : $chosen;
        $payment = is_object($request) && method_exists($request, 'get_param') ? $request->get_param('payment_method') : null;
        $payment = is_string($payment) ? $payment : $order->get_payment_method();
        if (!self::paymentAllowed($payment, $rates)) {
            CheckoutValidation::fail('grcs_payment_incompatible', __('This payment method is unavailable for BOX NOW. Choose a compatible payment method.', 'gr-commerce-suite'));
        }
        if (self::requiresPhone($rates)) {
            $address = $order->get_shipping_country() !== '' ? 'shipping' : 'billing';
            $country = $order->{'get_' . $address . '_country'}();
            if ($country === 'GR') {
                $postcode = self::greekPostcode($order->{'get_' . $address . '_postcode'}());
                if ($postcode === null) {
                    CheckoutValidation::fail('grcs_postcode_invalid', self::postcodeErrorMessage());
                }
                $order->{'set_' . $address . '_postcode'}($postcode);
            }
        }
        if (self::requiresPhone($rates)) {
            [$billing, $shipping] = $this->resolveOrderPhones($order, $request);
            $combined = self::combinePhones($shipping, $billing);
            if (!self::phoneValid($combined, $rates)) {
                CheckoutValidation::fail('grcs_phone_invalid', self::phoneErrorMessage(self::requiresMobilePhone($rates)));
            }
            $primary = PhoneNormalizer::toE164($combined);
            $normalizedBilling = self::phoneValid($billing, $rates) ? PhoneNormalizer::toE164($billing) : $primary;
            $normalizedShipping = $shipping !== '' && PhoneNormalizer::isValid($shipping, self::requiresMobilePhone($rates))
                ? PhoneNormalizer::toE164($shipping)
                : ($shipping !== '' && !self::requiresMobilePhone($rates) && PhoneNormalizer::isValid($shipping, false)
                    ? PhoneNormalizer::toE164($shipping)
                    : $normalizedBilling);
            self::setOrderPhone($order, 'set_billing_phone', $normalizedBilling);
            self::setOrderPhone($order, 'set_shipping_phone', $normalizedShipping);
        }
    }

    private static function phoneErrorMessage(bool $mobileRequired): string
    {
        return $mobileRequired
            ? __('Enter a valid mobile telephone number for BOX NOW locker delivery (e.g. 69XXXXXXXX or +3069XXXXXXXX).', 'gr-commerce-suite')
            : __('Enter a valid customer telephone number for courier delivery (e.g. 69XXXXXXXX, 21XXXXXXXX or +30...).', 'gr-commerce-suite');
    }

    /** Accept whitespace only; never strip letters or punctuation into an apparently valid code. */
    public static function greekPostcode(mixed $value): ?string
    {
        if (!is_string($value)) {
            return null;
        }
        $postcode = preg_replace('/[\s\p{Z}]+/u', '', $value);
        // Same 10000–85999 range the courier voucher normalizer enforces, so checkout never
        // accepts a postcode that later blocks voucher creation.
        return is_string($postcode) && preg_match('/^[0-9]{5}$/D', $postcode) === 1
            && (int) $postcode >= 10000 && (int) $postcode <= 85999 ? $postcode : null;
    }

    private static function postcodeErrorMessage(): string
    {
        return __('Please enter a valid five-digit Greek delivery postcode (e.g. 10563).', 'gr-commerce-suite');
    }

    private static function combinePhones(string $shippingPhone, string $billingPhone): string
    {
        $shipping = trim($shippingPhone);
        $billing = trim($billingPhone);
        if ($shipping !== '' && $billing !== '' && $shipping !== $billing) {
            return $shipping . ',' . $billing;
        }
        return $shipping !== '' ? $shipping : $billing;
    }

    /** @param array<string, mixed> $data */
    private function resolveClassicPhone(array $data): string
    {
        $hasExplicit = array_key_exists('billing_phone', $data) || array_key_exists('shipping_phone', $data)
            || isset($_POST['billing_phone']) || isset($_POST['shipping_phone']);
        $billing = is_scalar($data['billing_phone'] ?? null) ? (string) $data['billing_phone']
            : (isset($_POST['billing_phone']) && is_string($_POST['billing_phone']) ? wp_unslash($_POST['billing_phone']) : '');
        $shipping = is_scalar($data['shipping_phone'] ?? null) ? (string) $data['shipping_phone']
            : (isset($_POST['shipping_phone']) && is_string($_POST['shipping_phone']) ? wp_unslash($_POST['shipping_phone']) : '');
        if (!$hasExplicit && function_exists('WC') && is_object(WC()->customer)) {
            $customer = WC()->customer;
            if (method_exists($customer, 'get_billing_phone')) {
                $billing = (string) $customer->get_billing_phone();
            }
            if (method_exists($customer, 'get_shipping_phone')) {
                $shipping = (string) $customer->get_shipping_phone();
            }
        }
        return self::combinePhones($shipping, $billing);
    }

    /** @return array{0: string, 1: string} */
    private function resolveOrderPhones(WC_Order $order, mixed $request): array
    {
        $reqBilling = null;
        $reqShipping = null;
        if (is_object($request) && method_exists($request, 'get_param')) {
            $billingAddress = $request->get_param('billing_address');
            if (is_array($billingAddress) && array_key_exists('phone', $billingAddress) && is_scalar($billingAddress['phone'])) {
                $reqBilling = (string) $billingAddress['phone'];
            }
            $shippingAddress = $request->get_param('shipping_address');
            if (is_array($shippingAddress) && array_key_exists('phone', $shippingAddress) && is_scalar($shippingAddress['phone'])) {
                $reqShipping = (string) $shippingAddress['phone'];
            }
            if ($reqBilling === null) {
                $direct = $request->get_param('billing_phone');
                if (is_string($direct)) {
                    $reqBilling = $direct;
                }
            }
            if ($reqShipping === null) {
                $direct = $request->get_param('shipping_phone');
                if (is_string($direct)) {
                    $reqShipping = $direct;
                }
            }
        } elseif (is_array($request)) {
            if (array_key_exists('billing_phone', $request) && is_scalar($request['billing_phone'])) {
                $reqBilling = (string) $request['billing_phone'];
            }
            if (array_key_exists('shipping_phone', $request) && is_scalar($request['shipping_phone'])) {
                $reqShipping = (string) $request['shipping_phone'];
            }
        }
        if ($reqBilling === null && isset($_POST['billing_phone']) && is_string($_POST['billing_phone'])) {
            $reqBilling = wp_unslash($_POST['billing_phone']);
        }
        if ($reqShipping === null && isset($_POST['shipping_phone']) && is_string($_POST['shipping_phone'])) {
            $reqShipping = wp_unslash($_POST['shipping_phone']);
        }
        if ($reqBilling !== null || $reqShipping !== null) {
            // Explicit checkout input must not be rescued by a stale customer/draft phone.
            return [trim($reqBilling ?? ''), trim($reqShipping ?? '')];
        }
        return [self::orderPhone($order, 'get_billing_phone'), self::orderPhone($order, 'get_shipping_phone')];
    }

    private static function orderPhone(WC_Order $order, string $getter): string
    {
        if (!method_exists($order, $getter) && !is_callable([$order, $getter])) {
            return '';
        }
        $value = $order->$getter();
        return is_string($value) ? trim($value) : '';
    }

    private static function setOrderPhone(WC_Order $order, string $setter, string $phone): void
    {
        if (!method_exists($order, $setter) && !is_callable([$order, $setter])) {
            return;
        }
        $order->$setter($phone);
    }

    /** @param array<int|string, mixed> $rates */
    private function validSelection(array $rates): bool
    {
        if (!WC()->cart || !WC()->cart->needs_shipping()) {
            return true;
        }
        $packages = WC()->shipping()->get_packages();
        if ($packages === []) {
            return false;
        }
        foreach ($packages as $key => $package) {
            if (!is_string($rates[$key] ?? null) || !isset($package['rates'][$rates[$key]])) {
                return false;
            }
        }
        return true;
    }

    public function clearStaleLocker(): void
    {
        if (!WC()->session) {
            return;
        }
        foreach ($this->chosen() as $rate) {
            if (CourierSelection::fromEnabledRate($rate) === CourierSlug::BoxNow) {
                return;
            }
        }
        WC()->session->set(ShippingContext::LOCKER, '');
    }
}
