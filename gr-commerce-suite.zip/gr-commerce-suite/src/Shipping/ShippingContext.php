<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping;

use GRCommerceSuite\Frontend\BoxNowCheckoutPicker;
use GRCommerceSuite\Frontend\CheckoutPaymentRules;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Support\Money;
use WC_Product;
use WP_REST_Request;

/** Synchronize checkout inputs before rating and include nonstandard inputs in WC's package hash. */
final class ShippingContext
{
    public const LOCKER = 'grcs_pricing_locker';
    public const HIDE_GENERIC_FREE_SHIPPING = 'grcs_hide_generic_free_shipping';

    public function register(): void
    {
        add_filter('woocommerce_cart_shipping_packages', [$this, 'packages'], 100);
        add_filter('woocommerce_cart_shipping_method_full_label', [$this, 'fullLabel'], 20, 2);
        add_action('woocommerce_after_shipping_rate', [$this, 'freeShippingHint'], 10, 2);
        add_filter('woocommerce_package_rates', [$this, 'filterPackageRates'], 20, 2);
        add_action('woocommerce_checkout_update_order_review', [$this, 'classic']);
        add_action('woocommerce_checkout_process', [$this, 'classicCheckout']);
        add_action('woocommerce_store_api_checkout_update_customer_from_request', [$this, 'storeCustomer'], 5, 2);
        add_filter('rest_request_before_callbacks', [$this, 'storeRequest'], 5, 3);
        add_action('woocommerce_blocks_loaded', [$this, 'registerStoreUpdate']);
        // Plugin boot can follow WooCommerce Blocks boot on plugins_loaded.
        if (did_action('woocommerce_blocks_loaded') > 0) {
            $this->registerStoreUpdate();
        }
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
        add_action('woocommerce_cart_calculate_fees', [$this, 'fees']);
        add_action('updated_option', [$this, 'invalidateSettings']);
        add_action('added_option', [$this, 'invalidateSettings']);
        add_action('deleted_option', [$this, 'invalidateSettings']);
    }

    public function invalidateSettings(string $option): void
    {
        if ($option === self::HIDE_GENERIC_FREE_SHIPPING
            || $option === ModuleRegistry::OPTION
            || preg_match('/^woocommerce_grcs_(?:acs|boxnow|geniki)_[0-9]+_settings$/D', $option) === 1) {
            if ($option === ModuleRegistry::OPTION) {
                ModuleRegistry::reset();
            }
            self::flushShippingCache();
        }
    }

    public static function flushShippingCache(): void
    {
        if (class_exists(\WC_Cache_Helper::class)) {
            \WC_Cache_Helper::get_transient_version('shipping', true);
        }
        // Also bust package hashes for successive saves within the same second.
        update_option('grcs_shipping_pricing_revision', wp_generate_uuid4(), false);
    }

    /**
     * Format zero-cost ACS and BOX NOW rates using the store's currency and number format.
     *
     * @param string $label
     * @param mixed $rate
     */
    public function fullLabel(string $label, mixed $rate): string
    {
        if (!is_object($rate) || !method_exists($rate, 'get_id') || !method_exists($rate, 'get_cost')) {
            return $label;
        }
        $rateId = (string) $rate->get_id();
        $courier = CourierSelection::fromEnabledRate($rateId);
        if ($courier === null) {
            return $label;
        }
        $rawCost = (string) $rate->get_cost();
        try {
            if (!Money::fromDecimalString($rawCost)->isZero()) {
                return $label;
            }
        } catch (\InvalidArgumentException) {
            return $label;
        }
        $title = method_exists($rate, 'get_label') ? trim((string) $rate->get_label()) : trim(wp_strip_all_tags($label));
        if ($title === '') {
            $title = match ($courier) {
                CourierSlug::Acs => __('ACS Courier', 'gr-commerce-suite'),
                CourierSlug::BoxNow => __('BOX NOW Locker Delivery', 'gr-commerce-suite'),
                CourierSlug::Geniki => __('Geniki Taxydromiki', 'gr-commerce-suite'),
            };
        }
        $zero = wc_price(0);
        if (str_contains($label, $zero)) {
            return $label;
        }
        return esc_html($title) . ' — ' . $zero;
    }

    /**
     * Classic cart and checkout: under a paid ACS or BOX NOW rate, how much more the package needs to
     * reach that courier's own free-shipping threshold. Uses the same line totals (after coupons,
     * before tax) as Rules::qualifiesForFreeShipping(), and says nothing when no threshold is set.
     */
    public function freeShippingHint(mixed $rate, mixed $index = 0): void
    {
        if (!is_object($rate) || !method_exists($rate, 'get_id') || !method_exists($rate, 'get_instance_id') || !method_exists($rate, 'get_cost')
            || CourierSelection::fromEnabledRate((string) $rate->get_id()) === null) {
            return;
        }
        try {
            if (Money::fromDecimalString((string) $rate->get_cost())->isZero()) {
                return;
            }
            $method = \WC_Shipping_Zones::get_shipping_method((int) $rate->get_instance_id());
            $threshold = $method instanceof ConfiguredShippingMethod ? $method->get_option('free_threshold', '') : '';
            $package = WC()->shipping()->get_packages()[$index] ?? null;
            if (!is_string($threshold) || trim($threshold) === '' || !is_array($package)) {
                return;
            }
            $remaining = Pricing\Rules::money($threshold)->cents();
            foreach ($package['contents'] ?? [] as $item) {
                $line = is_array($item) && is_numeric($item['line_total'] ?? null) ? (float) $item['line_total'] : 0.0;
                $remaining -= Money::fromDecimalString(sprintf('%.2f', $line))->cents();
            }
        } catch (\InvalidArgumentException) {
            return;
        }
        if ($remaining <= 0) {
            return;
        }
        $amount = html_entity_decode(wp_strip_all_tags(wc_price($remaining / 100)), ENT_QUOTES, 'UTF-8');
        echo '<br><small class="grcs-free-shipping-hint">'
            . esc_html(sprintf(__('Απομένουν %s για δωρεάν αποστολή.', 'gr-commerce-suite'), $amount)) . '</small>';
    }

    /**
     * Preserve merchant WooCommerce Free shipping methods by default.
     * When the optional GRCS filter is explicitly enabled, only hide generic free_shipping
     * in packages that already have an eligible GRCS courier rate, keeping Local Pickup and other methods intact.
     *
     * @param array<string, mixed> $rates
     * @param array<string, mixed> $package
     * @return array<string, mixed>
     */
    public function filterPackageRates(array $rates, array $package = []): array
    {
        if (get_option(self::HIDE_GENERIC_FREE_SHIPPING, 'no') !== 'yes') {
            return $rates;
        }
        $hasCourierRate = false;
        foreach ($rates as $rateId => $rate) {
            if (CourierSelection::fromEnabledRate((string) $rateId) !== null) {
                $hasCourierRate = true;
                break;
            }
        }
        if (!$hasCourierRate) {
            return $rates;
        }
        foreach ($rates as $rateId => $rate) {
            $methodId = is_object($rate) && method_exists($rate, 'get_method_id') ? (string) $rate->get_method_id() : '';
            if (($methodId === 'free_shipping' || str_starts_with((string) $rateId, 'free_shipping:'))
                && CourierSelection::fromEnabledRate((string) $rateId) === null) {
                unset($rates[$rateId]);
            }
        }
        return $rates;
    }

    /** @param \WC_Cart $cart */
    public function fees($cart): void
    {
        if (self::paymentMethod() !== 'cod'
            || !WC()->session || (is_admin() && !wp_doing_ajax())) {
            return;
        }
        $chosen = WC()->session->get('chosen_shipping_methods', []);
        if (!CheckoutShippingValidation::paymentAllowed('cod', is_array($chosen) ? $chosen : [])) {
            return;
        }
        $totals = self::codHandlingCents(is_array($chosen) ? $chosen : []);
        // With BOX NOW the cod gateway is Pay on the Go (a payment link, not cash); name the fee to match.
        $payOnTheGo = CheckoutPaymentRules::usesEnabledBoxNow(is_array($chosen) ? $chosen : []);
        foreach ($totals as $group => $cents) {
            if ($cents > 0) {
                $label = $payOnTheGo ? __('Χρέωση BOX NOW Pay on the Go', 'gr-commerce-suite') : __('Αντικαταβολή', 'gr-commerce-suite');
                if ($group === 'none' && isset($totals['taxable'])) {
                    $label .= ' (' . __('χωρίς ΦΠΑ', 'gr-commerce-suite') . ')';
                }
                if (method_exists($cart, 'get_fees')) {
                    $alreadyAdded = false;
                    foreach ((array) $cart->get_fees() as $existingFee) {
                        $existingName = is_object($existingFee) ? ($existingFee->name ?? '') : ($existingFee['name'] ?? '');
                        if ($existingName === $label) {
                            $alreadyAdded = true;
                            break;
                        }
                    }
                    if ($alreadyAdded) {
                        continue;
                    }
                }
                $cart->add_fee($label, $cents / 100, $group === 'taxable');
            }
        }
    }

    /**
     * COD handling cents per tax group for the chosen GRCS rates. The single source for both the
     * cart fee and the amount named in the payment description before the customer selects COD.
     *
     * @param array<int|string, mixed> $chosen
     * @return array<string, int>
     */
    public static function codHandlingCents(array $chosen): array
    {
        $totals = [];
        foreach (WC()->shipping()->get_packages() as $key => $package) {
            $rate = $chosen[$key] ?? '';
            if (!is_string($rate) || !isset($package['rates'][$rate])
                || preg_match('/^grcs_(acs|boxnow):([0-9]+)$/D', $rate, $match) !== 1) {
                continue;
            }
            $method = \WC_Shipping_Zones::get_shipping_method((int) $match[2]);
            if (!$method instanceof ConfiguredShippingMethod) {
                continue;
            }
            $mode = (string) $method->get_option('pricing_mode', 'fixed');
            try {
                if ($mode === 'dynamic') {
                    if (wc_get_price_decimals() !== 2
                        || Pricing\Settings::configurationErrors($method->instance_settings, $match[1] === 'acs') !== []) {
                        continue;
                    }
                    // Paid fallback prices are already all-inclusive. Charge only eligible dynamic packages.
                    $calculator = $match[1] === 'acs' ? new Pricing\AcsRuleCalculator() : new Pricing\BoxNowRuleCalculator();
                    $calculator->calculate($package, $method->instance_settings, self::locker(), false);
                } elseif ($mode === 'fixed') {
                    $rawCost = $method->get_option('cost', '');
                    $costStr = is_string($rawCost) || is_int($rawCost) || is_float($rawCost) ? trim((string) $rawCost) : '';
                    if ($costStr === '' || Money::fromDecimalString($costStr)->cents() < 0) {
                        continue;
                    }
                } else {
                    continue;
                }
                $rawCod = $method->get_option('cod_handling', '0');
                $codStr = is_string($rawCod) || is_int($rawCod) || is_float($rawCod) ? trim((string) $rawCod) : '0';
                $cents = $codStr === '' ? 0 : Pricing\Rules::money($codStr)->cents();
                if ($cents <= 0) {
                    continue;
                }
                $taxable = $method->get_option('tax_status', 'taxable') !== 'none';
                $group = $taxable ? 'taxable' : 'none';
                $totals[$group] = Pricing\Rules::addCents($totals[$group] ?? 0, $cents);
            } catch (\InvalidArgumentException | \JsonException) {
                continue;
            }
        }
        return $totals;
    }

    public function registerStoreUpdate(): void
    {
        if (function_exists('woocommerce_store_api_register_update_callback')) {
            woocommerce_store_api_register_update_callback([
                'namespace' => 'grcs-shipping-pricing', 'callback' => [$this, 'update'],
            ]);
        }
    }

    public static function locker(): string
    {
        $value = WC()->session ? WC()->session->get(self::LOCKER, '') : '';
        return self::cleanLocker($value);
    }

    public static function paymentMethod(): string
    {
        $value = WC()->session ? WC()->session->get('chosen_payment_method', '') : '';
        return is_string($value) ? $value : '';
    }

    private static function cleanLocker(mixed $value): string
    {
        return is_string($value) && preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', trim($value)) === 1 ? trim($value) : '';
    }

    /** Store API cart/extensions performs the totals recalculation after this callback. */
    public function update(mixed $data): void
    {
        if (!is_array($data) || !WC()->session) {
            return;
        }
        if (array_key_exists('locker', $data)) {
            WC()->session->set(self::LOCKER, self::cleanLocker($data['locker']));
        }
        if (is_string($data['payment_method'] ?? null)) {
            WC()->session->set('chosen_payment_method', sanitize_key($data['payment_method']));
        }
    }

    public function classic(string $posted): void
    {
        wp_parse_str($posted, $data);
        $values = ['payment_method' => $data['payment_method'] ?? ''];
        if (array_key_exists('grcs_boxnow_locker_id', $data)) {
            $values['locker'] = $data['grcs_boxnow_locker_id'];
        }
        $this->update($values);
    }

    public function classicCheckout(): void
    {
        $this->update([
            'locker' => isset($_POST['grcs_boxnow_locker_id']) ? wp_unslash($_POST['grcs_boxnow_locker_id']) : '',
            'payment_method' => isset($_POST['payment_method']) ? wp_unslash($_POST['payment_method']) : '',
        ]);
    }

    /** @param mixed $customer */
    public function storeCustomer($customer, WP_REST_Request $request): void
    {
        $this->captureRequest($request);
    }

    /**
     * @param mixed $response
     * @param mixed $handler
     * @return mixed
     */
    public function storeRequest($response, $handler, WP_REST_Request $request): mixed
    {
        if ($response === null && preg_match('#^/wc/store/v[0-9]+/checkout/?$#D', $request->get_route()) === 1
            && in_array($request->get_method(), ['POST', 'PUT', 'PATCH'], true)) {
            $this->captureRequest($request);
        }
        return $response;
    }

    private function captureRequest(WP_REST_Request $request): void
    {
        $fields = $request->get_param('additional_fields');
        $data = [];
        if (is_array($fields) && array_key_exists(BoxNowCheckoutPicker::FIELD_ID, $fields)) {
            $data['locker'] = $fields[BoxNowCheckoutPicker::FIELD_ID];
        }
        // Retain compatibility with the picker's existing extension input.
        $extensions = $request->get_param('extensions');
        if (!array_key_exists('locker', $data) && is_array($extensions)
            && is_array($extensions['gr-commerce-suite'] ?? null)
            && array_key_exists('boxnow_locker_id', $extensions['gr-commerce-suite'])) {
            $data['locker'] = $extensions['gr-commerce-suite']['boxnow_locker_id'];
        }
        if (!array_key_exists('locker', $data)) {
            $legacy = $request->get_param('grcs_boxnow_locker_id');
            if ($legacy !== null) {
                $data['locker'] = $legacy;
            }
        }
        $payment = $request->get_param('payment_method');
        if (is_string($payment)) {
            $data['payment_method'] = $payment;
        }
        $this->update($data);
    }

    /**
     * @param array<int|string, mixed> $packages
     * @return array<int|string, mixed>
     */
    public function packages(array $packages): array
    {
        foreach ($packages as &$package) {
            if (!is_array($package)) {
                continue;
            }
            $products = [];
            foreach ($package['contents'] ?? [] as $key => $item) {
                $product = $item['data'] ?? null;
                if ($product instanceof WC_Product) {
                    // WC removes product objects from its cache hash. Explicitly include rating inputs.
                    $products[$key] = [$product->get_weight(), $product->get_length(), $product->get_width(),
                        $product->get_height(), $product->needs_shipping()];
                }
            }
            $package['grcs_pricing_context'] = [
                'version' => 1, 'locker' => self::locker(), 'payment' => self::paymentMethod(),
                'products' => $products, 'weight_unit' => get_option('woocommerce_weight_unit', 'kg'),
                'dimension_unit' => get_option('woocommerce_dimension_unit', 'cm'),
                'decimals' => wc_get_price_decimals(),
                'settings_revision' => get_option('grcs_shipping_pricing_revision', ''),
                'couriers' => [ModuleRegistry::isEnabled(ModuleRegistry::ACS), ModuleRegistry::courierCanCreate(CourierSlug::BoxNow), ModuleRegistry::isEnabled(ModuleRegistry::GENIKI)],
            ];
        }
        unset($package);
        return $packages;
    }

    public function enqueue(): void
    {
        if (!function_exists('is_checkout') || !is_checkout()) {
            return;
        }
        $dependencies = ['jquery', 'wp-data'];
        if (function_exists('has_block') && has_block('woocommerce/checkout')) {
            $dependencies[] = 'wc-blocks-checkout';
        }
        wp_enqueue_script('grcs-shipping-pricing', plugins_url('assets/js/shipping-pricing.js', GRCS_PLUGIN_FILE),
            $dependencies, GRCS_VERSION, true);
        wp_localize_script('grcs-shipping-pricing', 'grcsShippingPricing', [
            'error' => __('Shipping could not be updated. Please try again.', 'gr-commerce-suite'),
        ]);
    }
}
