<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping;

final class BoxNowShippingMethod extends ConfiguredShippingMethod
{
    protected function methodId(): string
    {
        return 'grcs_boxnow';
    }

    protected function defaultTitle(): string
    {
        return __('BOX NOW Locker Delivery', 'gr-commerce-suite');
    }
}
