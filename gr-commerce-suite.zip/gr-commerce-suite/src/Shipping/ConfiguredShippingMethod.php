<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping;

use GRCommerceSuite\I18n\AdminLocale;

use Exception;
use GRCommerceSuite\Shipping\Pricing\AcsRuleCalculator;
use GRCommerceSuite\Shipping\Pricing\BoxNowRuleCalculator;
use GRCommerceSuite\Shipping\Pricing\Parcel;
use GRCommerceSuite\Shipping\Pricing\Rules;
use GRCommerceSuite\Shipping\Pricing\Settings;
use GRCommerceSuite\Support\Money;
use InvalidArgumentException;
use JsonException;
use WC_Shipping_Method;

/** A zone-specific, merchant-priced rate. Rating never contacts a courier. */
abstract class ConfiguredShippingMethod extends WC_Shipping_Method
{
    abstract protected function methodId(): string;

    abstract protected function defaultTitle(): string;

    public function __construct(int $instance_id = 0)
    {
        parent::__construct($instance_id);
        $this->id = $this->methodId();
        // Method name is admin chrome; the editable/default rate title is customer data.
        $this->method_title = AdminLocale::display($this->defaultTitle());
        $this->method_description = AdminLocale::__('Merchant fixed or dynamic delivery prices for this zone. No live courier quotes.', 'gr-commerce-suite');
        $this->supports = ['shipping-zones', 'instance-settings', 'instance-settings-modal'];
        $this->instance_form_fields = [
            'enabled' => [
                'title' => AdminLocale::__('Enable/Disable', 'gr-commerce-suite'),
                'type' => 'checkbox',
                'label' => AdminLocale::__('Enable this shipping method', 'gr-commerce-suite'),
                'default' => 'yes',
            ],
            'title' => [
                'title' => AdminLocale::__('Title', 'gr-commerce-suite'),
                'type' => 'text',
                'default' => $this->defaultTitle(),
            ],
            'cost' => [
                'title' => AdminLocale::__('Shipping cost', 'gr-commerce-suite'),
                'type' => 'price',
                'class' => 'grcs-pricing-fixed',
                'description' => AdminLocale::__('Cost in store currency, excluding tax. Enter 0 for free delivery. A blank cost offers no rate.', 'gr-commerce-suite'),
                'default' => '',
            ],
            'tax_status' => [
                'title' => AdminLocale::__('Tax status', 'gr-commerce-suite'),
                'type' => 'select',
                'default' => 'taxable',
                'options' => [
                    'taxable' => AdminLocale::__('Taxable', 'gr-commerce-suite'),
                    'none' => AdminLocale::__('None', 'gr-commerce-suite'),
                ],
            ],
        ] + Settings::fields($this->id === 'grcs_acs');
        $this->init_instance_settings();
        $this->enabled = (string) $this->get_option('enabled', 'yes');
        $this->title = (string) $this->get_option('title', $this->defaultTitle());
        $this->tax_status = $this->get_option('tax_status', 'taxable') === 'none' ? 'none' : 'taxable';
        add_action('woocommerce_update_options_shipping_' . $this->id, function (): void {
            $this->process_admin_options();
        });
    }

    /** Validate the complete instance before writing; WC's default save permits partial invalid settings. */
    public function process_admin_options()
    {
        if (!$this->instance_id) {
            return parent::process_admin_options();
        }
        if (!isset($_REQUEST['instance_id']) || absint($_REQUEST['instance_id']) !== $this->instance_id) {
            return false;
        }
        $this->init_instance_settings();
        $values = $this->instance_settings;
        $post = $this->get_post_data();
        try {
            $mode = $this->validate_pricing_mode_field('pricing_mode',
                $post[$this->get_field_key('pricing_mode')] ?? $this->get_option('pricing_mode', 'fixed'));
        } catch (Exception $error) {
            $this->add_error(AdminLocale::error($error->getMessage()));
            return false;
        }
        $values['pricing_mode'] = $mode;
        $pricingFields = Settings::fields($this->id === 'grcs_acs');
        foreach ($this->get_instance_form_fields() as $key => $field) {
            // Keep inactive settings intact, including the legacy cost when Dynamic is selected.
            if (
                ($mode === 'fixed' && isset($pricingFields[$key]) && !in_array($key, ['free_threshold', 'cod_handling'], true))
                || ($mode === 'dynamic' && $key === 'cost')
                || $this->get_field_type($field) === 'title'
            ) {
                continue;
            }
            if (!array_key_exists($this->get_field_key($key), $post) && $this->get_field_type($field) !== 'checkbox') {
                continue;
            }
            try {
                $values[$key] = $this->get_field_value($key, $field, $post);
            } catch (Exception $error) {
                $this->add_error($field['title'] . ': ' . AdminLocale::error($error->getMessage()));
            }
        }
        if ($mode === 'dynamic') {
            foreach (Settings::configurationErrors($values, $this->id === 'grcs_acs', true) as $error) {
                $this->add_error($error);
            }
        }
        if ($this->get_errors()) {
            return false;
        }
        $this->instance_settings = apply_filters('woocommerce_shipping_' . $this->id . '_instance_settings_values', $values, $this);
        return update_option($this->get_instance_option_key(), $this->instance_settings, true);
    }

    public function get_admin_options_html()
    {
        $this->init_instance_settings();
        $html = parent::get_admin_options_html();
        $errors = $this->get_option('pricing_mode', 'fixed') === 'dynamic'
            ? Settings::configurationErrors($this->instance_settings, $this->id === 'grcs_acs', true) : [];
        $notice = '';
        if ($errors !== []) {
            $notice = '<div class="notice notice-error grcs-pricing-configuration-errors" role="alert"><p>'
                . esc_html(AdminLocale::__('Dynamic pricing configuration is incomplete. This method cannot offer dynamic rates until these errors are corrected:', 'gr-commerce-suite'))
                . '</p><ul>';
            foreach ($errors as $error) {
                $notice .= '<li>' . esc_html($error) . '</li>';
            }
            $notice .= '</ul></div>';
        }
        // Keep one stable root when WooCommerce replaces form tables inside its modal.
        return '<div class="grcs-pricing-settings">' . $notice . $html . '</div>';
    }

    /**
     * Keep the entered decimal intact: WC's localized price mask removes keypad periods.
     * @param array<string, mixed> $data
     */
    public function generate_price_html($key, $data)
    {
        $data['type'] = 'text';
        $data['custom_attributes']['inputmode'] = 'decimal';
        // Text rendering also reloads canonical stored decimals without locale/grouping conversion.
        return $this->generate_text_html($key, $data);
    }

    /**
     * @param string $key
     * @param mixed $value
     */
    public function validate_pricing_mode_field($key, $value): string
    {
        if (!in_array($value, ['fixed', 'dynamic'], true)) {
            throw new Exception(AdminLocale::__('Select Fixed price or Dynamic merchant rules.', 'gr-commerce-suite'));
        }
        return $value;
    }

    /**
     * @param array<string, mixed> $package
     */
    public function calculate_shipping($package = []): void
    {
        if ($this->id === 'grcs_boxnow' && !\GRCommerceSuite\Modules\ModuleRegistry::courierCanCreate(\GRCommerceSuite\Domain\Shared\CourierSlug::BoxNow)) {
            return;
        }
        // Zone activation and instance settings are independent switches in WooCommerce.
        if ($this->instance_id <= 0 || !$this->is_enabled()) {
            return;
        }
        // WooCommerce may reuse a zone method object after settings/cache invalidation.
        $this->init_instance_settings();
        if ($this->get_option('enabled', 'yes') !== 'yes') {
            return;
        }
        $mode = $this->get_option('pricing_mode', 'fixed');
        if ($mode === 'dynamic') {
            $cost = $this->dynamicCost($package);
        } elseif ($mode === 'fixed') {
            $raw = $this->get_option('cost', '');
            $cost = is_string($raw) || is_int($raw) || is_float($raw) ? (string) $raw : null;
            try {
                if ($cost === null || trim($cost) === '' || Money::fromDecimalString($cost)->cents() < 0) {
                    return;
                }
                if (Rules::qualifiesForFreeShipping(is_array($package) ? $package : [], $this->get_option('free_threshold', ''))) {
                    $cost = Money::zero()->toDecimalString();
                }
            } catch (InvalidArgumentException) {
                return;
            }
        } else {
            return;
        }
        if ($cost === null) {
            return;
        }
        $this->title = (string) $this->get_option('title', $this->defaultTitle());
        $this->tax_status = $this->get_option('tax_status', 'taxable') === 'none' ? 'none' : 'taxable';
        $this->add_rate([
            'id' => $this->get_rate_id(),
            'label' => $this->get_title(),
            'cost' => $cost,
            'package' => $package,
        ]);
    }

    /** @param array<string, mixed> $package */
    private function dynamicCost(array $package): ?string
    {
        // Never turn an unsupported destination into a fallback rate.
        if (($package['destination']['country'] ?? '') !== 'GR') {
            return null;
        }
        $errors = Settings::configurationErrors($this->instance_settings, $this->id === 'grcs_acs');
        if ($errors !== []) {
            wc_get_logger()->warning('Dynamic shipping configuration error: ' . implode(' ', $errors), [
                'source' => 'grcs-shipping-pricing', 'method' => $this->id, 'instance' => $this->instance_id,
            ]);
            return null;
        }
        try {
            if (wc_get_price_decimals() !== 2) {
                throw new InvalidArgumentException(__('Dynamic shipping requires a currency with two decimal places.', 'gr-commerce-suite'));
            }
            $calculator = $this->id === 'grcs_acs' ? new AcsRuleCalculator() : new BoxNowRuleCalculator();
            return $calculator->calculate(
                $package,
                $this->instance_settings,
                ShippingContext::locker(),
                false // COD is a separate cart fee, never part of the shipping tax base twice.
            )->toDecimalString();
        } catch (InvalidArgumentException | JsonException $error) {
            wc_get_logger()->warning('Dynamic shipping unavailable: ' . $error->getMessage(), [
                'source' => 'grcs-shipping-pricing', 'method' => $this->id, 'instance' => $this->instance_id,
            ]);
            if ($this->id === 'grcs_acs' && $this->get_option('pricing_failure', 'hide') === 'paid_fallback') {
                try {
                    $fallback = Rules::money($this->get_option('fallback_cost', ''));
                    if ($fallback->isPositive()) {
                        return $fallback->toDecimalString();
                    }
                } catch (InvalidArgumentException) {
                    return null;
                }
            }
            return null;
        }
    }

    /**
     * @param string $key
     * @param mixed $value
     */
    public function validate_textarea_field($key, $value): string
    {
        if (!in_array($key, ['classification_data', 'pricing_rules'], true)) {
            return parent::validate_textarea_field($key, $value);
        }
        if (!is_string($value)) {
            throw new Exception(__('Enter versioned pricing JSON.', 'gr-commerce-suite'));
        }
        // The modal supplies already-unslashed set_post_data(); standalone forms use raw $_POST.
        $raw = trim(empty($this->data) ? wp_unslash($value) : $value);
        if ($raw === '') {
            return '';
        }
        try {
            $rules = Rules::decode($raw);
            if ($key === 'classification_data') {
                Rules::validateData($rules);
            } elseif ($this->id === 'grcs_acs') {
                AcsRuleCalculator::validate($rules);
            } else {
                BoxNowRuleCalculator::validate($rules);
            }
        } catch (InvalidArgumentException | JsonException $error) {
            throw new Exception($error->getMessage());
        }
        return $raw;
    }

    /**
     * @param string $key
     * @param mixed $value
     */
    public function validate_text_field($key, $value): string
    {
        $numeric = ['default_weight', 'package_padding', 'packaging_weight', 'volumetric_divisor'];
        if (!in_array($key, array_merge($numeric, ['default_dimensions', 'price_adjustment', 'origin_postcode']), true)) {
            return parent::validate_text_field($key, $value);
        }
        if (!is_scalar($value)) {
            throw new Exception(__('Enter a valid pricing value.', 'gr-commerce-suite'));
        }
        $raw = trim((string) $value);
        if ($raw === '') {
            return in_array($key, ['package_padding', 'packaging_weight', 'price_adjustment'], true) ? '0' : '';
        }
        if (in_array($key, $numeric, true)) {
            Rules::number($raw, in_array($key, ['package_padding', 'packaging_weight'], true));
        } elseif ($key === 'default_dimensions') {
            Parcel::dimensions($raw);
        } elseif ($key === 'origin_postcode') {
            return Rules::postcode($raw);
        } else {
            return $this->normalizeMoneyInput($key, $raw, true);
        }
        return $raw;
    }

    /**
     * @param string $key
     * @param mixed $value
     */
    public function validate_free_threshold_field($key, $value): string
    {
        return $this->validate_cost_field($key, $value);
    }

    /**
     * @param string $key
     * @param mixed $value
     */
    public function validate_cod_handling_field($key, $value): string
    {
        $cost = $this->validate_cost_field($key, $value);
        return $cost === '' ? '0' : $cost;
    }

    /**
     * @param string $key
     * @param mixed $value
     */
    public function validate_fallback_cost_field($key, $value): string
    {
        $cost = $this->validate_cost_field($key, $value);
        if ($cost !== '' && !Money::fromDecimalString($cost)->isPositive()) {
            throw new Exception(__('Fallback shipping cost must be greater than zero.', 'gr-commerce-suite'));
        }
        return $cost;
    }

    /**
     * WC_Settings_API catches exceptions and displays them as settings errors.
     * @param string $key
     * @param mixed $value
     */
    public function validate_cost_field($key, $value): string
    {
        if (!is_scalar($value)) {
            throw new Exception(__('Enter a non-negative shipping cost.', 'gr-commerce-suite'));
        }
        $raw = trim((string) $value);
        if ($raw === '') {
            return '';
        }
        return $this->normalizeMoneyInput($key, $raw);
    }

    /** No grouping, exponent notation, currency symbols or ambiguous three-digit fractions. */
    private function normalizeMoneyInput(string $key, string $raw, bool $signed = false): string
    {
        $pattern = $signed ? '/^[+-]?[0-9]+(?:[.,][0-9]{1,2})?$/D' : '/^[0-9]+(?:[.,][0-9]{1,2})?$/D';
        // Preserve an unchanged canonical value from older versions, including extra precision.
        $existing = $this->get_option($key, '');
        $unchanged = is_scalar($existing) && $raw === (string) $existing
            && preg_match($signed ? '/^[+-]?[0-9]+(?:\.[0-9]+)?$/D' : '/^[0-9]+(?:\.[0-9]+)?$/D', $raw) === 1;
        try {
            if (!$unchanged && preg_match($pattern, $raw) !== 1) {
                throw new InvalidArgumentException();
            }
            $money = $signed ? Rules::money($raw, true) : Money::fromDecimalString($raw);
        } catch (InvalidArgumentException) {
            throw new Exception(__('Enter an amount using a dot or comma and up to two decimal places, without thousands separators.', 'gr-commerce-suite'));
        }
        return $unchanged ? $raw : $money->toDecimalString();
    }
}
