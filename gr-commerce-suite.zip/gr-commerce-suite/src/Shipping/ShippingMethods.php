<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping;

use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Modules\ModuleRegistry;

/** Registered at boot, including cart, checkout AJAX and Store API requests. */
final class ShippingMethods
{
    public function register(): void
    {
        add_filter('woocommerce_shipping_methods', [$this, 'methods']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueSettingsAssets']);
        if (ModuleRegistry::anyCourierEnabled()) {
            (new ShippingContext())->register();
        }
    }

    public function enqueueSettingsAssets(): void
    {
        if (!ModuleRegistry::anyCourierEnabled() || ($_GET['page'] ?? '') !== 'wc-settings' || ($_GET['tab'] ?? '') !== 'shipping') {
            return;
        }
        wp_enqueue_style('grcs-shipping-pricing-settings',
            plugins_url('assets/css/shipping-pricing-settings.css', GRCS_PLUGIN_FILE), [], GRCS_VERSION);
        wp_enqueue_script('grcs-shipping-pricing-settings',
            plugins_url('assets/js/shipping-pricing-settings.js', GRCS_PLUGIN_FILE), ['jquery'], GRCS_VERSION, true);
        wp_localize_script('grcs-shipping-pricing-settings', 'grcsPricingSettings', [
            'required' => AdminLocale::__('Dynamic pricing requires destination data, courier pricing rules and, for ACS, an origin postcode. Complete the marked fields before saving.', 'gr-commerce-suite'),
        ]);
    }

    /**
     * @param array<string, mixed> $methods
     * @return array<string, mixed>
     */
    public function methods(array $methods): array
    {
        // A disabled module only stops offering its rate for new checkouts; zone rows and their settings stay in the database.
        if (ModuleRegistry::isEnabled(ModuleRegistry::ACS)) {
            $methods['grcs_acs'] = AcsShippingMethod::class;
        }
        if (ModuleRegistry::courierCanCreate(\GRCommerceSuite\Domain\Shared\CourierSlug::BoxNow)) {
            $methods['grcs_boxnow'] = BoxNowShippingMethod::class;
        }
        if (ModuleRegistry::isEnabled(ModuleRegistry::GENIKI)) {
            $methods['grcs_geniki'] = \GRCommerceSuite\Modules\Geniki\GenikiShippingMethod::class;
        }
        return $methods;
    }
}
