<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Modules\ModuleRegistry;
use WC_Order;

/** One source of truth for checkout and voucher routing; labels and old meta are not evidence. */
final class CourierSelection
{
    public const BOXNOW_MAPPING = 'grcs_boxnow_shipping_methods';
    public const ACS_MAPPING = 'grcs_acs_shipping_methods';

    /** @return list<string> */
    public static function mappings(CourierSlug $courier): array
    {
        if ($courier === CourierSlug::Geniki) {
            return [];
        }
        $raw = (string) get_option($courier === CourierSlug::BoxNow ? self::BOXNOW_MAPPING : self::ACS_MAPPING, '');
        return array_values(array_filter(array_map('trim', explode(',', $raw)), static fn(string $id): bool => $id !== ''));
    }

    public static function fromRate(string $rate): ?CourierSlug
    {
        $method = explode(':', $rate, 2)[0];
        // Native IDs cannot be overridden by a stale legacy mapping.
        if ($method === 'grcs_acs') {
            return CourierSlug::Acs;
        }
        if ($method === 'grcs_boxnow') {
            return CourierSlug::BoxNow;
        }
        if ($method === 'grcs_geniki') {
            return CourierSlug::Geniki;
        }
        $matches = [];
        foreach ([CourierSlug::Acs, CourierSlug::BoxNow] as $courier) {
            $mapped = self::mappings($courier);
            if (in_array($rate, $mapped, true) || in_array($method, $mapped, true)) {
                $matches[] = $courier;
            }
        }
        if ($matches !== []) {
            return count($matches) === 1 ? $matches[0] : null;
        }
        // Preserve known legacy provider IDs, never fuzzy-match arbitrary IDs or display titles.
        return match ($method) {
            'acs' => CourierSlug::Acs,
            'boxnow', 'box_now', 'box-now' => CourierSlug::BoxNow,
            default => null,
        };
    }

    /** Active checkout classification; fromRate()/fromOrder() retain historical identity while a module is off. */
    public static function fromEnabledRate(string $rate): ?CourierSlug
    {
        $courier = self::fromRate($rate);
        return $courier !== null && ModuleRegistry::courierCanCreate($courier) ? $courier : null;
    }

    /** @return list<string> */
    public static function orderRates(WC_Order $order): array
    {
        $rates = [];
        foreach ($order->get_shipping_methods() as $method) {
            $rates[] = $method->get_method_id() . ':' . $method->get_instance_id();
        }
        return $rates;
    }

    /** Mixed or unidentified packages require an explicit merchant choice. */
    public static function fromOrder(WC_Order $order): ?CourierSlug
    {
        $selected = null;
        foreach (self::orderRates($order) as $rate) {
            $courier = self::fromRate($rate);
            if ($courier === null || ($selected !== null && $selected !== $courier)) {
                return null;
            }
            $selected = $courier;
        }
        return $selected;
    }
}
