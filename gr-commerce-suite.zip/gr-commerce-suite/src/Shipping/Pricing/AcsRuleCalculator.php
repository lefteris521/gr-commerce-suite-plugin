<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping\Pricing;

use GRCommerceSuite\Support\Money;
use InvalidArgumentException;

final class AcsRuleCalculator implements RateCalculator
{
    /** @param array<string, mixed> $rules */
    public static function validate(array $rules): void
    {
        if (!is_array($rules['categories'] ?? null) || $rules['categories'] === []) {
            throw new InvalidArgumentException(__('ACS rules need destination categories.', 'gr-commerce-suite'));
        }
        foreach ($rules['categories'] as $category => $rule) {
            if (!in_array($category, ['same_city', 'regional', 'mainland', 'island', 'remote'], true) || !is_array($rule)) {
                throw new InvalidArgumentException(__('Unknown ACS category.', 'gr-commerce-suite'));
            }
            if (!is_array($rule['bands'] ?? null) || !array_is_list($rule['bands']) || $rule['bands'] === []) {
                throw new InvalidArgumentException(__('Each ACS category needs ascending weight bands.', 'gr-commerce-suite'));
            }
            $previous = 0.0;
            foreach ($rule['bands'] as $band) {
                if (!is_array($band)) {
                    throw new InvalidArgumentException(__('Invalid ACS weight band.', 'gr-commerce-suite'));
                }
                $limit = Rules::number($band['up_to_kg'] ?? null);
                if ($limit <= $previous) {
                    throw new InvalidArgumentException(__('ACS weight bands must be strictly ascending.', 'gr-commerce-suite'));
                }
                Rules::money($band['price'] ?? null);
                $previous = $limit;
            }
            Rules::money($rule['extra_kg'] ?? null);
            Rules::money($rule['surcharge'] ?? '0');
        }
    }

    public function calculate(array $package, array $settings, string $locker, bool $cod): Money
    {
        if (($package['destination']['country'] ?? '') !== 'GR') {
            throw new InvalidArgumentException(__('ACS classification supports Greek destinations only.', 'gr-commerce-suite'));
        }
        $data = Rules::decode($settings['classification_data'] ?? '');
        Rules::validateData($data);
        $origin = Rules::destination($data, Rules::postcode($settings['origin_postcode'] ?? ''));
        $destination = Rules::destination($data, Rules::postcode($package['destination']['postcode'] ?? ''));
        // Islands and remote classifications always win over shared city/region identifiers.
        $area = Rules::category($destination['area']);
        $category = $area !== 'mainland' ? $area : ($origin['city'] === $destination['city'] ? 'same_city'
            : ($origin['region'] === $destination['region'] ? 'regional' : 'mainland'));
        $rules = Rules::decode($settings['pricing_rules'] ?? '');
        self::validate($rules);
        $rule = $rules['categories'][$category] ?? null;
        if (!is_array($rule)) {
            throw new InvalidArgumentException(__('No ACS price for this destination category.', 'gr-commerce-suite'));
        }
        $mode = $settings['weight_mode'] ?? 'actual';
        if (!in_array($mode, ['actual', 'billable'], true)) {
            throw new InvalidArgumentException(__('Unknown chargeable weight mode.', 'gr-commerce-suite'));
        }
        $volumetric = $mode === 'billable';
        $parcel = Parcel::fromPackage($package, $settings, $volumetric);
        $weight = $volumetric ? max($parcel->weight, $parcel->volumetric(Rules::number($settings['volumetric_divisor'] ?? null)))
            : $parcel->weight;
        $cents = 0;
        $limit = 0.0;
        foreach ($rule['bands'] as $band) {
            $limit = Rules::number($band['up_to_kg']);
            $cents = Rules::money($band['price'])->cents();
            if ($weight <= $limit + 0.000000001) {
                break;
            }
        }
        $extra = (int) ceil(max(0.0, $weight - $limit - 0.000000001));
        if ($extra > 1000000) {
            throw new InvalidArgumentException(__('Unsupported billable weight.', 'gr-commerce-suite'));
        }
        $perKg = Rules::money($rule['extra_kg'])->cents();
        if ($perKg > 0 && $extra > intdiv(PHP_INT_MAX, $perKg)) {
            throw new InvalidArgumentException(__('Additional weight charge exceeds the supported integer range.', 'gr-commerce-suite'));
        }
        $cents = Rules::addCents(Rules::addCents($cents, $extra * $perKg), Rules::money($rule['surcharge'] ?? '0')->cents());
        $result = Rules::finish(Money::fromCents($cents), $package, $settings);
        // Free delivery does not waive separately configured COD handling.
        return Money::fromCents(Rules::addCents($result->cents(), $cod ? Rules::money($settings['cod_handling'] ?? '0')->cents() : 0));
    }
}
