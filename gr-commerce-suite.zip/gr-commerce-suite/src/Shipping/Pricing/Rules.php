<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping\Pricing;

use GRCommerceSuite\Support\Money;
use InvalidArgumentException;

/** Strict, versioned merchant data. No inferred postcode geography or public tariffs. */
final class Rules
{
    /** @return array<string, mixed> */
    public static function decode(mixed $json): array
    {
        if (!is_string($json)) {
            throw new InvalidArgumentException(__('Pricing data must be a JSON string.', 'gr-commerce-suite'));
        }
        $data = json_decode($json, true, 32, JSON_THROW_ON_ERROR);
        if (!is_array($data) || ($data['version'] ?? null) !== 1) {
            throw new InvalidArgumentException(__('Pricing data must use schema version 1.', 'gr-commerce-suite'));
        }
        return $data;
    }

    public static function postcode(mixed $value): string
    {
        $code = is_string($value) ? str_replace(' ', '', trim($value)) : '';
        if (preg_match('/^[0-9]{5}$/D', $code) !== 1) {
            throw new InvalidArgumentException(__('A five-digit Greek postcode is required.', 'gr-commerce-suite'));
        }
        return $code;
    }

    /** @param array<string, mixed> $data */
    public static function validateData(array $data): void
    {
        foreach (['revision', 'source', 'verified_on'] as $field) {
            if (!is_string($data[$field] ?? null) || trim($data[$field]) === '') {
                throw new InvalidArgumentException(__('Classification data needs revision, source and verified_on.', 'gr-commerce-suite'));
            }
        }
        $date = explode('-', $data['verified_on']);
        if (preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/D', $data['verified_on']) !== 1
            || !checkdate((int) ($date[1] ?? 0), (int) ($date[2] ?? 0), (int) $date[0])) {
            throw new InvalidArgumentException(__('verified_on must be a valid YYYY-MM-DD date.', 'gr-commerce-suite'));
        }
        if (!is_array($data['postcodes'] ?? null) || !is_array($data['lockers'] ?? null)) {
            throw new InvalidArgumentException(__('Classification data needs postcodes and lockers objects.', 'gr-commerce-suite'));
        }
        foreach ($data['postcodes'] as $code => $entry) {
            self::postcode((string) $code);
            if (!is_array($entry) || !is_string($entry['city'] ?? null) || $entry['city'] === ''
                || !is_string($entry['region'] ?? null) || $entry['region'] === '') {
                throw new InvalidArgumentException(__('Each postcode needs explicit city and region identifiers.', 'gr-commerce-suite'));
            }
            self::category($entry['area'] ?? null);
        }
        foreach ($data['lockers'] as $id => $entry) {
            if (preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', (string) $id) !== 1 || !is_array($entry)) {
                throw new InvalidArgumentException(__('Invalid locker mapping.', 'gr-commerce-suite'));
            }
            self::category($entry['category'] ?? null);
            if (!is_array($entry['sizes'] ?? null) || $entry['sizes'] === []) {
                throw new InvalidArgumentException(__('Each locker needs explicit eligible size identifiers.', 'gr-commerce-suite'));
            }
            foreach ($entry['sizes'] as $size) {
                if (!is_string($size) || $size === '') {
                    throw new InvalidArgumentException(__('Invalid locker size identifier.', 'gr-commerce-suite'));
                }
            }
        }
    }

    public static function category(mixed $value): string
    {
        if (!is_string($value) || !in_array($value, ['mainland', 'island', 'remote'], true)) {
            throw new InvalidArgumentException(__('Unknown destination category.', 'gr-commerce-suite'));
        }
        return $value;
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    public static function destination(array $data, string $code): array
    {
        $entry = $data['postcodes'][$code] ?? null;
        if (!is_array($entry)) {
            throw new InvalidArgumentException(__('Postcode is absent from the configured classification revision.', 'gr-commerce-suite'));
        }
        return $entry;
    }

    public static function number(mixed $value, bool $zero = false): float
    {
        if ((!is_string($value) && !is_int($value) && !is_float($value)) || !is_numeric($value)) {
            throw new InvalidArgumentException(__('A finite measurement is required.', 'gr-commerce-suite'));
        }
        $number = (float) $value;
        if (!is_finite($number) || $number < 0 || (!$zero && $number === 0.0) || $number > 1000000) {
            throw new InvalidArgumentException(__('Measurement is outside the supported range.', 'gr-commerce-suite'));
        }
        return $number;
    }

    public static function money(mixed $value, bool $signed = false): Money
    {
        if (!is_string($value) || trim($value) === '') {
            throw new InvalidArgumentException(__('Prices must be explicit decimal strings.', 'gr-commerce-suite'));
        }
        $money = Money::fromDecimalString($value);
        // Bound arithmetic well below integer overflow, including per-kg multiplication.
        if ((!$signed && $money->cents() < 0) || abs($money->cents()) > 100000000) {
            throw new InvalidArgumentException(__('Price is outside the supported range.', 'gr-commerce-suite'));
        }
        return $money;
    }

    public static function addCents(int $left, int $right): int
    {
        if (($right > 0 && $left > PHP_INT_MAX - $right) || ($right < 0 && $left < PHP_INT_MIN - $right)) {
            throw new InvalidArgumentException(__('Calculated shipping amount exceeds the supported integer range.', 'gr-commerce-suite'));
        }
        return $left + $right;
    }

    /**
     * @param array<string, mixed> $package
     * @param array<string, mixed> $settings
     */
    public static function finish(Money $cost, array $package, array $settings): Money
    {
        $adjustment = self::money($settings['price_adjustment'] ?? '0', true);
        $cents = self::addCents($cost->cents(), $adjustment->cents());
        if ($cents < 0) {
            throw new InvalidArgumentException(__('Adjustment would make shipping negative.', 'gr-commerce-suite'));
        }
        $threshold = $settings['free_threshold'] ?? '';
        if ($threshold !== '' && self::qualifiesForFreeShipping($package, $threshold, true)) {
            return Money::zero();
        }
        return Money::fromCents($cents);
    }

    /**
     * @param array<string, mixed> $package
     */
    public static function qualifiesForFreeShipping(array $package, mixed $threshold, bool $strict = false): bool
    {
        if ($threshold === '' || $threshold === null) {
            return false;
        }
        if (is_string($threshold) && trim($threshold) === '') {
            if ($strict) {
                throw new InvalidArgumentException(__('Prices must be explicit decimal strings.', 'gr-commerce-suite'));
            }
            return false;
        }
        try {
            $minimum = self::money($threshold);
        } catch (InvalidArgumentException $error) {
            if ($strict) {
                throw $error;
            }
            return false;
        }
        $total = 0;
        foreach ($package['contents'] ?? [] as $item) {
            $amount = is_array($item) ? ($item['line_total'] ?? null) : null;
            if (!is_scalar($amount)) {
                if ($strict) {
                    throw new InvalidArgumentException(__('Package line total is missing.', 'gr-commerce-suite'));
                }
                return false;
            }
            try {
                $lineCents = self::money((string) $amount)->cents();
            } catch (InvalidArgumentException $error) {
                if ($strict) {
                    throw $error;
                }
                return false;
            }
            // Only the threshold comparison matters; cap to avoid overflowing huge carts.
            $total += min($lineCents, max(0, $minimum->cents() - $total));
        }
        if (!$strict && empty($package['contents']) && isset($package['contents_cost']) && is_scalar($package['contents_cost'])) {
            try {
                $lineCents = self::money((string) $package['contents_cost'])->cents();
                $total += min($lineCents, max(0, $minimum->cents() - $total));
            } catch (InvalidArgumentException) {
                return false;
            }
        }
        return $total >= $minimum->cents();
    }
}
