<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping\Pricing;

use GRCommerceSuite\Support\Money;

/** Local rules today; a verified, authenticated quote adapter can implement this later. */
interface RateCalculator
{
    /**
     * @param array<string, mixed> $package WooCommerce shipping package, never an order/voucher.
     * @param array<string, mixed> $settings Zone-instance settings.
     * @throws \InvalidArgumentException No safe rate can be calculated.
     */
    public function calculate(array $package, array $settings, string $locker, bool $cod): Money;
}
