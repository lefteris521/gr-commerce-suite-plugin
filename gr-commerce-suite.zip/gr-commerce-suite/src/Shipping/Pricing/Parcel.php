<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping\Pricing;

use InvalidArgumentException;
use WC_Product;

/** Constructive single-stack packing: bounds describe an achievable parcel, not summed volumes. */
final readonly class Parcel
{
    /** @param list<list<float>> $stacks */
    private function __construct(public float $weight, public array $stacks)
    {
    }

    /**
     * @param array<string, mixed> $package
     * @param array<string, mixed> $settings
     */
    public static function fromPackage(array $package, array $settings, bool $dimensions): self
    {
        $weight = Rules::number($settings['packaging_weight'] ?? '0', true);
        $stacks = [[0.0, 0.0, 0.0], [0.0, 0.0, 0.0], [0.0, 0.0, 0.0]];
        $count = 0;
        foreach ($package['contents'] ?? [] as $item) {
            $product = $item['data'] ?? null;
            if (!$product instanceof WC_Product) {
                throw new InvalidArgumentException(__('Package product is missing.', 'gr-commerce-suite'));
            }
            if (!$product->needs_shipping()) {
                continue;
            }
            $quantity = Rules::number($item['quantity'] ?? null);
            if (floor($quantity) !== $quantity || $quantity > 10000 || $count + $quantity > 10000) {
                throw new InvalidArgumentException(__('Unsupported package quantity.', 'gr-commerce-suite'));
            }
            $count += (int) $quantity;
            $rawWeight = $product->get_weight();
            if ($rawWeight === '' || (is_numeric($rawWeight) && (float) $rawWeight === 0.0)) {
                if (($settings['missing_weight'] ?? 'reject') !== 'configured') {
                    throw new InvalidArgumentException(__('Product weight is missing.', 'gr-commerce-suite'));
                }
                $kg = Rules::number($settings['default_weight'] ?? null);
            } else {
                $kg = Rules::number(wc_get_weight(Rules::number($rawWeight), 'kg'));
            }
            $weight += $kg * $quantity;
            if (!$dimensions) {
                continue;
            }
            $edges = [$product->get_length(), $product->get_width(), $product->get_height()];
            $missingEdge = static fn($edge): bool => $edge === '' || (is_numeric($edge) && (float) $edge === 0.0);
            $missing = count(array_filter($edges, $missingEdge)) > 0;
            if ($missing) {
                if (($settings['missing_dimensions'] ?? 'reject') !== 'configured') {
                    throw new InvalidArgumentException(__('Product dimensions are missing.', 'gr-commerce-suite'));
                }
                $defaults = self::dimensions($settings['default_dimensions'] ?? '');
                // Never replace a known edge with a smaller merchant fallback edge.
                foreach ($edges as $axis => $edge) {
                    $edges[$axis] = $missingEdge($edge) ? $defaults[$axis]
                        : Rules::number(wc_get_dimension(Rules::number($edge), 'cm'));
                }
            } else {
                $edges = array_map(static fn($edge): float => Rules::number(wc_get_dimension(Rules::number($edge), 'cm')), $edges);
            }
            sort($edges, SORT_NUMERIC);
            foreach ($stacks as $axis => &$stack) {
                foreach ($edges as $index => $edge) {
                    $stack[$index] = $axis === $index ? $stack[$index] + $edge * $quantity : max($stack[$index], $edge);
                }
            }
            unset($stack);
        }
        if ($count === 0 || !is_finite($weight) || $weight > 1000000) {
            throw new InvalidArgumentException(__('Empty or unsupported package.', 'gr-commerce-suite'));
        }
        if ($dimensions) {
            $padding = Rules::number($settings['package_padding'] ?? '0', true);
            foreach ($stacks as &$stack) {
                foreach ($stack as &$edge) {
                    $edge += 2 * $padding;
                }
                unset($edge);
                sort($stack, SORT_NUMERIC);
            }
            unset($stack);
        }
        return new self($weight, $dimensions ? $stacks : []);
    }

    /** @return list<float> */
    public static function dimensions(mixed $raw): array
    {
        $values = is_string($raw) ? explode(',', $raw) : $raw;
        if (!is_array($values) || !array_is_list($values) || count($values) !== 3) {
            throw new InvalidArgumentException(__('Enter three dimensions in cm, separated by commas.', 'gr-commerce-suite'));
        }
        return array_map(static fn($value): float => Rules::number($value), $values);
    }

    /** @param list<float> $bounds */
    public function fits(array $bounds, float $maxWeight): bool
    {
        if ($this->weight > $maxWeight + 0.000000001) {
            return false;
        }
        sort($bounds, SORT_NUMERIC);
        foreach ($this->stacks as $stack) {
            if ($stack[0] <= $bounds[0] && $stack[1] <= $bounds[1] && $stack[2] <= $bounds[2]) {
                return true;
            }
        }
        return false;
    }

    public function volumetric(float $divisor): float
    {
        if ($this->stacks === [] || $divisor <= 0) {
            throw new InvalidArgumentException(__('Volumetric weight needs parcel dimensions and a positive divisor.', 'gr-commerce-suite'));
        }
        return min(array_map(static fn(array $stack): float => array_product($stack) / $divisor, $this->stacks));
    }
}
