<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping\Pricing;

use GRCommerceSuite\I18n\AdminLocale;

/** Per-zone controls. Blank rules are intentional: there are no guaranteed carrier tariffs. */
final class Settings
{
    /** @return array<string, array<string, mixed>> */
    public static function fields(bool $acs): array
    {
        $fields = [
            'pricing_mode' => [
                'title' => AdminLocale::__('Pricing mode', 'gr-commerce-suite'), 'type' => 'select', 'default' => 'fixed',
                'options' => ['fixed' => AdminLocale::__('Fixed price (existing cost)', 'gr-commerce-suite'),
                    'dynamic' => AdminLocale::__('Dynamic merchant rules', 'gr-commerce-suite')],
                'class' => 'grcs-pricing-mode',
                'description' => AdminLocale::__('Dynamic pricing requires destination data and courier rules below. Invalid or incomplete configuration cannot be saved.', 'gr-commerce-suite'),
            ],
            'classification_data' => [
                'title' => AdminLocale::__('Versioned destination and locker data (JSON)', 'gr-commerce-suite'),
                'type' => 'textarea', 'default' => '', 'css' => 'width:100%;min-height:150px',
                'description' => AdminLocale::__('Use verified merchant/carrier records. No geographic data is supplied. Required: version (1), revision, source, verified_on (YYYY-MM-DD), postcodes, lockers. Each postcode has city, region, area (mainland/island/remote). Each locker has category and eligible size IDs. Unknown destinations hide the rate.', 'gr-commerce-suite')
                    . '<pre>' . esc_html('{"version":1,"revision":"YOUR-REVISION","source":"YOUR-CONTRACT","verified_on":"YYYY-MM-DD","postcodes":{},"lockers":{}}') . '</pre>'
                    . AdminLocale::__('Postcode entry: "POSTCODE":{"city":"CITY-ID","region":"REGION-ID","area":"mainland"}. Locker entry: "LOCKER-ID":{"category":"island","sizes":["small"]}. Replace placeholders with verified records. The checkout locker applies to all BOX NOW packages.', 'gr-commerce-suite'),
            ],
            'pricing_rules' => [
                'title' => $acs ? AdminLocale::__('ACS category and weight rates (JSON)', 'gr-commerce-suite')
                    : AdminLocale::__('BOX NOW compartments and rates (JSON)', 'gr-commerce-suite'),
                'type' => 'textarea', 'default' => '', 'css' => 'width:100%;min-height:180px',
                'description' => $acs
                    ? AdminLocale::__('Schema 1: categories same_city, regional, mainland, island, remote; each has ascending bands (up_to_kg, price), extra_kg and optional surcharge. Prices are decimal strings, excluding tax.', 'gr-commerce-suite')
                    : AdminLocale::__('Schema 1: sizes in preferred order; each has id, dimensions_cm, max_weight_kg, prices by mainland/island/remote. Confirm supported limits with your contract. No carrier dimensions or tariffs are assumed.', 'gr-commerce-suite'),
            ],
            'missing_weight' => [
                'title' => AdminLocale::__('Missing product weight', 'gr-commerce-suite'), 'type' => 'select', 'default' => 'reject',
                'options' => ['reject' => AdminLocale::__('Hide method', 'gr-commerce-suite'),
                    'configured' => AdminLocale::__('Use merchant weight bound per item', 'gr-commerce-suite')],
            ],
            'default_weight' => self::text(AdminLocale::__('Fallback item weight (kg)', 'gr-commerce-suite'), '',
                AdminLocale::__('Only used for missing/zero weights. Set a verified upper bound for your products.', 'gr-commerce-suite')),
            'missing_dimensions' => [
                'title' => AdminLocale::__('Missing product dimensions', 'gr-commerce-suite'), 'type' => 'select', 'default' => 'reject',
                'options' => ['reject' => AdminLocale::__('Hide method when dimensions are required', 'gr-commerce-suite'),
                    'configured' => AdminLocale::__('Use merchant dimension bounds per missing edge', 'gr-commerce-suite')],
            ],
            'default_dimensions' => self::text(AdminLocale::__('Fallback item dimensions (cm)', 'gr-commerce-suite'), '',
                AdminLocale::__('Length,width,height, for example 10,20,30. Merchant-verified upper bounds for missing edges only. Known dimensions are never replaced.', 'gr-commerce-suite')),
            'package_padding' => self::text(AdminLocale::__('Packaging clearance on each side (cm)', 'gr-commerce-suite'), '0',
                AdminLocale::__('Added to all three outer parcel dimensions after conservative stack packing. If no stack fits, BOX NOW is hidden; split the package or use another method.', 'gr-commerce-suite')),
            'packaging_weight' => self::text(AdminLocale::__('Packaging weight per shipping package (kg)', 'gr-commerce-suite'), '0'),
            'free_threshold' => [
                'title' => AdminLocale::__('Free delivery threshold', 'gr-commerce-suite'), 'type' => 'price', 'default' => '',
                'description' => AdminLocale::__('Blank disables. Uses this package’s item totals after discounts, excluding tax. Eligibility is checked first. COD handling remains payable.', 'gr-commerce-suite'),
            ],
            'price_adjustment' => self::text(AdminLocale::__('Delivery price adjustment', 'gr-commerce-suite'), '0',
                AdminLocale::__('Signed amount in store currency excluding tax, applied once per package. A negative result hides the rate.', 'gr-commerce-suite')),
        ];
        $fields['cod_handling'] = ['title' => AdminLocale::__('COD handling per package', 'gr-commerce-suite'),
            'type' => 'price', 'default' => '0',
            'description' => AdminLocale::__('Charged as Αντικαταβολή only for the selected WooCommerce cod gateway.', 'gr-commerce-suite')];
        if ($acs) {
            $fields += [
                'origin_postcode' => self::text(AdminLocale::__('Origin postcode', 'gr-commerce-suite'), '',
                    AdminLocale::__('Must be present in your classification data. Remote/island takes precedence, then same city, same region, mainland.', 'gr-commerce-suite')),
                'weight_mode' => [
                    'title' => AdminLocale::__('Chargeable weight', 'gr-commerce-suite'), 'type' => 'select', 'default' => 'actual',
                    'options' => ['actual' => AdminLocale::__('Actual weight', 'gr-commerce-suite'),
                        'billable' => AdminLocale::__('Greater of actual and volumetric weight', 'gr-commerce-suite')],
                ],
                'volumetric_divisor' => self::text(AdminLocale::__('Volumetric divisor (cm³/kg)', 'gr-commerce-suite'), '',
                    AdminLocale::__('Required for volumetric pricing. Use the divisor in your merchant contract.', 'gr-commerce-suite')),
                'pricing_failure' => [
                    'title' => AdminLocale::__('Dynamic calculation failure', 'gr-commerce-suite'), 'type' => 'select', 'default' => 'hide',
                    'options' => ['hide' => AdminLocale::__('Hide method', 'gr-commerce-suite'),
                        'paid_fallback' => AdminLocale::__('Use the explicit paid fallback', 'gr-commerce-suite')],
                ],
                'fallback_cost' => ['title' => AdminLocale::__('Paid fallback cost', 'gr-commerce-suite'), 'type' => 'price', 'default' => '',
                    'description' => AdminLocale::__('Must be greater than zero. No free threshold or COD adjustment is applied to this all-inclusive fallback. Failures are logged.', 'gr-commerce-suite')],
            ];
        }
        foreach ($fields as $key => &$field) {
            if (!in_array($key, ['pricing_mode', 'free_threshold', 'cod_handling'], true)) {
                $field['class'] = 'grcs-pricing-dynamic';
            }
            if (in_array($key, ['classification_data', 'pricing_rules', 'origin_postcode'], true)) {
                $field['custom_attributes'] = ['data-grcs-pricing-required' => '1'];
            }
        }
        unset($field);
        return $fields;
    }

    /**
     * Configuration checks independent of the current customer/package. Partial route coverage is allowed.
     * @param array<string, mixed> $settings
     * @return list<string>
     */
    public static function configurationErrors(array $settings, bool $acs, bool $admin = false): array
    {
        $translate = $admin ? [AdminLocale::class, '__'] : '__';
        $errors = [];
        $data = null;
        foreach (['classification_data', 'pricing_rules'] as $key) {
            $label = $key === 'classification_data'
                ? $translate('Destination and locker data', 'gr-commerce-suite')
                : $translate('Courier pricing rules', 'gr-commerce-suite');
            try {
                if (!is_string($settings[$key] ?? null) || trim($settings[$key]) === '') {
                    throw new \InvalidArgumentException($translate('Required for Dynamic pricing. Enter schema version 1 JSON.', 'gr-commerce-suite'));
                }
                $decoded = Rules::decode($settings[$key]);
                if ($key === 'classification_data') {
                    Rules::validateData($decoded);
                    if ($decoded['postcodes'] === [] && ($acs || $decoded['lockers'] === [])) {
                        throw new \InvalidArgumentException($translate('Add verified destination records.', 'gr-commerce-suite'));
                    }
                    $data = $decoded;
                } elseif ($acs) {
                    AcsRuleCalculator::validate($decoded);
                } else {
                    BoxNowRuleCalculator::validate($decoded);
                }
            } catch (\InvalidArgumentException | \JsonException $error) {
                $errors[] = $label . ': ' . ($admin ? AdminLocale::error($error->getMessage()) : $error->getMessage());
            }
        }
        if ($acs) {
            try {
                $origin = Rules::postcode($settings['origin_postcode'] ?? '');
                if ($data !== null) {
                    Rules::destination($data, $origin);
                }
            } catch (\InvalidArgumentException $error) {
                $errors[] = $translate('Origin postcode', 'gr-commerce-suite') . ': ' . ($admin ? AdminLocale::error($error->getMessage()) : $error->getMessage());
            }
        }
        $checks = [
            'missing_weight' => ['reject', 'configured'],
            'missing_dimensions' => ['reject', 'configured'],
        ];
        if ($acs) {
            $checks += ['weight_mode' => ['actual', 'billable'], 'pricing_failure' => ['hide', 'paid_fallback']];
        }
        $fields = self::fields($acs);
        foreach ($checks as $key => $allowed) {
            if (!in_array($settings[$key] ?? $fields[$key]['default'], $allowed, true)) {
                $errors[] = $fields[$key]['title'] . ': ' . $translate('Select a supported option.', 'gr-commerce-suite');
            }
        }
        foreach (['default_weight', 'default_dimensions', 'volumetric_divisor', 'fallback_cost'] as $key) {
            $required = match ($key) {
                'default_weight' => ($settings['missing_weight'] ?? 'reject') === 'configured',
                'default_dimensions' => ($settings['missing_dimensions'] ?? 'reject') === 'configured',
                'volumetric_divisor' => $acs && ($settings['weight_mode'] ?? 'actual') === 'billable',
                'fallback_cost' => $acs && ($settings['pricing_failure'] ?? 'hide') === 'paid_fallback',
            };
            if (!$required) {
                continue;
            }
            try {
                $value = $settings[$key] ?? '';
                if ($key === 'default_dimensions') {
                    Parcel::dimensions($value);
                } elseif ($key === 'fallback_cost') {
                    if (!Rules::money($value)->isPositive()) {
                        throw new \InvalidArgumentException($translate('Enter a cost greater than zero.', 'gr-commerce-suite'));
                    }
                } else {
                    Rules::number($value);
                }
            } catch (\InvalidArgumentException $error) {
                $errors[] = $fields[$key]['title'] . ': ' . ($admin ? AdminLocale::error($error->getMessage()) : $error->getMessage());
            }
        }
        return $errors;
    }

    /** @return array<string, mixed> */
    private static function text(string $title, string $default, string $description = ''): array
    {
        return ['title' => $title, 'type' => 'text', 'default' => $default, 'description' => $description];
    }
}
