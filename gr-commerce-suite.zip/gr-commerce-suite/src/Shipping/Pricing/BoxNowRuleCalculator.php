<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping\Pricing;

use GRCommerceSuite\Support\Money;
use InvalidArgumentException;

final class BoxNowRuleCalculator implements RateCalculator
{
    /** @param array<string, mixed> $rules */
    public static function validate(array $rules): void
    {
        if (!is_array($rules['sizes'] ?? null) || !array_is_list($rules['sizes']) || $rules['sizes'] === []) {
            throw new InvalidArgumentException(__('BOX NOW rules need parcel sizes, smallest first.', 'gr-commerce-suite'));
        }
        $seen = [];
        foreach ($rules['sizes'] as $size) {
            if (!is_array($size) || !is_string($size['id'] ?? null) || $size['id'] === '' || isset($seen[$size['id']])) {
                throw new InvalidArgumentException(__('Parcel size identifiers must be unique.', 'gr-commerce-suite'));
            }
            $seen[$size['id']] = true;
            Parcel::dimensions($size['dimensions_cm'] ?? null);
            Rules::number($size['max_weight_kg'] ?? null);
            if (!is_array($size['prices'] ?? null) || $size['prices'] === []) {
                throw new InvalidArgumentException(__('Each parcel size needs explicit destination prices.', 'gr-commerce-suite'));
            }
            foreach ($size['prices'] as $category => $price) {
                Rules::category($category);
                Rules::money($price);
            }
        }
    }

    public function calculate(array $package, array $settings, string $locker, bool $cod): Money
    {
        if (($package['destination']['country'] ?? '') !== 'GR') {
            throw new InvalidArgumentException(__('BOX NOW classification supports Greek destinations only.', 'gr-commerce-suite'));
        }
        $data = Rules::decode($settings['classification_data'] ?? '');
        Rules::validateData($data);
        $allowed = null;
        if ($locker !== '') {
            $mapping = $data['lockers'][$locker] ?? null;
            if (!is_array($mapping)) {
                throw new InvalidArgumentException(__('Selected locker has no verified pricing/size mapping.', 'gr-commerce-suite'));
            }
            $category = Rules::category($mapping['category']);
            $allowed = $mapping['sizes'];
        } else {
            $destination = Rules::destination($data, Rules::postcode($package['destination']['postcode'] ?? ''));
            $category = Rules::category($destination['area']);
        }
        $rules = Rules::decode($settings['pricing_rules'] ?? '');
        self::validate($rules);
        $parcel = Parcel::fromPackage($package, $settings, true);
        foreach ($rules['sizes'] as $size) {
            if ($allowed !== null && !in_array($size['id'], $allowed, true)) {
                continue;
            }
            if (!array_key_exists($category, $size['prices'])) {
                continue;
            }
            if ($parcel->fits(Parcel::dimensions($size['dimensions_cm']), Rules::number($size['max_weight_kg']))) {
                $shipping = Rules::finish(Rules::money($size['prices'][$category]), $package, $settings);
                $codFee = $cod ? Rules::money($settings['cod_handling'] ?? '0')->cents() : 0;
                return Money::fromCents(Rules::addCents($shipping->cents(), $codFee));
            }
        }
        // Never offer a paid fallback (or free threshold) for an ineligible parcel.
        throw new InvalidArgumentException(__('No eligible BOX NOW compartment and destination price.', 'gr-commerce-suite'));
    }
}
