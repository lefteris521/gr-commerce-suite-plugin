<?php

declare(strict_types=1);

namespace GRCommerceSuite\Shipping;

final class AcsShippingMethod extends ConfiguredShippingMethod
{
    protected function methodId(): string
    {
        return 'grcs_acs';
    }

    protected function defaultTitle(): string
    {
        return __('ACS Courier', 'gr-commerce-suite');
    }
}
