<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

/**
 * Thrown when the courier reports that the requested voucher number does not exist (SPEC.md §8.4).
 */
final class VoucherNotFoundException extends CourierException
{
    public function isRetryable(): bool
    {
        return false;
    }
}
