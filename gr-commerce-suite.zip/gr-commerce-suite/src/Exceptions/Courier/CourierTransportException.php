<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use Throwable;

/**
 * Thrown when a transport failure occurred while talking to the courier.
 *
 * `failedBeforeTransmission()` is the typed classification produced by the HTTP client: `true` proves the
 * payload never reached the courier (DNS, TCP connect, TLS handshake) and is safe to retry; `false` means the
 * request was transmitted and the outcome is ambiguous; `null` means the thrower supplied no classification and
 * callers may fall back to message matching (SPEC.md §8.4, §9.5).
 */
final class CourierTransportException extends CourierException
{
    public function __construct(
        string $message,
        CourierSlug $courier,
        ?int $httpStatus = null,
        array $context = [],
        ?string $merchantSafeMessage = null,
        ?Throwable $previous = null,
        private readonly ?bool $failedBeforeTransmission = null,
    ) {
        parent::__construct($message, $courier, $httpStatus, $context, $merchantSafeMessage, $previous);
    }

    public function isRetryable(): bool
    {
        return true;
    }

    /** True: proven not sent (safe retry). False: sent (ambiguous). Null: no typed classification. */
    public function failedBeforeTransmission(): ?bool
    {
        return $this->failedBeforeTransmission;
    }
}
