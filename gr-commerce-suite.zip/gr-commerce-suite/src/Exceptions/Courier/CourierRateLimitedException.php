<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use Throwable;

/**
 * Thrown when the courier throttles requests (HTTP 429 or equivalent).
 * Retryable after getRetryAfterSeconds() (SPEC.md §8.4, §9.5).
 */
final class CourierRateLimitedException extends CourierException
{
    /**
     * @param array<string, mixed> $context
     */
    public function __construct(
        string $message,
        CourierSlug $courier,
        private readonly int $retryAfterSeconds = 60,
        ?int $httpStatus = 429,
        array $context = [],
        ?string $merchantSafeMessage = null,
        ?Throwable $previous = null,
    ) {
        parent::__construct($message, $courier, $httpStatus, $context, $merchantSafeMessage, $previous);
    }

    public function isRetryable(): bool
    {
        return true;
    }

    public function getRetryAfterSeconds(): int
    {
        return max(1, $this->retryAfterSeconds);
    }
}
