<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use RuntimeException;
use Throwable;

/**
 * Base exception for all courier integration failures (SPEC.md §8.4).
 */
abstract class CourierException extends RuntimeException
{
    /**
     * @param array<string, mixed> $context Redacted diagnostic context.
     */
    public function __construct(
        string $message,
        protected readonly CourierSlug $courier,
        protected readonly ?int $httpStatus = null,
        protected readonly array $context = [],
        protected readonly ?string $merchantSafeMessage = null,
        ?Throwable $previous = null,
    ) {
        parent::__construct($message, $this->httpStatus ?? 0, $previous);
    }

    abstract public function isRetryable(): bool;

    public function courier(): CourierSlug
    {
        return $this->courier;
    }

    public function httpStatus(): ?int
    {
        return $this->httpStatus;
    }

    /**
     * @return array<string, mixed>
     */
    public function context(): array
    {
        return $this->context;
    }

    /**
     * Merchant-readable message free of PII or credentials (SPEC.md §8.4).
     */
    public function merchantMessage(): string
    {
        if ($this->merchantSafeMessage !== null && trim($this->merchantSafeMessage) !== '') {
            return $this->merchantSafeMessage;
        }

        return $this->getMessage();
    }
}
