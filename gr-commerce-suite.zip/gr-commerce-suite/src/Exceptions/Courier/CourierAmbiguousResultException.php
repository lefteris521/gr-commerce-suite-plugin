<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

use GRCommerceSuite\Domain\Voucher\VoucherState;

/**
 * Thrown when an HTTP request timed out after transmission or returned a malformed 2xx payload,
 * leaving it ambiguous whether a voucher was created at the courier.
 *
 * MUST NEVER be blindly retried: transitions the voucher row `state` to `'unknown'` (SPEC.md §6.3, §7, §8.4).
 */
final class CourierAmbiguousResultException extends CourierException
{
    public const TARGET_STATE = 'unknown';

    public function isRetryable(): bool
    {
        return false;
    }

    public function targetState(): VoucherState
    {
        return VoucherState::Unknown;
    }
}
