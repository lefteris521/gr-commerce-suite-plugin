<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

/**
 * Thrown when the requested print format is not supported by the courier adapter (SPEC.md §8.4).
 */
final class UnsupportedPrintFormatException extends CourierValidationException
{
}
