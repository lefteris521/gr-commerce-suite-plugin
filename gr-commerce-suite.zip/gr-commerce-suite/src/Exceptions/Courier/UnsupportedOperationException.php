<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

/**
 * Thrown when the courier API does not support an operation (SPEC.md §8.4).
 */
final class UnsupportedOperationException extends CourierException
{
    public function isRetryable(): bool
    {
        return false;
    }
}
