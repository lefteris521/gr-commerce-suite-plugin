<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

/**
 * Thrown when the courier permanently rejects request data (address, phone, weight, locker ID, etc.).
 * Moves voucher state to `failed`; never retried (SPEC.md §8.4, §9.5).
 */
class CourierValidationException extends CourierException
{
    public function isRetryable(): bool
    {
        return false;
    }
}
