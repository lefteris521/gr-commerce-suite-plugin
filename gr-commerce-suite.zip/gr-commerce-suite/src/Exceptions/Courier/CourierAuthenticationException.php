<?php

declare(strict_types=1);

namespace GRCommerceSuite\Exceptions\Courier;

/**
 * Thrown when courier credentials or OAuth tokens are invalid/expired.
 * Moves voucher state to `failed`, pauses the courier queue, and surfaces an admin notice (SPEC.md §8.4, §9.5).
 */
final class CourierAuthenticationException extends CourierException
{
    public function isRetryable(): bool
    {
        return false;
    }
}
