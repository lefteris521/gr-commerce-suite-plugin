<?php

declare(strict_types=1);

namespace GRCommerceSuite\Feed;

/**
 * One normalized legacy offer; no WordPress objects or marketplace tag names.
 * Identity/grouping policy stays with extraction until an owner-approved migration.
 */
final readonly class MarketplaceProduct
{
    /**
     * @param list<string> $additionalImages
     * @param list<array{id: string, size: string, price: float, availability: string, quantity: int, ean: string, mpn: string}> $sizeVariations
     * @param list<string> $issues Compatibility holds requiring merchant remediation or approved policy.
     */
    public function __construct(
        public string $id,
        public string $name,
        public string $link,
        public string $image,
        public array $additionalImages,
        public string $category,
        public float $price,
        public string $vat,
        public string $availability,
        public string $description,
        public string $manufacturer,
        public string $mpn,
        public string $ean,
        public bool $inStock,
        public bool $backorder,
        public ?int $quantity,
        public float $weight,
        public string $color,
        public string $sizes,
        public array $sizeVariations,
        public bool $requiresVariantSplit = false,
        public array $issues = [],
        public string $isbn = '',
    ) {
    }

    /**
     * Same offer with extra compatibility issues; every other value is carried over unchanged.
     *
     * @param list<string> $extra
     */
    public function withIssues(array $extra): self
    {
        return new self(
            id: $this->id, name: $this->name, link: $this->link, image: $this->image,
            additionalImages: $this->additionalImages, category: $this->category, price: $this->price,
            vat: $this->vat, availability: $this->availability, description: $this->description,
            manufacturer: $this->manufacturer, mpn: $this->mpn, ean: $this->ean,
            inStock: $this->inStock, backorder: $this->backorder, quantity: $this->quantity,
            weight: $this->weight, color: $this->color, sizes: $this->sizes, sizeVariations: $this->sizeVariations,
            requiresVariantSplit: $this->requiresVariantSplit,
            issues: array_values(array_unique(array_merge($this->issues, $extra))),
            isbn: $this->isbn,
        );
    }
}
