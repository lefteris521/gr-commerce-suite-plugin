<?php

declare(strict_types=1);

namespace GRCommerceSuite\Feed;

use Throwable;
use ZipArchive;

/** One-file ZIP, bounded streaming fallback, and atomic replacement on the destination filesystem. */
final class FeedZipArchive
{
    private const ENTRY = 'skroutz.xml';
    private const CHUNK = 65536;
    private const ZIP32_LIMIT = 0xffffffff;

    public function create(string $source, string $destination, bool $preferNative = true): bool
    {
        $temp = $destination . '.' . bin2hex(random_bytes(8)) . '.tmp';
        try {
            if (!is_file($source) || !is_readable($source)) {
                return false;
            }
            // A native compression failure is a failure, not permission to overwrite via another path.
            $ok = $preferNative && class_exists(ZipArchive::class)
                ? $this->native($source, $temp) : $this->streaming($source, $temp);
            if (!$ok) {
                return false;
            }
            for ($attempt = 0; $attempt < 3; ++$attempt) {
                if ($attempt > 0) {
                    usleep(150000);
                }
                if (@rename($temp, $destination)) {
                    return true;
                }
            }
            return false; // Never truncate/unlink/copy over a published destination.
        } catch (Throwable) {
            return false;
        } finally {
            if (is_file($temp)) {
                @unlink($temp);
            }
        }
    }

    private function native(string $source, string $temp): bool
    {
        $zip = new ZipArchive();
        if ($zip->open($temp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            return false;
        }
        $added = $zip->addFile($source, self::ENTRY);
        $closed = $zip->close(); // close is where libzip actually reads/compresses the source.
        if (!$added || !$closed) {
            return false;
        }
        $reader = new ZipArchive();
        if ($reader->open($temp, ZipArchive::CHECKCONS) !== true) {
            return false;
        }
        try {
            if ($reader->numFiles !== 1) {
                return false;
            }
            $stream = $reader->getStream(self::ENTRY);
            if ($stream === false) {
                return false;
            }
            try {
                $hash = hash_init('sha256');
                $size = hash_update_stream($hash, $stream);
                return $size === filesize($source) && hash_final($hash) === hash_file('sha256', $source);
            } finally {
                fclose($stream);
            }
        } finally {
            $reader->close();
        }
    }

    private function streaming(string $source, string $temp): bool
    {
        if (!function_exists('deflate_init') || !function_exists('inflate_init')) {
            return false;
        }
        $input = @fopen($source, 'rb');
        $output = @fopen($temp, 'x+b');
        if ($input === false || $output === false) {
            if (is_resource($input)) { fclose($input); }
            if (is_resource($output)) { fclose($output); }
            return false;
        }
        try {
            // ZIP32 only. Refuse large files explicitly rather than overflowing the headers.
            $initialSize = filesize($source);
            if ($initialSize === false || $initialSize >= self::ZIP32_LIMIT) {
                return false;
            }
            $deflate = deflate_init(ZLIB_ENCODING_RAW);
            if ($deflate === false || !$this->write($output, str_repeat("\0", 30) . self::ENTRY)) {
                return false;
            }
            $crc = hash_init('crc32b');
            $sha = hash_init('sha256');
            $size = 0;
            $compressedSize = 0;
            while (!feof($input)) {
                $chunk = fread($input, self::CHUNK);
                if ($chunk === false || ($chunk === '' && !feof($input))) {
                    return false;
                }
                $size += strlen($chunk);
                hash_update($crc, $chunk);
                hash_update($sha, $chunk);
                $compressed = deflate_add($deflate, $chunk, feof($input) ? ZLIB_FINISH : ZLIB_NO_FLUSH);
                if ($compressed === false) {
                    return false;
                }
                $compressedSize += strlen($compressed);
                if ($size >= self::ZIP32_LIMIT || $compressedSize >= self::ZIP32_LIMIT || !$this->write($output, $compressed)) {
                    return false;
                }
            }
            $crcValue = (int) hexdec(hash_final($crc));
            $expectedHash = hash_final($sha);
            $offset = 30 + strlen(self::ENTRY) + $compressedSize;
            $date = getdate();
            $time = ($date['hours'] << 11) | ($date['minutes'] << 5) | ($date['seconds'] >> 1);
            $day = (($date['year'] - 1980) << 9) | ($date['mon'] << 5) | $date['mday'];
            $fields = pack('vvvvvVVVvv', 20, 0, 8, $time, $day, $crcValue, $compressedSize, $size, strlen(self::ENTRY), 0);
            // The central header adds comment/disk/internal/external/offset after the shared fields.
            $central = "PK\x01\x02" . pack('v', 20) . $fields . pack('vvvVV', 0, 0, 0, 0, 0) . self::ENTRY;
            $end = "PK\x05\x06" . pack('vvvvVVv', 0, 0, 1, 1, strlen($central), $offset, 0);
            $local = "PK\x03\x04" . $fields . self::ENTRY;
            if ($offset + strlen($central) >= self::ZIP32_LIMIT || $size !== $initialSize
                || !$this->write($output, $central . $end)
                || fseek($output, 0) !== 0 || !$this->write($output, $local)
                || !fflush($output)) {
                return false;
            }
            $stat = fstat($output);
            if ($stat === false || $stat['size'] !== $offset + strlen($central) + strlen($end)
                || fseek($output, 0) !== 0 || fread($output, strlen($local)) !== $local
                || fseek($output, $offset) !== 0 || fread($output, strlen($central . $end)) !== $central . $end) {
                return false;
            }
            // Read the staged compressed payload back before it may become public.
            if (fseek($output, 30 + strlen(self::ENTRY)) !== 0) {
                return false;
            }
            $inflate = inflate_init(ZLIB_ENCODING_RAW);
            if ($inflate === false) {
                return false;
            }
            $verified = hash_init('sha256');
            $remaining = $compressedSize;
            $decodedSize = 0;
            while ($remaining > 0) {
                // A small compressed slice bounds expansion even for highly compressible XML.
                $bytes = fread($output, min(1024, $remaining));
                if ($bytes === false || $bytes === '') { return false; }
                $remaining -= strlen($bytes);
                $decoded = inflate_add($inflate, $bytes, $remaining === 0 ? ZLIB_FINISH : ZLIB_SYNC_FLUSH);
                if ($decoded === false) { return false; }
                $decodedSize += strlen($decoded);
                hash_update($verified, $decoded);
            }
            return inflate_get_status($inflate) === ZLIB_STREAM_END && $decodedSize === $size
                && hash_final($verified) === $expectedHash;
        } finally {
            fclose($input);
            fclose($output);
        }
    }

    /** @param resource $stream */
    private function write($stream, string $bytes): bool
    {
        return $bytes === '' || fwrite($stream, $bytes) === strlen($bytes);
    }
}
