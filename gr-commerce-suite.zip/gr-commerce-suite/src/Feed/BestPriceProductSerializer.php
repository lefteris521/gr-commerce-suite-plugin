<?php

declare(strict_types=1);

namespace GRCommerceSuite\Feed;

use DomainException;
use GRCommerceSuite\Utils\GreekDataNormalizer;
use XMLWriter;

/**
 * BestPrice v2.0.14 flat records. Local preview only: no route, job, URL or registration.
 * Refuse a lossy conversion; never manufacture identities or flatten a different size's price.
 */
final class BestPriceProductSerializer
{
    /** @return list<string> Machine-readable reasons; presence of XML is not marketplace acceptance. */
    public function readinessIssues(MarketplaceProduct $product): array
    {
        $issues = [];
        foreach (['name', 'link', 'image', 'category', 'manufacturer'] as $field) {
            if (trim($product->$field) === '') {
                $issues[] = 'missing_' . $field;
            }
        }
        if ($product->mpn === '' && $product->ean === '') {
            $issues[] = 'missing_manufacturer_identifier';
        }
        if (!$this->canRepresent($product)) {
            $issues[] = 'variant_mapping_requires_approval';
        }
        return $issues;
    }

    public function serialize(MarketplaceProduct $product): string
    {
        if (!$this->canRepresent($product)) {
            throw new DomainException('BestPrice offer ' . $product->id . ' needs an approved variant mapping; no record was serialized.');
        }
        $writer = new XMLWriter();
        $writer->openMemory();
        $writer->setIndent(true);
        $writer->setIndentString('    ');
        $writer->startElement('product');
        // Mandatory fields remain present even when merchant data is missing (PDF observations).
        foreach ([
            'productId' => $product->id,
            'title' => $product->name,
            'productURL' => $product->link,
            'image' => $product->image,
        ] as $tag => $value) {
            $this->text($writer, $tag, $value);
        }
        foreach ($product->additionalImages as $image) {
            $this->text($writer, 'additional_image', $image);
        }
        $this->text($writer, 'category_path', $product->category);
        $writer->writeElement('price', number_format($product->price, 2, '.', ''));
        $this->text($writer, 'availability', $product->availability);
        $this->text($writer, 'brand', $product->manufacturer);
        $this->text($writer, 'mpn', $product->mpn);
        if ($product->ean !== '') {
            $this->text($writer, 'ean', $product->ean);
        }
        if ($product->isbn !== '') {
            $this->text($writer, 'isbn', $product->isbn);
        }
        $writer->writeElement('stock', $product->inStock && !$product->backorder ? 'Y' : 'N');
        if ($product->weight > 0.0) {
            $writer->writeElement('weight', number_format($product->weight, 2, '.', ''));
        }
        if ($product->color !== '') {
            $this->text($writer, 'color', $product->color);
        }
        if ($product->sizes !== '') {
            $this->text($writer, 'size', $product->sizes);
        }
        $writer->endElement();
        return $writer->outputMemory();
    }

    private function canRepresent(MarketplaceProduct $product): bool
    {
        if ($product->requiresVariantSplit || in_array('mixed_vat', $product->issues, true)) {
            return false;
        }
        $sizes = array_map('trim', explode(',', $product->sizes));
        foreach ($product->sizeVariations as $variation) {
            if ($variation['price'] !== $product->price || $variation['availability'] !== $product->availability
                || !in_array($variation['size'], $sizes, true)) {
                return false;
            }
        }
        return true;
    }

    private function text(XMLWriter $writer, string $tag, string $value): void
    {
        $writer->startElement($tag);
        $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($value));
        $writer->endElement();
    }
}
