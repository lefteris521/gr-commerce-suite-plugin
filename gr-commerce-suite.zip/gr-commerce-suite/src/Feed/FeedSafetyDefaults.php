<?php

declare(strict_types=1);

namespace GRCommerceSuite\Feed;

use FilesystemIterator;
use Throwable;

/**
 * Owner-approved option B for the D9/D10 exclusion policies: new installs start with both ON, upgrades keep OFF.
 *
 * The generator still reads both options with a hard-coded `'no'` fallback, so any site that never goes through
 * {@see self::seedForNewInstall()} (plugin updates, network sites provisioned lazily) stays OFF and byte-identical.
 * Uncertain history means EXISTING: callers must capture {@see self::hadInstallHistory()} BEFORE the plugin writes any
 * of its own rows (schema version, activation stamp), otherwise every activation would look like a reactivation.
 */
final class FeedSafetyDefaults
{
    private const POLICY_OPTIONS = [
        SkroutzXmlGenerator::OPTION_EXCLUDE_SHARED_STOCK,
        SkroutzXmlGenerator::OPTION_EXCLUDE_MIXED_VAT,
    ];

    /**
     * Turn both exclusion policies ON for the current site unless it has install history.
     * Never overwrites an option that already exists, so a merchant's explicit choice survives reactivation.
     *
     * @param bool $hadHistory Result of {@see self::hadInstallHistory()} captured before this activation wrote anything.
     * @return bool True when this call seeded the defaults.
     */
    public static function seedForNewInstall(bool $hadHistory): bool
    {
        if ($hadHistory) {
            return false;
        }

        $seeded = false;
        foreach (self::POLICY_OPTIONS as $option) {
            // add_option() is a no-op when the row exists; autoload stays off like the other feed options.
            $seeded = add_option($option, 'yes', '', false) || $seeded;
        }

        return $seeded;
    }

    /**
     * Any trace that GR Commerce Suite ran on this site (current blog), or any doubt, counts as history.
     *
     * Evidence: any `grcs_*` option row (schema version, activation stamp, settings, feed state; uninstall keeps them
     * on purpose, so a reinstall is recognised), or anything left in the plugin's uploads folder (feed files, logs).
     */
    public static function hadInstallHistory(): bool
    {
        global $wpdb;

        try {
            $row = $wpdb->get_var($wpdb->prepare(
                "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s LIMIT 1",
                $wpdb->esc_like('grcs_') . '%'
            ));
            if ($row !== null || (string) $wpdb->last_error !== '') {
                return true;
            }

            $uploads = wp_upload_dir(null, false);
            if (!is_array($uploads) || !empty($uploads['error']) || empty($uploads['basedir'])) {
                return true;
            }

            $dir = rtrim((string) $uploads['basedir'], '/\\') . '/gr-commerce-suite';
            return file_exists($dir) && (!is_dir($dir) || (new FilesystemIterator($dir))->valid());
        } catch (Throwable) {
            return true;
        }
    }
}
