<?php

declare(strict_types=1);

namespace GRCommerceSuite\Feed;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Jobs\JobDispatcher;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Support\Logger;
use GRCommerceSuite\Utils\GreekDataNormalizer;
use RuntimeException;
use Throwable;
use WC_Product;
use WC_Product_Variation;

/**
 * Chunked Skroutz & BestPrice XML Feed Generator (SPEC.md §12).
 *
 * Key Architectural Highlights:
 * 1. Bounded batch streaming: Uses PHP XMLWriter opening fragments in memory and flushing directly
 *    to a temporary disk file (`wp-content/uploads/gr-commerce-suite/skroutz-temp.xml`) in batches
 *    via Action Scheduler. One parent's children/fragments are still materialized; readiness keeps
 *    an EAN index, so neither a constant-memory bound nor a fixed memory ceiling is guaranteed.
 * 2. Staged completion: Validate XML and ZIP before individually atomic public replacements, with XML
 *    rollback on ZIP replacement failure. Two static URLs do not provide atomic pair consistency.
 * 3. 2026 Skroutz XML specifications:
 *    - Reads native WooCommerce 9.2+ EAN/Barcode via `$product->get_global_unique_id()` with fallback to custom meta.
 *    - Groups variable products by Size attributes into a `<size>` comma-separated tag, while splitting
 *      distinct Color variations into separate `<product>` nodes as required by Skroutz fashion rules.
 *      A product's `<size>` lists only sizes sold at its advertised price and availability; when every size
 *      has a tracked quantity, each size is also sent as a Skroutz `<variation>` with its own price and stock.
 *    - Supports a custom per-product `_grcs_skroutz_price` override and a global percentage markup setting.
 *    - Uses `GreekDataNormalizer::sanitizeXmlString()` on all product titles and descriptions.
 */
final class SkroutzXmlGenerator implements HookSubscriberInterface
{
    public const DEFAULT_BATCH_SIZE = 200;
    public const HOOK_CHUNK_ACTION = 'grcs/feeds/skroutz_chunk';
    /** Recurring Action Scheduler hook (D7, owner-approved 2026-11-04): regenerates the feed every 12 h. */
    public const HOOK_SCHEDULED = 'grcs/feeds/skroutz_scheduled';
    /** Checkbox option; a missing option means ON. */
    public const OPTION_AUTO_REFRESH = 'grcs_skroutz_auto_refresh';
    public const AUTO_REFRESH_INTERVAL = 12 * 3600;
    /** A scheduled tick is skipped when the last finished run (a manual one counts) is younger than this. */
    private const AUTO_REFRESH_MIN_AGE = 11 * 3600;
    private const RUN_ABANDONED_AFTER = 2 * 3600;
    public const NONCE_ACTION_GENERATE = 'grcs_generate_skroutz_xml_nonce';
    public const OPTION_LAST_RUN = 'grcs_feed_last_run_skroutz';
    public const OPTION_LAST_FAILURE = 'grcs_feed_last_failure_skroutz';
    public const OPTION_PUBLICATION_FAILURE = 'grcs_feed_publication_failure_skroutz';
    private const WRITE_AHEAD_KEYS = ['wal_run_id', 'wal_prior_partial', 'old_xml_sha256', 'old_zip_sha256', 'new_xml_sha256', 'new_zip_sha256', 'report'];
    public const OPTION_FEED_ENABLED = 'grcs_skroutz_feed_enabled';
    public const OPTION_MARKUP_PERCENT = 'grcs_skroutz_markup_percentage';
    public const OPTION_ACTIVE_RUN = 'grcs_feed_active_run_skroutz';
    public const OPTION_AVAILABILITY = 'grcs_skroutz_availability';
    public const OPTION_SIZE_ATTRIBUTE = 'grcs_skroutz_size_attribute';
    public const OPTION_COLOR_ATTRIBUTE = 'grcs_skroutz_color_attribute';
    public const OPTION_BRAND_ATTRIBUTE = 'grcs_skroutz_brand_attribute';
    public const OPTION_DEFAULT_MANUFACTURER = 'grcs_skroutz_default_manufacturer';
    public const OPTION_INCLUDE_OUT_OF_STOCK = 'grcs_skroutz_include_out_of_stock';
    /**
     * Owner-approved D9 interim policy: leave listings whose variations share one stock pool out of newly generated
     * Skroutz XML. Stays "no" until the owner has approved the dry-run impact report (bin/marketplace-shared-stock-report.php).
     */
    public const OPTION_EXCLUDE_SHARED_STOCK = 'grcs_skroutz_exclude_shared_stock';
    /**
     * Owner-approved D10 policy (option 3): leave listings whose published variations carry different effective VAT rates
     * out of newly generated Skroutz XML. Stays "no" until the owner has reviewed bin/marketplace-mixed-vat-report.php.
     */
    public const OPTION_EXCLUDE_MIXED_VAT = 'grcs_skroutz_exclude_mixed_vat';
    /** Record-level marker (never serialized): the listing is kept out of the Skroutz XML because its identity is unsafe. */
    private const IDENTITY_WITHHELD = 'identity_withheld';
    public const DEFAULT_AVAILABILITY = 'Παράδοση 1 έως 3 ημέρες';
    /** Shown for backorders and opted-in out-of-stock products: no delivery window is promised on the merchant's behalf. */
    public const ON_ORDER_AVAILABILITY = 'Κατόπιν παραγγελίας';
    /** Skroutz accepts quantities from 0 to 10,000,000 and at most 15 unique images per product. */
    private const MAX_QUANTITY = 10000000;
    private const MAX_IMAGES = 15;
    private const UNAVAILABLE = ['in_stock' => false, 'backorder' => false, 'quantity' => 0];

    public const DEFAULT_TEMP_FILENAME = 'skroutz-temp.xml';
    public const DEFAULT_FINAL_FILENAME = 'skroutz.xml';
    public const DEFAULT_ZIP_FILENAME = 'skroutz.xml.zip';

    private readonly LoggerInterface $logger;

    private ?string $uploadsDir = null;

    private ?string $runId = null;

    /** @var list<int> Products whose distinct variants cannot all be represented under the legacy grouping. */
    private array $variationIssues = [];

    /** @var array<int, list<string>> Readiness warnings; export policies and existing IDs are preserved. */
    private array $productIssues = [];

    public function __construct(
        private readonly ?JobDispatcher $jobDispatcher = null,
        ?LoggerInterface $logger = null,
        ?string $uploadsDir = null,
    ) {
        $this->logger = $logger ?? new Logger('grcs-feeds');
        $this->uploadsDir = $uploadsDir;
    }

    /**
     * Register Action Scheduler hook subscriber (SPEC.md §5.2, §9.1).
     */
    public function register(): void
    {
        if (!LicenseManager::isLicensed() || !ModuleRegistry::isEnabled(ModuleRegistry::SKROUTZ)) {
            return;
        }

        if (function_exists('add_action')) {
            add_action(self::HOOK_CHUNK_ACTION, [$this, 'handleChunkAction'], 10, 1);
            add_action(self::HOOK_SCHEDULED, [$this, 'handleScheduledRefresh'], 10, 1);
            add_action('admin_post_grcs_generate_skroutz_xml', [$this, 'handleAdminPostGenerate']);
        }
    }

    /**
     * Recurring D7 refresh (every 12 h via Action Scheduler). Re-checks licence, module, feed switch and the auto-refresh option;
     * never supersedes a running run (startGeneration() would) and skips when the last finished run, manual or scheduled, is
     * younger than 11 h. A failed run keeps the previous files under the existing recovery policy. Never throws, so the
     * scheduler does not mark the tick failed; problems are logged and the next tick tries again. No stock/price triggers.
     *
     * @param mixed $payload Scheduler payload; unused.
     */
    public function handleScheduledRefresh(mixed $payload = []): void
    {
        try {
            if (!$this->autoRefreshEnabled()) {
                return;
            }
            $active = (string) get_option(self::OPTION_ACTIVE_RUN, '');
            if ($active !== '') {
                if (!$this->isRunAbandoned($active)) {
                    $this->logger->info('Scheduled Skroutz feed refresh skipped: a generation run is still active.');
                    return;
                }
                $this->logger->info('Scheduled Skroutz feed refresh: the active run is abandoned (temp file missing or stale); starting a new run.', ['run_id' => $active]);
            }
            $age = $this->secondsSinceLastFinishedRun();
            if ($age !== null && $age < self::AUTO_REFRESH_MIN_AGE) {
                $this->logger->info('Scheduled Skroutz feed refresh skipped: the last finished run is recent.', ['age_seconds' => $age]);
                return;
            }
            if ($this->startGeneration(enqueue: true, onlyIfIdle: true) === '') {
                $this->logger->info('Scheduled Skroutz feed refresh skipped: a live generation run claimed the feed first.');
            }
        } catch (Throwable $error) {
            try {
                $this->logger->error('Scheduled Skroutz feed refresh could not start; the previous feed stays online.', ['error' => $error->getMessage()]);
            } catch (Throwable) {
                // The handler must never throw, even when logging fails.
            }
        }
    }

    /**
     * A run is never abandoned while Action Scheduler holds a pending or in-progress chunk action for it (a backlogged queue
     * can leave the temp file untouched for hours). Only without one: abandoned when its temp file (appended by every chunk)
     * is missing or has not been touched for 2 h.
     */
    private function isRunAbandoned(string $runId): bool
    {
        if (preg_match('/^[a-f0-9]{16}$/D', $runId) !== 1) {
            return true;
        }
        if ($this->hasLiveChunkAction($runId)) {
            return false;
        }
        $temp = $this->getUploadsDir() . '/skroutz-temp-' . $runId . '.xml';
        if ($this->runLockIsHeld($temp . '.lock')) {
            return false;
        }
        clearstatcache(true, $temp);
        $mtime = is_file($temp) ? @filemtime($temp) : false;
        return $mtime === false || $mtime < time() - self::RUN_ABANDONED_AFTER;
    }

    /**
     * Liveness probe: a chunk worker or the synchronous generateAll() holds the run's `.lock` exclusively while it works.
     * Busy or unopenable (inconclusive) counts as live. A lock obtained here is released at once; the file is left in place.
     */
    private function runLockIsHeld(string $lockPath): bool
    {
        $handle = @fopen($lockPath, 'c+b');
        if ($handle === false) {
            return true;
        }
        $got = flock($handle, LOCK_EX | LOCK_NB);
        if ($got) {
            flock($handle, LOCK_UN);
        }
        fclose($handle);
        return !$got;
    }

    /**
     * Whether Action Scheduler has a pending or in-progress HOOK_CHUNK_ACTION for this run, in the group used by enqueue.
     * When the lookup itself fails the run cannot be proven dead, so it counts as live. No scheduler functions: no chunk.
     */
    private function hasLiveChunkAction(string $runId): bool
    {
        if (!function_exists('as_get_scheduled_actions')) {
            return false;
        }
        $group = $this->jobDispatcher !== null && defined('GRCS_AS_GROUP') ? (string) constant('GRCS_AS_GROUP') : JobDispatcher::GROUP;
        $perPage = 100;
        try {
            foreach (['pending', 'in-progress'] as $status) {
                $complete = false;
                for ($page = 0; $page < 50; ++$page) {
                    $actions = as_get_scheduled_actions(
                        ['hook' => self::HOOK_CHUNK_ACTION, 'group' => $group, 'status' => $status, 'per_page' => $perPage, 'offset' => $page * $perPage],
                        'OBJECT'
                    );
                    if (!is_array($actions)) {
                        $complete = true;
                        break;
                    }
                    foreach ($actions as $action) {
                        $args = is_object($action) && method_exists($action, 'get_args') ? $action->get_args() : [];
                        $payload = is_array($args) ? ($args[0] ?? $args) : [];
                        if (is_array($payload) && ($payload['run_id'] ?? null) === $runId) {
                            return true;
                        }
                    }
                    if (count($actions) < $perPage) {
                        $complete = true;
                        break;
                    }
                }
                if (!$complete) {
                    return true; // page cap reached without finishing the scan: inconclusive counts as live
                }
            }
        } catch (Throwable) {
            return true;
        }
        return false;
    }

    /**
     * Whether the 12 h refresh may exist at all: licensed, Skroutz module on, feed enabled and the auto-refresh option on.
     * Plugin::registerRecurringJobs schedules or cancels the recurring hook from this, and the handler re-checks it.
     */
    public function autoRefreshEnabled(): bool
    {
        try {
            return LicenseManager::isLicensed()
                && ModuleRegistry::isEnabled(ModuleRegistry::SKROUTZ)
                && $this->isFeedEnabled()
                && self::autoRefreshOptionOn();
        } catch (Throwable) {
            return false;
        }
    }

    /** `grcs_skroutz_auto_refresh`: a missing option means ON; only an explicit unchecked save turns it off. */
    private static function autoRefreshOptionOn(): bool
    {
        return in_array(get_option(self::OPTION_AUTO_REFRESH, 'yes'), ['yes', true, 1, '1'], true);
    }

    /**
     * Seconds since the last finished (published) run. Null when none is recorded, when `finished_at` is not exactly
     * `Y-m-d H:i:s` (UTC) without parse warnings/errors, or when it lies in the future: all count as "no record".
     */
    private function secondsSinceLastFinishedRun(): ?int
    {
        $last = get_option(self::OPTION_LAST_RUN, []);
        $finished = is_array($last) ? ($last['finished_at'] ?? null) : null;
        if (!is_string($finished)) {
            return null;
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $finished, new \DateTimeZone('UTC'));
        $errors = \DateTimeImmutable::getLastErrors();
        if ($date === false || ($errors !== false && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))) {
            return null;
        }
        $age = time() - $date->getTimestamp();
        return $age < 0 ? null : $age;
    }

    /** "Next automatic refresh: <local time>" from the scheduler; empty when auto refresh is off or nothing is scheduled. */
    private function nextAutomaticRefreshNote(): string
    {
        if (!self::autoRefreshOptionOn() || !function_exists('as_next_scheduled_action')) {
            return '';
        }
        try {
            $group = defined('GRCS_AS_GROUP') ? (string) constant('GRCS_AS_GROUP') : JobDispatcher::GROUP;
            $next = as_next_scheduled_action(self::HOOK_SCHEDULED, null, $group);
        } catch (Throwable) {
            return '';
        }
        if (!is_int($next) || $next <= 0) {
            return '';
        }
        $when = function_exists('wp_date') ? (string) wp_date('j/n/Y H:i', $next) : gmdate('j/n/Y H:i', $next);
        return sprintf(AdminLocale::__('Next automatic refresh: %s', 'gr-commerce-suite'), $when);
    }

    /**
     * Handle synchronous trigger from WP Admin (`admin-post.php?action=grcs_generate_skroutz_xml`).
     */
    public function handleAdminPostGenerate(): void
    {
        if (
            !function_exists('current_user_can')
            || !(current_user_can('manage_woocommerce') || current_user_can('grcs_manage_settings'))
        ) {
            if (function_exists('wp_die')) {
                wp_die(esc_html__('Permission denied.', 'gr-commerce-suite'), 403);
            }
            return;
        }

        check_admin_referer(self::NONCE_ACTION_GENERATE);

        if (!$this->isFeedEnabled()) {
            wp_die(esc_html__('XML feed generation is disabled in settings.', 'gr-commerce-suite'), 400);
        }

        $this->startGeneration(enqueue: true);

        $redirect = function_exists('wp_get_referer') ? (string) wp_get_referer() : '';
        if ($redirect === '' && function_exists('admin_url')) {
            $redirect = admin_url('admin.php?page=grcs-cod-reconciliation');
        }
        if (function_exists('add_query_arg') && $redirect !== '') {
            $redirect = add_query_arg(['grcs_skroutz_queued' => 1], $redirect);
        }
        if (function_exists('wp_safe_redirect') && $redirect !== '') {
            wp_safe_redirect($redirect);
            exit;
        }
    }

    /**
     * Public feed URL shared by the reconciliation page and WooCommerce settings.
     */
    public static function getPublicFeedUrl(): string
    {
        if (function_exists('wp_upload_dir')) {
            $uploads = wp_upload_dir();
            if (is_array($uploads) && !empty($uploads['baseurl'])) {
                return rtrim((string) $uploads['baseurl'], '/') . '/gr-commerce-suite/skroutz.xml';
            }
        }

        if (function_exists('content_url')) {
            return rtrim((string) content_url('uploads/gr-commerce-suite/skroutz.xml'), '/');
        }

        return '/wp-content/uploads/gr-commerce-suite/skroutz.xml';
    }

    /**
     * What a merchant needs before submitting the URL: does a feed exist, when was it built,
     * how many products it holds, and whether a new run is still in progress. Read-only.
     *
     * A feed older than a day is reported as out of date. With automatic refresh on, a run is scheduled every 12 h, so that
     * only shows when scheduled runs stop (switched off, scheduler not running, repeated failures); a manual run works any time.
     * While a refresh is scheduled the text ends with "Next automatic refresh: <local time>".
     *
     * @return array{state: 'ready'|'attention'|'stale'|'empty'|'running'|'never', text: string, fix?: list<array{name: string, url: string}>}
     */
    public function statusSummary(): array
    {
        $summary = $this->buildStatusSummary();
        $next = $this->nextAutomaticRefreshNote();
        if ($next !== '') {
            $summary['text'] .= ' ' . $next;
        }

        return $summary;
    }

    /**
     * @return array{state: 'ready'|'attention'|'stale'|'empty'|'running'|'never', text: string, fix?: list<array{name: string, url: string}>}
     */
    private function buildStatusSummary(): array
    {
        $last = get_option(self::OPTION_LAST_RUN, []);
        $last = is_array($last) ? $last : [];
        $published = file_exists($this->getFinalFilePath());
        $count = (int) ($last['products_written'] ?? 0);
        $built = '';
        $ageDays = 0;
        if ($published && is_string($last['finished_at'] ?? null) && ($time = strtotime($last['finished_at'] . ' UTC')) !== false) {
            $built = function_exists('wp_date') ? (string) wp_date('j/n/Y H:i', $time) : gmdate('j/n/Y H:i', $time);
            $ageDays = intdiv(max(0, time() - $time), 86400);
        }
        $running = (string) get_option(self::OPTION_ACTIVE_RUN, '') !== '';
        $failed = (string) get_option(self::OPTION_LAST_FAILURE, '') !== '';
        $publicationFailure = get_option(self::OPTION_PUBLICATION_FAILURE, []);
        if (is_array($publicationFailure) && !empty($publicationFailure['partial'])) {
            return ['state' => 'attention', 'text' => AdminLocale::__('Feed publication was interrupted. XML and ZIP may be from different generations; check Diagnostics before using either URL.', 'gr-commerce-suite')];
        }

        if (!$published) {
            if ($failed) {
                return ['state' => 'attention', 'text' => AdminLocale::__('Feed generation failed. No feed has been published; correct the error in Diagnostics and generate again.', 'gr-commerce-suite')];
            }
            $state = $running ? 'running' : 'never';
            $text = $running
                ? AdminLocale::__('The first feed is being generated in the background. The URL starts working when it finishes; refresh this page in a minute.', 'gr-commerce-suite')
                : (ModuleRegistry::isEnabled(ModuleRegistry::BESTPRICE)
                    ? AdminLocale::__('Not generated yet. The Skroutz URL starts working after you generate the feed. BestPrice is available for local preview only; no BestPrice feed is published.', 'gr-commerce-suite')
                    : AdminLocale::__('Not generated yet. The Skroutz URL starts working after you generate the feed.', 'gr-commerce-suite'));
            return ['state' => $state, 'text' => $text];
        }
        $text = $built !== ''
            ? sprintf(AdminLocale::_n('Last generated %1$s with %2$d product.', 'Last generated %1$s with %2$d products.', $count, 'gr-commerce-suite'), $built, $count)
            : AdminLocale::__('A feed file is published.', 'gr-commerce-suite');
        if ($failed) {
            return ['state' => 'attention', 'text' => $text . ' ' . AdminLocale::__('The latest generation failed. The previous feed remains online; check Diagnostics and generate again.', 'gr-commerce-suite')];
        }
        if ($running) {
            return ['state' => 'running', 'text' => $text . ' ' . AdminLocale::__('A new version is being generated; the current file stays online until it is ready.', 'gr-commerce-suite')];
        }
        if (array_key_exists('zip_created', $last) && (empty($last['zip_created']) || !is_file($this->getZipFilePath())
            || (isset($last['zip_size']) && filesize($this->getZipFilePath()) !== (int) $last['zip_size']))) {
            return ['state' => 'attention', 'text' => $text . ' ' . AdminLocale::__('The ZIP archive is missing or was not created successfully. Generate the feed again.', 'gr-commerce-suite')];
        }
        if ($built !== '' && $count === 0) {
            return ['state' => 'empty', 'text' => $text . ' ' . AdminLocale::__('Check that products are published and in stock, or include out-of-stock products.', 'gr-commerce-suite')];
        }
        $stale = $ageDays >= 1
            ? ' ' . sprintf(AdminLocale::_n('The file is %d day old: generate it again so marketplaces see current prices and stock.',
                'The file is %d days old: generate it again so marketplaces see current prices and stock.', $ageDays, 'gr-commerce-suite'), $ageDays)
            : '';
        $gaps = is_array($last['gaps'] ?? null) ? $last['gaps'] : [];
        if (array_key_exists('diagnostics_available', $gaps) && $gaps['diagnostics_available'] !== true) {
            return ['state' => 'attention', 'text' => $text . ' ' . AdminLocale::__('Feed checks could not be completed. Check Diagnostics and generate again.', 'gr-commerce-suite')];
        }
        $noDescription = (int) ($gaps['no_description'] ?? 0);
        $noImage = (int) ($gaps['no_image'] ?? 0);
        $uncategorized = (int) ($gaps['uncategorized'] ?? 0);
        $noIdentifier = (int) ($gaps['no_identifier'] ?? 0);
        $duplicateEan = (int) ($gaps['duplicate_ean'] ?? 0);
        $variationPrices = (int) ($gaps['variation_prices'] ?? 0);
        $noQuantity = (int) ($gaps['no_quantity'] ?? 0);
        $parts = [];
        if ($noDescription > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product has no description', '%d products have no description', $noDescription, 'gr-commerce-suite'), $noDescription);
        }
        $sharedStock = (int) ($gaps['shared_stock'] ?? 0);
        $sharedStockExcluded = (int) ($gaps['shared_stock_excluded'] ?? 0);
        if ($sharedStockExcluded > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product has listings excluded from the Skroutz feed because its variations share one stock quantity', '%d products have listings excluded from the Skroutz feed because their variations share one stock quantity', $sharedStockExcluded, 'gr-commerce-suite'), $sharedStockExcluded);
        } elseif ($sharedStock > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product shares stock across variations (warning only: no stock exclusion is active); verified per-variation inventory or an approved marketplace policy is required', '%d products share stock across variations (warning only: no stock exclusion is active); verified per-variation inventory or an approved marketplace policy is required', $sharedStock, 'gr-commerce-suite'), $sharedStock);
        }
        $mixedVatExcluded = (int) ($gaps['mixed_vat_excluded'] ?? 0);
        $unstableId = (int) ($gaps['unstable_id'] ?? 0);
        if ($unstableId > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product has unstable or colliding colour IDs; an approved identity migration is required', '%d products have unstable or colliding colour IDs; an approved identity migration is required', $unstableId, 'gr-commerce-suite'), $unstableId);
        }
        $mixedVat = (int) ($gaps['mixed_vat'] ?? 0);
        if ($mixedVatExcluded > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product has listings excluded from the Skroutz feed because its variations have conflicting VAT rates', '%d products have listings excluded from the Skroutz feed because their variations have conflicting VAT rates', $mixedVatExcluded, 'gr-commerce-suite'), $mixedVatExcluded);
        } elseif ($mixedVat > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product groups variations with different VAT rates (warning only: no VAT exclusion is active); an approved listing policy is required', '%d products group variations with different VAT rates (warning only: no VAT exclusion is active); an approved listing policy is required', $mixedVat, 'gr-commerce-suite'), $mixedVat);
        }
        if ($noImage > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product has no image', '%d products have no image', $noImage, 'gr-commerce-suite'), $noImage);
        }
        if ($uncategorized > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product has no category', '%d products have no category', $uncategorized, 'gr-commerce-suite'), $uncategorized);
        }
        if ($noIdentifier > 0) {
            // Runs stored before the split carry only the total: keep the original sentence for them.
            if (array_key_exists('no_identifier_both', $gaps)) {
                $noBoth = (int) $gaps['no_identifier_both'];
                $noEanOnly = (int) ($gaps['no_ean_only'] ?? 0);
                $noMpnOnly = (int) ($gaps['no_mpn_only'] ?? 0);
                if ($noBoth > 0) {
                    $parts[] = sprintf(AdminLocale::_n('%d product has neither an EAN barcode nor an MPN', '%d products have neither an EAN barcode nor an MPN', $noBoth, 'gr-commerce-suite'), $noBoth);
                }
                if ($noEanOnly > 0) {
                    $parts[] = sprintf(AdminLocale::_n('%d product has an MPN but no EAN barcode', '%d products have an MPN but no EAN barcode', $noEanOnly, 'gr-commerce-suite'), $noEanOnly);
                }
                if ($noMpnOnly > 0) {
                    $parts[] = sprintf(AdminLocale::_n('%d product has an EAN barcode but no MPN', '%d products have an EAN barcode but no MPN', $noMpnOnly, 'gr-commerce-suite'), $noMpnOnly);
                }
            } else {
                $parts[] = sprintf(AdminLocale::_n('%d product has no EAN barcode or MPN', '%d products have no EAN barcode or MPN', $noIdentifier, 'gr-commerce-suite'), $noIdentifier);
            }
        }
        if ($duplicateEan > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product shares its EAN barcode with another product', '%d products share an EAN barcode with another product', $duplicateEan, 'gr-commerce-suite'), $duplicateEan);
        }
        if ($variationPrices > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product has variations that cannot all be represented in this feed', '%d products have variations that cannot all be represented in this feed', $variationPrices, 'gr-commerce-suite'), $variationPrices);
        }
        if ($noQuantity > 0) {
            $parts[] = sprintf(AdminLocale::_n('%d product has no recorded stock quantity', '%d products have no recorded stock quantity', $noQuantity, 'gr-commerce-suite'), $noQuantity);
        }
        $bestPriceVariations = (int) ($gaps['bestprice_variations'] ?? 0);
        // Preview-only BestPrice mapping remains visible without lowering Skroutz readiness.
        $bestPriceAdvice = $bestPriceVariations > 0 && ModuleRegistry::isEnabled(ModuleRegistry::BESTPRICE) ? ' ' . sprintf(AdminLocale::_n('BestPrice size mapping is unresolved for %d product', 'BestPrice size mapping is unresolved for %d products', $bestPriceVariations, 'gr-commerce-suite'), $bestPriceVariations) . '.' : '';
        if ($parts !== []) {
            $advice = [];
            if ($noImage + $uncategorized + $noIdentifier + $duplicateEan + $noDescription > 0) {
                $advice[] = AdminLocale::__('Skroutz may reject these products. Add the missing details in Products and generate again.', 'gr-commerce-suite');
            }
            if ($noQuantity > 0) {
                $advice[] = AdminLocale::__('Skroutz requires a known quantity. Enable “Track stock quantity” in Inventory and enter verified stock before generating again.', 'gr-commerce-suite');
            }
            if ($sharedStockExcluded > 0) {
                $advice[] = AdminLocale::__('To list them again, open each product, turn off “Track stock quantity for this product” on the parent, tick “Manage stock?” on every variation and enter the units you really hold; also check that no “no recorded stock quantity” warning remains.', 'gr-commerce-suite');
            }
            if ($mixedVatExcluded > 0) {
                $advice[] = AdminLocale::__('For each product with a VAT conflict, open Variations and set the tax class to “Same as parent” if they should share one VAT rate; variations that truly differ in VAT cannot share one listing.', 'gr-commerce-suite');
            }
            // Return rule: a listing is back only when no enabled exclusion still applies, so name the combined case explicitly.
            if ($sharedStockExcluded > 0 && $mixedVatExcluded > 0) {
                $advice[] = AdminLocale::__('A listing with both a stock problem and a VAT problem stays excluded until both are fixed; every other excluded listing returns, with the same ID, the next time the feed is generated after its own problem is fixed.', 'gr-commerce-suite');
            } elseif ($sharedStockExcluded > 0) {
                $advice[] = AdminLocale::__('Each excluded listing returns, with the same ID, the next time the feed is generated after its stock problem is fixed.', 'gr-commerce-suite');
            } elseif ($mixedVatExcluded > 0) {
                $advice[] = AdminLocale::__('Each excluded listing returns, with the same ID, the next time the feed is generated after its VAT problem is fixed.', 'gr-commerce-suite');
            }
            if ($variationPrices > 0) {
                $advice[] = ModuleRegistry::isEnabled(ModuleRegistry::BESTPRICE)
                    ? AdminLocale::__('Some variations need an approved listing migration before this feed can represent them correctly. BestPrice remains available for local preview only.', 'gr-commerce-suite')
                    : AdminLocale::__('Some variations need an approved listing migration before this feed can represent them correctly.', 'gr-commerce-suite');
            }
            return ['state' => 'attention', 'text' => $text . ' ' . implode(', ', $parts) . '. ' . implode(' ', $advice) . $stale . $bestPriceAdvice,
                'fix' => $this->fixLinks(is_array($gaps['fix'] ?? null) ? $gaps['fix'] : [], is_array($gaps['mixed_vat_excluded_ids'] ?? null) ? $gaps['mixed_vat_excluded_ids'] : [])];
        }
        if ($stale !== '') {
            return ['state' => 'stale', 'text' => $text . $stale . $bestPriceAdvice];
        }
        return ['state' => 'ready', 'text' => $text . $bestPriceAdvice];
    }

    /**
     * Edit links for the products the last run flagged; trashed or deleted products drop out.
     *
     * A product excluded for conflicting VAT also lists its published variations with their real rates, e.g. "Shirt (S 13% / M 24%)".
     *
     * @param array<mixed> $ids
     * @param array<mixed> $vatConflictIds
     * @return list<array{name: string, url: string}>
     */
    private function fixLinks(array $ids, array $vatConflictIds = []): array
    {
        $vatConflictIds = array_map('intval', $vatConflictIds);
        if (!function_exists('get_edit_post_link') || !function_exists('get_post_status')) {
            return [];
        }
        $links = [];
        foreach ($ids as $id) {
            $id = (int) $id;
            $url = $id > 0 && !in_array(get_post_status($id), [false, 'trash'], true) ? (string) get_edit_post_link($id, 'raw') : '';
            if ($url !== '') {
                $name = (string) get_the_title($id);
                $detail = in_array($id, $vatConflictIds, true) ? $this->vatConflictDetail($id) : '';
                $links[] = ['name' => $detail !== '' ? $name . ' (' . $detail . ')' : $name, 'url' => $url];
            }
        }
        return $links;
    }

    /**
     * "S 13% / M 24%": each published, sellable variation with the VAT rate WooCommerce really applies to it.
     * Parent context only: it lists every published in-stock child of the parent (other colours and sizes the feed may
     * withhold included), not exactly the sizes of the excluded listing.
     */
    private function vatConflictDetail(int $productId): string
    {
        $product = function_exists('wc_get_product') ? wc_get_product($productId) : null;
        if (!$product instanceof WC_Product || !$product->is_type('variable')) {
            return '';
        }
        $parts = [];
        foreach ($product->get_children() as $childId) {
            $child = wc_get_product($childId);
            if ($child instanceof WC_Product_Variation && $child->get_status() === 'publish' && $child->is_in_stock()) {
                $label = function_exists('wc_get_formatted_variation') ? trim(wp_strip_all_tags((string) wc_get_formatted_variation($child, true, false, false))) : '';
                $parts[] = ($label !== '' ? $label : '#' . $child->get_id()) . ' ' . $this->getProductVatRate($child) . '%';
            }
        }
        return implode(' / ', $parts);
    }

    /**
     * Resolve the uploads directory path for GR Commerce Suite feeds (`wp-content/uploads/gr-commerce-suite`).
     */
    public function getUploadsDir(): string
    {
        if ($this->uploadsDir !== null && $this->uploadsDir !== '') {
            if (!is_dir($this->uploadsDir)) {
                wp_mkdir_p($this->uploadsDir);
            }
            return rtrim($this->uploadsDir, '/\\');
        }

        if (function_exists('wp_upload_dir')) {
            $upload = wp_upload_dir();
            $dir = rtrim((string) $upload['basedir'], '/\\') . '/gr-commerce-suite';
        } else {
            $dir = sys_get_temp_dir() . '/gr-commerce-suite';
        }

        if (!is_dir($dir)) {
            if (function_exists('wp_mkdir_p')) {
                wp_mkdir_p($dir);
            } else {
                @mkdir($dir, 0755, true);
            }
        }

        return $dir;
    }

    public function getTempFilePath(): string
    {
        $filename = $this->runId === null ? self::DEFAULT_TEMP_FILENAME : 'skroutz-temp-' . $this->runId . '.xml';
        return $this->getUploadsDir() . '/' . $filename;
    }

    public function getFinalFilePath(): string
    {
        return $this->getUploadsDir() . '/' . self::DEFAULT_FINAL_FILENAME;
    }

    public function getZipFilePath(): string
    {
        return $this->getUploadsDir() . '/' . self::DEFAULT_ZIP_FILENAME;
    }

    /**
     * Start a fresh chunked feed generation run.
     * Initializes the temporary file with XML header and enqueues the first chunk of 200 products.
     */
    public function startGeneration(int $batchSize = self::DEFAULT_BATCH_SIZE, bool $enqueue = true, bool $onlyIfIdle = false): string
    {
        LicenseManager::assertLicensed();

        if (!$this->isFeedEnabled()) {
            throw new RuntimeException(__('XML feed generation is disabled in settings.', 'gr-commerce-suite'));
        }

        $batchSize = max(1, min(self::DEFAULT_BATCH_SIZE, $batchSize));
        $runId = bin2hex(random_bytes(8));
        $priorRunId = $this->runId;
        $this->runId = $runId;
        $tempFile = $this->getTempFilePath();

        $createdAt = gmdate('Y-m-d H:i');
        if (function_exists('wp_timezone')) {
            try {
                $nowLocal = new \DateTimeImmutable('now', wp_timezone());
                $createdAt = $nowLocal->format('Y-m-d H:i');
            } catch (Throwable) {
                $createdAt = gmdate('Y-m-d H:i');
            }
        }

        $headerXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
            . "<mywebstore>\n"
            . '    <created_at>' . $createdAt . "</created_at>\n"
            . "    <products>\n";
        if (file_put_contents($tempFile, $headerXml, LOCK_EX) === false) {
            throw new RuntimeException(__('Could not create the temporary XML feed.', 'gr-commerce-suite'));
        }
        // Serialize ownership changes with publication; never supersede between the two public renames.
        try {
            $publicationLock = $this->lockPublication();
        } catch (Throwable $error) {
            @unlink($tempFile);
            throw $error;
        }
        $claimRefused = false;
        $refusal = '';
        try {
            // Before ownership changes: the crashed run's staged files and snapshot are still needed.
            $this->recoverInterruptedPublication();
            $this->removeUnreferencedSnapshots();
            if (function_exists('wp_cache_delete')) {
                wp_cache_delete(self::OPTION_ACTIVE_RUN, 'options');
            }
            $previousRun = get_option(self::OPTION_ACTIVE_RUN, '');
            if ($onlyIfIdle && is_string($previousRun) && $previousRun !== '' && !$this->isRunAbandoned($previousRun)) {
                $claimRefused = true; // A live run owns the feed: do not supersede it.
                $refusal = 'a live run owns the feed';
            } elseif ($onlyIfIdle && $this->lastRunIsRecentUnderLock()) {
                $claimRefused = true; // A run finished (e.g. a manual one) after the caller's pre-check.
                $refusal = 'the last finished run is recent';
            } else {
                update_option(self::OPTION_ACTIVE_RUN, $runId, false);
                update_option(self::OPTION_LAST_FAILURE, '', false);
            }
        } finally {
            flock($publicationLock, LOCK_UN);
            fclose($publicationLock);
        }
        if ($claimRefused) {
            @unlink($tempFile);
            $this->runId = $priorRunId;
            $this->logger->info('XML feed generation not started: ' . $refusal . '.');
            return '';
        }
        if (is_string($previousRun) && $previousRun !== '') { $this->cleanupRun($previousRun); }
        // Sweep only recognisable, inactive, old run files, never recovery snapshots or the publication lock.
        foreach (glob($this->getUploadsDir() . '/skroutz-temp-*.xml*') ?: [] as $candidate) {
            if (preg_match('/^skroutz-temp-([a-f0-9]{16})\.xml(?:\.lock|\.zip(?:\.[a-f0-9]{16}\.tmp)?)?$/D', basename($candidate), $match) === 1
                && is_file($candidate) && filemtime($candidate) < time() - 86400) {
                $this->cleanupRun($match[1]);
            }
        }
        $this->logger->info('XML feed generation started.', ['run_id' => $runId, 'background' => $enqueue]);

        $payload = [
            'run_id' => $runId,
            'offset' => 0,
            'batch_size' => $batchSize,
            'products_written' => 0,
            'started_at' => gmdate('Y-m-d H:i:s'),
        ];

        if (!$enqueue) {
            return $runId;
        }
        if ($this->jobDispatcher !== null) {
            $this->jobDispatcher->enqueueAsync(self::HOOK_CHUNK_ACTION, $payload);
        } elseif (function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action(self::HOOK_CHUNK_ACTION, [$payload], 'gr-commerce-suite');
        }

        return $runId;
    }

    /** Fresh read (object cache bypassed) of the last finished run; true when it is younger than the auto-refresh minimum. */
    private function lastRunIsRecentUnderLock(): bool
    {
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete(self::OPTION_LAST_RUN, 'options');
        }
        $age = $this->secondsSinceLastFinishedRun();
        return $age !== null && $age < self::AUTO_REFRESH_MIN_AGE;
    }

    /**
     * Action Scheduler chunk handler.
     * Processes 200 products and schedules the subsequent chunk or finalizes the feed.
     *
     * @param mixed $payload
     */
    public function handleChunkAction(mixed $payload = []): void
    {
        LicenseManager::assertLicensed();

        if (!$this->isFeedEnabled()) {
            return;
        }

        $args = is_array($payload) ? $payload : [];
        if (isset($args[0]) && is_array($args[0])) {
            $args = $args[0];
        }

        $runId = $args['run_id'] ?? '';
        if (!is_string($runId) || preg_match('/^[a-f0-9]{16}$/D', $runId) !== 1) {
            return;
        }
        if (!$this->isActiveRun($runId)) {
            $this->cleanupRun($runId);
            return; // A superseded or completed run must never recreate or overwrite the public feed.
        }
        $this->runId = $runId;
        // A run killed while publishing is settled under the publication lock before any temp-file or checkpoint guard can reject its retry.
        $settled = $this->settleOwnInterruption($runId);
        if ($settled === 'busy') { return; }
        if ($settled === 'completed') { $this->cleanupRun($runId); return; }
        $offset = max(0, (int) ($args['offset'] ?? 0));
        $batchSize = max(1, min(self::DEFAULT_BATCH_SIZE, (int) ($args['batch_size'] ?? self::DEFAULT_BATCH_SIZE)));
        $totalWritten = max(0, (int) ($args['products_written'] ?? 0));
        $startedAt = (string) ($args['started_at'] ?? gmdate('Y-m-d H:i:s'));

        $tempFile = $this->getTempFilePath();
        if (!file_exists($tempFile)) {
            $this->recordRunFailure($runId);
            throw new RuntimeException(__('The queued XML feed run has no temporary file. Please regenerate the feed.', 'gr-commerce-suite'));
        }
        $lockFile = $tempFile . '.lock';
        $lock = fopen($lockFile, 'c+');
        if ($lock === false) {
            $this->recordRunFailure($runId);
            throw new RuntimeException(__('Could not lock the queued XML feed run.', 'gr-commerce-suite'));
        }
        try {
            if (!flock($lock, LOCK_EX | LOCK_NB)) {
                return; // Another worker owns this chunk and will queue its continuation.
            }
            $checkpointJson = stream_get_contents($lock);
            $checkpoint = is_string($checkpointJson) ? json_decode($checkpointJson, true) : null;
            if ($checkpointJson !== '' && !is_array($checkpoint)) {
                throw new RuntimeException(__('The XML feed checkpoint is damaged. Please regenerate the feed.', 'gr-commerce-suite'));
            }
            if (!is_array($checkpoint)) {
                $checkpoint = ['offset' => 0, 'size' => filesize($tempFile)];
                $this->writeCheckpoint($lock, $checkpoint);
            }
            $terminal = null;
            if ($offset !== $checkpoint['offset']) {
                // Duplicate or out-of-order delivery must not append the same products twice. The one exception: the
                // last chunk already stored everything finalization needs, so a redelivery may finish a killed run.
                if (!is_array($checkpoint['final'] ?? null) || $offset > (int) $checkpoint['offset']) {
                    return;
                }
                $terminal = $checkpoint['final'];
            }
            $output = fopen($tempFile, 'c+b');
            if ($output === false) {
                throw new RuntimeException(__('Could not resume the queued XML feed run.', 'gr-commerce-suite'));
            }
            try {
                if (!ftruncate($output, max(0, (int) $checkpoint['size']))) {
                    throw new RuntimeException(__('Could not restore the XML feed checkpoint.', 'gr-commerce-suite'));
                }
            } finally {
                fclose($output);
            }

            if ($terminal !== null) {
                $result = ['has_more' => false];
                $newTotalWritten = max(0, (int) ($terminal['products_written'] ?? 0));
                $startedAt = (string) ($terminal['started_at'] ?? $startedAt);
                $variationIssues = self::addVariationIssues($terminal['variation_issues'] ?? [], []);
                $productIssues = self::addProductIssues($terminal['product_issues'] ?? [], []);
            } else {
                $result = $this->processBatch($offset, $batchSize);
                $newTotalWritten = $totalWritten + $result['written_count'];
                // Carried in the payload like the product count, so a retried chunk never counts twice.
                $variationIssues = self::addVariationIssues($args['variation_issues'] ?? [], $result['variation_issues']);
                $productIssues = self::addProductIssues($args['product_issues'] ?? [], $result['product_issues']);
                clearstatcache(true, $tempFile);
                $this->writeCheckpoint($lock, ['offset' => $result['next_offset'], 'size' => filesize($tempFile)]
                    + ($result['has_more'] ? [] : ['final' => ['products_written' => $newTotalWritten, 'started_at' => $startedAt,
                        'variation_issues' => $variationIssues, 'product_issues' => $productIssues]]));
            }

            if ($result['has_more']) {
                $nextPayload = [
                'run_id' => $runId,
                'offset' => $result['next_offset'],
                'batch_size' => $batchSize,
                'products_written' => $newTotalWritten,
                'started_at' => $startedAt,
                'variation_issues' => $variationIssues,
                'product_issues' => $productIssues,
                ];

                if ($this->jobDispatcher !== null) {
                    $this->jobDispatcher->enqueueAsync(self::HOOK_CHUNK_ACTION, $nextPayload);
                } elseif (function_exists('as_enqueue_async_action')) {
                    as_enqueue_async_action(self::HOOK_CHUNK_ACTION, [$nextPayload], 'gr-commerce-suite');
                }
            } else {
                // Catalogue iteration complete: finalize, rename, compress
                if (!$this->finalizeGeneration($runId, $newTotalWritten, $startedAt, $variationIssues, $productIssues)) {
                    throw new RuntimeException(__('XML feed could not be published.', 'gr-commerce-suite'));
                }
            }
        } catch (Throwable $error) {
            $this->recordRunFailure($runId);
            throw $error;
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
            if (!file_exists($tempFile)) {
                unlink($lockFile);
            }
            if (!$this->isActiveRun($runId)) { $this->cleanupRun($runId); }
        }
    }

    private function recordRunFailure(string $runId): void
    {
        if (get_option(self::OPTION_ACTIVE_RUN) === $runId) {
            update_option(self::OPTION_LAST_FAILURE, $runId, false);
        }
    }

    /**
     * @param resource $lock
     * @param array<string, mixed> $checkpoint
     */
    private function writeCheckpoint($lock, array $checkpoint): void
    {
        $json = json_encode($checkpoint, JSON_THROW_ON_ERROR);
        rewind($lock);
        if (!ftruncate($lock, 0) || fwrite($lock, $json) !== strlen($json) || !fflush($lock)) {
            throw new RuntimeException(__('Could not persist the XML feed checkpoint.', 'gr-commerce-suite'));
        }
    }

    /**
     * Adds one batch's flagged products to the run total, keeping the first five to link to.
     *
     * @param list<int> $batch
     * @return array{count: int, fix: list<int>}
     */
    private static function addVariationIssues(mixed $total, array $batch): array
    {
        $total = is_array($total) ? $total : [];
        $fix = is_array($total['fix'] ?? null) ? array_map('intval', $total['fix']) : [];
        return ['count' => max(0, (int) ($total['count'] ?? 0)) + count($batch),
            'fix' => array_slice(array_values(array_unique(array_merge($fix, $batch))), 0, 5)];
    }

    /** @param array<int, list<string>> $batch
     *  @return array<string, array{count: int, fix: list<int>}>
     */
    private static function addProductIssues(mixed $total, array $batch): array
    {
        $total = is_array($total) ? $total : [];
        $result = [];
        foreach (['shared_stock', 'shared_stock_excluded', 'mixed_vat_excluded', 'unstable_id', 'mixed_vat'] as $issue) {
            $ids = array_keys(array_filter($batch, static fn(array $issues): bool => in_array($issue, $issues, true)));
            $result[$issue] = self::addVariationIssues($total[$issue] ?? [], $ids);
        }
        return $result;
    }

    /**
     * Synchronous complete generation runner (useful for CLI/Cron or automated testing).
     */
    public function generateAll(int $batchSize = self::DEFAULT_BATCH_SIZE): string
    {
        LicenseManager::assertLicensed();

        $batchSize = max(1, min(self::DEFAULT_BATCH_SIZE, $batchSize));
        $runId = $this->startGeneration($batchSize, false);
        $offset = 0;
        $totalWritten = 0;
        $variationIssues = [];
        $productIssues = [];
        $startedAt = gmdate('Y-m-d H:i:s');
        $runLock = @fopen($this->getTempFilePath() . '.lock', 'c+b');
        if ($runLock === false || !flock($runLock, LOCK_EX | LOCK_NB)) {
            if (is_resource($runLock)) { fclose($runLock); }
            $this->recordRunFailure($runId);
            throw new RuntimeException('Could not lock synchronous feed generation.');
        }

        try {
            if (!$this->isActiveRun($runId)) { throw new RuntimeException('Feed generation was superseded.'); }
            while (true) {
                $result = $this->processBatch($offset, $batchSize);
                $totalWritten += $result['written_count'];
                $variationIssues = self::addVariationIssues($variationIssues, $result['variation_issues']);
                $productIssues = self::addProductIssues($productIssues, $result['product_issues']);
                $offset = $result['next_offset'];

                if (!$result['has_more']) {
                    break;
                }
            }

            if (!$this->finalizeGeneration($runId, $totalWritten, $startedAt, $variationIssues, $productIssues)) {
                throw new RuntimeException(__('XML feed could not be published.', 'gr-commerce-suite'));
            }
        } catch (Throwable $error) {
            $this->recordRunFailure($runId);
            throw $error;
        } finally {
            flock($runLock, LOCK_UN);
            fclose($runLock);
            if (!is_file($this->getTempFilePath())) { @unlink($this->getTempFilePath() . '.lock'); }
            if (!$this->isActiveRun($runId)) { $this->cleanupRun($runId); }
        }

        return $this->getFinalFilePath();
    }

    /**
     * Process a single batch of products, streaming rendered <product> nodes to the temporary disk file.
     *
     * `variation_issues` lists products whose variations differ in price or availability but could not each be listed.
     *
     * @return array{written_count: int, has_more: bool, next_offset: int, variation_issues: list<int>, product_issues: array<int, list<string>>}
     */
    public function processBatch(int $offset = 0, int $batchSize = self::DEFAULT_BATCH_SIZE): array
    {
        LicenseManager::assertLicensed();

        if (!$this->isFeedEnabled()) {
            return ['written_count' => 0, 'has_more' => false, 'next_offset' => max(0, $offset), 'variation_issues' => [], 'product_issues' => []];
        }

        $batchSize = max(1, min(self::DEFAULT_BATCH_SIZE, $batchSize));
        $offset = max(0, $offset);

        // Suspend cache additions during heavy feed generation
        $previousCacheState = function_exists('wp_suspend_cache_addition') ? wp_suspend_cache_addition(true) : false;
        try {
            return $this->writeBatch($offset, $batchSize);
        } finally {
            if (function_exists('wp_suspend_cache_addition')) {
                wp_suspend_cache_addition($previousCacheState);
            }
        }
    }

    /** @return array{written_count: int, has_more: bool, next_offset: int, variation_issues: list<int>, product_issues: array<int, list<string>>} */
    private function writeBatch(int $offset, int $batchSize): array
    {
        $products = $this->queryProducts($offset, $batchSize);
        $count = count($products);
        $this->variationIssues = [];
        $this->productIssues = [];

        if ($count === 0) {
            return [
                'written_count' => 0,
                'has_more' => false,
                'next_offset' => $offset,
                'variation_issues' => [],
                'product_issues' => [],
            ];
        }

        $tempFile = $this->getTempFilePath();
        $writtenCount = 0;
        $output = null;
        try {
            foreach ($products as $product) {
                if (!$product instanceof WC_Product) {
                    continue;
                }

                // Merchant filter to include or exclude specific products
                if (function_exists('apply_filters')) {
                    $include = (bool) apply_filters('grcs/feeds/include_product', true, $product, 'skroutz');
                    if (!$include) {
                        continue;
                    }
                }

                // Exclude products without title, price, or not published
                if ($product->get_status() !== 'publish') {
                    continue;
                }

                $productXml = $this->renderProductXml($product);
                if ($productXml !== '') {
                    if ($output === null) {
                        $output = fopen($tempFile, 'ab');
                        if ($output === false || !flock($output, LOCK_EX)) {
                            throw new RuntimeException(__('Could not write the XML feed batch.', 'gr-commerce-suite'));
                        }
                    }
                    if (fwrite($output, $productXml) !== strlen($productXml)) {
                        throw new RuntimeException(__('Could not write the XML feed batch.', 'gr-commerce-suite'));
                    }
                    $writtenCount++;
                }
            }
            if (is_resource($output) && !fflush($output)) {
                throw new RuntimeException(__('Could not write the XML feed batch.', 'gr-commerce-suite'));
            }
        } finally {
            if (is_resource($output)) {
                flock($output, LOCK_UN);
                fclose($output);
            }
        }

        // Clean per-product runtime cache & free memory
        unset($products);

        return [
            'written_count' => $writtenCount,
            'has_more' => $count >= $batchSize,
            'next_offset' => $offset + $count,
            'variation_issues' => array_values(array_unique($this->variationIssues)),
            'product_issues' => $this->productIssues,
        ];
    }

    /**
     * Complete both staged files before publication. Each replacement is atomic; the pair is not a transaction.
     *
     * @param array<mixed> $variationIssues Run total from {@see processBatch()}: products whose variation prices could not all be listed.
     * @param array<string, array{count: int, fix: list<int>}> $productIssues
     */
    public function finalizeGeneration(string $runId, int $productsWritten, string $startedAt, array $variationIssues = [], array $productIssues = []): bool
    {
        LicenseManager::assertLicensed();

        if (!$this->isFeedEnabled()) {
            return false;
        }

        if (!$this->isActiveRun($runId)) {
            $this->cleanupRun($runId);
            return false;
        }

        // Before any temp-file assumption: a retry of a run killed mid-publication may have no staged XML left.
        $settled = $this->settleOwnInterruption($runId);
        if ($settled === 'busy') { return false; }
        if ($settled === 'completed') { $this->cleanupRun($runId); return true; } // Recovery never announces a feed.

        $tempFile = $this->getTempFilePath();
        $finalFile = $this->getFinalFilePath();
        $zipFile = $this->getZipFilePath();

        $stagedZip = $tempFile . '.zip';
        $rollback = $tempFile . '.previous';
        $publicationLock = null;
        $xmlPublished = false;
        $success = false;
        $writeAhead = null;
        $priorPublication = $this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE, []);
        $priorPublication = is_array($priorPublication) ? $priorPublication : [];
        $partial = !empty($priorPublication['partial']);
        $stage = 'complete_xml';
        try {
            $footer = "    </products>\n</mywebstore>\n";
            // A re-entered finalization must not close the document twice.
            $closed = is_file($tempFile) && filesize($tempFile) >= strlen($footer)
                && file_get_contents($tempFile, false, null, filesize($tempFile) - strlen($footer)) === $footer;
            if (!is_file($tempFile) || (!$closed && file_put_contents($tempFile, $footer, FILE_APPEND | LOCK_EX) !== strlen($footer))) {
                throw new RuntimeException('Could not complete staged XML.');
            }
            $gaps = $this->countFeedGaps($tempFile, self::addVariationIssues($variationIssues, []));
            if (!$gaps['diagnostics_available']) {
                throw new RuntimeException('Staged XML could not be validated.');
            }
            foreach (['shared_stock', 'shared_stock_excluded', 'mixed_vat_excluded', 'unstable_id', 'mixed_vat'] as $issue) {
                if (!isset($productIssues[$issue])) { continue; }
                $details = $productIssues[$issue];
                $gaps[$issue] = $details['count'];
                // Products that lose listings come first: merchants without CLI access must be able to reach them.
                if ($issue === 'mixed_vat_excluded') {
                    $gaps['mixed_vat_excluded_ids'] = array_slice(array_map('intval', $details['fix']), 0, 5);
                }
                $merged = in_array($issue, ['shared_stock_excluded', 'mixed_vat_excluded'], true) ? array_merge($details['fix'], $gaps['fix']) : array_merge($gaps['fix'], $details['fix']);
                $gaps['fix'] = array_slice(array_values(array_unique($merged)), 0, 5);
            }
            $stage = 'compress_zip';
            if (!$this->createZipArchive($tempFile, $stagedZip)) {
                throw new RuntimeException('Could not create and verify staged ZIP.');
            }
            $stage = 'publication_lock';
            $publicationLock = $this->lockPublication();
            if (!$this->isActiveRun($runId)) {
                return false;
            }
            // Another run's interruption is settled here; this run's own was settled before the temp file was trusted.
            $this->recoverInterruptedPublication();
            // A failed retry cannot certify an already interrupted pair as recovered.
            $priorPublication = $this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE, []);
            $priorPublication = is_array($priorPublication) ? $priorPublication : [];
            $partial = !empty($priorPublication['partial']);
            $stage = 'identity_transitions';
            $this->assertPublishedIdentitiesSafe($finalFile);
            // Snapshot to a private path only; recovery also uses rename, never copy over public XML.
            $stage = 'snapshot_xml';
            $oldXmlHash = is_file($finalFile) ? hash_file('sha256', $finalFile) : null;
            $oldZipHash = is_file($zipFile) ? hash_file('sha256', $zipFile) : null;
            if ($oldXmlHash !== null && (!@copy($finalFile, $rollback)
                || filesize($rollback) !== filesize($finalFile)
                || hash_file('sha256', $rollback) !== $oldXmlHash)) {
                throw new RuntimeException('Could not preserve previous XML for rollback.');
            }
            // A disable racing this worker is re-checked here: re-read the per-request module cache and both switches
            // under the lock immediately before the first rename, and withdraw ownership when either is off. A disable
            // that lands after this check still lets this one worker finish a consistent pair (bounded residual); nothing
            // is published after the worker's next check. Withdrawing here keeps the merchant's disable out of the
            // failure counter; the caller discards the staged files and the pair stays untouched.
            ModuleRegistry::reset();
            if (!$this->isActiveRun($runId) || !$this->isFeedEnabled()) {
                if ($this->isActiveRun($runId)) {
                    update_option(self::OPTION_ACTIVE_RUN, '', false);
                }
                throw new RuntimeException('Feed publication was stopped because the feed or module was disabled.');
            }
            $stage = 'publish_xml';
            $report = [
                'run_id' => $runId, 'started_at' => $startedAt, 'finished_at' => gmdate('Y-m-d H:i:s'),
                'products_written' => $gaps['product_count'], 'parents_processed' => $productsWritten, 'file_size' => (int) filesize($tempFile),
                'zip_created' => true, 'zip_size' => (int) filesize($stagedZip), 'gaps' => $gaps,
            ];
            $newXmlHash = hash_file('sha256', $tempFile);
            $newZipHash = hash_file('sha256', $stagedZip);
            if ($oldXmlHash === false || $oldZipHash === false || $newXmlHash === false || $newZipHash === false) {
                throw new RuntimeException('Could not fingerprint the staged publication.');
            }
            // Write-ahead record: with the file hashes it tells {@see recoverInterruptedPublication()} what a killed worker did.
            $writeAhead = ['wal_run_id' => $runId, 'wal_prior_partial' => $partial, 'old_xml_sha256' => $oldXmlHash, 'old_zip_sha256' => $oldZipHash, 'new_xml_sha256' => $newXmlHash,
                'new_zip_sha256' => $newZipHash, 'report' => $report];
            // A hard process termination cannot enter catch/finally. Persist uncertainty before the
            // first public mutation so a killed worker cannot leave an apparently healthy pair.
            $intent = ['run_id' => $runId, 'stage' => 'publishing', 'partial' => true] + $writeAhead;
            if ($partial) {
                $intent['recovery_run_id'] = $priorPublication['recovery_run_id'] ?? $priorPublication['run_id'] ?? $runId;
            }
            update_option(self::OPTION_PUBLICATION_FAILURE, $intent, false);
            if ($this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE) !== $intent) {
                throw new RuntimeException('Could not persist publication intent.');
            }
            if (!$this->replaceFile($tempFile, $finalFile)) {
                $this->logger->error('Could not atomically publish the XML feed; the previous feed was retained.');
                throw new RuntimeException('XML replacement failed.');
            }
            $xmlPublished = true;
            $partial = true;
            $stage = 'publish_zip';
            if (!$this->replaceFile($stagedZip, $zipFile)) {
                // There is a short mixed-generation window even when rollback succeeds.
                $rollbackFailed = is_file($rollback) ? !$this->replaceFile($rollback, $finalFile) : !@unlink($finalFile);
                $partial = !empty($priorPublication['partial']) || $rollbackFailed;
                throw new RuntimeException('ZIP replacement failed; XML rollback attempted.');
            }
            $stage = 'record_success';
            update_option(self::OPTION_LAST_RUN, $report, false);
            if ($this->readPublicationOption(self::OPTION_LAST_RUN) !== $report) {
                throw new RuntimeException('Could not persist the published generation report.');
            }
            update_option(self::OPTION_LAST_FAILURE, '', false);
            update_option(self::OPTION_PUBLICATION_FAILURE, [], false);
            update_option(self::OPTION_ACTIVE_RUN, '', false);
            if ($this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE) !== []
                || $this->readPublicationOption(self::OPTION_LAST_FAILURE) !== '' || $this->readPublicationOption(self::OPTION_ACTIVE_RUN) !== '') {
                throw new RuntimeException('Could not confirm publication completion.');
            }
            $partial = false;
            $success = true;
        } catch (Throwable $error) {
            if ($this->isActiveRun($runId) || $stage === 'record_success') {
                $this->recordRunFailure($runId);
                $failure = ['run_id' => $runId, 'stage' => $stage,
                    'partial' => $partial, 'xml_was_published' => $xmlPublished];
                if (!empty($priorPublication['partial'])) {
                    $failure['recovery_run_id'] = $priorPublication['recovery_run_id'] ?? $priorPublication['run_id'] ?? $runId;
                }
                // An unresolved pair keeps the evidence that lets the next run settle it.
                if ($partial) {
                    $failure += $writeAhead ?? array_intersect_key($priorPublication, array_flip(self::WRITE_AHEAD_KEYS));
                }
                update_option(self::OPTION_PUBLICATION_FAILURE, $failure, false);
                update_option(self::OPTION_ACTIVE_RUN, '', false);
            }
            if ($stage !== 'publish_xml') {
                $this->logger->error('Feed publication failed.', ['stage' => $stage, 'partial' => $partial, 'error' => $error->getMessage()]);
            }
        } finally {
            foreach ([$tempFile, $stagedZip] as $file) {
                if (is_file($file)) { @unlink($file); }
            }
            // Preserve recovery bytes if Windows also prevented atomic rollback.
            if (!$partial && is_file($rollback)) { @unlink($rollback); }
            if (is_resource($publicationLock)) {
                flock($publicationLock, LOCK_UN);
                fclose($publicationLock);
            }
        }
        if (!$success) {
            return false;
        }
        if (function_exists('do_action')) {
            do_action('grcs/feed/generated', 'skroutz', $finalFile, $zipFile);
        }
        $this->logger->info('XML and verified ZIP feed published.', ['run_id' => $runId]);
        return true;
    }

    /**
     * Protect previously published new-scheme identities under the publication lock, after recovery.
     * Inspect the previous feed, including parents withheld from this run; stock/exclusion lapses
     * are handled by the detector independently of the currently exportable listings.
     */
    private function assertPublishedIdentitiesSafe(string $file): void
    {
        if (!$this->identity()->isConfigured()) {
            return;
        }
        if (!is_file($file)) {
            if ($this->readPublicationOption(self::OPTION_LAST_RUN, []) !== []) {
                throw new RuntimeException('Published XML identity evidence is missing.');
            }
            return; // First publication has no prior identities to protect.
        }
        if (!class_exists(\XMLReader::class) || !function_exists('simplexml_load_string')) {
            throw new RuntimeException('Published XML identities could not be validated.');
        }
        $previousErrors = libxml_use_internal_errors(true);
        libxml_clear_errors();
        $reader = new \XMLReader();
        try {
            if (!@$reader->open($file, null, LIBXML_NONET)) {
                throw new RuntimeException('Published XML identities could not be read.');
            }
            $rootSeen = false;
            $rootClosed = false;
            /** @var array<int, list<string>> $published */
            $published = [];
            while ($reader->read()) {
                if ($reader->nodeType === \XMLReader::DOC_TYPE) {
                    throw new RuntimeException('Published XML identities contain an unsupported document type.');
                }
                if ($reader->depth === 0 && $reader->name === 'mywebstore') {
                    $rootSeen = $rootSeen || $reader->nodeType === \XMLReader::ELEMENT;
                    $rootClosed = $reader->nodeType === \XMLReader::END_ELEMENT
                        || ($reader->nodeType === \XMLReader::ELEMENT && $reader->isEmptyElement);
                }
                if ($reader->nodeType !== \XMLReader::ELEMENT || $reader->name !== 'product' || $reader->depth !== 2) {
                    continue;
                }
                $node = simplexml_load_string($reader->readOuterXml(), \SimpleXMLElement::class, LIBXML_NONET);
                if ($node === false) {
                    throw new RuntimeException('Published XML identities could not be parsed.');
                }
                $id = trim((string) $node->id);
                if (preg_match('/^([1-9][0-9]*)-.*[tv][0-9]+$/D', $id, $match) === 1) {
                    $published[(int) $match[1]][] = $id;
                }
            }
            if (!$rootSeen || !$rootClosed || libxml_get_errors() !== []) {
                throw new RuntimeException('Published XML identities could not be validated.');
            }
            foreach ($published as $parentId => $ids) {
                $product = wc_get_product($parentId);
                if (!$product instanceof WC_Product || $product->get_status() !== 'publish') {
                    continue; // Deleted/unpublished parents are legitimate lapses.
                }
                $transition = $this->identityTransitions($product, $ids);
                if ($transition['blocking'] !== []) {
                    throw new RuntimeException('Published listing identity would change for product ' . $parentId . '.');
                }
            }
        } finally {
            $reader->close();
            libxml_clear_errors();
            libxml_use_internal_errors($previousErrors);
        }
    }

    /**
     * Settle this run's own interrupted publication under the publication lock.
     *
     * @return string|null 'busy' (a live worker publishes), the recovery outcome, or null when there was nothing to settle
     */
    private function settleOwnInterruption(string $runId): ?string
    {
        $intent = $this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE, []);
        $wal = is_array($intent) ? $this->writeAheadRecord($intent) : null;
        if ($wal === null || $wal['wal_run_id'] !== $runId) { return null; }
        try {
            $lock = $this->lockPublication();
        } catch (Throwable) {
            return 'busy';
        }
        try {
            $outcome = $this->recoverInterruptedPublication();
            if ($outcome === 'completed') {
                update_option(self::OPTION_ACTIVE_RUN, '', false);
            }
            return $outcome;
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    /**
     * Settle a publication a killed worker left half-done without starting a new generation. Saving the settings calls
     * this, including while the feed switch or the whole module is off: it only certifies a complete pair, rolls the
     * XML back, or clears an untouched pair. A live publisher keeps the lock; its own worker settles that run.
     *
     * @return string|null 'completed', 'rolled_back', 'not_published', or null when nothing was settled
     */
    public function settleInterruptedPublication(): ?string
    {
        try {
            $lock = $this->lockPublication();
        } catch (Throwable) {
            return null;
        }
        try {
            $intent = $this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE, []);
            $wal = is_array($intent) ? $this->writeAheadRecord($intent) : null;
            $outcome = $this->recoverInterruptedPublication();
            if ($outcome !== null && $wal !== null && $this->isActiveRun($wal['wal_run_id'])) {
                update_option(self::OPTION_ACTIVE_RUN, '', false);
            }
            return $outcome;
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    /**
     * Module switched off: withdraw run ownership while holding the publication lock, retrying briefly (5 × 100 ms) so
     * an in-flight finalize worker that has not yet passed its in-lock switch check finds no owned run and withdraws
     * itself instead of publishing. A still-busy lock defers the clear to that worker, which re-checks the module and
     * feed switches under the lock before the first rename. Residual: a disable landing after that check lets the single
     * in-flight worker finish its consistent publication (never a mixed pair); nothing is published after its next
     * check. Files are untouched.
     */
    public function retirePendingPublication(): void
    {
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete(self::OPTION_ACTIVE_RUN, 'options');
        }
        if ((string) get_option(self::OPTION_ACTIVE_RUN, '') === '') {
            return;
        }
        $lock = null;
        for ($attempt = 0; $attempt < 5 && !is_resource($lock); ++$attempt) {
            if ($attempt > 0) { usleep(100000); }
            try {
                $lock = $this->lockPublication();
            } catch (Throwable) {
                // A live worker owns the publication; it settles ownership itself after the in-lock switch check.
            }
        }
        if (!is_resource($lock)) { return; }
        try {
            update_option(self::OPTION_ACTIVE_RUN, '', false);
        } finally {
            flock($lock, LOCK_UN);
            fclose($lock);
        }
    }

    /**
     * Settle a publication a killed worker left half-done. Call only while holding the publication lock: a
     * dead worker's lock is released by the OS, so holding it proves nobody is still publishing. The
     * write-ahead record says which public bytes mean what; only an explained old pair or an explained new
     * pair is settled, anything else stays `partial` with its snapshot and record untouched.
     *
     * @return string|null 'completed', 'rolled_back' or 'not_published'; null when nothing was settled
     */
    private function recoverInterruptedPublication(): ?string
    {
        try {
            $intent = $this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE, []);
            $wal = is_array($intent) ? $this->writeAheadRecord($intent) : null;
            if ($wal === null) { return null; }
            $finalFile = $this->getFinalFilePath();
            $zipFile = $this->getZipFilePath();
            $xml = is_file($finalFile) ? @hash_file('sha256', $finalFile) : null;
            $zip = is_file($zipFile) ? @hash_file('sha256', $zipFile) : null;
            // A failed fingerprint is never evidence of identity (including the legacy unknown-ZIP sentinel).
            if ($xml === false || $zip === false) { return null; }
            $rollback = $this->getUploadsDir() . '/skroutz-temp-' . $wal['wal_run_id'] . '.xml.previous';
            if ($xml === $wal['new_xml_sha256'] && $zip === $wal['new_zip_sha256']) {
                // Killed after both renames: only the success bookkeeping is missing. The report must be
                // readable back before the record that lets a later start retry it is cleared.
                update_option(self::OPTION_LAST_RUN, $wal['report'], false);
                if ($this->readPublicationOption(self::OPTION_LAST_RUN) !== $wal['report']) {
                    throw new RuntimeException('Could not persist the recovered generation report.');
                }
                update_option(self::OPTION_LAST_FAILURE, '', false);
                // A silently failed clear would report a failure after a recovered publication; keep intent + snapshot.
                if ($this->readPublicationOption(self::OPTION_LAST_FAILURE) !== '') {
                    throw new RuntimeException('Could not clear the recorded failure after recovery.');
                }
                update_option(self::OPTION_PUBLICATION_FAILURE, [], false);
                if ($this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE) !== []) {
                    throw new RuntimeException('Could not confirm recovery bookkeeping.');
                }
                $outcome = 'completed';
            } elseif ($wal['wal_prior_partial'] || $wal['old_zip_sha256'] === false || $zip !== $wal['old_zip_sha256']) {
                // Already mixed before this run, or a ZIP that is neither the recorded old nor new one: unexplained.
                return null;
            } elseif ($xml === $wal['old_xml_sha256']) {
                $outcome = 'not_published'; // Old XML with the old ZIP: nothing went public.
            } elseif ($xml === $wal['new_xml_sha256']) {
                $restored = $wal['old_xml_sha256'] === null
                    ? @unlink($finalFile)
                    : (is_file($rollback) && @hash_file('sha256', $rollback) === $wal['old_xml_sha256']
                        && $this->replaceFile($rollback, $finalFile) && @hash_file('sha256', $finalFile) === $wal['old_xml_sha256']);
                if (!$restored) {
                    $this->logger->error('Interrupted feed publication could not be rolled back; XML and ZIP may differ.', ['run_id' => $wal['wal_run_id']]);
                    return null;
                }
                $outcome = 'rolled_back';
            } else {
                return null;
            }
            if ($outcome !== 'completed') {
                update_option(self::OPTION_PUBLICATION_FAILURE, ['run_id' => $wal['wal_run_id'], 'stage' => 'recovered',
                    'partial' => false, 'xml_was_published' => $outcome === 'rolled_back'], false);
                $recorded = $this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE);
                if (!is_array($recorded) || !empty($recorded['partial'])) {
                    throw new RuntimeException('Could not confirm recovery bookkeeping.');
                }
            }
            if (is_file($rollback)) { @unlink($rollback); }
            $this->logger->info('Interrupted feed publication recovered.', ['run_id' => $wal['wal_run_id'], 'outcome' => $outcome]);
            return $outcome;
        } catch (Throwable $error) {
            // Recovery must never block a new generation; the record and snapshot stay and the feed keeps its warning.
            $this->logger->error('Interrupted feed publication recovery failed.', ['error' => $error->getMessage()]);
            return null;
        }
    }

    /**
     * Snapshots are evidence while any publication is unresolved (a chain of failed runs can need an older one).
     * With nothing unresolved, a killed worker's leftover copy is only a full-size orphan. Publication lock held.
     */
    private function removeUnreferencedSnapshots(): void
    {
        $recorded = $this->readPublicationOption(self::OPTION_PUBLICATION_FAILURE, []);
        if (!is_array($recorded) || !empty($recorded['partial'])) {
            return;
        }
        foreach (glob($this->getUploadsDir() . '/skroutz-temp-*.xml.previous') ?: [] as $snapshot) {
            if (preg_match('/^skroutz-temp-[a-f0-9]{16}\.xml\.previous$/D', basename($snapshot)) === 1) {
                @unlink($snapshot);
            }
        }
    }

    /**
     * @param array<mixed> $intent
     * @return array{wal_run_id: string, wal_prior_partial: bool, old_xml_sha256: ?string, old_zip_sha256: string|false|null, new_xml_sha256: string, new_zip_sha256: string, report: array<mixed>}|null
     */
    private function writeAheadRecord(array $intent): ?array
    {
        $isHash = static fn (mixed $value): bool => is_string($value) && preg_match('/^[a-f0-9]{64}$/D', $value) === 1;
        $run = $intent['wal_run_id'] ?? null;
        if (empty($intent['partial']) || !is_string($run) || !is_bool($intent['wal_prior_partial'] ?? null) || preg_match('/^[a-f0-9]{16}$/D', $run) !== 1
            || !array_key_exists('old_xml_sha256', $intent) || ($intent['old_xml_sha256'] !== null && !$isHash($intent['old_xml_sha256']))
            || (($intent['old_zip_sha256'] ?? null) !== null && !$isHash($intent['old_zip_sha256']))
            || !$isHash($intent['new_xml_sha256'] ?? null) || !$isHash($intent['new_zip_sha256'] ?? null)
            || !is_array($intent['report'] ?? null)) {
            return null;
        }
        // A record written before the old ZIP was recorded (false) can still certify a complete new pair, never an old one.
        $oldZip = array_key_exists('old_zip_sha256', $intent) ? $intent['old_zip_sha256'] : false;
        return ['wal_run_id' => $run, 'wal_prior_partial' => $intent['wal_prior_partial'], 'old_xml_sha256' => $intent['old_xml_sha256'],
            'old_zip_sha256' => $oldZip, 'new_xml_sha256' => $intent['new_xml_sha256'],
            'new_zip_sha256' => $intent['new_zip_sha256'], 'report' => $intent['report']];
    }

    /** @return resource */
    private function lockPublication()
    {
        // Keep the lock inode: unlinking it lets concurrent workers lock different files.
        $lock = @fopen($this->getUploadsDir() . '/skroutz-publication.lock', 'c+b');
        if ($lock === false || !flock($lock, LOCK_EX | LOCK_NB)) {
            if (is_resource($lock)) { fclose($lock); }
            throw new RuntimeException('Another feed publication is in progress; retry generation.');
        }
        return $lock;
    }

    /** @phpstan-impure */
    private function isActiveRun(string $runId): bool
    {
        if (function_exists('wp_cache_delete')) {
            wp_cache_delete(self::OPTION_ACTIVE_RUN, 'options');
        }
        return get_option(self::OPTION_ACTIVE_RUN) === $runId;
    }

    /** @phpstan-impure */
    private function readPublicationOption(string $name, mixed $default = false): mixed
    {
        return get_option($name, $default);
    }

    private function replaceFile(string $source, string $destination): bool
    {
        for ($attempt = 0; $attempt < 3; ++$attempt) {
            if ($attempt > 0) { usleep(150000); }
            if (@rename($source, $destination)) { return true; }
        }
        return false;
    }

    private function cleanupRun(string $runId): void
    {
        if (preg_match('/^[a-f0-9]{16}$/D', $runId) !== 1 || $this->isActiveRun($runId)) { return; }
        $temp = $this->getUploadsDir() . '/skroutz-temp-' . $runId . '.xml';
        $lock = @fopen($temp . '.lock', 'c+b');
        if ($lock === false) { return; }
        $owned = false;
        try {
            $owned = flock($lock, LOCK_EX | LOCK_NB);
            if (!$owned || $this->isActiveRun($runId)) { return; }
            foreach (array_merge([$temp, $temp . '.zip'], glob($temp . '.zip.*.tmp') ?: []) as $file) {
                if (is_file($file)) { @unlink($file); }
            }
        } finally {
            fclose($lock);
            if ($owned) { @unlink($temp . '.lock'); }
        }
    }

    /**
     * Products the marketplaces are likely to reject or misread, counted once per run by streaming the
     * published file (never on page views): no image, only the default "uncategorised" category, no EAN
     * or no MPN (`no_identifier` is the total; `no_identifier_both`, `no_ean_only` and `no_mpn_only` split it
     * and never change what is counted), an EAN shared with another product, or no quantity because stock is not tracked.
     *
     * `fix` keeps up to five product IDs, the most serious gaps first, so the status can link straight to them.
     *
     * @param array{count: int, fix: list<int>} $variationIssues Products whose variation prices could not all be listed.
     * @return array{diagnostics_available: bool, product_count: int, no_description: int, no_image: int, uncategorized: int, no_identifier: int, no_identifier_both: int, no_ean_only: int, no_mpn_only: int, duplicate_ean: int, no_quantity: int, variation_prices: int, bestprice_variations: int, fix: list<int>}
     */
    private function countFeedGaps(string $file, array $variationIssues = ['count' => 0, 'fix' => []]): array
    {
        $gaps = ['diagnostics_available' => false, 'product_count' => 0, 'no_description' => 0, 'no_image' => 0, 'uncategorized' => 0, 'no_identifier' => 0, 'no_identifier_both' => 0, 'no_ean_only' => 0, 'no_mpn_only' => 0, 'duplicate_ean' => 0, 'no_quantity' => 0,
            'variation_prices' => $variationIssues['count'], 'bestprice_variations' => 0, 'fix' => []];
        // Rejections first, then wrong or missing identifiers, unlisted variation prices, untracked stock.
        $fix = [[], [], $variationIssues['fix'], []];
        $eans = [];
        $eanHolders = [];
        $default = function_exists('get_term') ? get_term((int) get_option('default_product_cat', 0), 'product_cat') : null;
        $defaultName = is_object($default) && isset($default->name) ? (string) $default->name : '';
        if (!class_exists(\XMLReader::class) || !function_exists('simplexml_load_string')) {
            return $gaps;
        }
        $previousErrors = libxml_use_internal_errors(true);
        libxml_clear_errors();
        $reader = new \XMLReader();
        if (!@$reader->open($file, null, LIBXML_NONET)) {
            libxml_clear_errors();
            libxml_use_internal_errors($previousErrors);
            return $gaps;
        }
        $rootClosed = false;
        try {
            while (@$reader->read()) {
                if ($reader->name === 'mywebstore' && ($reader->nodeType === \XMLReader::END_ELEMENT
                    || ($reader->nodeType === \XMLReader::ELEMENT && $reader->isEmptyElement))) {
                    $rootClosed = true;
                }
                if ($reader->nodeType !== \XMLReader::ELEMENT || $reader->name !== 'product') {
                    continue;
                }
                $node = @simplexml_load_string($reader->readOuterXml());
                if ($node === false) {
                    return $gaps;
                }
                ++$gaps['product_count'];
                $noDescription = trim((string) $node->description) === '';
                $noImage = trim((string) $node->image) === '';
                $category = trim((string) $node->category);
                $uncategorized = $category === '' || ($defaultName !== '' && $category === $defaultName);
                $ean = trim((string) $node->ean);
                $eans[$ean] = ($eans[$ean] ?? 0) + 1;
                $duplicate = $ean !== '' && $eans[$ean] > 1;
                $noMpn = trim((string) $node->mpn) === '';
                $noIdentifier = $ean === '' || $noMpn;
                $noQuantity = count($node->quantity) === 0;
                $bestPriceVariations = false;
                $sizes = array_map('trim', explode(',', (string) $node->size));
                foreach ($node->variations->variation ?? [] as $variation) {
                    if ((string) $variation->price_with_vat !== (string) $node->price_with_vat
                        || (string) $variation->availability !== (string) $node->availability
                        || !in_array(trim((string) $variation->size), $sizes, true)) {
                        $bestPriceVariations = true;
                        break;
                    }
                }
                $gaps['bestprice_variations'] += $bestPriceVariations ? 1 : 0;
                $gaps['no_image'] += $noImage ? 1 : 0;
                $gaps['no_description'] += $noDescription ? 1 : 0;
                $gaps['uncategorized'] += $uncategorized ? 1 : 0;
                $gaps['no_identifier'] += $noIdentifier ? 1 : 0;
                $gaps['no_identifier_both'] += $ean === '' && $noMpn ? 1 : 0;
                $gaps['no_ean_only'] += $ean === '' && !$noMpn ? 1 : 0;
                $gaps['no_mpn_only'] += $ean !== '' && $noMpn ? 1 : 0;
                // The first holder of a shared EAN is only known to be affected once the second appears.
                $gaps['duplicate_ean'] += $duplicate ? ($eans[$ean] === 2 ? 2 : 1) : 0;
                $gaps['no_quantity'] += $noQuantity ? 1 : 0;
                // Node ids are the product ID, or "<product ID>-<colour>" for colour splits.
                $postId = preg_match('/^([0-9]+)(?:-|$)/', trim((string) $node->id), $match) === 1 ? (int) $match[1] : 0;
                $flag = [];
                if ($ean !== '' && $eans[$ean] === 1) {
                    $eanHolders[$ean] = $postId;
                } elseif ($duplicate && $eans[$ean] === 2) {
                    $flag[] = [1, $eanHolders[$ean] ?? 0];
                }
                $tier = match (true) {
                    $noImage || $uncategorized || $noDescription => 0,
                    $noIdentifier || $duplicate => 1,
                    $noQuantity || $bestPriceVariations => 3,
                    default => null,
                };
                if ($tier !== null) {
                    $flag[] = [$tier, $postId];
                }
                foreach ($flag as [$flagTier, $flagId]) {
                    if ($flagId > 0 && count($fix[$flagTier]) < 5 && !in_array($flagId, $fix[$flagTier], true)) {
                        $fix[$flagTier][] = $flagId;
                    }
                }
            }
            $gaps['diagnostics_available'] = $rootClosed && libxml_get_errors() === [];
        } catch (Throwable) {
            $gaps['diagnostics_available'] = false;
        } finally {
            $reader->close();
            libxml_clear_errors();
            libxml_use_internal_errors($previousErrors);
        }
        $gaps['fix'] = array_slice(array_values(array_unique(array_merge(...$fix))), 0, 5);
        return $gaps;
    }

    /**
     * Render a single product or its color variations into Skroutz XML fragments.
     *
     * Skroutz 2026 Fashion Rules:
     * - Variable products with Color attributes MUST be split into distinct <product> nodes per Color.
     * - Variable products with Size attributes MUST have their sizes grouped into a single
     *   comma-separated `<size>` tag.
     */
    public function renderProductXml(WC_Product $product): string
    {
        $serializer = new SkroutzProductSerializer();
        // A `new` product whose identities collide is withheld whole, whatever the D9/D10 gates say (see normalizeProduct()).
        $records = array_values(array_filter(
            $this->normalizeProduct($product),
            static fn(MarketplaceProduct $record): bool => !in_array(self::IDENTITY_WITHHELD, $record->issues, true)
        ));
        // Skroutz only: normalizeProduct() (and so the BestPrice preview) is deliberately untouched. Each owner-approved
        // exclusion (D9 shared stock, D10 mixed VAT) is independent; a listing leaves if any enabled policy applies and
        // returns, with its unchanged ID, only when none applies.
        $policies = array_filter([
            'shared_stock' => $this->excludeSharedStock(),
            'mixed_vat' => $this->excludeMixedVat(),
        ]);
        if ($policies !== []) {
            $kept = array_values(array_filter($records, static function (MarketplaceProduct $record) use ($policies): bool {
                return array_intersect(array_keys($policies), $record->issues) === [];
            }));
            if (count($kept) !== count($records)) {
                foreach (array_keys($policies) as $issue) {
                    if (array_filter($records, static fn(MarketplaceProduct $record): bool => in_array($issue, $record->issues, true)) !== []) {
                        $this->productIssues[$product->get_id()][] = $issue . '_excluded';
                    }
                }
            }
            $records = $kept;
        }
        return implode('', array_map($serializer->serialize(...), $records));
    }

    private function excludeMixedVat(): bool
    {
        return function_exists('get_option') && in_array(
            get_option(self::OPTION_EXCLUDE_MIXED_VAT, 'no'), ['yes', true, 1, '1'], true
        );
    }

    private function excludeSharedStock(): bool
    {
        return function_exists('get_option') && in_array(
            get_option(self::OPTION_EXCLUDE_SHARED_STOCK, 'no'), ['yes', true, 1, '1'], true
        );
    }

    /**
     * Shared WooCommerce extraction. Records retain the published legacy identities and grouping.
     * Consumers must not infer BestPrice compatibility from the presence of Skroutz size variations.
     *
     * @return list<MarketplaceProduct>
     */
    public function normalizeProduct(WC_Product $product): array
    {
        if ($product->is_type('variable')) {
            $records = $this->normalizeVariableProduct($product);
            $ids = array_map(static fn(MarketplaceProduct $r): string => $r->id, $records);
            $duplicateIds = count(array_unique($ids)) !== count($ids);
            // Fail closed for a `new` product only; legacy and uncertain products keep emitting exactly what they always did.
            // A `duplicate_colour_key` product is withheld whole: its fallback IDs would be orphaned the moment the merchant
            // fixes the typo and the product moves to the new scheme. Any other `new` product on the legacy fallback may
            // already have published its non-colliding IDs, so only the records whose ID occurs more than once are withheld.
            if ($duplicateIds && $this->identity()->isConfigured() && $this->identity()->classify($product)['class'] === FeedIdentityPolicy::NEW) {
                $whole = $this->classifyIdentityOf($product, $this->getAvailableVariations($product))['reason'] === 'duplicate_colour_key';
                $counts = array_count_values($ids);
                $records = array_map(
                    static fn(MarketplaceProduct $r): MarketplaceProduct => $whole || $counts[$r->id] > 1 ? $r->withIssues(['unstable_id', self::IDENTITY_WITHHELD]) : $r,
                    $records
                );
            }
            $issues = array_values(array_unique(array_merge([], ...array_map(static fn(MarketplaceProduct $r): array => $r->issues, $records))));
            if ($duplicateIds) { $issues[] = 'unstable_id'; }
            $issues = array_values(array_unique($issues));
            if ($issues !== []) { $this->productIssues[$product->get_id()] = $issues; }
            return $records;
        }

        return array_values(array_filter([$this->normalizeSingleProduct(
            product: $product,
            id: (string) $product->get_id(),
            name: $product->get_name(),
            color: $this->detectAttributeValue($product, 'color'),
            sizes: $this->detectAttributeValue($product, 'size'),
            overridePrice: $this->getProductPriceOverride($product),
        )]));
    }

    /**
     * Normalize variable products without changing published grouping.
     *
     * @return list<MarketplaceProduct>
     */
    private function normalizeVariableProduct(WC_Product $product): array
    {
        $attributes = $product->get_attributes();
        $colorAttrKey = null;
        $sizeAttrKey = null;

        foreach ($attributes as $key => $attr) {
            $attrName = is_string($key) ? $key
                : (is_object($attr) && method_exists($attr, 'get_name') ? (string) $attr->get_name() : '');
            $attrLabel = is_object($attr) && method_exists($attr, 'get_name') ? (string) $attr->get_name() : $attrName;
            if ($colorAttrKey === null && ($this->isColorAttribute($attrName) || $this->isColorAttribute($attrLabel))) {
                $colorAttrKey = $attrName !== '' ? $attrName : $attrLabel;
            }
            if ($sizeAttrKey === null && ($this->isSizeAttribute($attrName) || $this->isSizeAttribute($attrLabel))) {
                $sizeAttrKey = $attrName !== '' ? $attrName : $attrLabel;
            }
        }

        $variations = $this->getAvailableVariations($product);
        // Inspect owners before colour/stock filtering: one parent pool may back several colour records.
        $owners = [];
        foreach ($variations as $variation) {
            $pool = $this->poolOfSellableVariation($variation);
            if ($pool !== null) {
                $owners[$pool] = ($owners[$pool] ?? 0) + 1;
            }
        }
        /** @var list<int> $sharedPools Stock owners whose one quantity backs more than one variation. */
        $sharedPools = array_keys(array_filter($owners, static fn(int $count): bool => $count > 1));
        if ($variations === []) {
            $parentColors = $this->detectAttributeOptions($product, 'color');

            if ($parentColors !== []) {
                $output = [];
                foreach ($parentColors as $colorName) {
                    $colorSlug = function_exists('sanitize_title')
                        ? sanitize_title($colorName)
                        : strtolower(trim($colorName));
                    $productId = sprintf('%d-%s', $product->get_id(), $colorSlug !== '' ? $colorSlug : 'color');
                    $varTitle = $product->get_name();
                    $lowerTitle = mb_strtolower($varTitle, 'UTF-8');
                    $lowerColor = mb_strtolower($colorName, 'UTF-8');
                    if (!str_contains($lowerTitle, $lowerColor)) {
                        $varTitle .= ' ' . $colorName;
                    }

                    $output[] = $this->normalizeSingleProduct(
                        product: $product,
                        id: $productId,
                        name: $varTitle,
                        color: $colorName,
                        stock: self::UNAVAILABLE,
                        overridePrice: $this->getProductPriceOverride($product),
                        issues: $colorSlug === '' || rawurldecode($colorSlug) !== $colorSlug ? ['unstable_id'] : [],
                    );
                }

                return array_values(array_filter($output));
            }

            // Variable product with no active variations: fallback to parent node
            return array_values(array_filter([$this->normalizeSingleProduct(
                product: $product,
                id: (string) $product->get_id(),
                name: $product->get_name(),
                stock: self::UNAVAILABLE,
            )]));
        }

        // Opt-in identity scheme (OFF unless the baseline option exists): only products classified `new` ever change.
        if ($this->identity()->isConfigured()) {
            $identity = $this->classifyIdentityOf($product, $variations);
            if ($identity['class'] === FeedIdentityPolicy::NEW) {
                $listings = $this->normalizeNewIdentityListings($product, $variations, $sharedPools);
                if ($listings !== null) {
                    return $listings;
                }
            }
        }

        // Case A: Variable product has distinct Color variations -> Split into separate <product> nodes per color
        if ($colorAttrKey !== null) {
            /** @var array<string, list<WC_Product_Variation>> $colorGroups */
            $colorGroups = [];

            foreach ($variations as $variation) {
                if (!$variation->is_in_stock() && !$this->includeOutOfStock()) {
                    continue;
                }
                $colorVal = $this->getVariationAttributeValue($variation, $colorAttrKey);
                $colorGroups[$colorVal !== '' ? $colorVal : 'Default'][] = $variation;
            }

            $output = [];

            foreach ($colorGroups as $colorName => $group) {
                $colorName = (string) $colorName;
                // Published ids keep their historical fallback: the first in-stock variation of the colour.
                $idVariation = $group[0];
                foreach ($group as $variation) {
                    if ($variation->is_in_stock()) {
                        $idVariation = $variation;
                        break;
                    }
                }
                $colorSlug = function_exists('sanitize_title')
                    ? rawurldecode(sanitize_title($colorName))
                    : strtolower(trim($colorName));
                $productId = sprintf(
                    '%d-%s',
                    $product->get_id(),
                    $colorSlug !== '' ? $colorSlug : (string) $idVariation->get_id()
                );

                $varTitle = $product->get_name();
                $lowerTitle = mb_strtolower($varTitle, 'UTF-8');
                $lowerColor = mb_strtolower($colorName, 'UTF-8');
                if ($colorName !== 'Default' && !str_contains($lowerTitle, $lowerColor)) {
                    $varTitle .= ' ' . $colorName;
                }

                // Each colour is its own product, so it never borrows the parent's barcode unless it is the only one.
                $output[] = $this->normalizeVariationGroup($product, $group, $productId, $varTitle,
                    $colorName !== 'Default' ? $colorName : '', $sizeAttrKey, true, count($colorGroups) === 1,
                    array_merge($this->drawsOnSharedPool($group, $sharedPools) ? ['shared_stock'] : [], $colorSlug === '' ? ['unstable_id'] : []));
            }

            return array_values(array_filter($output));
        }

        // Case B: sizes without colour -> one <product> under the parent id.
        // Case C: neither size nor colour (e.g. capacity) -> one <product> under the parent id; listing each
        // variation separately would change published ids and awaits an owner decision (GRCS-006).
        return array_values(array_filter([$this->normalizeVariationGroup($product, $variations, (string) $product->get_id(), $product->get_name(),
            '', $sizeAttrKey, false, true, $this->drawsOnSharedPool($variations, $sharedPools) ? ['shared_stock'] : [])]));
    }

    private ?FeedIdentityPolicy $identityPolicy = null;

    private function identity(): FeedIdentityPolicy
    {
        return $this->identityPolicy ??= new FeedIdentityPolicy();
    }

    /**
     * Read-only diagnostic: how this product's listing identity is treated. `new` products use the opt-in technical
     * listing identities; `legacy` and `uncertain` ones keep today's derivation (nothing is ever reassigned).
     *
     * @return array{class: string, reason: string}
     */
    public function classifyIdentity(WC_Product $product): array
    {
        if (!$product->is_type('variable')) {
            return ['class' => FeedIdentityPolicy::LEGACY, 'reason' => 'not_variable'];
        }
        return $this->classifyIdentityOf($product, $this->getAvailableVariations($product));
    }

    /**
     * Read-only diagnostic: whether the Phase 1 identity rule can represent this product's technical configurations
     * as separate listings (independent of switch and classification). Used by the legacy seed-manifest report.
     *
     * @return array{supported: bool, reason: string}
     */
    public function identityDefinitionSupport(WC_Product $product): array
    {
        if (!$product->is_type('variable')) {
            return ['supported' => true, 'reason' => 'not_variable'];
        }
        $plan = $this->planNewIdentity($product, $this->getAvailableVariations($product));
        return ['supported' => $plan['ok'], 'reason' => $plan['reason']];
    }

    /**
     * Read-only transition detector for a `new` product, fed with the listing IDs of a published feed copy that the caller
     * supplies as evidence (nothing here reads or writes a file, option or product; in-memory diagnostics only).
     *
     * A published ID the current identity no longer produces is classified by what its anchor says:
     * `blocking` — the new-scheme anchor (`-v<variation ID>` / `-t<term ID>`) still names a live configuration of this
     * product, so regenerating would give that configuration a different ID (Size added to a `-v` product, a technical
     * attribute added to a `-t` product, global/custom attribute swaps ...); `lapsed` — the anchor is gone (variation
     * deleted or unpublished, term deleted or no longer used), a legitimate lapse; `unrecognised` — not a new-scheme
     * form or not corroborated by this product's own variations and terms, so nothing is claimed about it.
     * Products that are not `new` (or when the feature is off) are not evaluated: no historical identity is invented.
     *
     * @param list<string> $publishedIds
     * @return array{evaluated: bool, reason: string, plan_reason: string, blocking: list<array{id: string, anchor: string, anchor_id: int}>, lapsed: list<string>, unrecognised: list<string>}
     */
    public function identityTransitions(WC_Product $product, array $publishedIds): array
    {
        $skip = static fn(string $reason): array => ['evaluated' => false, 'reason' => $reason, 'plan_reason' => '', 'blocking' => [], 'lapsed' => [], 'unrecognised' => []];
        if (!$product->is_type('variable') || !method_exists($product, 'get_variation_attributes')) {
            return $skip('not_variable');
        }
        if (!$this->identity()->isConfigured()) {
            return $skip('feature_off');
        }
        $class = $this->identity()->classify($product);
        if ($class['class'] !== FeedIdentityPolicy::NEW) {
            return $skip('not_new:' . $class['reason']);
        }
        $variations = $this->getAvailableVariations($product);
        $plan = $this->planNewIdentity($product, $variations);
        // Derivable set: every planned group (out-of-stock variations included, before D9/D10), else what is emitted today.
        $current = $plan['ok'] && !$plan['noop']
            ? array_map(static fn(array $group): string => $group['id'], $plan['groups'])
            : array_map(static fn(MarketplaceProduct $record): string => $record->id, array_values(array_filter(
                $this->normalizeProduct($product),
                static fn(MarketplaceProduct $record): bool => !in_array(self::IDENTITY_WITHHELD, $record->issues, true)
            )));

        $parentId = $product->get_id();
        $taxonomies = [];
        foreach (array_keys($product->get_variation_attributes()) as $key) {
            if (str_starts_with((string) $key, 'pa_') && taxonomy_exists((string) $key)) {
                $taxonomies[] = (string) $key;
            }
        }
        $blocking = [];
        $lapsed = [];
        $unrecognised = [];
        foreach ($publishedIds as $id) {
            if (in_array($id, $current, true) || ($id !== (string) $parentId && !str_starts_with($id, $parentId . '-'))) {
                continue;
            }
            if (preg_match('/-([tv])(\d+)$/D', $id, $match) !== 1) {
                $unrecognised[] = $id;
                continue;
            }
            $anchorId = (int) $match[2];
            // What sits between "<parent>-" and the anchor tail is the colour part of a combined ID ("" for none).
            $beforeTail = substr($id, 0, strlen($id) - strlen($match[0]));
            $colourPart = $beforeTail === (string) $parentId ? '' : substr($beforeTail, strlen((string) $parentId) + 1);
            $status = $match[1] === 'v'
                ? $this->variationAnchorStatus($parentId, $anchorId)
                : $this->termAnchorStatus($anchorId, $taxonomies, $variations, $colourPart, $this->colourAttributeKey($product));
            if ($status === 'live') {
                $blocking[] = ['id' => $id, 'anchor' => $match[1], 'anchor_id' => $anchorId];
            } elseif ($status === 'gone') {
                $lapsed[] = $id;
            } else {
                $unrecognised[] = $id;
            }
        }
        return ['evaluated' => true, 'reason' => 'new', 'plan_reason' => $plan['reason'], 'blocking' => $blocking, 'lapsed' => $lapsed, 'unrecognised' => $unrecognised];
    }

    /** @return 'live'|'gone'|'foreign' A `-v` anchor: a published child of this product, a deleted/unpublished one, or not ours. */
    private function variationAnchorStatus(int $parentId, int $variationId): string
    {
        if (!get_post($variationId) instanceof \WP_Post) {
            return 'gone';
        }
        $variation = wc_get_product($variationId);
        if (!$variation instanceof WC_Product) {
            return 'gone';
        }
        if (!$variation instanceof WC_Product_Variation || $variation->get_parent_id() !== $parentId) {
            return 'foreign';
        }
        return $variation->get_status() === 'publish' ? 'live' : 'gone';
    }

    /** Variation attribute key that carries the colour, or null. */
    private function colourAttributeKey(WC_Product $product): ?string
    {
        if (!method_exists($product, 'get_variation_attributes')) {
            return null;
        }
        foreach (array_keys($product->get_variation_attributes()) as $key) {
            if ($this->isColorAttribute((string) $key)) {
                return (string) $key;
            }
        }
        return null;
    }

    /**
     * A `-t` tail is live only when one published variation carries that term AND the colour part of the ID
     * (`t<colour term ID>` or the text-derived key), so deleting a colour never reads as a transition just because
     * another colour still uses the same technical term.
     *
     * @param list<string> $taxonomies This product's taxonomy variation attributes.
     * @param list<WC_Product_Variation> $variations
     * @return 'live'|'gone'|'foreign' A `-t` anchor: a live configuration, a deleted/unused one, or not ours.
     */
    private function termAnchorStatus(int $termId, array $taxonomies, array $variations, string $colourPart, ?string $colourKey): string
    {
        $term = get_term($termId);
        if (!$term instanceof \WP_Term) {
            return 'gone';
        }
        if (!in_array($term->taxonomy, $taxonomies, true)) {
            return 'foreign';
        }
        foreach ($variations as $variation) {
            if ($this->rawVariationAttribute($variation, $term->taxonomy) !== $term->slug) {
                continue;
            }
            if ($colourPart === '' || $colourKey === null) {
                return 'live';
            }
            $rawColour = $this->rawVariationAttribute($variation, $colourKey);
            if (preg_match('/^t(\d+)$/D', $colourPart, $colour) === 1 && str_starts_with($colourKey, 'pa_')) {
                $colourTerm = $rawColour === '' ? false : get_term_by('slug', $rawColour, $colourKey);
                if ($colourTerm instanceof \WP_Term && $colourTerm->term_id === (int) $colour[1]) {
                    return 'live';
                }
            } elseif ($rawColour !== '' && rawurldecode(sanitize_title($rawColour)) === $colourPart) {
                return 'live';
            }
        }
        return 'gone';
    }

    /**
     * @param list<WC_Product_Variation> $variations
     * @return array{class: string, reason: string}
     */
    private function classifyIdentityOf(WC_Product $product, array $variations): array
    {
        $class = $this->identity()->classify($product);
        if ($class['class'] !== FeedIdentityPolicy::NEW) {
            return $class;
        }
        $plan = $this->planNewIdentity($product, $variations);
        return $plan['ok'] ? $class : ['class' => FeedIdentityPolicy::UNCERTAIN, 'reason' => $plan['reason']];
    }

    /** Stored (raw) value of one variation attribute: a term slug for taxonomy attributes, the text otherwise. */
    private function rawVariationAttribute(WC_Product_Variation $variation, string $attrKey): string
    {
        $clean = $this->normalizeAttribute(preg_replace('/^attribute_/i', '', $attrKey) ?? $attrKey);
        foreach ($variation->get_attributes() as $key => $value) {
            if ($this->normalizeAttribute(preg_replace('/^attribute_/i', '', (string) $key) ?? (string) $key) === $clean) {
                return trim((string) $value);
            }
        }
        return '';
    }

    /**
     * Identity plan of a `new` product from attribute DEFINITIONS and immutable WooCommerce IDs only; never from
     * counts, stock, price or order. T = variation attributes other than colour and size:
     * T empty -> no suffix; T one taxonomy attribute -> `-t<term ID>`; no size attribute -> `-v<variation ID>`;
     * anything else (custom-text/multi-attribute T with sizes, "any" values, unresolved terms, empty colour slug,
     * duplicate IDs) is unsupported and keeps today's derivation. Pure: writes nothing.
     *
     * @param list<WC_Product_Variation> $variations
     * @return array{ok: bool, reason: string, noop: bool, groups: list<array{id: string, tuple: string, colour: string, labels: list<string>, variations: list<WC_Product_Variation>}>}
     */
    private function planNewIdentity(WC_Product $product, array $variations): array
    {
        $fail = static fn(string $reason): array => ['ok' => false, 'reason' => $reason, 'noop' => false, 'groups' => []];
        if (!method_exists($product, 'get_variation_attributes')) {
            return $fail('not_variable');
        }
        $colour = null;
        $size = null;
        $technical = [];
        foreach (array_keys($product->get_variation_attributes()) as $key) {
            $key = (string) $key;
            if ($colour === null && $this->isColorAttribute($key)) {
                $colour = $key;
            } elseif ($size === null && $this->isSizeAttribute($key)) {
                $size = $key;
            } else {
                $technical[] = $key;
            }
        }
        $isTaxonomy = static fn(string $key): bool => str_starts_with($key, 'pa_') && taxonomy_exists($key);
        $form = match (true) {
            $technical === [] => 'none',
            count($technical) === 1 && $isTaxonomy($technical[0]) => 'term',
            $size === null => 'variation',
            default => 'unsupported',
        };
        if ($form === 'unsupported') {
            return $fail('unsupported_technical_definition');
        }
        if ($colour === null && $form === 'none') {
            return ['ok' => true, 'reason' => 'no_colour_or_technical_attribute', 'noop' => true, 'groups' => []];
        }

        $groups = [];
        /** @var array<string, string> $rawByColourKey First raw custom-text colour value seen for each derived key. */
        $rawByColourKey = [];
        foreach ($variations as $variation) {
            $colourKey = '';
            $colourName = '';
            if ($colour !== null) {
                $raw = $this->rawVariationAttribute($variation, $colour);
                if ($raw === '') {
                    return $fail('any_value_colour');
                }
                if ($isTaxonomy($colour)) {
                    $term = get_term_by('slug', $raw, $colour);
                    if (!$term instanceof \WP_Term) {
                        return $fail('unresolved_colour_term');
                    }
                    $colourKey = 't' . $term->term_id;
                    $colourName = (string) $term->name;
                } else {
                    $colourKey = rawurldecode(sanitize_title($raw));
                    $colourName = rawurldecode($raw);
                    if ($colourKey === '') {
                        return $fail('empty_colour_slug');
                    }
                    // Two different raw values that derive one key ("Red"/"red") would merge into a single listing.
                    if (($rawByColourKey[$colourKey] ?? $raw) !== $raw) {
                        return $fail('duplicate_colour_key');
                    }
                    $rawByColourKey[$colourKey] = $raw;
                }
            }
            $technicalKey = '';
            $labels = [];
            if ($form === 'term') {
                $raw = $this->rawVariationAttribute($variation, $technical[0]);
                $term = $raw === '' ? false : get_term_by('slug', $raw, $technical[0]);
                if (!$term instanceof \WP_Term) {
                    return $fail('unresolved_technical_term');
                }
                $technicalKey = 't' . $term->term_id;
                $labels[] = (string) $term->name;
            } elseif ($form === 'variation') {
                $technicalKey = 'v' . $variation->get_id();
                foreach ($technical as $key) {
                    $label = $this->getVariationAttributeValue($variation, $key);
                    if ($label === '') {
                        return $fail('any_value_technical');
                    }
                    $labels[] = $label;
                }
            }
            $id = (string) $product->get_id() . ($colourKey !== '' ? '-' . $colourKey : '') . ($technicalKey !== '' ? '-' . $technicalKey : '');
            $tuple = $colourKey . '|' . $technicalKey;
            if (isset($groups[$id]) && $groups[$id]['tuple'] !== $tuple) {
                return $fail('id_collision'); // two different (colour, configuration) pairs would share one ID
            }
            $groups[$id] ??= ['id' => $id, 'tuple' => $tuple, 'colour' => $colourName, 'labels' => $labels, 'variations' => []];
            $groups[$id]['variations'][] = $variation;
        }
        if ($groups === []) {
            return $fail('no_variations');
        }
        return ['ok' => true, 'reason' => 'planned', 'noop' => false, 'groups' => array_values($groups)];
    }

    /**
     * Listings of a `new` product through the existing group renderer, so D9/D10 flags, exclusions and BestPrice
     * records behave exactly as for legacy records. Null keeps today's derivation (noop or unsupported definition).
     *
     * @param list<WC_Product_Variation> $variations
     * @param list<int> $sharedPools
     * @return list<MarketplaceProduct>|null
     */
    private function normalizeNewIdentityListings(WC_Product $product, array $variations, array $sharedPools): ?array
    {
        if (!method_exists($product, 'get_variation_attributes')) {
            return null;
        }
        $plan = $this->planNewIdentity($product, $variations);
        if (!$plan['ok'] || $plan['noop']) {
            return null;
        }
        $sizeKey = null;
        foreach (array_keys($product->get_variation_attributes()) as $key) {
            if ($this->isSizeAttribute((string) $key) && !$this->isColorAttribute((string) $key)) {
                $sizeKey = (string) $key;
                break;
            }
        }
        $records = [];
        foreach ($plan['groups'] as $group) {
            $members = array_values(array_filter(
                $group['variations'],
                fn(WC_Product_Variation $variation): bool => $variation->is_in_stock() || $this->includeOutOfStock()
            ));
            if ($members === []) {
                continue;
            }
            $title = $product->get_name();
            foreach (array_merge($group['colour'] !== '' ? [$group['colour']] : [], $group['labels']) as $label) {
                if (!str_contains(mb_strtolower($title, 'UTF-8'), mb_strtolower($label, 'UTF-8'))) {
                    $title .= ' ' . $label;
                }
            }
            $records[] = $this->normalizeVariationGroup($product, $members, $group['id'], $title, $group['colour'], $sizeKey, true,
                count($plan['groups']) === 1, $this->drawsOnSharedPool($members, $sharedPools) ? ['shared_stock'] : [],
                count($plan['groups']) !== 1);
        }
        return array_values(array_filter($records));
    }

    /** Stock owner of a variation that currently counts toward a pool, or null when it is not sellable from tracked stock. */
    private function poolOfSellableVariation(WC_Product_Variation $variation): ?int
    {
        $offer = $this->stockOffer($variation);
        if ($variation->is_in_stock() && !$offer['backorder'] && $offer['quantity'] !== 0 && $variation->managing_stock()) {
            return $offer['pool'];
        }
        return null;
    }

    /**
     * Whether any of these variations takes its quantity from a pool that also backs another variation of the product.
     * A record is affected only if it contains such a variation; records of independently stocked colours are not.
     *
     * @param list<WC_Product_Variation> $variations
     * @param list<int> $sharedPools
     */
    private function drawsOnSharedPool(array $variations, array $sharedPools): bool
    {
        foreach ($variations as $variation) {
            $pool = $this->poolOfSellableVariation($variation);
            if ($pool !== null && in_array($pool, $sharedPools, true)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Render one <product> for a set of variations: one colour, or a whole product without colours.
     *
     * Price, availability, quantity and the <size> list all describe the same variations: the available one
     * with the best availability and lowest price, plus every available size sold on those same terms. A size
     * sold at another price or availability is never listed under this price. It is sent as its own Skroutz
     * <variation>, which requires a quantity, so only when each available size appears once with tracked stock;
     * otherwise it is left out and the product is reported in the feed status.
     *
     * @param list<WC_Product_Variation> $variations
     * @param list<string> $issues
     */
    private function normalizeVariationGroup(
        WC_Product $parent,
        array $variations,
        string $id,
        string $name,
        string $color,
        ?string $sizeAttrKey,
        bool $variationNode,
        bool $inheritParentEan,
        array $issues = [],
        bool $ownMpnOnly = false,
    ): ?MarketplaceProduct {
        $offers = [];
        foreach ($variations as $variation) {
            if (!$variation->is_in_stock()) {
                continue;
            }
            $size = $sizeAttrKey !== null ? $this->getVariationAttributeValue($variation, $sizeAttrKey) : '';
            $offers[] = $this->stockOffer($variation) + [
                'variation' => $variation,
                'size' => $size,
                // A variation for "any size" is sold in every size of the parent.
                'sizes' => $sizeAttrKey === null ? [] : ($size !== '' ? [$size] : $this->detectAttributeOptions($parent, 'size')),
                'price' => $this->calculatePrice($variation, $parent),
                'vat' => $this->getProductVatRate($variation),
            ];
        }

        if ($offers === []) {
            // Reached only when out-of-stock products are included: nothing is advertised as available.
            return $variations === [] ? null : $this->normalizeSingleProduct(
                product: $variationNode ? $variations[0] : $parent,
                id: $id,
                name: $name,
                color: $color,
                parentProduct: $variationNode ? $parent : null,
                stock: self::UNAVAILABLE,
                inheritParentEan: $inheritParentEan,
                issues: $issues,
                ownMpnOnly: $ownMpnOnly,
            );
        }

        $best = $offers[0];
        foreach ($offers as $offer) {
            if ([$offer['backorder'], $offer['price']] < [$best['backorder'], $best['price']]) {
                $best = $offer;
            }
        }
        $listed = [];
        $sizes = [];
        foreach ($offers as $offer) {
            if ($offer['backorder'] === $best['backorder'] && $offer['price'] === $best['price']) {
                $listed[] = $offer;
                $sizes = array_merge($sizes, $offer['sizes']);
            }
        }

        $sizeVariations = [];
        // Technical variants remain distinct products even when their prices happen to match.
        // Diagnose now; changing their published IDs requires the owner's migration decision.
        $technicalVariants = [];
        foreach ($offers as $offer) {
            $technical = [];
            foreach ($offer['variation']->get_attributes() as $key => $value) {
                if (!$this->isColorAttribute((string) $key) && !$this->isSizeAttribute((string) $key)) {
                    $technical[(string) $key] = $value;
                }
            }
            ksort($technical);
            $technicalVariants[serialize($technical)] = true;
        }
        $distinctTechnicalVariants = count($technicalVariants) > 1;
        $ownSizes = array_map(static fn(array $offer): string => $offer['size'], $offers);
        $quantified = array_filter($offers, static fn(array $offer): bool => $offer['quantity'] !== null);
        $canListSizes = $sizeAttrKey !== null && !in_array('', $ownSizes, true)
            && count(array_unique($ownSizes)) === count($ownSizes) && count($quantified) === count($offers)
            && (!function_exists('apply_filters') || (bool) apply_filters('grcs/feeds/size_variations', true, $parent));
        // Only what is published matters: every size when sizes are listed, else just the sizes sold on the advertised terms.
        $publishedOffers = $canListSizes ? $offers : $listed;
        if (count(array_unique(array_column($publishedOffers, 'vat'))) > 1) {
            $issues[] = 'mixed_vat';
        }
        if ($canListSizes) {
            foreach ($offers as $offer) {
                $sizeVariations[] = [
                    'id' => (string) $offer['variation']->get_id(),
                    'size' => $offer['size'],
                    'price' => $offer['price'],
                    'availability' => $this->getProductAvailability($offer['variation'], true, $offer['backorder']),
                    'quantity' => (int) $offer['quantity'],
                    // Only the variation's own codes: a parent SKU is not this size's part number.
                    'ean' => $this->getProductEan($offer['variation']),
                    'mpn' => $this->getProductMpn($offer['variation'], 'edit'),
                ];
            }
        }
        if ($distinctTechnicalVariants || (!$canListSizes && count($listed) < count($offers))) {
            $this->variationIssues[] = $parent->get_id();
        }

        return $this->normalizeSingleProduct(
            product: $variationNode ? $best['variation'] : $parent,
            id: $id,
            name: $name,
            color: $color,
            sizes: implode(', ', array_values(array_unique($sizes))),
            parentProduct: $variationNode ? $parent : null,
            stock: ['in_stock' => true, 'backorder' => $best['backorder'], 'quantity' => $this->poolQuantity($listed)],
            price: $best['price'],
            inheritParentEan: $inheritParentEan,
            fallbackEan: $variationNode ? '' : $this->getProductEan($best['variation']),
            sizeVariations: $sizeVariations,
            requiresVariantSplit: $distinctTechnicalVariants || count($listed) < count($offers),
            taxProduct: $best['variation'],
            issues: $issues,
            ownMpnOnly: $ownMpnOnly,
        );
    }

    /**
     * What may truthfully be said about one sellable item. A quantity is only ever WooCommerce's own stock
     * count: untracked stock stays unknown (null) rather than being invented, and a backorder is not stock.
     *
     * @return array{in_stock: bool, backorder: bool, quantity: ?int, pool: int}
     */
    private function stockOffer(WC_Product $product): array
    {
        $inStock = $product->is_in_stock();
        $backorder = $inStock && $product->get_stock_status() === 'onbackorder';
        $managed = (bool) $product->managing_stock();
        $recordedQuantity = $managed ? $product->get_stock_quantity() : null;
        $quantity = match (true) {
            !$inStock, $backorder => 0,
            $recordedQuantity !== null => min(self::MAX_QUANTITY, max(0, (int) $recordedQuantity)),
            default => null,
        };
        // Variations sharing the parent's stock report the parent as owner, so the pool is counted once.
        return ['in_stock' => $inStock, 'backorder' => $backorder, 'quantity' => $quantity,
            'pool' => $managed ? (int) $product->get_stock_managed_by_id() : $product->get_id()];
    }

    /**
     * Units available across the items, counting a shared stock pool once; unknown if any item's stock is untracked.
     *
     * @param list<array{quantity: ?int, pool: int}> $offers
     */
    private function poolQuantity(array $offers): ?int
    {
        $pools = [];
        foreach ($offers as $offer) {
            if ($offer['quantity'] === null) {
                return null;
            }
            $pools[$offer['pool']] = $offer['quantity'];
        }
        return min(self::MAX_QUANTITY, array_sum($pools));
    }

    /**
     * Render an individual <product> XML node.
     *
     * `$stock` defaults to the product's own stock; `$price` to {@see calculatePrice()}. `$sizeVariations`
     * become Skroutz size <variation> entries, each with its own price, availability and quantity.
     *
     * @param array{in_stock: bool, backorder: bool, quantity: ?int}|null $stock
     * @param list<array{id: string, size: string, price: float, availability: string, quantity: int, ean: string, mpn: string}> $sizeVariations
     * @param list<string> $issues
     */
    private function normalizeSingleProduct(
        WC_Product $product,
        string $id,
        string $name,
        string $color = '',
        string $sizes = '',
        ?WC_Product $parentProduct = null,
        ?array $stock = null,
        ?float $overridePrice = null,
        ?float $price = null,
        bool $inheritParentEan = true,
        string $fallbackEan = '',
        array $sizeVariations = [],
        bool $requiresVariantSplit = false,
        ?WC_Product $taxProduct = null,
        array $issues = [],
        bool $ownMpnOnly = false,
    ): ?MarketplaceProduct {
        $stock ??= $this->stockOffer($product);
        $inStock = $stock['in_stock'];
        if (!$inStock && !$this->includeOutOfStock()) {
            return null;
        }
        $effectiveProduct = $parentProduct ?? $product;

        // Title and description sanitized via GreekDataNormalizer (removes XML control chars, decodes HTML entities)
        $cleanName = GreekDataNormalizer::sanitizeXmlString($name);
        $description = $product->get_description();
        if ($description === '' && $parentProduct !== null) {
            $description = $parentProduct->get_description();
        }
        if ($description === '') {
            $description = $effectiveProduct->get_short_description();
        }
        $cleanDesc = GreekDataNormalizer::sanitizeXmlString($description);

        // Price calculation: per-product override or base price with global percentage markup
        $price ??= $this->calculatePrice($product, $parentProduct, $overridePrice);

        // EAN: WooCommerce 9.2+ native get_global_unique_id() with fallback to custom meta
        $ean = $this->getProductEan($product);
        if ($ean === '' && $parentProduct !== null && $inheritParentEan) {
            $ean = $this->getProductEan($parentProduct);
        }
        if ($ean === '') {
            $ean = $fallbackEan;
        }

        // URLs and images
        $link = $product->get_permalink();
        $imageUrl = $this->getProductImageUrl($product, $parentProduct);
        $additionalImages = $this->getAdditionalGalleryImages($effectiveProduct, $imageUrl);

        // Categories, manufacturer, VAT, availability
        $categoryPath = $this->getProductCategoryPath($effectiveProduct);
        // Size-only groups keep the parent identity/metadata, but the price belongs to the chosen child.
        $vat = $this->getProductVatRate($taxProduct ?? $product);
        $availability = $this->getProductAvailability($product, $inStock, $stock['backorder']);
        $manufacturer = $this->getProductManufacturer($effectiveProduct);
        // New-scheme configuration listings never borrow the parent SKU as a shared part number (the EAN rule, applied to MPN).
        $mpn = $this->getProductMpn($product, $ownMpnOnly ? 'edit' : 'view');

        $weight = (float) $product->get_weight();
        if ($weight <= 0.0 && $parentProduct !== null) {
            $weight = (float) $parentProduct->get_weight();
        }
        if ($weight > 0.0) {
            // Both marketplaces interpret an unlabelled weight as grams, not the store unit.
            $weight = (float) wc_get_weight($weight, 'g');
        }

        return new MarketplaceProduct(
            id: $id, name: $cleanName, link: $link, image: $imageUrl,
            additionalImages: $additionalImages, category: $categoryPath, price: $price,
            vat: $vat, availability: $availability, description: $cleanDesc,
            manufacturer: $manufacturer, mpn: $mpn, ean: $ean,
            inStock: $inStock, backorder: $stock['backorder'], quantity: $stock['quantity'],
            weight: $weight, color: $color, sizes: $sizes, sizeVariations: $sizeVariations,
            requiresVariantSplit: $requiresVariantSplit,
            issues: $issues,
            isbn: $this->getProductIsbn($product, $parentProduct),
        );
    }

    /** Explicit GRCS mapping only: no universal WooCommerce ISBN key or category-name guess. */
    public function getProductIsbn(WC_Product $product, ?WC_Product $parent = null): string
    {
        $value = trim((string) $product->get_meta('_grcs_isbn'));
        // A parent ISBN must not be copied to distinct colour/configuration records.
        if (function_exists('apply_filters')) {
            $value = (string) apply_filters('grcs/feeds/isbn', $value, $product, $parent);
        }
        $isbn = strtoupper(preg_replace('/[\s-]+/', '', $value) ?? '');
        if (preg_match('/^(?:978|979)[0-9]{10}$/D', $isbn) === 1) {
            $sum = 0;
            for ($i = 0; $i < 13; ++$i) { $sum += (int) $isbn[$i] * ($i % 2 === 0 ? 1 : 3); }
            return $sum % 10 === 0 ? $isbn : '';
        }
        if (preg_match('/^[0-9]{9}[0-9X]$/D', $isbn) === 1) {
            $sum = 0;
            for ($i = 0; $i < 10; ++$i) { $sum += ($isbn[$i] === 'X' ? 10 : (int) $isbn[$i]) * (10 - $i); }
            return $sum % 11 === 0 ? $isbn : '';
        }
        return '';
    }

    /**
     * Reads EAN / Barcode from WooCommerce 9.2+ native `$product->get_global_unique_id()` with fallback to custom meta.
     */
    public function getProductEan(WC_Product $product): string
    {
        // 1. Native WooCommerce 9.2+ GTIN / Barcode getter
        /** @phpstan-ignore function.alreadyNarrowedType */
        if (method_exists($product, 'get_global_unique_id')) {
            $nativeVal = trim((string) $product->get_global_unique_id());
            if ($this->isValidBarcode($nativeVal)) {
                return $nativeVal;
            }
        }

        // 2. Custom meta fallbacks
        $metaKeys = [
            '_global_unique_id',
            '_grcs_ean',
            '_ean',
            '_gtin',
            '_barcode',
            'ean',
            'barcode',
            'gtin',
            '_ts_gtin',
            'hpos_barcode',
        ];

        foreach ($metaKeys as $key) {
            // WooCommerce 9.2+ owns _global_unique_id as a product property; reading it as meta logs
            // "called incorrectly" for every product, and the getter above has already read it.
            /** @phpstan-ignore function.alreadyNarrowedType */
            if ($key === '_global_unique_id' && method_exists($product, 'get_global_unique_id')) {
                continue;
            }
            $metaVal = trim((string) $product->get_meta($key));
            if ($this->isValidBarcode($metaVal)) {
                return $metaVal;
            }
        }

        return '';
    }

    private function isValidBarcode(string $value): bool
    {
        return preg_match('/^(?:[0-9]{8}|[0-9]{12}|[0-9]{13}|[0-9]{14})$/D', $value) === 1;
    }

    /**
     * Manufacturer part number from metadata, else the SKU. Empty when neither exists: a made-up code
     * would misidentify the product. `$context` 'edit' ignores a SKU a variation inherits from its parent.
     */
    public function getProductMpn(WC_Product $product, string $context = 'view'): string
    {
        foreach (['_grcs_mpn', '_mpn'] as $key) {
            $value = GreekDataNormalizer::sanitizeXmlString((string) $product->get_meta($key));
            if ($value !== '') {
                return $value;
            }
        }
        return GreekDataNormalizer::sanitizeXmlString((string) $product->get_sku($context));
    }

    private function includeOutOfStock(): bool
    {
        return function_exists('get_option') && in_array(
            get_option(self::OPTION_INCLUDE_OUT_OF_STOCK, 'no'), ['yes', true, 1, '1'], true
        );
    }

    /**
     * Calculates the effective product price including VAT, supporting:
     * 1. Per-product `_grcs_skroutz_price` override.
     * 2. Global percentage markup setting.
     */
    public function calculatePrice(
        WC_Product $product,
        ?WC_Product $parentProduct = null,
        ?float $explicitOverride = null,
    ): float {
        // Check per-product override
        if ($explicitOverride !== null && $explicitOverride > 0.0) {
            return round($explicitOverride, 2);
        }

        $override = $this->getProductPriceOverride($product);
        if ($override !== null && $override > 0.0) {
            return round($override, 2);
        }

        if ($parentProduct !== null) {
            $parentOverride = $this->getProductPriceOverride($parentProduct);
            if ($parentOverride !== null && $parentOverride > 0.0) {
                return round($parentOverride, 2);
            }
        }

        // Base price including tax
        $basePrice = 0.0;
        if (function_exists('wc_get_price_including_tax')) {
            $basePrice = (float) wc_get_price_including_tax($product);
        } else {
            $rawPrice = $product->get_price();
            $basePrice = $rawPrice !== '' ? (float) $rawPrice : (float) $product->get_regular_price();
        }

        if ($basePrice <= 0.0 && $parentProduct !== null) {
            if (function_exists('wc_get_price_including_tax')) {
                $basePrice = (float) wc_get_price_including_tax($parentProduct);
            } else {
                $rawPrice = $parentProduct->get_price();
                $basePrice = $rawPrice !== '' ? (float) $rawPrice : (float) $parentProduct->get_regular_price();
            }
        }

        // Apply global percentage markup setting if configured
        $markupPercent = $this->getGlobalMarkupPercentage();
        if ($markupPercent != 0.0) {
            $basePrice = $basePrice * (1.0 + ($markupPercent / 100.0));
        }

        return max(0.0, round($basePrice, 2));
    }

    /**
     * Checks for a custom per-product `_grcs_skroutz_price` override.
     */
    public function getProductPriceOverride(WC_Product $product): ?float
    {
        $val = $product->get_meta('_grcs_skroutz_price');
        if ($val !== '' && $val !== null && is_numeric($val) && (float) $val > 0.0) {
            return (float) $val;
        }

        return null;
    }

    /**
     * Retrieves the global markup percentage setting.
     */
    public function getGlobalMarkupPercentage(): float
    {
        if (function_exists('get_option')) {
            $standalone = get_option(self::OPTION_MARKUP_PERCENT, null);
            if ($standalone !== null) {
                return is_numeric($standalone) ? (float) $standalone : 0.0;
            }

            $settings = get_option('grcs_settings', []);
            if (
                is_array($settings)
                && isset($settings['skroutz_markup_percentage'])
                && is_numeric($settings['skroutz_markup_percentage'])
            ) {
                return (float) $settings['skroutz_markup_percentage'];
            }
        }

        return 0.0;
    }

    /**
     * Check the module and the preserved Skroutz generation setting at every work entry point.
     */
    public function isFeedEnabled(): bool
    {
        if (!ModuleRegistry::isEnabled(ModuleRegistry::SKROUTZ)) {
            return false;
        }
        if (function_exists('get_option')) {
            $enabled = get_option(self::OPTION_FEED_ENABLED, null);
            if ($enabled !== null && $enabled !== '') {
                return $enabled === 'yes' || $enabled === true || $enabled === '1' || $enabled === 1;
            }

            $settings = get_option('grcs_settings', []);
            if (is_array($settings) && isset($settings['skroutz_feed_enabled'])) {
                $val = $settings['skroutz_feed_enabled'];
                return $val === 'yes' || $val === true || $val === '1' || $val === 1;
            }
        }

        return true;
    }

    /**
     * Sets the global markup percentage setting.
     */
    public function setGlobalMarkupPercentage(float $percent): void
    {
        if (function_exists('update_option')) {
            update_option(self::OPTION_MARKUP_PERCENT, $percent, false);
        }
    }

    /**
     * Compresses the generated XML file to a valid ZIP archive.
     * Uses native ZipArchive when available, with a pure-PHP PKZIP fallback.
     */
    public function createZipArchive(string $sourceFile, string $zipFile): bool
    {
        return (new FeedZipArchive())->create($sourceFile, $zipFile);
    }

    /**
     * Detects if an attribute name or label corresponds to a color variation.
     */
    public function isColorAttribute(string $name): bool
    {
        return $this->matchesAttribute($name, 'color');
    }

    /**
     * Detects if an attribute name or label corresponds to a size variation.
     */
    public function isSizeAttribute(string $name): bool
    {
        return $this->matchesAttribute($name, 'size');
    }

    private function normalizeAttribute(string $name): string
    {
        $name = mb_strtolower(GreekDataNormalizer::stripGreekAccentsUpper(rawurldecode(trim($name))), 'UTF-8');
        return preg_replace('/^(?:attribute_)?(?:pa_)?/', '', $name) ?? $name;
    }

    /** @return list<string> */
    private function attributeAliases(string $type): array
    {
        $option = 'grcs_skroutz_' . $type . '_attribute';
        $override = function_exists('get_option') ? trim((string) get_option($option, '')) : '';
        if ($override !== '') {
            return array_values(array_filter(array_map('trim', explode(',', $override))));
        }
        return match ($type) {
            'size' => ['size', 'megethos', 'noumero', 'μέγεθος', 'νούμερο'],
            'color' => ['color', 'colour', 'xroma', 'chroma', 'χρώμα'],
            'brand' => ['product_brand', 'pa_brand', 'pa_manufacturer', 'pa_kataskeuastis', 'pa_marka', 'μάρκα', 'κατασκευαστής', '_brand', 'brand', 'manufacturer', 'yith_product_brand', 'pwb-brand'],
            default => [],
        };
    }

    private function matchesAttribute(string $name, string $type): bool
    {
        return in_array($this->normalizeAttribute($name), array_map($this->normalizeAttribute(...), $this->attributeAliases($type)), true);
    }

    /**
     * Extracts an attribute string value from a product.
     */
    private function detectAttributeValue(WC_Product $product, string $type): string
    {
        $options = $this->detectAttributeOptions($product, $type);

        return implode(', ', $options);
    }

    /**
     * Extracts individual attribute option labels from a product.
     *
     * @return list<string>
     */
    private function detectAttributeOptions(WC_Product $product, string $type): array
    {
        $attributes = $product->get_attributes();
        foreach ($attributes as $key => $attr) {
            $name = is_string($key) ? $key
                : (is_object($attr) && method_exists($attr, 'get_name') ? (string) $attr->get_name() : '');
            $label = is_object($attr) && method_exists($attr, 'get_name') ? (string) $attr->get_name() : $name;
            $isMatch = $this->matchesAttribute($name, $type) || $this->matchesAttribute($label, $type);

            if ($isMatch) {
                if (is_string($attr)) {
                    $parts = preg_split('/\s*[|,]\s*/', $attr) ?: [$attr];
                    return array_values(array_filter(array_map('trim', $parts), static fn(string $s) => $s !== ''));
                }
                if (
                    is_object($attr)
                    && method_exists($attr, 'is_taxonomy')
                    && $attr->is_taxonomy()
                    && function_exists('wc_get_product_terms')
                ) {
                    $taxName = method_exists($attr, 'get_name') ? (string) $attr->get_name() : $name;
                    $terms = wc_get_product_terms($product->get_id(), $taxName, ['fields' => 'names']);
                    if (is_array($terms) && $terms !== []) {
                        return array_values(array_map('strval', $terms));
                    }
                }
                if (is_object($attr) && method_exists($attr, 'get_options')) {
                    $options = $attr->get_options();
                    if (is_array($options) && !empty($options)) {
                        return array_values(array_map('strval', $options));
                    }
                }
            }
        }

        return [];
    }

    /**
     * Extracts variation attribute value cleanly.
     */
    private function getVariationAttributeValue(WC_Product_Variation $variation, string $attrKey): string
    {
        $strippedKey = preg_replace('/^attribute_/i', '', $attrKey) ?? $attrKey;
        $cleanKey = $this->normalizeAttribute($strippedKey);
        $attributes = $variation->get_attributes();

        foreach ($attributes as $k => $v) {
            $strippedK = preg_replace('/^attribute_/i', '', (string) $k) ?? (string) $k;
            $normK = $this->normalizeAttribute($strippedK);
            if ($normK === $cleanKey) {
                $val = trim((string) $v);
                if ($val !== '') {
                    $taxonomyKey = str_starts_with($strippedK, 'pa_') ? $strippedK : $strippedKey;
                    // Try to resolve taxonomy term name if value is a slug
                    if (function_exists('get_term_by') && str_starts_with($taxonomyKey, 'pa_')) {
                        $term = get_term_by('slug', $val, $taxonomyKey);
                        if ($term instanceof \WP_Term) {
                            return (string) $term->name;
                        }
                    }
                    return rawurldecode($val);
                }
            }
        }

        return '';
    }

    /**
     * Fetch active child variation objects of a variable product.
     *
     * @return list<WC_Product_Variation>
     */
    private function getAvailableVariations(WC_Product $product): array
    {
        $variations = [];
        $children = $product->get_children();

        foreach ($children as $childId) {
            $variation = function_exists('wc_get_product') ? wc_get_product($childId) : null;
            if ($variation instanceof WC_Product_Variation && $variation->get_status() === 'publish') {
                $variations[] = $variation;
            }
        }

        return $variations;
    }

    /**
     * Resolves product image URL with fallback to parent.
     */
    private function getProductImageUrl(WC_Product $product, ?WC_Product $parentProduct = null): string
    {
        $imageId = (int) $product->get_image_id();
        if ($imageId <= 0 && $parentProduct !== null) {
            $imageId = (int) $parentProduct->get_image_id();
        }

        if ($imageId > 0 && function_exists('wp_get_attachment_image_url')) {
            $url = wp_get_attachment_image_url($imageId, 'full');
            if (is_string($url) && $url !== '') {
                return $url;
            }
        }

        return '';
    }

    /**
     * Gallery image URLs other than the main image, without repeats, up to 15 unique images in all.
     *
     * @return list<string>
     */
    private function getAdditionalGalleryImages(WC_Product $product, string $mainImage): array
    {
        $galleryIds = $product->get_gallery_image_ids();
        if (empty($galleryIds) || !function_exists('wp_get_attachment_image_url')) {
            return [];
        }

        $urls = [];
        foreach ($galleryIds as $id) {
            $url = wp_get_attachment_image_url((int) $id, 'full');
            if (is_string($url) && $url !== '' && $url !== $mainImage) {
                $urls[$url] = true;
            }
        }

        return array_slice(array_keys($urls), 0, self::MAX_IMAGES - ($mainImage !== '' ? 1 : 0));
    }

    /**
     * Builds hierarchical category path (e.g. "Αρχική > Ανδρικά > Μπλούζες").
     */
    public function getProductCategoryPath(WC_Product $product): string
    {
        $catIds = $product->get_category_ids();
        if (empty($catIds) || !function_exists('get_term')) {
            return '';
        }

        $primaryId = $catIds[0];
        $ancestors = function_exists('get_ancestors') ? get_ancestors($primaryId, 'product_cat', 'taxonomy') : [];
        $ancestors = array_reverse($ancestors);
        $ancestors[] = $primaryId;

        $names = [];
        foreach ($ancestors as $termId) {
            $term = get_term($termId, 'product_cat');
            if ($term instanceof \WP_Term) {
                $names[] = GreekDataNormalizer::sanitizeXmlString((string) $term->name);
            }
        }

        return implode(' > ', $names);
    }

    /**
     * Resolves VAT percentage rate (e.g. 24, 13, 6).
     */
    public function getProductVatRate(WC_Product $product): string
    {
        if ($product->get_tax_status() !== 'taxable') {
            return '0';
        }
        if (function_exists('wc_tax_enabled') && !wc_tax_enabled()) {
            return '0';
        }

        if (function_exists('WC') && WC()->customer !== null && WC()->customer->get_is_vat_exempt()) {
            return '0';
        }
        if (!class_exists('\WC_Tax')) {
            return '0';
        }
        // Match wc_get_price_including_tax(): view context resolves a variation's "parent" class.
        $rates = \WC_Tax::get_rates($product->get_tax_class());
        if (function_exists('wc_prices_include_tax') && wc_prices_include_tax()
            && !apply_filters('woocommerce_adjust_non_base_location_prices', true)) {
            $rates = \WC_Tax::get_base_tax_rates($product->get_tax_class('unfiltered'));
        }
        // Missing matching rates means no tax in WooCommerce, never an assumed 24%.
        // Calculating on 100 also respects compound/multiple rates instead of taking only the first.
        $rate = array_sum(\WC_Tax::calc_tax(100.0, $rates, false));
        return rtrim(rtrim(number_format($rate, 2, '.', ''), '0'), '.');
    }

    /**
     * Resolves standard Skroutz availability string: the merchant's delivery text for stock on the shelf,
     * otherwise "on order". Backorders get no delivery window the merchant has not promised.
     */
    public function getProductAvailability(WC_Product $product, ?bool $inStockOverride = null, ?bool $backorder = null): string
    {
        $inStock = $inStockOverride ?? $product->is_in_stock();
        $backorder ??= $inStock && $product->get_stock_status() === 'onbackorder';

        if ($inStock && !$backorder) {
            $configured = function_exists('get_option') ? (string) get_option(self::OPTION_AVAILABILITY, '') : '';
            return trim($configured) !== '' ? $configured : self::DEFAULT_AVAILABILITY;
        }

        return self::ON_ORDER_AVAILABILITY;
    }

    /**
     * Resolves brand / manufacturer from product taxonomies or custom meta.
     */
    public function getProductManufacturer(WC_Product $product): string
    {
        $brandTaxonomies = $this->attributeAliases('brand');
        foreach ($brandTaxonomies as $taxonomy) {
            if (function_exists('get_the_terms')) {
                $terms = get_the_terms($product->get_id(), $taxonomy);
                if (is_array($terms) && isset($terms[0]) && $terms[0] instanceof \WP_Term) {
                    $name = GreekDataNormalizer::sanitizeXmlString((string) $terms[0]->name);
                    if ($name !== '') {
                        return $name;
                    }
                }
            }
        }

        $attribute = GreekDataNormalizer::sanitizeXmlString($this->detectAttributeValue($product, 'brand'));
        if ($attribute !== '') {
            return $attribute;
        }
        $metaKeys = array_unique(array_merge($brandTaxonomies, ['_manufacturer', '_brand', 'brand', 'manufacturer', '_grcs_brand', '_grcs_manufacturer']));
        foreach ($metaKeys as $key) {
            $metaVal = GreekDataNormalizer::sanitizeXmlString((string) $product->get_meta($key));
            if ($metaVal !== '') {
                return $metaVal;
            }
        }

        $default = function_exists('get_option') ? (string) get_option(self::OPTION_DEFAULT_MANUFACTURER, '') : '';
        if (GreekDataNormalizer::sanitizeXmlString($default) !== '') {
            return GreekDataNormalizer::sanitizeXmlString($default);
        }
        return function_exists('get_bloginfo') ? GreekDataNormalizer::sanitizeXmlString(get_bloginfo('name')) : '';
    }

    /**
     * Queries published products in batches of `$limit` offset by `$offset`.
     *
     * @return list<WC_Product>
     */
    private function queryProducts(int $offset, int $limit): array
    {
        if (!function_exists('wc_get_products')) {
            return [];
        }

        $args = [
            'status' => 'publish',
            'limit' => $limit,
            'offset' => $offset,
            'orderby' => 'ID',
            'order' => 'ASC',
            'return' => 'objects',
        ];

        $products = wc_get_products($args);
        return is_array($products)
            ? array_values(array_filter($products, static fn(mixed $product): bool => $product instanceof WC_Product))
            : [];
    }
}
