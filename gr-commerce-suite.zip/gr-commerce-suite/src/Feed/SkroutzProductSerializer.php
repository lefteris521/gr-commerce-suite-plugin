<?php

declare(strict_types=1);

namespace GRCommerceSuite\Feed;

use GRCommerceSuite\Utils\GreekDataNormalizer;
use XMLWriter;

/** Skroutz tags only; extraction, grouping, prices and stock are resolved before serialization. */
final class SkroutzProductSerializer
{
    public function serialize(MarketplaceProduct $product): string
    {
        $writer = new XMLWriter();
        $writer->openMemory();
        $writer->setIndent(true);
        $writer->setIndentString('    ');

        $writer->startElement('product');
        $writer->writeElement('id', GreekDataNormalizer::sanitizeXmlString($product->id));

        $writer->startElement('name');
        $writer->writeCdata($product->name);
        $writer->endElement();

        $writer->startElement('link');
        $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($product->link));
        $writer->endElement();

        // Both specifications ask for an empty image link rather than none, so a later image is picked up.
        $writer->startElement('image');
        $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($product->image));
        $writer->endElement();

        // One element per photo: both marketplaces read repeated elements, never a joined list.
        foreach ($product->additionalImages as $additionalImage) {
            $writer->startElement('additional_imageurl');
            $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($additionalImage));
            $writer->endElement();
        }

        if ($product->category !== '') {
            $writer->startElement('category');
            $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($product->category));
            $writer->endElement();
        }

        $writer->writeElement('price_with_vat', number_format($product->price, 2, '.', ''));
        $writer->writeElement('vat', GreekDataNormalizer::sanitizeXmlString($product->vat));
        $writer->writeElement('availability', GreekDataNormalizer::sanitizeXmlString($product->availability));

        if ($product->description !== '') {
            $writer->startElement('description');
            $writer->writeCdata($product->description);
            $writer->endElement();
        }

        if ($product->manufacturer !== '') {
            $writer->startElement('manufacturer');
            $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($product->manufacturer));
            $writer->endElement();
        }

        if ($product->mpn !== '') {
            $writer->startElement('mpn');
            $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($product->mpn));
            $writer->endElement();
        }

        if ($product->ean !== '') {
            $writer->startElement('ean');
            $writer->writeCdata($product->ean);
            $writer->endElement();
        }

        // A backorder can be ordered but is not on the shelf.
        $writer->writeElement('instock', $product->inStock && !$product->backorder ? 'Y' : 'N');
        if ($product->quantity !== null) {
            $writer->writeElement('quantity', (string) $product->quantity);
        }

        if ($product->weight > 0.0) {
            $writer->writeElement('weight', number_format($product->weight, 2, '.', ''));
        }

        if ($product->color !== '') {
            $writer->startElement('color');
            $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($product->color));
            $writer->endElement();
        }

        if ($product->sizes !== '') {
            $writer->startElement('size');
            $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($product->sizes));
            $writer->endElement();
        }

        if ($product->sizeVariations !== []) {
            $writer->startElement('variations');
            foreach ($product->sizeVariations as $variation) {
                $writer->startElement('variation');
                $writer->writeElement('variationid', GreekDataNormalizer::sanitizeXmlString($variation['id']));
                $writer->writeElement('availability', GreekDataNormalizer::sanitizeXmlString($variation['availability']));
                if ($variation['mpn'] !== '') {
                    $writer->startElement('manufacturersku');
                    $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($variation['mpn']));
                    $writer->endElement();
                }
                if ($variation['ean'] !== '') {
                    $writer->startElement('ean');
                    $writer->writeCdata($variation['ean']);
                    $writer->endElement();
                }
                $writer->writeElement('price_with_vat', number_format($variation['price'], 2, '.', ''));
                $writer->startElement('size');
                $writer->writeCdata(GreekDataNormalizer::sanitizeXmlString($variation['size']));
                $writer->endElement();
                $writer->writeElement('quantity', (string) $variation['quantity']);
                $writer->endElement(); // </variation>
            }
            $writer->endElement(); // </variations>
        }

        $writer->endElement(); // </product>

        return $writer->outputMemory();
    }
}
