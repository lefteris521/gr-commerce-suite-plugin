<?php

declare(strict_types=1);

namespace GRCommerceSuite\Feed;

use WC_Product;

/**
 * Decides whether a variable product may use the new technical-configuration listing identities
 * ({@see SkroutzXmlGenerator}); every other product keeps today's derivation untouched.
 *
 * Inputs are frozen or immutable only. The current skroutz.xml is never read: a product missing from it is not
 * proof that it was never published, and after its first publication it legitimately contains the new IDs.
 * Creation date is necessary but never sufficient; any doubt means "not new". Nothing here writes anything.
 *
 * Baseline option `grcs_skroutz_identity_baseline` (absent = feature off, nothing is seeded at install):
 * `cutoff` (unix time of switch-on), `max_id` (MAX(ID) of the posts table then), `parents` (parent IDs in the
 * published feed then, a veto only) and optional `closed` (unix time the feature was switched off; products created
 * inside [cutoff, closed) stay on the new scheme so their published IDs are not orphaned).
 */
final class FeedIdentityPolicy
{
    public const OPTION_BASELINE = 'grcs_skroutz_identity_baseline';
    /** The only native WooCommerce import marker; written by the CSV importer when an ID column does not map to an existing product. */
    public const IMPORT_MARKER_META = '_original_id';

    public const NEW = 'new';
    public const LEGACY = 'legacy';
    public const UNCERTAIN = 'uncertain';

    /** @var array<string, mixed>|null */
    private ?array $baseline = null;

    /** True when a baseline exists (feature switched on at least once). One option read, nothing else. */
    public function isConfigured(): bool
    {
        return $this->baseline() !== [];
    }

    /**
     * @return array{class: string, reason: string}
     */
    public function classify(WC_Product $parent): array
    {
        $baseline = $this->baseline();
        if ($baseline === []) {
            return ['class' => self::LEGACY, 'reason' => 'feature_off'];
        }
        $created = $parent->get_date_created();
        if ($created === null) {
            return ['class' => self::UNCERTAIN, 'reason' => 'no_creation_date'];
        }
        $timestamp = $created->getTimestamp();
        if ($timestamp <= (int) $baseline['cutoff']) {
            return ['class' => self::LEGACY, 'reason' => 'created_before_cutoff'];
        }
        if (isset($baseline['closed']) && $timestamp >= (int) $baseline['closed']) {
            return ['class' => self::LEGACY, 'reason' => 'created_after_close'];
        }
        if ($parent->get_id() <= (int) $baseline['max_id']) {
            return ['class' => self::UNCERTAIN, 'reason' => 'id_not_above_switch_on_maximum'];
        }
        if (in_array($parent->get_id(), array_map('intval', (array) ($baseline['parents'] ?? [])), true)) {
            return ['class' => self::UNCERTAIN, 'reason' => 'in_switch_on_published_snapshot'];
        }
        if ($this->hasImportMarker($parent)) {
            return ['class' => self::UNCERTAIN, 'reason' => 'import_marker_original_id'];
        }
        return ['class' => self::NEW, 'reason' => 'all_criteria_met'];
    }

    private function hasImportMarker(WC_Product $parent): bool
    {
        if ((string) $parent->get_meta(self::IMPORT_MARKER_META) !== '') {
            return true;
        }
        foreach ($parent->get_children() as $childId) {
            if ((string) get_post_meta((int) $childId, self::IMPORT_MARKER_META, true) !== '') {
                return true;
            }
        }
        return false;
    }

    /** @return array<string, mixed> Empty when the feature is off or the stored value is unusable. */
    private function baseline(): array
    {
        if ($this->baseline === null) {
            $stored = function_exists('get_option') ? get_option(self::OPTION_BASELINE, []) : [];
            $valid = is_array($stored) && isset($stored['cutoff'], $stored['max_id'])
                && is_numeric($stored['cutoff']) && is_numeric($stored['max_id']);
            $this->baseline = $valid ? $stored : [];
        }
        return $this->baseline;
    }
}
