<?php

declare(strict_types=1);

namespace GRCommerceSuite\Payments;

/**
 * The D1 v4 payment-attempt ledger contract as data: ONE definition feeds both CREATE TABLE and the readiness check, so they cannot
 * drift. Types are stored in canonical form (no integer display width); {@see self::createSql()} adds the width MariaDB / MySQL 5.7 expect.
 * No foreign keys anywhere (docs/agents/handoffs/2026-10-30-sonnet-d1-payment-attempt-design.md, "Final table contract").
 */
final class LedgerSpec
{
    public const ATTEMPTS = 'grcs_payment_attempts';
    public const SCOPE_MUTEX = 'grcs_payment_scope_mutex';
    public const BINDINGS = 'grcs_payment_bindings';
    public const ACTIVE_CLAIMS = 'grcs_payment_active_claims';
    public const RESERVATIONS = 'grcs_payment_reservations';
    public const SCOPE_LINKS = 'grcs_payment_scope_links';
    public const QUARANTINE = 'grcs_payment_quarantine';
    public const EVENTS = 'grcs_payment_events';
    public const RESERVATION_EVENTS = 'grcs_payment_reservation_events';
    public const RECOVERY_TOKENS = 'grcs_payment_recovery_tokens';
    public const SUBMISSIONS = 'grcs_payment_submissions';

    /** Bumped whenever the contract below changes; readiness compares it with the stored marker. */
    public const CONTRACT_VERSION = 1;

    /**
     * @return array<string, array{columns: array<string, array{string, bool}>, primary: list<string>, unique: array<string, list<string>>, index: array<string, list<string>>, auto?: string}>
     *   column => [canonical type, nullable]
     */
    public static function tables(): array
    {
        $uuid = 'binary(16)';
        $hash = 'binary(32)';
        $ts = 'datetime(6)';
        $big = 'bigint unsigned';
        $scope = ['scope_type' => ['varchar(24)', false], 'scope_hash' => [$hash, false]];

        return [
            self::ATTEMPTS => [
                'columns' => [
                    'attempt_id' => [$uuid, false], 'order_id' => [$big, false], 'gateway_id' => ['varchar(191)', false],
                    'cart_hash' => [$hash, true], 'amount_minor' => [$big, true], 'currency' => ['char(3)', true],
                    'currency_exponent' => ['tinyint unsigned', true], 'merchant_identity_hash' => [$hash, true],
                    'environment' => ['varchar(32)', true], 'context_status' => ['varchar(16)', false],
                    'context_version' => ['smallint unsigned', false], 'state' => ['varchar(24)', false], 'version' => [$big, false],
                    'source' => ['varchar(32)', false], 'evidence_ref' => ['varchar(191)', true], 'evidence_digest' => [$hash, true],
                    'created_utc' => [$ts, false], 'updated_utc' => [$ts, false],
                ],
                'primary' => ['attempt_id'], 'unique' => [],
                'index' => ['order_state' => ['order_id', 'state'], 'state_updated' => ['state', 'updated_utc']],
            ],
            self::SCOPE_MUTEX => ['columns' => $scope, 'primary' => ['scope_type', 'scope_hash'], 'unique' => [], 'index' => []],
            self::BINDINGS => [
                'columns' => $scope + ['attempt_id' => [$uuid, false], 'created_utc' => [$ts, false]],
                'primary' => ['scope_type', 'scope_hash', 'attempt_id'], 'unique' => [],
                'index' => ['attempt_scope' => ['attempt_id', 'scope_type', 'scope_hash']],
            ],
            self::ACTIVE_CLAIMS => [
                'columns' => $scope + ['owner_id' => [$uuid, false], 'owner_kind' => ['varchar(16)', false], 'created_utc' => [$ts, false]],
                'primary' => ['scope_type', 'scope_hash'], 'unique' => [], 'index' => ['owner' => ['owner_kind', 'owner_id']],
            ],
            self::RESERVATIONS => [
                'columns' => [
                    'reservation_id' => [$uuid, false], 'token_hash' => [$hash, false], 'session_scope_hash' => [$hash, false],
                    'candidate_order_id' => [$big, true], 'state' => ['varchar(24)', false], 'version' => [$big, false],
                    'attempt_id' => [$uuid, true], 'created_utc' => [$ts, false], 'updated_utc' => [$ts, false],
                ],
                'primary' => ['reservation_id'], 'unique' => [],
                'index' => ['candidate_state' => ['candidate_order_id', 'state'], 'state_attempt' => ['state', 'attempt_id', 'created_utc']],
            ],
            self::SCOPE_LINKS => [
                'columns' => [
                    'left_type' => ['varchar(24)', false], 'left_hash' => [$hash, false], 'right_type' => ['varchar(24)', false],
                    'right_hash' => [$hash, false], 'created_utc' => [$ts, false],
                ],
                'primary' => ['left_type', 'left_hash', 'right_type', 'right_hash'], 'unique' => [],
                'index' => ['right_left' => ['right_type', 'right_hash', 'left_type', 'left_hash']],
            ],
            self::QUARANTINE => [
                'columns' => $scope + ['opened_utc' => [$ts, false], 'updated_utc' => [$ts, false], 'reason' => ['varchar(191)', false]],
                'primary' => ['scope_type', 'scope_hash'], 'unique' => [], 'index' => [],
            ],
            self::EVENTS => [
                'columns' => [
                    'event_id' => [$big, false], 'attempt_id' => [$uuid, false], 'version' => [$big, false], 'from_state' => ['varchar(24)', true],
                    'to_state' => ['varchar(24)', false], 'actor_type' => ['varchar(32)', false], 'actor_id' => [$big, true],
                    'at_utc' => [$ts, false], 'evidence_type' => ['varchar(32)', true], 'evidence_ref' => ['varchar(191)', true],
                    'reason' => ['varchar(191)', true], 'note' => ['text', true],
                ],
                'primary' => ['event_id'], 'unique' => ['attempt_version' => ['attempt_id', 'version']], 'index' => ['at' => ['at_utc']],
                'auto' => 'event_id',
            ],
            self::RESERVATION_EVENTS => [
                'columns' => [
                    'event_id' => [$big, false], 'reservation_id' => [$uuid, false], 'version' => [$big, false],
                    'event_type' => ['varchar(24)', false], 'actor_type' => ['varchar(32)', false], 'actor_id' => [$big, true],
                    'at_utc' => [$ts, false], 'reason' => ['varchar(191)', true], 'note' => ['text', true],
                ],
                'primary' => ['event_id'], 'unique' => ['reservation_version' => ['reservation_id', 'version']], 'index' => ['at' => ['at_utc']],
                'auto' => 'event_id',
            ],
            self::RECOVERY_TOKENS => [
                'columns' => [
                    'selector' => [$uuid, false], 'verifier_hash' => [$hash, false], 'order_id' => [$big, false],
                    'expires_utc' => [$ts, false], 'consumed_utc' => [$ts, true], 'created_utc' => [$ts, false],
                ],
                'primary' => ['selector'], 'unique' => [], 'index' => ['order_expires' => ['order_id', 'expires_utc']],
            ],
            self::SUBMISSIONS => [
                'columns' => ['selector_hash' => [$hash, false], 'order_id' => [$big, false], 'created_utc' => [$ts, false]],
                'primary' => ['selector_hash'], 'unique' => [], 'index' => ['by_order' => ['order_id']],
            ],
        ];
    }

    /** @return list<string> unprefixed names in contract order */
    public static function names(): array
    {
        return array_keys(self::tables());
    }

    /** dbDelta()-compatible CREATE TABLE for one table. */
    public static function createSql(string $name, string $prefix, string $collate): string
    {
        $spec = self::tables()[$name];
        $lines = [];
        foreach ($spec['columns'] as $column => [$type, $nullable]) {
            $sqlType = (string) preg_replace(
                ['/^bigint unsigned$/', '/^smallint unsigned$/', '/^tinyint unsigned$/'],
                ['bigint(20) unsigned', 'smallint(5) unsigned', 'tinyint(3) unsigned'],
                $type
            );
            $auto = ($spec['auto'] ?? '') === $column ? ' AUTO_INCREMENT' : '';
            $lines[] = '  ' . $column . ' ' . $sqlType . ($nullable ? ' NULL' : ' NOT NULL') . $auto;
        }
        $lines[] = '  PRIMARY KEY  (' . implode(',', $spec['primary']) . ')';
        foreach ($spec['unique'] as $key => $cols) {
            $lines[] = '  UNIQUE KEY ' . $key . ' (' . implode(',', $cols) . ')';
        }
        foreach ($spec['index'] as $key => $cols) {
            $lines[] = '  KEY ' . $key . ' (' . implode(',', $cols) . ')';
        }

        return 'CREATE TABLE ' . $prefix . $name . " (\n" . implode(",\n", $lines) . "\n) ENGINE=InnoDB {$collate};";
    }

    /** `bigint(20) unsigned` / `int(10)` -> `bigint unsigned` / `int` so MariaDB and MySQL 8 compare equal. */
    public static function normalizeType(string $type): string
    {
        $type = strtolower(trim($type));

        return (string) preg_replace('/^(tinyint|smallint|mediumint|int|bigint)\(\d+\)/', '$1', $type);
    }
}
