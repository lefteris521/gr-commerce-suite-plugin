<?php

declare(strict_types=1);

namespace GRCommerceSuite\Payments;

use wpdb;

/**
 * The durable payment-attempt ledger (D1 v4). The ONLY writer of the ledger tables.
 *
 * Protocol, for every mutation: derive the full scope set, sort it by (scope_type, scope_hash) BEFORE any mutex upsert, take the
 * persistent mutex rows in exactly that order inside one pinned transaction ({@see LedgerTransaction}), then re-read the scope-link /
 * binding graph, claims, quarantine and attempt states with LOCKING reads (current data, never an old REPEATABLE READ snapshot). If the
 * graph reveals scopes outside the locked set, everything is rolled back and restarted with the expanded sorted set. Unique active
 * claims are an independent final fence. Nothing here calls a provider, and no state is ever released by a clock.
 */
final class PaymentLedger
{
    public const STATE_CREATED = 'created';
    public const STATE_IN_FLIGHT = 'in_flight';
    public const STATE_UNKNOWN = 'unknown';
    public const STATE_SUCCEEDED = 'succeeded';
    public const STATE_FAILED = 'failed';
    public const STATE_RELEASED = 'released';
    public const STATE_OFFLINE = 'offline_no_charge';

    /** States that block. Terminal states (succeeded, failed, released, offline_no_charge) never do. */
    public const BLOCKING = [self::STATE_CREATED, self::STATE_IN_FLIGHT, self::STATE_UNKNOWN];

    public const SCOPE_ACCOUNT = 'account';
    public const SCOPE_SESSION = 'session';
    public const SCOPE_GUEST_PROOF = 'guest_proof';
    public const SCOPE_ORDER = 'order';
    public const SCOPE_RECOVERY = 'recovery_session';

    public const RESERVATION_PREPARING = 'preparing';
    public const RESERVATION_PROMOTED = 'promoted';
    public const RESERVATION_RELEASED = 'released';

    private const MAX_ROUNDS = 6;

    public function __construct(private readonly wpdb $db)
    {
    }

    public static function fromGlobals(): self
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            throw new LedgerException('no_wpdb');
        }

        return new self($wpdb);
    }

    // ---- identifiers ------------------------------------------------------------------------------------------------------------

    /** Site- and type-separated keyed hash of a raw scope key (binary(32)). Raw session keys, ids and emails are never stored. */
    public static function scopeHash(string $type, string $raw): string
    {
        $key = function_exists('wp_salt') ? wp_salt('auth') : 'grcs-payment-ledger';
        $blog = function_exists('get_current_blog_id') ? (int) get_current_blog_id() : 1;

        return hash_hmac('sha256', $blog . '|' . $type . '|' . $raw, $key, true);
    }

    public static function newId(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);

        return $bytes;
    }

    public static function now(): string
    {
        $t = microtime(true);
        $sec = (int) floor($t);
        $micro = min(999_999, (int) (($t - $sec) * 1_000_000));

        return gmdate('Y-m-d H:i:s', $sec) . '.' . str_pad((string) $micro, 6, '0', STR_PAD_LEFT);
    }

    /**
     * @param array<string, string|list<string>> $scopes type => raw key (or list of raw keys)
     * @return list<array{0: string, 1: string}> unique [type, binary hash], sorted by (type, hash) bytes
     */
    public static function sortedScopes(array $scopes): array
    {
        $set = [];
        foreach ($scopes as $type => $raws) {
            foreach ((array) $raws as $raw) {
                if ((string) $raw === '' || preg_match('/^[a-z_]{1,24}$/', (string) $type) !== 1) {
                    continue;
                }
                $hash = self::scopeHash((string) $type, (string) $raw);
                $set[$type . "\0" . $hash] = [(string) $type, $hash];
            }
        }
        ksort($set, SORT_STRING);

        return array_values($set);
    }

    /**
     * The ONE place a ledger statement is prepared. Every statement is composed from this class's own fixed SQL, the site prefix and
     * {@see LedgerSpec} constants (hex literals for binary values); every VALUE is bound through wpdb::prepare() placeholders. wpdb's stub
     * wants a literal-string, which a statement containing the prefixed table name can never be, hence the single justified suppression.
     *
     * @param mixed ...$args
     */
    private function sql(string $query, mixed ...$args): string
    {
        $prepared = $this->db->prepare($query, ...$args); // @phpstan-ignore argument.type (composed from fixed code and the table prefix; values are bound)
        if (!is_string($prepared) || $prepared === '') {
            throw new LedgerException('prepare_failed');
        }

        return $prepared;
    }

    private function t(string $name): string
    {
        return '`' . $this->db->prefix . $name . '`';
    }

    // ---- reservation (seam a) ---------------------------------------------------------------------------------------------------

    /**
     * Commits a `preparing` reservation with unique active claims on every scope BEFORE WooCommerce may resume or mutate an order.
     * Refuses (BLOCKED) when any unresolved attempt, claim, reservation or quarantine already covers one of the scopes.
     *
     * @param array<string, string|list<string>> $scopes
     * @return array{id: string, token: string, scopes: array<string, string|list<string>>, virtual?: bool, session?: string}
     * @throws LedgerException
     */
    public function reserve(array $scopes, ?int $candidateOrderId, string $sessionRaw): array
    {
        $id = self::newId();
        $token = bin2hex(random_bytes(32));
        if (self::sortedScopes($scopes) === []) {
            // Nothing to fence yet (a guest with no awaiting order): no claim can be held, so no row is committed here. The reservation is
            // recorded, already promoted, inside the admission transaction that binds the new order.
            return ['id' => $id, 'token' => $token, 'scopes' => $scopes, 'virtual' => true, 'session' => $sessionRaw];
        }
        $tokenHash = hash('sha256', $token, true);
        $sessionScopeHash = self::scopeHash(self::SCOPE_SESSION, $sessionRaw !== '' ? $sessionRaw : 'none');

        $this->withLockedScopes($scopes, function (LedgerTransaction $tx, array $set) use ($id, $tokenHash, $sessionScopeHash, $candidateOrderId): void {
            $this->assertNoBlockers($tx, $set, null);
            $now = self::now();
            $candidate = $candidateOrderId !== null && $candidateOrderId > 0 ? (string) (int) $candidateOrderId : 'NULL';
            $tx->exec($this->sql(
                "INSERT INTO {$this->t(LedgerSpec::RESERVATIONS)} (reservation_id, token_hash, session_scope_hash, candidate_order_id, state, version, attempt_id, created_utc, updated_utc)
                 VALUES (UNHEX('" . bin2hex($id) . "'), UNHEX('" . bin2hex($tokenHash) . "'), UNHEX('" . bin2hex($sessionScopeHash) . "'), {$candidate}, %s, 1, NULL, %s, %s)",
                self::RESERVATION_PREPARING,
                $now,
                $now
            ));
            $this->insertReservationEvent($tx, bin2hex($id), 1, 'created', $now);
            foreach ($set as [$type, $hash]) {
                $this->insertClaim($tx, $type, $hash, $id, 'reservation', $now);
            }
        });

        return ['id' => $id, 'token' => $token, 'scopes' => $scopes];
    }

    // ---- admission (seam c) -----------------------------------------------------------------------------------------------------

    /**
     * Admission transaction: immutable payment context + attempt + bindings + event + claims, committed (and positively acknowledged)
     * before any gateway can be invoked. The request's valid reservation is atomically promoted: its claims move to the attempt.
     *
     * @param array{id: string, token: string} $reservation
     * @param array<string, string|list<string>> $scopes shopper and order scopes (the reservation's scopes must be included)
     * @param array{order_id: int, gateway_id: string, cart_hash: ?string, amount_minor: int, currency: string, currency_exponent: int, merchant_identity_hash: string, environment: string, context_status: string, source: string, offline?: bool, selector_hash?: string} $context
     * @return string binary attempt id
     * @throws LedgerException
     */
    public function admit(array $reservation, array $scopes, array $context): string
    {
        $attemptId = self::newId();

        $this->withLockedScopes($scopes, function (LedgerTransaction $tx, array $set) use ($reservation, $context, $attemptId): void {
            $resHex = bin2hex($reservation['id']);
            $virtual = !empty($reservation['virtual']);
            if (!$virtual) {
                $row = $tx->getRows(
                    "SELECT state, version, HEX(token_hash) AS th FROM {$this->t(LedgerSpec::RESERVATIONS)} WHERE reservation_id = UNHEX('{$resHex}') FOR UPDATE"
                )[0] ?? null;
                if ($row === null || $row['state'] !== self::RESERVATION_PREPARING || (int) $row['version'] !== 1
                    || !hash_equals(strtolower((string) $row['th']), bin2hex(hash('sha256', $reservation['token'], true)))) {
                    throw new LedgerException('reservation_not_promotable', LedgerException::BLOCKED);
                }
            }
            $this->assertNoBlockers($tx, $set, ['reservation', $resHex]);

            $now = self::now();
            $attHex = bin2hex($attemptId);
            $offline = !empty($context['offline']);
            $initialState = $offline ? self::STATE_OFFLINE : self::STATE_CREATED;
            $cart = $context['cart_hash'] !== null && $context['cart_hash'] !== '' ? "UNHEX('" . bin2hex(hash('sha256', $context['cart_hash'], true)) . "')" : 'NULL';
            $tx->exec($this->sql(
                "INSERT INTO {$this->t(LedgerSpec::ATTEMPTS)} (attempt_id, order_id, gateway_id, cart_hash, amount_minor, currency, currency_exponent, merchant_identity_hash, environment, context_status, context_version, state, version, source, evidence_ref, evidence_digest, created_utc, updated_utc)
                 VALUES (UNHEX('{$attHex}'), %d, %s, {$cart}, %d, %s, %d, UNHEX('" . bin2hex($context['merchant_identity_hash']) . "'), %s, %s, 1, %s, 1, %s, NULL, NULL, %s, %s)",
                $context['order_id'],
                $context['gateway_id'],
                $context['amount_minor'],
                $context['currency'],
                $context['currency_exponent'],
                $context['environment'],
                $context['context_status'],
                $initialState,
                $context['source'],
                $now,
                $now
            ));
            $this->insertEvent($tx, $attHex, 1, null, $initialState, 'checkout', self::actorId(), null, null, null, null, $now);
            foreach ($set as [$type, $hash]) {
                $tx->exec($this->sql(
                    "INSERT INTO {$this->t(LedgerSpec::BINDINGS)} (scope_type, scope_hash, attempt_id, created_utc) VALUES (%s, UNHEX('" . bin2hex($hash) . "'), UNHEX('{$attHex}'), %s)",
                    $type,
                    $now
                ));
            }
            if ($offline) {
                // Reviewed offline implementation: terminal and nonblocking from the start. The reservation's claims are dropped, none are taken.
                $tx->exec($this->sql(
                    "DELETE FROM {$this->t(LedgerSpec::ACTIVE_CLAIMS)} WHERE owner_kind = 'reservation' AND owner_id = UNHEX(%s)",
                    $resHex
                ));
            } else {
                // The reservation's claims become the attempt's claims (same scopes, same lock window); any other scope gets a fresh unique claim.
                $tx->exec($this->sql(
                    "UPDATE {$this->t(LedgerSpec::ACTIVE_CLAIMS)} SET owner_id = UNHEX('{$attHex}'), owner_kind = 'attempt' WHERE owner_kind = 'reservation' AND owner_id = UNHEX(%s)",
                    $resHex
                ));
                $claimed = [];
                foreach ($tx->getRows("SELECT scope_type, HEX(scope_hash) AS h FROM {$this->t(LedgerSpec::ACTIVE_CLAIMS)} WHERE owner_kind = 'attempt' AND owner_id = UNHEX('{$attHex}')") as $claim) {
                    $claimed[$claim['scope_type'] . "\0" . strtolower((string) $claim['h'])] = true;
                }
                foreach ($set as [$type, $hash]) {
                    if (!isset($claimed[$type . "\0" . bin2hex($hash)])) {
                        $this->insertClaim($tx, $type, $hash, $attemptId, 'attempt', $now);
                    }
                }
            }
            $this->linkAliases($tx, $set, $now);
            if (($context['selector_hash'] ?? '') !== '') {
                $bound = $tx->exec($this->sql(
                    "UPDATE {$this->t(LedgerSpec::SUBMISSIONS)} SET order_id = %d WHERE selector_hash = UNHEX(%s) AND order_id = 0",
                    $context['order_id'],
                    bin2hex($context['selector_hash'])
                ));
                if ((int) $bound !== 1) {
                    throw new LedgerException('submission_selector_already_used', LedgerException::BLOCKED);
                }
            }
            if ($virtual) {
                $sessionHash = self::scopeHash(self::SCOPE_SESSION, (string) (($reservation['session'] ?? '') !== '' ? $reservation['session'] : 'none'));
                $tx->exec($this->sql(
                    "INSERT INTO {$this->t(LedgerSpec::RESERVATIONS)} (reservation_id, token_hash, session_scope_hash, candidate_order_id, state, version, attempt_id, created_utc, updated_utc)
                     VALUES (UNHEX('{$resHex}'), UNHEX('" . bin2hex(hash('sha256', $reservation['token'], true)) . "'), UNHEX('" . bin2hex($sessionHash) . "'), NULL, %s, 2, UNHEX('{$attHex}'), %s, %s)",
                    self::RESERVATION_PROMOTED,
                    $now,
                    $now
                ));
                $this->insertReservationEvent($tx, $resHex, 1, 'created', $now);
            } else {
                $affected = $tx->exec($this->sql(
                    "UPDATE {$this->t(LedgerSpec::RESERVATIONS)} SET state = %s, version = 2, attempt_id = UNHEX('{$attHex}'), updated_utc = %s WHERE reservation_id = UNHEX('{$resHex}') AND state = %s AND version = 1",
                    self::RESERVATION_PROMOTED,
                    $now,
                    self::RESERVATION_PREPARING
                ));
                if ((int) $affected !== 1) {
                    throw new LedgerException('reservation_promotion_lost', LedgerException::BLOCKED);
                }
            }
            $this->insertReservationEvent($tx, $resHex, 2, 'promoted', $now);
        });

        return $attemptId;
    }

    // ---- evidence transitions (seams e / f, release) ---------------------------------------------------------------------------

    /**
     * Compare-and-set transition of one unresolved attempt to a terminal state, with its append-only event, in one transaction under the
     * same sorted mutexes as admission. Bindings are kept. The attempt's claims are removed - or handed to another unresolved attempt bound to
     * the same scope, so releasing A never unblocks B. Returns false when the attempt is not (or no longer) unresolved.
     *
     * @throws LedgerException
     */
    public function transition(string $attemptHex, string $to, string $actorType, ?int $actorId, ?string $evidenceType, ?string $evidenceRef, ?string $reason, ?string $note): bool
    {
        if (preg_match('/^[0-9a-f]{32}$/', $attemptHex) !== 1 || !in_array($to, [self::STATE_SUCCEEDED, self::STATE_FAILED, self::STATE_RELEASED, self::STATE_UNKNOWN], true)) {
            throw new LedgerException('transition_invalid');
        }
        $set = $this->attemptScopeSet($attemptHex);

        return (bool) $this->withLockedSet($set, function (LedgerTransaction $tx, array $locked) use ($attemptHex, $to, $actorType, $actorId, $evidenceType, $evidenceRef, $reason, $note): bool {
            $row = $tx->getRows("SELECT state, version FROM {$this->t(LedgerSpec::ATTEMPTS)} WHERE attempt_id = UNHEX('{$attemptHex}') FOR UPDATE")[0] ?? null;
            if ($row === null || !in_array($row['state'], self::BLOCKING, true) || ($row['state'] === $to)) {
                return false;
            }
            $now = self::now();
            $version = (int) $row['version'];
            $changed = $tx->exec($this->sql(
                "UPDATE {$this->t(LedgerSpec::ATTEMPTS)} SET state = %s, version = %d, evidence_ref = {$this->lit($evidenceRef)}, updated_utc = %s WHERE attempt_id = UNHEX('{$attemptHex}') AND version = %d AND state = %s",
                $to,
                $version + 1,
                $now,
                $version,
                $row['state']
            ));
            if ((int) $changed !== 1) {
                throw new LedgerException('transition_cas_lost');
            }
            $this->insertEvent($tx, $attemptHex, $version + 1, (string) $row['state'], $to, $actorType, $actorId, $evidenceType, $evidenceRef, $reason, $note, $now);
            if (in_array($to, self::BLOCKING, true)) {
                return true; // reopened as unknown: claims stay
            }
            $this->releaseClaims($tx, 'attempt', $attemptHex, $now);
            $this->clearSettledQuarantine($tx, $locked);

            return true;
        });
    }

    /** Hex id of the unresolved attempt bound to this order, or null. */
    public function blockingAttemptForOrder(int $orderId): ?string
    {
        $marks = implode(',', array_fill(0, count(self::BLOCKING), '%s'));
        $hex = $this->db->get_var($this->sql(
            "SELECT HEX(attempt_id) FROM {$this->t(LedgerSpec::ATTEMPTS)} WHERE order_id = %d AND state IN ({$marks}) ORDER BY created_utc DESC LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
            $orderId,
            ...self::BLOCKING
        ));
        if ($this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }

        return is_string($hex) && $hex !== '' ? strtolower($hex) : null;
    }

    /**
     * The immutable context committed at admission for this order's checkout attempt (the only authority provider evidence is compared to).
     *
     * @return array{amount_minor: int, currency: string, environment: string}|null
     */
    public function contextForOrder(int $orderId, ?string $attemptHex = null): ?array
    {
        $target = $attemptHex !== null && preg_match('/^[0-9a-f]{32}$/', $attemptHex) === 1 ? " AND attempt_id = UNHEX('{$attemptHex}')" : '';
        $row = $this->db->get_row($this->sql(
            "SELECT amount_minor, currency, environment FROM {$this->t(LedgerSpec::ATTEMPTS)} WHERE order_id = %d{$target} AND source = 'checkout' AND context_status = 'complete' AND amount_minor IS NOT NULL ORDER BY created_utc DESC LIMIT 1",
            $orderId
        ), ARRAY_A);
        if ($this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }

        return is_array($row) ? ['amount_minor' => (int) $row['amount_minor'], 'currency' => (string) $row['currency'], 'environment' => (string) $row['environment']] : null;
    }

    // ---- server-issued submission selectors (seam d) ----------------------------------------------------------------------------

    /** Issues a random selector bound to this session; only its keyed hash is stored. */
    public function issueSelector(string $sessionRaw): string
    {
        $selector = bin2hex(random_bytes(16));
        $ok = $this->db->query($this->sql(
            "INSERT INTO {$this->t(LedgerSpec::SUBMISSIONS)} (selector_hash, order_id, created_utc) VALUES (UNHEX(%s), 0, %s)",
            bin2hex(self::selectorHash($selector, $sessionRaw)),
            self::now()
        ));
        if ($ok === false) {
            throw new LedgerException('selector_issue_failed');
        }

        return $selector;
    }

    public static function selectorHash(string $selector, string $sessionRaw): string
    {
        return self::scopeHash('submission', $selector . '|' . $sessionRaw);
    }

    /** @return int|null null = not a selector this session was issued; 0 = issued and unused; >0 = already bound to that order */
    public function selectorOrder(string $selector, string $sessionRaw): ?int
    {
        $row = $this->db->get_var($this->sql(
            "SELECT order_id FROM {$this->t(LedgerSpec::SUBMISSIONS)} WHERE selector_hash = UNHEX(%s)",
            bin2hex(self::selectorHash($selector, $sessionRaw))
        ));
        if ($this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }

        return $row === null ? null : (int) $row;
    }

    // ---- checkout signup join (seam b) ------------------------------------------------------------------------------------------

    /**
     * Records a persistent verified alias between two scopes (the original guest session and the account that checkout signup just created)
     * under both endpoint locks, EVEN IF no attempt exists yet: later requests then discover the joined component, and a concurrent request
     * still using the original scope serializes against this join.
     *
     * @param array<string, string> $a one scope: type => raw key
     * @param array<string, string> $b another scope
     * @throws LedgerException
     */
    public function linkScopes(array $a, array $b): void
    {
        $left = self::sortedScopes($a)[0] ?? null;
        $right = self::sortedScopes($b)[0] ?? null;
        if ($left === null || $right === null) {
            throw new LedgerException('link_scope_empty');
        }
        [$first, $second] = strcmp($left[0] . "\0" . $left[1], $right[0] . "\0" . $right[1]) <= 0 ? [$left, $right] : [$right, $left];
        $this->withLockedScopes($a + $b, function (LedgerTransaction $tx) use ($first, $second): void {
            $tx->exec($this->sql(
                "INSERT IGNORE INTO {$this->t(LedgerSpec::SCOPE_LINKS)} (left_type, left_hash, right_type, right_hash, created_utc) VALUES (%s, UNHEX('" . bin2hex($first[1]) . "'), %s, UNHEX('" . bin2hex($second[1]) . "'), %s)",
                $first[0],
                $second[0],
                self::now()
            ));
        });
    }

    // ---- orphan reservations (seam h) -------------------------------------------------------------------------------------------

    /** @return list<array{reference: string, state: string, created: string}> `preparing` reservations with no order and no attempt (non-secret fields only) */
    public function orphanReservations(int $limit = 200): array
    {
        $rows = $this->db->get_results($this->sql(
            "SELECT HEX(reservation_id) AS r, state, created_utc AS c FROM {$this->t(LedgerSpec::RESERVATIONS)}
             WHERE state = %s AND candidate_order_id IS NULL AND attempt_id IS NULL ORDER BY created_utc ASC LIMIT %d",
            self::RESERVATION_PREPARING,
            $limit
        ), ARRAY_A);
        if (!is_array($rows) || $this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }

        return array_map(static fn(array $r): array => ['reference' => strtolower((string) $r['r']), 'state' => (string) $r['state'], 'created' => (string) $r['c']], $rows);
    }

    /** @return array{state: string, candidate_order_id: ?int, attempt: bool}|null */
    public function reservationRow(string $resHex): ?array
    {
        if (preg_match('/^[0-9a-f]{32}$/', $resHex) !== 1) {
            return null;
        }
        $row = $this->db->get_row("SELECT state, candidate_order_id, attempt_id IS NOT NULL AS has_attempt FROM {$this->t(LedgerSpec::RESERVATIONS)} WHERE reservation_id = UNHEX('{$resHex}')", ARRAY_A);

        return is_array($row) ? ['state' => (string) $row['state'], 'candidate_order_id' => $row['candidate_order_id'] !== null ? (int) $row['candidate_order_id'] : null, 'attempt' => (int) $row['has_attempt'] === 1] : null;
    }

    /**
     * Attested merchant release of an orphan `preparing` reservation: under the same sorted mutexes, CAS only that reservation to
     * `released` (promotion is then permanently refused), delete only the claims it owns (handing shared scopes to other unresolved holds),
     * and append its attributed event - all in one transaction, so any failure leaves the previous blocking state.
     *
     * @throws LedgerException
     */
    public function releaseReservation(string $resHex, int $actorId, string $reason, string $note): bool
    {
        if (preg_match('/^[0-9a-f]{32}$/', $resHex) !== 1) {
            throw new LedgerException('reservation_id_invalid');
        }
        $claims = $this->db->get_results($this->sql(
            "SELECT scope_type AS ty, HEX(scope_hash) AS h FROM {$this->t(LedgerSpec::ACTIVE_CLAIMS)} WHERE owner_kind = 'reservation' AND owner_id = UNHEX(%s)",
            $resHex
        ), ARRAY_A);
        if (!is_array($claims) || $this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }
        $set = [];
        foreach ($claims as $claim) {
            $hash = (string) hex2bin(strtolower((string) $claim['h']));
            $set[$claim['ty'] . "\0" . $hash] = [(string) $claim['ty'], $hash];
        }
        ksort($set, SORT_STRING);

        return (bool) $this->withLockedSet(array_values($set), function (LedgerTransaction $tx, array $locked) use ($resHex, $actorId, $reason, $note): bool {
            $row = $tx->getRows("SELECT state, version, attempt_id IS NOT NULL AS has_attempt FROM {$this->t(LedgerSpec::RESERVATIONS)} WHERE reservation_id = UNHEX('{$resHex}') FOR UPDATE")[0] ?? null;
            if ($row === null || $row['state'] !== self::RESERVATION_PREPARING || (int) $row['has_attempt'] === 1) {
                return false; // promotion already won (or it is gone): use the order / attempt process
            }
            $now = self::now();
            $version = (int) $row['version'];
            $changed = $tx->exec($this->sql(
                "UPDATE {$this->t(LedgerSpec::RESERVATIONS)} SET state = %s, version = %d, updated_utc = %s WHERE reservation_id = UNHEX(%s) AND version = %d AND state = %s",
                self::RESERVATION_RELEASED,
                $version + 1,
                $now,
                $resHex,
                $version,
                self::RESERVATION_PREPARING
            ));
            if ((int) $changed !== 1) {
                throw new LedgerException('reservation_release_cas_lost');
            }
            $this->insertReservationEvent($tx, $resHex, $version + 1, 'released', $now, 'merchant', $actorId, substr($reason, 0, 191), $note);
            $this->releaseClaims($tx, 'reservation', $resHex, $now);

            return true;
        });
    }

    // ---- guest email recovery tokens (seams i / j) ------------------------------------------------------------------------------

    /**
     * Atomically revokes any earlier unconsumed token for $orderId and issues a fresh one under the order scope lock, so at most one
     * unconsumed token per order is valid at any time.
     *
     * @return array{selector: string, verifier: string} hex selector (16 bytes) and hex verifier (32 bytes); only the verifier's hash is stored
     * @throws LedgerException
     */
    public function issueRecoveryToken(int $orderId, int $lifetimeSeconds = 1800): array
    {
        $selector = random_bytes(16);
        $verifier = bin2hex(random_bytes(32));
        $this->withLockedScopes([self::SCOPE_ORDER => (string) $orderId], function (LedgerTransaction $tx) use ($orderId, $lifetimeSeconds, $selector, $verifier): void {
            $now = self::now();
            $revoked = gmdate('Y-m-d H:i:s', time() - 1) . '.000000';
            $expires = gmdate('Y-m-d H:i:s', time() + $lifetimeSeconds) . '.000000';
            $tx->exec($this->sql(
                "UPDATE {$this->t(LedgerSpec::RECOVERY_TOKENS)} SET expires_utc = %s WHERE order_id = %d AND consumed_utc IS NULL AND expires_utc > %s",
                $revoked,
                $orderId,
                $now
            ));
            $tx->exec($this->sql(
                "INSERT INTO {$this->t(LedgerSpec::RECOVERY_TOKENS)} (selector, verifier_hash, order_id, expires_utc, consumed_utc, created_utc)
                 VALUES (UNHEX(%s), UNHEX(%s), %d, %s, NULL, %s)",
                bin2hex($selector),
                bin2hex(hash('sha256', $verifier, true)),
                $orderId,
                $expires,
                $now
            ));
        });

        return ['selector' => bin2hex($selector), 'verifier' => $verifier];
    }

    /**
     * Single-use confirmation. One transaction: the token is consumed by CAS (unused, unexpired, verifier hash equal) and a fresh
     * `recovery_session` scope is bound to every unresolved attempt of the token's order. Concurrent confirmations: exactly one wins.
     * Returns the order id, or null for any invalid / expired / used token (callers answer all of them the same way).
     *
     * @throws LedgerException
     */
    public function consumeRecoveryToken(string $selectorHex, string $verifier, string $recoveryProofRaw): ?int
    {
        if (preg_match('/^[0-9a-f]{32}$/', $selectorHex) !== 1 || preg_match('/^[0-9a-f]{64}$/', $verifier) !== 1 || $recoveryProofRaw === '') {
            return null;
        }
        $row = $this->db->get_row($this->sql(
            "SELECT order_id, HEX(verifier_hash) AS vh, expires_utc, consumed_utc FROM {$this->t(LedgerSpec::RECOVERY_TOKENS)} WHERE selector = UNHEX(%s)",
            $selectorHex
        ), ARRAY_A);
        if ($this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }
        $verifierHash = bin2hex(hash('sha256', $verifier, true));
        if (!is_array($row) || $row['consumed_utc'] !== null || !hash_equals(strtolower((string) $row['vh']), $verifierHash) || (string) $row['expires_utc'] <= self::now()) {
            return null;
        }
        $orderId = (int) $row['order_id'];
        $set = array_merge($this->attemptScopesOfOrder($orderId), self::sortedScopes([self::SCOPE_RECOVERY => $recoveryProofRaw]));
        $unique = [];
        foreach ($set as [$type, $hash]) {
            $unique[$type . "\0" . $hash] = [$type, $hash];
        }
        ksort($unique, SORT_STRING);
        $recoveryHash = self::scopeHash(self::SCOPE_RECOVERY, $recoveryProofRaw);

        $won = $this->withLockedSet(array_values($unique), function (LedgerTransaction $tx) use ($selectorHex, $verifierHash, $orderId, $recoveryHash): bool {
            $now = self::now();
            $consumed = $tx->exec($this->sql(
                "UPDATE {$this->t(LedgerSpec::RECOVERY_TOKENS)} SET consumed_utc = %s WHERE selector = UNHEX(%s) AND consumed_utc IS NULL AND expires_utc > %s AND verifier_hash = UNHEX(%s)",
                $now,
                $selectorHex,
                $now,
                $verifierHash
            ));
            if ((int) $consumed !== 1) {
                return false;
            }
            $marks = "'" . implode("','", self::BLOCKING) . "'";
            foreach ($tx->getCol("SELECT HEX(attempt_id) FROM {$this->t(LedgerSpec::ATTEMPTS)} WHERE order_id = {$orderId} AND state IN ({$marks}) FOR UPDATE") as $attemptHex) {
                $tx->exec($this->sql(
                    "INSERT IGNORE INTO {$this->t(LedgerSpec::BINDINGS)} (scope_type, scope_hash, attempt_id, created_utc) VALUES (%s, UNHEX(%s), UNHEX(%s), %s)",
                    self::SCOPE_RECOVERY,
                    bin2hex($recoveryHash),
                    strtolower($attemptHex),
                    $now
                ));
            }

            return true;
        });

        return $won === true ? $orderId : null;
    }

    /** @return list<array{0: string, 1: string}> scopes bound to the unresolved attempts of an order */
    private function attemptScopesOfOrder(int $orderId): array
    {
        $marks = "'" . implode("','", self::BLOCKING) . "'";
        $rows = $this->db->get_results($this->sql(
            "SELECT b.scope_type AS ty, HEX(b.scope_hash) AS h FROM {$this->t(LedgerSpec::BINDINGS)} b JOIN {$this->t(LedgerSpec::ATTEMPTS)} a ON a.attempt_id = b.attempt_id
             WHERE a.order_id = %d AND a.state IN ({$marks})",
            $orderId
        ), ARRAY_A);
        if (!is_array($rows) || $this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }

        return array_map(static fn(array $r): array => [(string) $r['ty'], (string) hex2bin(strtolower((string) $r['h']))], $rows);
    }

    // ---- legacy `_grcs_pay_intent` migration ------------------------------------------------------------------------------------

    /**
     * Imports one legacy unresolved intent as an `unknown` attempt (idempotent per order): order scope claimed and bound, account scope
     * bound. Context is explicitly unknown and is never backfilled from the current order or settings. Provenance: source `legacy_intent`.
     */
    public function importLegacyIntent(int $orderId, int $customerId, string $gatewayId, string $source = 'legacy_intent'): void
    {
        $scopes = [self::SCOPE_ORDER => (string) $orderId];
        if ($customerId > 0) {
            $scopes[self::SCOPE_ACCOUNT] = (string) $customerId;
        }
        $this->withLockedScopes($scopes, function (LedgerTransaction $tx, array $set) use ($orderId, $gatewayId, $source): void {
            $exists = $tx->getVar($this->sql(
                "SELECT COUNT(*) FROM {$this->t(LedgerSpec::ATTEMPTS)} WHERE order_id = %d AND source = %s FOR UPDATE",
                $orderId,
                $source
            ));
            if ((int) $exists > 0) {
                return;
            }
            $attemptId = self::newId();
            $attHex = bin2hex($attemptId);
            $now = self::now();
            $tx->exec($this->sql(
                "INSERT INTO {$this->t(LedgerSpec::ATTEMPTS)} (attempt_id, order_id, gateway_id, cart_hash, amount_minor, currency, currency_exponent, merchant_identity_hash, environment, context_status, context_version, state, version, source, evidence_ref, evidence_digest, created_utc, updated_utc)
                 VALUES (UNHEX('{$attHex}'), %d, %s, NULL, NULL, NULL, NULL, NULL, NULL, 'unknown', 1, %s, 1, %s, NULL, NULL, %s, %s)",
                $orderId,
                substr($gatewayId, 0, 191),
                self::STATE_UNKNOWN,
                $source,
                $now,
                $now
            ));
            $this->insertEvent($tx, $attHex, 1, null, self::STATE_UNKNOWN, 'migration', null, null, null, $source, 'imported without provider finality', $now);
            foreach ($set as [$type, $hash]) {
                $tx->exec($this->sql(
                    "INSERT INTO {$this->t(LedgerSpec::BINDINGS)} (scope_type, scope_hash, attempt_id, created_utc) VALUES (%s, UNHEX('" . bin2hex($hash) . "'), UNHEX('{$attHex}'), %s)",
                    $type,
                    $now
                ));
            }
            $orderHash = self::scopeHash(self::SCOPE_ORDER, (string) $orderId);
            $tx->exec($this->sql(
                "INSERT IGNORE INTO {$this->t(LedgerSpec::ACTIVE_CLAIMS)} (scope_type, scope_hash, owner_id, owner_kind, created_utc) VALUES (%s, UNHEX('" . bin2hex($orderHash) . "'), UNHEX('{$attHex}'), 'attempt', %s)",
                self::SCOPE_ORDER,
                $now
            ));
        });
    }

    // ---- reads that need no mutex (single autocommit statements on the writer) --------------------------------------------------

    /** True when an unresolved attempt is bound to this order (current committed data; used by the cron veto and the order guard). */
    public function orderHasBlockingAttempt(int $orderId): bool
    {
        $marks = implode(',', array_fill(0, count(self::BLOCKING), '%s'));
        $count = $this->db->get_var($this->sql(
            "SELECT COUNT(*) FROM {$this->t(LedgerSpec::ATTEMPTS)} WHERE order_id = %d AND state IN ({$marks})", // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
            $orderId,
            ...self::BLOCKING
        ));
        if ($count === null || $this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }

        return (int) $count > 0;
    }

    /** Terminal state of the newest attempt for an order, or null (none / still blocking). Used to settle legacy intents. */
    public function orderHasTerminalOnly(int $orderId): bool
    {
        $rows = $this->db->get_col($this->sql(
            "SELECT state FROM {$this->t(LedgerSpec::ATTEMPTS)} WHERE order_id = %d",
            $orderId
        ));
        if (!is_array($rows) || $this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }

        return $rows !== [] && array_diff($rows, [self::STATE_SUCCEEDED, self::STATE_FAILED, self::STATE_RELEASED, self::STATE_OFFLINE]) === [];
    }

    // ---- transaction plumbing ---------------------------------------------------------------------------------------------------

    /**
     * @template T
     * @param array<string, string|list<string>> $scopes
     * @param callable(LedgerTransaction, list<array{0: string, 1: string}>): T $work
     * @return T|null
     * @throws LedgerException
     */
    private function withLockedScopes(array $scopes, callable $work)
    {
        return $this->withLockedSet(self::sortedScopes($scopes), $work);
    }

    /**
     * Same protocol for an already hashed, sorted set (a transition only knows the hashes stored in the bindings).
     *
     * @template T
     * @param list<array{0: string, 1: string}> $set
     * @param callable(LedgerTransaction, list<array{0: string, 1: string}>): T $work
     * @return T|null
     * @throws LedgerException
     */
    private function withLockedSet(array $set, callable $work)
    {
        for ($round = 0; $round < self::MAX_ROUNDS; ++$round) {
            LedgerTransaction::refuseOuterTransaction($this->db);
            $this->ensureMutexRows($set);
            $expanded = null;
            $result = (new LedgerTransaction($this->db))->run(function (LedgerTransaction $tx) use ($set, $work, &$expanded) {
                foreach ($set as [$type, $hash]) {
                    $found = $tx->getVar($this->sql(
                        "SELECT scope_type FROM {$this->t(LedgerSpec::SCOPE_MUTEX)} WHERE scope_type = %s AND scope_hash = UNHEX('" . bin2hex($hash) . "') FOR UPDATE",
                        $type
                    ));
                    if ($found === null) {
                        throw new LedgerException('mutex_row_missing');
                    }
                }
                $connected = $this->connected($tx, $set);
                if ($connected !== $set) {
                    $expanded = $connected; // discovered scopes outside the locked set: roll back, restart with the sorted union

                    return null;
                }

                return $work($tx, $set);
            });
            if ($expanded === null) {
                return $result;
            }
            $set = $expanded;
        }

        throw new LedgerException('scope_graph_unstable');
    }

    /**
     * Persistent mutex rows must exist before they can be locked; INSERT IGNORE outside the transaction avoids gap-lock deadlocks.
     *
     * @param list<array{0: string, 1: string}> $set
     */
    private function ensureMutexRows(array $set): void
    {
        if ($set === []) {
            return;
        }
        $values = [];
        foreach ($set as [$type, $hash]) {
            $values[] = $this->sql("(%s, UNHEX('" . bin2hex($hash) . "'))", $type);
        }
        $suppress = $this->db->suppress_errors(true);
        $show = $this->db->hide_errors();
        try {
            $ok = $this->db->query("INSERT IGNORE INTO {$this->t(LedgerSpec::SCOPE_MUTEX)} (scope_type, scope_hash) VALUES " . implode(',', $values));
            if ($ok === false) {
                throw new LedgerException('mutex_upsert_failed');
            }
        } finally {
            $this->db->suppress_errors($suppress);
            if ($show) {
                $this->db->show_errors(true);
            }
        }
    }

    /**
     * Scopes connected to $set through persistent alias links and through the bindings of any UNRESOLVED attempt bound to a scope in it,
     * as locking reads.
     *
     * @param list<array{0: string, 1: string}> $set
     * @return list<array{0: string, 1: string}> sorted union (equal to $set when nothing new was discovered)
     */
    private function connected(LedgerTransaction $tx, array $set): array
    {
        if ($set === []) {
            return $set;
        }
        $union = [];
        foreach ($set as [$type, $hash]) {
            $union[$type . "\0" . $hash] = [$type, $hash];
        }
        $left = $this->tupleCondition('left_type', 'left_hash', $set);
        $right = $this->tupleCondition('right_type', 'right_hash', $set);
        $marks = "'" . implode("','", self::BLOCKING) . "'";
        $bound = $this->tupleCondition('b1.scope_type', 'b1.scope_hash', $set);
        $queries = [
            "SELECT right_type AS ty, HEX(right_hash) AS h FROM {$this->t(LedgerSpec::SCOPE_LINKS)} WHERE {$left} FOR UPDATE",
            "SELECT left_type AS ty, HEX(left_hash) AS h FROM {$this->t(LedgerSpec::SCOPE_LINKS)} WHERE {$right} FOR UPDATE",
            "SELECT b2.scope_type AS ty, HEX(b2.scope_hash) AS h FROM {$this->t(LedgerSpec::BINDINGS)} b1
                JOIN {$this->t(LedgerSpec::ATTEMPTS)} a ON a.attempt_id = b1.attempt_id
                JOIN {$this->t(LedgerSpec::BINDINGS)} b2 ON b2.attempt_id = b1.attempt_id
                WHERE a.state IN ({$marks}) AND {$bound} FOR UPDATE",
        ];
        foreach ($queries as $sql) {
            foreach ($tx->getRows($sql) as $row) {
                $hash = (string) hex2bin(strtolower((string) $row['h']));
                $union[$row['ty'] . "\0" . $hash] = [(string) $row['ty'], $hash];
            }
        }
        ksort($union, SORT_STRING);

        return array_values($union);
    }

    /** @param list<array{0: string, 1: string}> $set */
    private function tupleCondition(string $typeCol, string $hashCol, array $set): string
    {
        $parts = [];
        foreach ($set as [$type, $hash]) {
            $parts[] = $this->sql("({$typeCol} = %s AND {$hashCol} = UNHEX('" . bin2hex($hash) . "'))", $type);
        }

        return '(' . implode(' OR ', $parts) . ')';
    }

    /**
     * Current (locking) reads over the locked set. Refuses on quarantine, on any claim not owned by $owner, and on any unresolved
     * attempt bound to any scope: releasing one attempt never unblocks another.
     *
     * @param list<array{0: string, 1: string}> $set
     * @param array{0: string, 1: string}|null $owner [kind, hex id] whose claims are the caller's own
     */
    private function assertNoBlockers(LedgerTransaction $tx, array $set, ?array $owner): void
    {
        if ($set === []) {
            return;
        }
        $q = $this->tupleCondition('scope_type', 'scope_hash', $set);
        if ($tx->getCol("SELECT scope_type FROM {$this->t(LedgerSpec::QUARANTINE)} WHERE {$q} FOR UPDATE") !== []) {
            throw new LedgerException('quarantined', LedgerException::BLOCKED);
        }
        foreach ($tx->getRows("SELECT owner_kind AS k, HEX(owner_id) AS o FROM {$this->t(LedgerSpec::ACTIVE_CLAIMS)} WHERE {$q} FOR UPDATE") as $claim) {
            if ($owner === null || $claim['k'] !== $owner[0] || strtolower((string) $claim['o']) !== strtolower($owner[1])) {
                throw new LedgerException('active_claim', LedgerException::BLOCKED);
            }
        }
        $marks = "'" . implode("','", self::BLOCKING) . "'";
        $b = $this->tupleCondition('b.scope_type', 'b.scope_hash', $set);
        $blocking = $tx->getCol(
            "SELECT HEX(a.attempt_id) FROM {$this->t(LedgerSpec::BINDINGS)} b JOIN {$this->t(LedgerSpec::ATTEMPTS)} a ON a.attempt_id = b.attempt_id
             WHERE a.state IN ({$marks}) AND {$b} FOR UPDATE"
        );
        if ($blocking !== []) {
            throw new LedgerException('unresolved_attempt', LedgerException::BLOCKED);
        }
    }

    /**
     * Removes every active claim an owner holds and hands each freed scope to another UNRESOLVED attempt bound to it, so releasing one
     * hold never unblocks another.
     */
    private function releaseClaims(LedgerTransaction $tx, string $kind, string $ownerHex, string $now): void
    {
        $freed = $tx->getRows($this->sql(
            "SELECT scope_type, HEX(scope_hash) AS h FROM {$this->t(LedgerSpec::ACTIVE_CLAIMS)} WHERE owner_kind = %s AND owner_id = UNHEX(%s) FOR UPDATE",
            $kind,
            $ownerHex
        ));
        $tx->exec($this->sql(
            "DELETE FROM {$this->t(LedgerSpec::ACTIVE_CLAIMS)} WHERE owner_kind = %s AND owner_id = UNHEX(%s)",
            $kind,
            $ownerHex
        ));
        $marks = "'" . implode("','", self::BLOCKING) . "'";
        foreach ($freed as $claim) {
            $other = $tx->getVar($this->sql(
                "SELECT HEX(a.attempt_id) FROM {$this->t(LedgerSpec::BINDINGS)} b JOIN {$this->t(LedgerSpec::ATTEMPTS)} a ON a.attempt_id = b.attempt_id
                 WHERE b.scope_type = %s AND b.scope_hash = UNHEX(%s) AND a.state IN ({$marks}) AND a.attempt_id <> UNHEX(%s) LIMIT 1 FOR UPDATE",
                $claim['scope_type'],
                strtolower((string) $claim['h']),
                $ownerHex
            ));
            if ($other !== null && $other !== '') {
                $this->insertClaim($tx, (string) $claim['scope_type'], (string) hex2bin(strtolower((string) $claim['h'])), (string) hex2bin(strtolower($other)), 'attempt', $now);
            }
        }
    }

    /**
     * A quarantined scope is cleared only when at most ONE unresolved attempt remains bound to it (the incumbent): admission stays blocked
     * through that attempt's binding, so clearing the marker never opens anything.
     *
     * @param list<array{0: string, 1: string}> $locked
     */
    private function clearSettledQuarantine(LedgerTransaction $tx, array $locked): void
    {
        if ($locked === []) {
            return;
        }
        $q = $this->tupleCondition('scope_type', 'scope_hash', $locked);
        $marks = "'" . implode("','", self::BLOCKING) . "'";
        foreach ($tx->getRows("SELECT scope_type, HEX(scope_hash) AS h FROM {$this->t(LedgerSpec::QUARANTINE)} WHERE {$q} FOR UPDATE") as $row) {
            $count = (int) $tx->getVar($this->sql(
                "SELECT COUNT(DISTINCT a.attempt_id) FROM {$this->t(LedgerSpec::BINDINGS)} b JOIN {$this->t(LedgerSpec::ATTEMPTS)} a ON a.attempt_id = b.attempt_id
                 WHERE b.scope_type = %s AND b.scope_hash = UNHEX(%s) AND a.state IN ({$marks}) FOR UPDATE",
                $row['scope_type'],
                strtolower((string) $row['h'])
            ));
            if ($count <= 1) {
                $tx->exec($this->sql(
                    "DELETE FROM {$this->t(LedgerSpec::QUARANTINE)} WHERE scope_type = %s AND scope_hash = UNHEX(%s)",
                    $row['scope_type'],
                    strtolower((string) $row['h'])
                ));
            }
        }
    }

    /** @return list<array{0: string, 1: string}> the scopes an attempt is bound to, sorted */
    private function attemptScopeSet(string $attemptHex): array
    {
        $rows = $this->db->get_results($this->sql(
            "SELECT scope_type AS ty, HEX(scope_hash) AS h FROM {$this->t(LedgerSpec::BINDINGS)} WHERE attempt_id = UNHEX(%s)",
            $attemptHex
        ), ARRAY_A);
        if (!is_array($rows) || $this->db->last_error !== '') {
            throw new LedgerException('read_failed');
        }
        $set = [];
        foreach ($rows as $row) {
            $hash = (string) hex2bin(strtolower((string) $row['h']));
            $set[$row['ty'] . "\0" . $hash] = [(string) $row['ty'], $hash];
        }
        ksort($set, SORT_STRING);

        return array_values($set);
    }

    /**
     * Persistent verified alias edges: when one attempt is bound to an account AND session scopes (checkout signup joins the original guest
     * session to the new account), the edges are written under both endpoint locks so future requests discover the whole component.
     *
     * @param list<array{0: string, 1: string}> $set
     */
    private function linkAliases(LedgerTransaction $tx, array $set, string $now): void
    {
        $accounts = array_values(array_filter($set, static fn(array $s): bool => $s[0] === self::SCOPE_ACCOUNT));
        $sessions = array_values(array_filter($set, static fn(array $s): bool => $s[0] === self::SCOPE_SESSION));
        foreach ($accounts as $account) {
            foreach ($sessions as $session) {
                [$left, $right] = strcmp($account[0] . "\0" . $account[1], $session[0] . "\0" . $session[1]) <= 0 ? [$account, $session] : [$session, $account];
                $tx->exec($this->sql(
                    "INSERT IGNORE INTO {$this->t(LedgerSpec::SCOPE_LINKS)} (left_type, left_hash, right_type, right_hash, created_utc) VALUES (%s, UNHEX('" . bin2hex($left[1]) . "'), %s, UNHEX('" . bin2hex($right[1]) . "'), %s)",
                    $left[0],
                    $right[0],
                    $now
                ));
            }
        }
    }

    private function insertClaim(LedgerTransaction $tx, string $type, string $hash, string $ownerId, string $kind, string $now): void
    {
        $tx->exec($this->sql(
            "INSERT INTO {$this->t(LedgerSpec::ACTIVE_CLAIMS)} (scope_type, scope_hash, owner_id, owner_kind, created_utc) VALUES (%s, UNHEX('" . bin2hex($hash) . "'), UNHEX('" . bin2hex($ownerId) . "'), %s, %s)",
            $type,
            $kind,
            $now
        ));
    }

    private function insertEvent(LedgerTransaction $tx, string $attemptHex, int $version, ?string $from, string $to, string $actorType, ?int $actorId, ?string $evidenceType, ?string $evidenceRef, ?string $reason, ?string $note, string $now): void
    {
        $tx->exec(
            "INSERT INTO {$this->t(LedgerSpec::EVENTS)} (attempt_id, version, from_state, to_state, actor_type, actor_id, at_utc, evidence_type, evidence_ref, reason, note)
             VALUES (UNHEX('{$attemptHex}'), {$version}, {$this->lit($from)}, {$this->lit($to)}, {$this->lit($actorType)}, {$this->lit($actorId)}, {$this->lit($now)}, {$this->lit($evidenceType)}, {$this->lit($evidenceRef)}, {$this->lit($reason)}, {$this->lit($note)})"
        );
    }

    private function insertReservationEvent(LedgerTransaction $tx, string $reservationHex, int $version, string $type, string $now, string $actorType = 'worker', ?int $actorId = null, ?string $reason = null, ?string $note = null): void
    {
        $actor = $actorId ?? ($actorType === 'worker' ? self::actorId() : null);
        $tx->exec(
            "INSERT INTO {$this->t(LedgerSpec::RESERVATION_EVENTS)} (reservation_id, version, event_type, actor_type, actor_id, at_utc, reason, note)
             VALUES (UNHEX('{$reservationHex}'), {$version}, {$this->lit($type)}, {$this->lit($actorType)}, {$this->lit($actor)}, {$this->lit($now)}, {$this->lit($reason)}, {$this->lit($note)})"
        );
    }

    /** SQL literal: NULL, an integer, or an escaped quoted string. */
    private function lit(mixed $value): string
    {
        if ($value === null) {
            return 'NULL';
        }
        if (is_int($value)) {
            return (string) $value;
        }

        return $this->sql('%s', (string) $value);
    }

    private static function actorId(): ?int
    {
        $id = function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;

        return $id > 0 ? $id : null;
    }
}
