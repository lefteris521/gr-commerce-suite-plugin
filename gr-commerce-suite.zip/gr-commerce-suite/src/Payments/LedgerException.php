<?php

declare(strict_types=1);

namespace GRCommerceSuite\Payments;

/**
 * Every ledger refusal. Callers (checkout hooks) turn it into ONE generic customer sentence; the `kind` and the technical message are
 * for logs and tests, never shown to a shopper.
 */
final class LedgerException extends \RuntimeException
{
    /** An unresolved attempt, claim, reservation, quarantine or legacy hold covers this shopper or order. */
    public const BLOCKED = 'blocked';
    /** The ledger cannot be used safely (schema, topology, reconnect, SQL error). Nothing was admitted. */
    public const CLOSED = 'closed';
    /** COMMIT outcome unknown. Rows may be durable; they are re-read on the writer by the next request, never retried. */
    public const AMBIGUOUS = 'ambiguous';
    /** Deadlock / lock wait on a rolled-back transaction: local admission only may restart, before any provider call. */
    public const RETRY = 'retry';

    public function __construct(string $message, public readonly string $kind = self::CLOSED, ?\Throwable $previous = null)
    {
        parent::__construct($message, 0, $previous);
    }
}
