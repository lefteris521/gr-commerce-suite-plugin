<?php

declare(strict_types=1);

namespace GRCommerceSuite\Payments;

use wpdb;

/**
 * One connection-pinned InnoDB transaction on the authoritative writer (D1 v4, "Transaction and conflict protocol").
 *
 * - The mysqli handle is held by reference from START TRANSACTION to COMMIT/ROLLBACK. `wpdb::query()` may reconnect and REPLAY a query on
 *   a fresh connection (including COMMIT); a replaced handle is detected after every statement and aborts the operation (never an
 *   autocommit continuation). A session variable set at START and re-read before COMMIT proves the same session is still in the transaction.
 * - Every statement goes through `wpdb::query()` so the standard `query` filter still sees it; wpdb error printing is silenced for the
 *   duration and the errno is read here. Nothing is ever retried on a replaced connection.
 * - An already-open outer transaction (or autocommit=0 session with an active transaction) is refused before START TRANSACTION via a
 *   one-shot `SET TRANSACTION READ WRITE` probe (errno 1568 / SQLSTATE 25001); the session's autocommit setting is never modified.
 * - Binary values are passed as `UNHEX('..')` (see {@see self::hex()}): raw bytes in wpdb::prepare() are rejected by its invalid-text check.
 * - No provider call or other external side effect may run inside {@see self::run()}.
 */
final class LedgerTransaction
{
    private ?object $pinned = null;
    private int $connectionId = 0;
    private string $marker = '';
    private bool $open = false;
    private bool $showErrors = false;
    private bool $suppressed = false;
    private bool $prevSuppress = false;

    public function __construct(private readonly wpdb $db)
    {
    }

    /** @return string lowercase hex for UNHEX() */
    public static function hex(string $binary): string
    {
        return bin2hex($binary);
    }

    /**
     * Runs $work inside a pinned transaction and commits. Rolls back everything on any failure. A deadlock or lock-wait timeout is
     * retried (bounded) because it happens BEFORE any commit, so no provider could have been called.
     *
     * @template T
     * @param callable(self): T $work
     * @return T
     * @throws LedgerException
     */
    public function run(callable $work, int $maxAttempts = 3)
    {
        for ($try = 1; ; ++$try) {
            try {
                return $this->once($work);
            } catch (LedgerException $e) {
                if ($e->kind !== LedgerException::RETRY || $try >= $maxAttempts) {
                    throw $e->kind === LedgerException::RETRY ? new LedgerException('retry_exhausted', LedgerException::CLOSED, $e) : $e;
                }
                usleep(random_int(20_000, 80_000));
            }
        }
    }

    /**
     * @template T
     * @param callable(self): T $work
     * @return T
     */
    private function once(callable $work)
    {
        try {
            $this->begin();
        } catch (\Throwable $e) {
            $this->finish();
            throw $e instanceof LedgerException ? $e : new LedgerException('begin_failed:' . $e->getMessage(), LedgerException::CLOSED, $e);
        }
        try {
            $result = $work($this);
        } catch (\Throwable $e) {
            $this->rollbackQuietly();
            $this->finish();
            throw $e instanceof LedgerException ? $e : new LedgerException('work_failed:' . $e->getMessage(), LedgerException::CLOSED, $e);
        }
        try {
            $this->commit();
        } finally {
            $this->finish();
        }

        return $result;
    }

    private function begin(): void
    {
        $dbh = $this->handle() ?? null;
        if (!$dbh instanceof \mysqli) {
            throw new LedgerException('no_mysqli_handle');
        }
        $this->suppressed = true;
        $this->showErrors = $this->db->hide_errors();
        $this->prevSuppress = (bool) $this->db->suppress_errors(true);

        // Primary writer only: a read-only (replica / failover) session can never be the authority.
        $readOnly = $this->db->get_var('SELECT @@read_only');
        if ($readOnly === null || (string) $readOnly !== '0') {
            $this->finish();
            throw new LedgerException('not_a_writer');
        }
        $conn = $this->db->get_var('SELECT CONNECTION_ID()');
        if (!is_numeric($conn) || (int) $conn <= 0 || $this->handle() !== $dbh) {
            $this->finish();
            throw new LedgerException('connection_unverified');
        }
        $this->pinned = $dbh;
        $this->connectionId = (int) $conn;
        $this->marker = bin2hex(random_bytes(8));

        self::refuseOuterTransaction($this->db, $dbh);
        $this->exec('START TRANSACTION');
        $this->open = true;
        $this->exec("SET @grcs_ledger_tx = '{$this->marker}'");
        // Test-only pause point (native concurrency workers define the constant); inert in production.
        if (\defined('GRCS_TEST_LEDGER_HOOKS') && \constant('GRCS_TEST_LEDGER_HOOKS') === true) {
            do_action('grcs_test_ledger_after_begin', $this);
        }
    }

    /**
     * START TRANSACTION implicitly COMMITS whatever this session already has open (a WP_UnitTestCase transaction, another plugin's). A bare
     * one-shot `SET TRANSACTION` is refused with 1568 / 25001 (ER_CANT_CHANGE_TX_CHARACTERISTICS) exactly while the server's in-transaction
     * flag is set, on MySQL 8.0+ and MariaDB 10.6+ alike: no privilege, no cache, no implicit commit. READ WRITE is what the ledger
     * transaction gets anyway. Not seen: an outer "transaction" that touched only non-transactional tables (nothing there to commit).
     * On refusal nothing is committed or rolled back and autocommit is never changed: the outer transaction stays the caller's.
     */
    public static function refuseOuterTransaction(wpdb $db, ?\mysqli $pinned = null): void
    {
        $dbh = $pinned ?? $db->__get('dbh');
        if (!$dbh instanceof \mysqli) {
            throw new LedgerException('no_mysqli_handle');
        }
        $showErrors = $db->hide_errors();
        $prevSuppress = (bool) $db->suppress_errors(true);
        try {
            $result = $db->query('SET TRANSACTION READ WRITE');
        } finally {
            $db->suppress_errors($prevSuppress);
            if ($showErrors) {
                $db->show_errors(true);
            }
        }
        if ($db->__get('dbh') !== $dbh) {
            throw new LedgerException('connection_replaced', LedgerException::CLOSED);
        }
        if ($result !== false) {
            return;
        }
        $errno = mysqli_errno($dbh);
        $state = mysqli_sqlstate($dbh);
        $db->last_error = ''; // an expected probe result, not an error for the caller
        if ($errno === 1568 || $state === '25001') {
            throw new LedgerException('outer_transaction_open', LedgerException::CLOSED);
        }
        throw new LedgerException(sprintf('outer_transaction_probe_failed:%d:%s', $errno, $state), LedgerException::CLOSED);
    }

    /** The live mysqli handle (wpdb keeps it protected; its public magic getter exposes it). */
    private function handle(): mixed
    {
        return $this->db->__get('dbh');
    }

    /** One statement on the pinned connection. @return int|bool wpdb result */
    public function exec(string $sql): int|bool
    {
        $this->assertPinned();
        $result = $this->db->query($sql);
        $this->assertPinned();
        if ($result === false) {
            throw $this->failure($sql);
        }

        return $result;
    }

    public function getVar(string $sql): ?string
    {
        $this->assertPinned();
        $value = $this->db->get_var($sql);
        $this->assertPinned();
        $this->throwIfError($sql);

        return $value === null ? null : (string) $value;
    }

    /** @return list<string> */
    public function getCol(string $sql): array
    {
        $this->assertPinned();
        $col = $this->db->get_col($sql);
        $this->assertPinned();
        $this->throwIfError($sql);

        return array_values(array_map('strval', is_array($col) ? $col : []));
    }

    /** @return list<array<string, mixed>> */
    public function getRows(string $sql): array
    {
        $this->assertPinned();
        $rows = $this->db->get_results($sql, ARRAY_A);
        $this->assertPinned();
        $this->throwIfError($sql);

        return is_array($rows) ? array_values($rows) : [];
    }

    private function assertPinned(): void
    {
        if ($this->pinned === null || $this->handle() !== $this->pinned) {
            $this->open = false; // the original session (and its transaction) is gone; nothing to roll back here
            throw new LedgerException('connection_replaced', LedgerException::CLOSED);
        }
    }

    private function throwIfError(string $sql): void
    {
        if ($this->db->last_error !== '') {
            throw $this->failure($sql);
        }
    }

    private function failure(string $sql): LedgerException
    {
        $dbh = $this->pinned;
        $errno = $dbh instanceof \mysqli ? mysqli_errno($dbh) : 0;
        $state = $dbh instanceof \mysqli ? mysqli_sqlstate($dbh) : '';
        $kind = in_array($errno, [1213, 1205], true) || $state === '40001' ? LedgerException::RETRY : LedgerException::CLOSED;

        return new LedgerException(sprintf('sql_error:%d:%s:%s', $errno, $state, strtok(trim($sql), " \n")), $kind);
    }

    private function commit(): void
    {
        // The same session must still own the transaction: a reconnect would have lost the marker.
        $marker = $this->getVar('SELECT @grcs_ledger_tx');
        $conn = $this->getVar('SELECT CONNECTION_ID()');
        if ($marker !== $this->marker || (int) $conn !== $this->connectionId) {
            $this->rollbackQuietly();
            throw new LedgerException('session_changed_before_commit', LedgerException::CLOSED);
        }
        $result = $this->db->query('COMMIT');
        if ($this->handle() !== $this->pinned) {
            // COMMIT was replayed (or lost) on another connection: whether the original committed is unknown.
            $this->open = false;
            throw new LedgerException('commit_connection_replaced', LedgerException::AMBIGUOUS);
        }
        if ($result === false) {
            $this->rollbackQuietly(); // harmless if the server did commit and only the acknowledgement was lost
            throw new LedgerException('commit_failed', LedgerException::AMBIGUOUS);
        }
        $this->open = false;
    }

    private function rollbackQuietly(): void
    {
        if (!$this->open || $this->pinned === null || $this->handle() !== $this->pinned) {
            $this->open = false;

            return;
        }
        $this->db->query('ROLLBACK');
        $this->open = false;
    }

    private function finish(): void
    {
        $this->pinned = null;
        if ($this->suppressed) {
            $this->db->suppress_errors($this->prevSuppress);
            if ($this->showErrors) {
                $this->db->show_errors(true);
            }
            $this->suppressed = false;
        }
    }
}
