<?php

declare(strict_types=1);

namespace GRCommerceSuite\Payments;

use WC_Order;

/**
 * Bridge to the pre-ledger `_grcs_pay_intent` order meta (written by a third-party gateway that left an order pending).
 *
 * Migration rule (D1 v4): an intent without reliable provider finality is an UNKNOWN attempt whatever its age or local order status;
 * elapsed time, a local `failed` / `cancelled` status or a stale pending window never resolve it. The only things that do: positive
 * payment (the order is paid) or a terminal ledger state recorded for it (merchant release / provider evidence, K1b/K1c).
 * Reads are live (dual-read) so a legacy order is honoured even before it has been imported into the ledger.
 */
final class LegacyIntents
{
    public const META = '_grcs_pay_intent';

    public static function isUnresolved(WC_Order $order): bool
    {
        if (!is_array($order->get_meta(self::META)) || $order->is_paid()) {
            return false;
        }
        try {
            return !PaymentLedger::fromGlobals()->orderHasTerminalOnly($order->get_id());
        } catch (LedgerException) {
            return true; // the ledger cannot be read: stay blocked
        }
    }

    /**
     * Orders of this verified shopper that carry an unresolved legacy intent: the account's orders and the orders the shopper proved.
     * Each one found is also imported into the ledger (idempotent) so that it is a first-class blocking attempt from now on.
     *
     * @param list<int> $orderIds
     * @return list<WC_Order>
     */
    public static function unresolvedFor(int $userId, array $orderIds): array
    {
        if (!function_exists('wc_get_orders') || !function_exists('wc_get_order')) {
            return [];
        }
        $candidates = [];
        if ($userId > 0) {
            $found = \wc_get_orders([
                'limit' => -1,
                'customer_id' => $userId,
                'status' => array_keys(\wc_get_order_statuses()),
                'meta_query' => [['key' => self::META, 'compare' => 'EXISTS']],
            ]);
            foreach (is_array($found) ? $found : [] as $order) {
                if ($order instanceof WC_Order) {
                    $candidates[$order->get_id()] = $order;
                }
            }
        }
        foreach (array_unique(array_map('intval', $orderIds)) as $id) {
            $order = $id > 0 ? \wc_get_order($id) : false;
            if ($order instanceof WC_Order) {
                $candidates[$order->get_id()] = $order;
            }
        }
        $unresolved = [];
        foreach ($candidates as $order) {
            if (self::isUnresolved($order)) {
                $unresolved[] = $order;
                self::import($order);
            }
        }

        return $unresolved;
    }

    public static function import(WC_Order $order): void
    {
        $intent = $order->get_meta(self::META);
        if (!is_array($intent)) {
            return;
        }
        try {
            PaymentLedger::fromGlobals()->importLegacyIntent($order->get_id(), (int) $order->get_customer_id(), (string) ($intent['gateway'] ?? $order->get_payment_method()));
        } catch (LedgerException) {
            // best effort: the live dual-read above keeps the hold in force even when the import cannot be written
        }
    }
}
