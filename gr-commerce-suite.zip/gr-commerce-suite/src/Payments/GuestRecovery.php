<?php

declare(strict_types=1);

namespace GRCommerceSuite\Payments;

use GRCommerceSuite\Database\PreparedQuery;
use GRCommerceSuite\Database\Repositories\RateCounterRepository;
use GRCommerceSuite\I18n\AdminLocale;
use GRCommerceSuite\Modules\Klarna\KlarnaOrderRecord;
use GRCommerceSuite\Modules\Klarna\KlarnaShopperProof;
use WC_Order;
use wpdb;

/**
 * Guest email recovery (D1 v4 seams i and j): a guest who lost every cookie proves control of the BILLING mailbox of an order and gets the
 * browser proof back. The typed address is an unverified delivery address, never an identity: it only selects which stored billing
 * addresses may receive a link.
 *
 *  - Form: classic checkout only, guests only, rendered after the checkout form and revealed by {@see assets/js/guest-recovery.js} when the
 *    blocked-payment notice appears. E-mail plus an OPTIONAL order number (a pending order sends the customer no e-mail, so the number may
 *    be unknown); the number only narrows which of the address's orders may receive a link.
 *  - Request: the same generic 200 answer for every input (existing, unknown, malformed, over any limit). The nonce is checked first (its
 *    verdict does not depend on address, order, token or quota); then the per-IP counter; then the work is QUEUED - the request does the
 *    same thing for every address, so response time says nothing. The queued job looks the orders up, applies the per-address quota,
 *    issues one single-use token per eligible order (30 minutes; only a hash of the 256-bit verifier is stored), revokes the order's older
 *    tokens and mails the order's STORED billing address (no order detail in the mail).
 *  - Quota: counted when a mail is really sent, per address+order, in windows as long as a token lives. Whoever exhausts it can only cause
 *    mail to the owner; the newest mailed link outlives the window, so the owner is never locked out.
 *  - Confirm: GET shows the same page for every link and consumes nothing (scanner-safe, `no-store`, no referrer). The token travels in the
 *    URL FRAGMENT (never sent to a server, a log or a Referer) and is POSTed by the page. POST (nonce) consumes by CAS and binds a fresh
 *    `recovery_session` proof to the order's unresolved attempts in the SAME transaction; concurrent POSTs: exactly one wins. A token
 *    expiring or being used never releases anything; a winner on an order that is no longer unresolved gets no cookie and no proof.
 *  - Housekeeping: a daily job purges expired tokens, stale queue payloads and old rate buckets.
 * Works with the Klarna module OFF and the licence expired: it only restores a guest's hold awareness on existing orders.
 */
final class GuestRecovery
{
    public const COOKIE = 'grcs_recovery_proof';
    public const REQUEST_NONCE = 'grcs_payment_recovery_request';
    public const CONFIRM_NONCE = 'grcs_payment_recovery_confirm';
    public const SEND_HOOK = 'grcs_payment_recovery_send';
    public const PURGE_HOOK = 'grcs_payment_recovery_purge';
    public const PAYLOAD_PREFIX = 'grcs_pay_rec_q_';
    private const PER_ADDRESS = 3;
    private const ADDRESS_WINDOW = 1800; // = token lifetime: the newest mailed link is valid until the quota resets
    private const PER_IP = 10;
    private const CONFIRM_PER_IP = 30;
    private const MAX_ORDERS = 5;
    private const TOKEN_LIFETIME = 1800;
    private const RETENTION = 86400;

    public static function register(): void
    {
        add_action('wc_ajax_grcs_payment_recovery_request', [self::class, 'request']);
        add_action('wc_ajax_grcs_payment_recovery_confirm', [self::class, 'confirm']);
        add_action(self::SEND_HOOK, [self::class, 'deliver']);
        add_action(self::PURGE_HOOK, [self::class, 'purge']);
        add_action('wp_enqueue_scripts', [self::class, 'enqueue']);
        add_action('woocommerce_after_checkout_form', [self::class, 'renderForm']); // classic checkout only: the block checkout never fires it
        if (function_exists('wp_next_scheduled') && function_exists('wp_schedule_event') && !wp_next_scheduled(self::PURGE_HOOK)) {
            wp_schedule_event(time() + 300, 'daily', self::PURGE_HOOK);
        }
    }

    /** The recovery proof this browser holds, or ''. Only a well-formed value is ever used as a scope key. */
    public static function proofFromCookie(): string
    {
        $value = isset($_COOKIE[self::COOKIE]) && is_string($_COOKIE[self::COOKIE]) ? $_COOKIE[self::COOKIE] : '';

        return preg_match('/^[0-9a-f]{64}$/', $value) === 1 ? $value : '';
    }

    /** The checkout refusal shown for a blocked payment ({@see \GRCommerceSuite\Modules\Klarna\KlarnaPaymentAdmission}); the form is revealed when it appears. */
    public static function blockedNotice(): string
    {
        return __('A previous payment may still be in progress. Please check your email or contact the store before paying again.', 'gr-commerce-suite'); // customer-facing
    }

    // ---- form (classic checkout, guests) ----------------------------------------------------------------------------------------

    private static function formVisible(): bool
    {
        return function_exists('is_checkout') && is_checkout() && !(function_exists('is_order_received_page') && is_order_received_page())
            && function_exists('is_user_logged_in') && !is_user_logged_in();
    }

    public static function enqueue(): void
    {
        if (!self::formVisible() || !defined('GRCS_PLUGIN_FILE')) {
            return;
        }
        wp_enqueue_script('grcs-guest-recovery', plugins_url('assets/js/guest-recovery.js', GRCS_PLUGIN_FILE), ['jquery'], defined('GRCS_VERSION') ? GRCS_VERSION : false, true);
        wp_localize_script('grcs-guest-recovery', 'grcsRecovery', [
            'blocked' => self::blockedNotice(),
            'i18n' => [
                'sending' => __('Sending...', 'gr-commerce-suite'), // customer-facing
                'failed' => __('Something went wrong. Please reload the page and try again.', 'gr-commerce-suite'), // customer-facing
            ],
        ]);
    }

    public static function renderForm(): void
    {
        if (!self::formVisible()) {
            return;
        }
        $action = \WC_AJAX::get_endpoint(self::REQUEST_NONCE);
        $nonce = wp_create_nonce(self::REQUEST_NONCE);
        include dirname(__DIR__, 2) . '/templates/checkout/guest-recovery-form.php';
    }

    // ---- request ----------------------------------------------------------------------------------------------------------------

    public static function request(): void
    {
        $generic = ['result' => 'success', 'message' => __('If an eligible order exists, we will send a confirmation link to its billing email address.', 'gr-commerce-suite')]; // customer-facing
        if (!self::nonceOk(self::REQUEST_NONCE)) {
            // Independent of address, order and quota: it only says the page is stale.
            wp_send_json(['result' => 'failure', 'message' => __('This link is invalid, expired, or already used. Please request another link.', 'gr-commerce-suite')], 403); // customer-facing
        }
        // Over the per-IP limit the answer is the generic one and nothing is queued: no 429, no distinguishable status.
        if (RateCounterRepository::reserve(self::bucket('i', self::ip())) <= self::PER_IP) {
            // phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above
            $email = strtolower(trim(sanitize_email(wp_unslash(isset($_POST['billing_email']) && is_string($_POST['billing_email']) ? $_POST['billing_email'] : ''))));
            $ref = isset($_POST['grcs_order_ref']) && is_string($_POST['grcs_order_ref']) ? sanitize_text_field(wp_unslash($_POST['grcs_order_ref'])) : '';
            // phpcs:enable
            if ($email !== '' && is_email($email)) {
                self::queue($email, ltrim(substr(trim($ref), 0, 40), '#'));
            }
        }
        wp_send_json($generic); // identical for existing, unknown, malformed and rate-limited addresses
    }

    /** The address never goes into a cron/queue argument: the payload sits in a non-autoloaded option that the job deletes when it runs. */
    private static function queue(string $email, string $ref): void
    {
        $key = self::PAYLOAD_PREFIX . bin2hex(random_bytes(12));
        add_option($key, (string) wp_json_encode(['e' => $email, 'r' => $ref, 't' => time()]), '', false);
        if (function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action(self::SEND_HOOK, [$key], 'gr-commerce-suite');
        } elseif (function_exists('wp_schedule_single_event')) {
            wp_schedule_single_event(time(), self::SEND_HOOK, [$key]);
        }
    }

    /** Queue worker. Single use: the payload is deleted before anything else happens. */
    public static function deliver(mixed $key = ''): void
    {
        if (!is_string($key) || strpos($key, self::PAYLOAD_PREFIX) !== 0) {
            return;
        }
        $raw = get_option($key, '');
        if (!delete_option($key) || !is_string($raw)) {
            return; // gone already (another runner has it) or never existed
        }
        $payload = json_decode($raw, true);
        if (!is_array($payload) || !is_string($payload['e'] ?? null) || !is_email($payload['e'])) {
            return;
        }
        self::sendLinks(strtolower($payload['e']), is_string($payload['r'] ?? null) ? $payload['r'] : '');
    }

    private static function sendLinks(string $email, string $ref): void
    {
        try {
            $ledger = PaymentLedger::fromGlobals();
            $orders = \wc_get_orders([
                'limit' => 25,
                'billing_email' => $email,
                'status' => array_keys(\wc_get_order_statuses()),
                'orderby' => 'date',
                'order' => 'DESC',
            ]);
            $sent = 0;
            foreach (is_array($orders) ? $orders : [] as $order) {
                if ($sent >= self::MAX_ORDERS || !$order instanceof WC_Order || strtolower((string) $order->get_billing_email()) !== $email) {
                    continue;
                }
                if ($ref !== '' && (string) $order->get_order_number() !== $ref && (string) $order->get_id() !== $ref) {
                    continue;
                }
                if (!self::eligible($order)) {
                    continue;
                }
                // Counted only now that a mail is really going out, per address+order: requests for unknown or resolved orders burn nothing.
                $bucket = self::bucket('a', $email . '|' . $order->get_id(), self::ADDRESS_WINDOW);
                if (RateCounterRepository::reserve($bucket) > self::PER_ADDRESS) {
                    continue;
                }
                // Atomically revokes older unused tokens and issues the new one under the order scope lock; wp_mail stays outside the transaction.
                $token = $ledger->issueRecoveryToken($order->get_id(), self::TOKEN_LIFETIME);
                // The token rides in the URL fragment: it never reaches a server log or a Referer, and the page POSTs it.
                // Absolute: WC_AJAX::get_endpoint() is root-relative, which is useless in an e-mail.
                $url = add_query_arg('wc-ajax', 'grcs_payment_recovery_confirm', home_url('/')) . '#' . $token['selector'] . '-' . $token['verifier'];
                // Stored billing address only; no order detail in the message.
                $ok = false;
                try {
                    $ok = (bool) wp_mail(
                        (string) $order->get_billing_email(),
                        __('Confirm access to your payment', 'gr-commerce-suite'), // customer-facing
                        __('Open this link to confirm access to a payment that may still be in progress. It works once and expires in 30 minutes. If you did not ask for it, ignore this message.', 'gr-commerce-suite') . "\n\n" . esc_url_raw($url) // customer-facing
                    );
                } catch (\Throwable) {
                    $ok = false;
                }
                if (!$ok) {
                    RateCounterRepository::refund($bucket);
                    self::expireToken($token['selector']);
                    continue;
                }
                ++$sent;
            }
        } catch (\Throwable) {
            // never distinguishable from "no eligible order": nothing here reaches the response
        }
    }

    /** Revoke a token when delivery fails: an undelivered token must never remain valid. */
    private static function expireToken(string $selectorHex): void
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb || preg_match('/^[0-9a-f]{32}$/', $selectorHex) !== 1) {
            return;
        }
        try {
            $table = $wpdb->prefix . LedgerSpec::RECOVERY_TOKENS;
            $sql = PreparedQuery::prepare(
                $wpdb,
                'UPDATE %i SET expires_utc = %s WHERE selector = UNHEX(%s) AND consumed_utc IS NULL',
                $table,
                gmdate('Y-m-d H:i:s', time() - 1) . '.000000',
                $selectorHex
            );
            $wpdb->query($sql);
        } catch (\Throwable) {
            // best effort expiration
        }
    }

    private static function eligible(WC_Order $order): bool
    {
        if (LegacyIntents::isUnresolved($order)) {
            return true;
        }
        if ((new KlarnaOrderRecord($order))->unresolved()) {
            return true;
        }
        try {
            return PaymentLedger::fromGlobals()->orderHasBlockingAttempt($order->get_id());
        } catch (LedgerException) {
            return false;
        }
    }

    // ---- housekeeping -----------------------------------------------------------------------------------------------------------

    /** Daily: expired/used tokens, stale queue payloads and old rate buckets. Bounded per run. */
    public static function purge(): void
    {
        global $wpdb;
        try {
            $table = $wpdb->prefix . LedgerSpec::RECOVERY_TOKENS;
            $wpdb->query($wpdb->prepare(
                "DELETE FROM `{$table}` WHERE expires_utc < %s LIMIT 500",
                gmdate('Y-m-d H:i:s', time() - self::RETENTION) . '.000000'
            ));
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s LIMIT 200",
                $wpdb->esc_like(self::PAYLOAD_PREFIX) . '%'
            ), ARRAY_A);
            foreach (is_array($rows) ? $rows : [] as $row) {
                $payload = json_decode((string) $row['option_value'], true);
                if (!is_array($payload) || (int) ($payload['t'] ?? 0) < time() - self::RETENTION) {
                    delete_option((string) $row['option_name']);
                }
            }
            foreach (['i' => 3600, 'c' => 3600, 'a' => self::ADDRESS_WINDOW] as $kind => $window) {
                for ($i = 0; $i < 5 && RateCounterRepository::cleanup('grcs_pay_rec_' . $kind . '_', (int) floor(time() / $window) - 1) >= 100; ++$i) {
                    // bounded: at most 5 batches of 100 per kind and run
                }
            }
        } catch (\Throwable) {
            // housekeeping must never break a request
        }
    }

    // ---- confirm ----------------------------------------------------------------------------------------------------------------

    public static function confirm(): void
    {
        $method = isset($_SERVER['REQUEST_METHOD']) && is_string($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';
        if ($method !== 'POST') {
            self::page(); // GET (and HEAD): the same page for every link, nothing is consumed or revealed
        }
        $invalid = ['result' => 'failure', 'message' => __('This link is invalid, expired, or already used. Please request another link.', 'gr-commerce-suite')]; // customer-facing
        if (!self::nonceOk(self::CONFIRM_NONCE)) {
            wp_send_json($invalid, 403); // independent of the token and of any quota
        }
        if (RateCounterRepository::reserve(self::bucket('c', self::ip())) > self::CONFIRM_PER_IP) {
            wp_send_json($invalid); // same status and body as an unknown token
        }
        // phpcs:disable WordPress.Security.NonceVerification.Missing -- verified above
        $selector = isset($_POST['selector']) && is_string($_POST['selector']) ? strtolower(sanitize_text_field(wp_unslash($_POST['selector']))) : '';
        $verifier = isset($_POST['verifier']) && is_string($_POST['verifier']) ? strtolower(sanitize_text_field(wp_unslash($_POST['verifier']))) : '';
        // phpcs:enable
        $proof = bin2hex(random_bytes(32));
        try {
            $orderId = PaymentLedger::fromGlobals()->consumeRecoveryToken($selector, $verifier, $proof);
        } catch (LedgerException) {
            $orderId = null;
        }
        $order = $orderId === null ? false : \wc_get_order($orderId);
        // Already resolved (released, paid, cancelled): the token is spent but nothing is bound, so no cookie and no proof either.
        if (!$order instanceof WC_Order || !self::eligible($order)) {
            wp_send_json($invalid);
        }
        // Private audit note: no address, IP, selector or verifier.
        $order->add_order_note(AdminLocale::__('GR Commerce Suite: guest payment recovery confirmed by e-mail link (one-time token used).', 'gr-commerce-suite'));
        $_COOKIE[self::COOKIE] = $proof;
        if (!headers_sent() && function_exists('setcookie')) {
            setcookie(self::COOKIE, $proof, [
                'expires' => time() + 2592000,
                'path' => defined('COOKIEPATH') && COOKIEPATH !== '' ? (string) COOKIEPATH : '/',
                'secure' => function_exists('is_ssl') && is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
        KlarnaShopperProof::issue($order); // the long-standing signed per-order proof as well (guest orders only)
        wp_send_json(['result' => 'success', 'message' => __('Your payment access has been confirmed. You may return to checkout.', 'gr-commerce-suite')]); // customer-facing
    }

    /** The confirmation page: identical for any query string, no order data, no third-party resources, never cached. */
    private static function page(): never
    {
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=utf-8');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Referrer-Policy: no-referrer');
            header('X-Robots-Tag: noindex, nofollow');
        }
        $action = esc_url(\WC_AJAX::get_endpoint('grcs_payment_recovery_confirm'));
        // The token is read from the URL fragment, the fragment is removed BEFORE anything is sent, and nothing submits by itself.
        $html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="no-referrer">'
            . '<title>' . esc_html__('Confirm payment access', 'gr-commerce-suite') . '</title></head><body><main style="max-width:32rem;margin:3rem auto;padding:0 1rem;font-family:sans-serif">'
            . '<h1>' . esc_html__('Confirm payment access', 'gr-commerce-suite') . '</h1>'
            . '<form id="grcs-rec" method="post" action="' . $action . '">'
            . '<input type="hidden" name="selector" value=""><input type="hidden" name="verifier" value="">'
            . '<input type="hidden" name="grcs_recovery_confirm" value="1"><input type="hidden" name="_wpnonce" value="' . esc_attr(wp_create_nonce(self::CONFIRM_NONCE)) . '">'
            . '<button type="submit">' . esc_html__('Confirm payment access', 'gr-commerce-suite') . '</button></form><p id="grcs-rec-msg" role="status"></p>'
            . '<script>(function(){var f=document.getElementById("grcs-rec"),m=document.getElementById("grcs-rec-msg"),p=location.hash.replace(/^#/,"").split("-");'
            . 'if(history.replaceState){history.replaceState(null,"",location.pathname+location.search);}'
            . 'if(/^[0-9a-f]{32}$/i.test(p[0]||"")&&/^[0-9a-f]{64}$/i.test(p[1]||"")){f.selector.value=p[0];f.verifier.value=p[1];}'
            . 'f.addEventListener("submit",function(e){e.preventDefault();fetch(f.action,{method:"POST",body:new FormData(f),credentials:"same-origin"})'
            . '.then(function(r){return r.json();}).then(function(j){m.textContent=j.message||"";})'
            . '.catch(function(){m.textContent="";});});})();</script></main></body></html>';
        wp_die($html, '', ['response' => 200]);
    }

    private static function nonceOk(string $action): bool
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Missing -- this IS the verification
        $nonce = isset($_POST['_wpnonce']) && is_string($_POST['_wpnonce']) ? $_POST['_wpnonce'] : '';

        return $nonce !== '' && wp_verify_nonce($nonce, $action) !== false;
    }

    private static function ip(): string
    {
        return isset($_SERVER['REMOTE_ADDR']) && is_string($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    }

    /** Fixed-window bucket, keyed and hashed: no address or IP ever appears in an option name. One prefix per kind (purge compares the numeric suffix). */
    private static function bucket(string $kind, string $subject, int $window = 3600): string
    {
        $salt = function_exists('wp_salt') ? wp_salt('auth') : 'grcs-recovery';

        return 'grcs_pay_rec_' . $kind . '_' . substr(hash_hmac('sha256', $kind . '|' . $subject, $salt), 0, 32) . '_' . (int) floor(time() / $window);
    }
}
