<?php

declare(strict_types=1);

namespace GRCommerceSuite\Reconciliation;

use GRCommerceSuite\I18n\AdminLocale;
use DateTimeImmutable;
use DateTimeZone;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Cod\CodReconciliationResult;
use GRCommerceSuite\Domain\Cod\CodSettlementStatus;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\DiagnosticLogger;
use GRCommerceSuite\Utils\GreekDataNormalizer;
use GRCommerceSuite\Support\Logger;
use GRCommerceSuite\Support\Money;
use InvalidArgumentException;
use RuntimeException;
use Throwable;
use WC_Order;

/**
 * Cash-on-Delivery (`Antikatavoli`) Reconciliation Engine (SPEC.md §7, §10).
 *
 * Capabilities:
 * 1. Parses courier COD payout CSV statements with customizable column mapping for:
 *    - Voucher Number (`voucher_no`)
 *    - Collected Amount (`collected_amount`)
 *    - Settlement Reference (`settlement_ref`)
 *    - Payout Date (`payout_date`)
 *    supporting ACS Courier, BOX NOW, and Geniki Taxydromiki (including semicolon/comma delimiters
 *    and European decimal formatting).
 * 2. Cross-checks each CSV row by `voucher_no` against `{prefix}_grcs_vouchers` (`cod_amount`) and
 *    the expected WooCommerce HPOS `$order->get_total()`.
 * 3. Updates `cod_collected`, `cod_reconciled`, `cod_reconciled_at`, and `cod_settlement_ref` in
 *    `{prefix}_grcs_vouchers` and categorizes results into:
 *    a) Exact Match (`cod_reconciled = 1`),
 *    b) Amount Mismatch (`cod_collected != cod_amount` — flags the exact Euro difference),
 *    c) Overdue Unpaid COD (vouchers where `tracking_status = 'delivered'` more than X configurable
 *       days ago, `cod_amount > 0`, and `cod_reconciled = 0`).
 */
final class CodReconciliationService
{
    public const DEFAULT_OVERDUE_DAYS = 7;

    public const OPTION_OVERDUE_DAYS = 'grcs_cod_overdue_days';

    public const OPTION_COLUMN_MAPPING_PREFIX = 'grcs_cod_csv_mapping_';

    public const OPTION_LAST_CSV_REPORT = 'grcs_cod_last_csv_report';

    /** Per-voucher marker: `pending|<identity>` before emission, bare identity once done. */
    public const OPTION_NOTIFIED_PREFIX = 'grcs_cod_notified_';

    private const NOTIFICATION_PENDING_PREFIX = 'pending|';

    /**
     * Default CSV column header mappings per Greek courier provider.
     *
     * @var array<string, array{voucher_no: string, collected_amount: string, settlement_ref: string, payout_date: string}>
     */
    private const DEFAULT_COURIER_MAPPINGS = [
        'acs' => [
            'voucher_no' => 'Voucher_No',
            'collected_amount' => 'Cod_Amount',
            'settlement_ref' => 'Settlement_Ref',
            'payout_date' => 'Payout_Date',
        ],
        'boxnow' => [
            'voucher_no' => 'parcel_id',
            'collected_amount' => 'amount_collected',
            'settlement_ref' => 'settlement_reference',
            'payout_date' => 'payout_date',
        ],
        'geniki' => [
            'voucher_no' => 'Voucher',
            'collected_amount' => 'Antikatavoli',
            'settlement_ref' => 'Borderau_No',
            'payout_date' => 'Date_Paid',
        ],
    ];

    /**
     * Common Greek and English column header aliases used in courier remittance CSV exports.
     *
     * @var array<string, list<string>>
     */
    private const HEADER_ALIASES = [
        'voucher_no' => [
            'voucher_no',
            'voucherno',
            'voucher',
            'voucher number',
            'awb',
            'barcode',
            'tracking',
            'φορτωτικη',
            'parcel_id',
            'parcelid',
            'tracking_number',
            'tracking number',
            'αρ. αποστολής',
            'αριθμός αποστολής',
            'αρ αποστολης',
            'αριθμος αποστολης',
            'κωδικός αποστολής',
            'αριθμός voucher',
        ],
        'collected_amount' => [
            'cod_amount',
            'cod_collected',
            'collected_amount',
            'amount_collected',
            'amountcollected',
            'antikatavoli',
            'cod',
            'amount',
            'collected',
            'εισπραχθεν',
            'αξια αντικαταβολης',
            'ποσό αντικαταβολής',
            'ποσο αντικαταβολης',
            'αντικαταβολή',
            'αντικαταβολη',
            'εισπραχθέν ποσό',
            'ποσό',
        ],
        'settlement_ref' => [
            'settlement_ref',
            'cod_settlement_ref',
            'settlement_reference',
            'settlementreference',
            'remittance_no',
            'remittance_ref',
            'borderau_no',
            'bordereau_no',
            'batch_id',
            'reference',
            'remittance',
            'εκκαθαριση',
            'πινάκιο',
            'κωδικός απόδοσης',
            'κωδικος αποδοσης',
            'αρ. εκκαθάρισης',
            'αρ. πινακίου',
            'πινάκιο απόδοσης',
        ],
        'payout_date' => [
            'payout_date',
            'settled_at',
            'settledat',
            'remittance_date',
            'date_paid',
            'settlement_date',
            'date',
            'ημερομηνία απόδοσης',
            'ημ/νία απόδοσης',
            'ημ/νία πληρωμής',
            'ημερομηνία',
        ],
    ];

    private readonly LoggerInterface $logger;

    /**
     * @var (callable(int): ?WC_Order)|null
     */
    private $orderResolver = null;

    public function __construct(
        private readonly VoucherRepository $repository,
        private readonly ?CourierRegistry $courierRegistry = null,
        ?LoggerInterface $logger = null,
    ) {
        $this->logger = $logger ?? new Logger('gr-commerce-suite');
    }

    /**
     * Configure a custom order resolver callback (used for unit testing without full WordPress runtime).
     *
     * @param (callable(int): ?WC_Order)|null $resolver
     */
    public function setOrderResolver(?callable $resolver): void
    {
        $this->orderResolver = $resolver;
    }

    /**
     * Return default CSV column mapping for ACS, Box Now, or Geniki.
     *
     * @return array{voucher_no: string, collected_amount: string, settlement_ref: string, payout_date: string}
     */
    public function getDefaultColumnMapping(CourierSlug|string $courier): array
    {
        $slug = $courier instanceof CourierSlug ? $courier->value : strtolower(trim($courier));

        return self::DEFAULT_COURIER_MAPPINGS[$slug] ?? self::DEFAULT_COURIER_MAPPINGS['acs'];
    }

    /**
     * Retrieve merchant-configured CSV column mapping for a courier, falling back to courier defaults.
     *
     * @return array{voucher_no: string, collected_amount: string, settlement_ref: string, payout_date: string}
     */
    public function getColumnMapping(CourierSlug|string $courier): array
    {
        $slug = $courier instanceof CourierSlug ? $courier->value : strtolower(trim($courier));
        $defaults = $this->getDefaultColumnMapping($slug);

        if (!function_exists('get_option')) {
            return $defaults;
        }

        $saved = get_option(self::OPTION_COLUMN_MAPPING_PREFIX . $slug, null);
        if (!is_array($saved)) {
            return $defaults;
        }

        return [
            'voucher_no' => isset($saved['voucher_no']) && trim((string) $saved['voucher_no']) !== ''
                ? trim((string) $saved['voucher_no'])
                : $defaults['voucher_no'],
            'collected_amount' => isset($saved['collected_amount']) && trim((string) $saved['collected_amount']) !== ''
                ? trim((string) $saved['collected_amount'])
                : $defaults['collected_amount'],
            'settlement_ref' => isset($saved['settlement_ref']) && trim((string) $saved['settlement_ref']) !== ''
                ? trim((string) $saved['settlement_ref'])
                : $defaults['settlement_ref'],
            'payout_date' => isset($saved['payout_date']) && trim((string) $saved['payout_date']) !== ''
                ? trim((string) $saved['payout_date'])
                : $defaults['payout_date'],
        ];
    }

    /**
     * Persist custom CSV column mapping for a courier.
     *
     * @param array<string, mixed> $mapping
     */
    public function saveColumnMapping(CourierSlug|string $courier, array $mapping): void
    {
        $slug = $courier instanceof CourierSlug ? $courier->value : strtolower(trim($courier));
        $defaults = $this->getDefaultColumnMapping($slug);

        $normalized = [
            'voucher_no' => isset($mapping['voucher_no']) && trim((string) $mapping['voucher_no']) !== ''
                ? trim((string) $mapping['voucher_no'])
                : $defaults['voucher_no'],
            'collected_amount' => isset($mapping['collected_amount']) &&
                 trim((string) $mapping['collected_amount']) !== ''
                ? trim((string) $mapping['collected_amount'])
                : $defaults['collected_amount'],
            'settlement_ref' => isset($mapping['settlement_ref']) && trim((string) $mapping['settlement_ref']) !== ''
                ? trim((string) $mapping['settlement_ref'])
                : $defaults['settlement_ref'],
            'payout_date' => isset($mapping['payout_date']) && trim((string) $mapping['payout_date']) !== ''
                ? trim((string) $mapping['payout_date'])
                : $defaults['payout_date'],
        ];

        if (function_exists('update_option')) {
            update_option(self::OPTION_COLUMN_MAPPING_PREFIX . $slug, $normalized, false);
        }
    }

    /**
     * Retrieve the configured overdue unpaid COD threshold in days (default: 7 days).
     */
    public function getOverdueDaysThreshold(): int
    {
        $days = self::DEFAULT_OVERDUE_DAYS;

        if (function_exists('get_option')) {
            $opt = get_option(self::OPTION_OVERDUE_DAYS, null);
            if ($opt !== null && is_numeric($opt)) {
                $days = max(1, (int) $opt);
            } else {
                $settings = get_option('grcs_settings', []);
                if (
                    is_array($settings) &&
                     isset($settings['cod_overdue_days']) &&
                     is_numeric($settings['cod_overdue_days'])
                ) {
                    $days = max(1, (int) $settings['cod_overdue_days']);
                }
            }
        }

        if (function_exists('apply_filters')) {
            $days = (int) apply_filters('grcs/cod/overdue_days', $days);
        }

        return max(1, $days);
    }

    /**
     * Update the configurable overdue unpaid COD threshold in days.
     */
    public function setOverdueDaysThreshold(int $days): void
    {
        if (function_exists('update_option')) {
            update_option(self::OPTION_OVERDUE_DAYS, max(1, $days), false);
        }
    }

    /**
     * Reconcile a courier COD payout CSV file from disk.
     *
     * @param array<string, string> $columnMapping
     * @return array{
     *     exact_matches: list<array<string, mixed>>,
     *     amount_mismatches: list<array<string, mixed>>,
     *     overdue_unpaid: list<array<string, mixed>>,
     *     unmatched: list<array<string, mixed>>,
     *     summary: array<string, int|string>
     * }
     */
    public function reconcileCsvFile(
        string $filePath,
        ?CourierSlug $courier = null,
        array $columnMapping = [],
        ?int $overdueDays = null,
    ): array {
        LicenseManager::assertLicensed();

        if (!is_file($filePath) || !is_readable($filePath)) {
            throw new InvalidArgumentException(sprintf(
                __('CSV statement file "%s" does not exist or is not readable.', 'gr-commerce-suite'),
                $filePath
            ));
        }
        if (filesize($filePath) > 10 * 1024 * 1024) {
            throw new InvalidArgumentException(__('CSV statements must be 10 MB or smaller.', 'gr-commerce-suite'));
        }

        $contents = file_get_contents($filePath);
        if ($contents === false) {
            throw new RuntimeException(sprintf(__('Failed to read CSV statement file "%s".', 'gr-commerce-suite'), $filePath));
        }

        return $this->reconcileCsvContent($contents, $courier, $columnMapping, $overdueDays);
    }

    /**
     * Reconcile a courier COD payout CSV statement content string against `{prefix}_grcs_vouchers`
     * and WooCommerce HPOS `$order->get_total()` (SPEC.md §7, §10).
     *
     * Categorizes results into:
     *  a) `exact_matches` (`cod_reconciled = 1`)
     *  b) `amount_mismatches` (`cod_collected != cod_amount` — with exact Euro difference)
     *  c) `overdue_unpaid` (delivered > X configurable days ago, `cod_amount > 0`, `cod_reconciled = 0`)
     * Cancelled and otherwise ineligible (unknown/failed/reserved) voucher settlements remain
     * actionable in `unmatched`, outside collection totals.
     *
     * @param array<string, string> $columnMapping
     * @return array{
     *     exact_matches: list<array<string, mixed>>,
     *     amount_mismatches: list<array<string, mixed>>,
     *     overdue_unpaid: list<array<string, mixed>>,
     *     unmatched: list<array<string, mixed>>,
     *     summary: array<string, int|string>
     * }
     */
    public function reconcileCsvContent(
        string $csvContent,
        ?CourierSlug $courier = null,
        array $columnMapping = [],
        ?int $overdueDays = null,
    ): array {
        LicenseManager::assertLicensed();
        if (strlen($csvContent) > 10 * 1024 * 1024) {
            throw new InvalidArgumentException(__('CSV statements must be 10 MB or smaller.', 'gr-commerce-suite'));
        }

        $effectiveMapping = $this->resolveEffectiveMapping($courier, $columnMapping);
        if ($courier !== null && $columnMapping !== []) {
            $this->saveColumnMapping($courier, $effectiveMapping);
        }

        $resolvedOverdueDays = $overdueDays !== null ? max(1, $overdueDays) : $this->getOverdueDaysThreshold();
        if ($overdueDays !== null) {
            $this->setOverdueDaysThreshold($resolvedOverdueDays);
        }

        $parsedRows = $this->parseCsvStatement($csvContent, $courier, $effectiveMapping);

        $exactMatches = [];
        $amountMismatches = [];
        $unmatched = [];

        $totalExpectedCents = 0;
        $totalCollectedCents = 0;
        $totalReconciledCents = 0;
        $totalDiscrepancyCents = 0;

        // Validate all rows for a voucher before changing it. A contradictory file must
        // not apply whichever payout happens to appear first or last.
        $identities = [];
        $conflicts = [];
        foreach ($parsedRows as $csvRow) {
            $key = $csvRow['voucher_no'];
            $identity = [$csvRow['collected_cents'], $csvRow['settlement_ref'], $csvRow['payout_date']];
            if (isset($identities[$key]) && $identities[$key] !== $identity) {
                $conflicts[$key] = true;
            }
            $identities[$key] = $identity;
        }
        $seen = [];
        foreach ($parsedRows as $csvRow) {
            $voucherNo = $csvRow['voucher_no'];
            $collectedCents = $csvRow['collected_cents'];
            $settlementRef = $csvRow['settlement_ref'];
            $payoutDateUtc = $csvRow['payout_date'];

            if (!isset($conflicts[$voucherNo]) && isset($seen[$voucherNo])) {
                continue;
            }
            $seen[$voucherNo] = true;

            $voucherRow = $this->repository->findByVoucherNoAnyCourier($voucherNo, $courier);
            if (($voucherRow['state'] ?? null) === VoucherState::Cancelled->value) {
                $unmatched[] = $this->cancelledSettlementDiscrepancy($csvRow, $voucherRow, isset($conflicts[$voucherNo]));
                continue;
            }
            if (isset($conflicts[$voucherNo])) {
                $unmatched[] = array_diff_key($csvRow, ['raw_row' => true])
                    + ['reason' => 'Conflicting settlement records for the same voucher.'];
                continue;
            }
            if ($voucherRow === null) {
                $unmatched[] = [
                    'voucher_no' => $voucherNo,
                    'collected_cents' => $collectedCents,
                    'collected_eur' => Money::fromCents($collectedCents)->toDecimalString(),
                    'settlement_ref' => $settlementRef,
                    'payout_date' => $payoutDateUtc,
                ];
                continue;
            }
            // Only an issued voucher may receive a settlement. Unknown, failed and reserved
            // vouchers stay actionable in `unmatched` instead of aborting the remaining rows.
            if (($voucherRow['state'] ?? null) !== VoucherState::Created->value) {
                $unmatched[] = $this->ineligibleVoucherDiscrepancy($csvRow, $voucherRow);
                continue;
            }

            $voucherId = (int) ($voucherRow['id'] ?? 0);
            $orderId = (int) ($voucherRow['order_id'] ?? 0);
            $voucherCourierSlug = (string) ($voucherRow['courier_slug'] ??
                 ($courier !== null ? $courier->value : 'acs'));
            $dbCodCents = Money::fromDecimalString((string) ($voucherRow['cod_amount'] ?? '0.00'))->cents();

            $order = $this->resolveOrder($orderId);
            $orderTotalCents = $order instanceof WC_Order
                ? Money::fromDecimalString((string) $order->get_total())->cents()
                : $dbCodCents;

            // The issued voucher amount, including zero, stays fixed after order edits.
            $expectedCents = $dbCodCents;
            $isExact = $collectedCents === $expectedCents;
            $alreadyReconciled = (int) ($voucherRow['cod_reconciled'] ?? 0) === 1;
            if ($alreadyReconciled && (
                !$isExact || !$this->sameSettlement($voucherRow, $collectedCents, true, $settlementRef)
                || ($payoutDateUtc !== null && $payoutDateUtc !== ($voucherRow['cod_reconciled_at'] ?? null))
            )) {
                // Link the existing voucher's order so the merchant can compare both settlements.
                $unmatched[] = array_diff_key($csvRow, ['raw_row' => true])
                    + ['reason' => 'Record conflicts with an existing reconciled settlement.', 'order_id' => (int) ($voucherRow['order_id'] ?? 0)];
                continue;
            }
            // A corrected partial for a voucher that already has a different recorded partial is a
            // discrepancy, not a write: the stored evidence stays, totals are unchanged and later
            // rows continue. Only a concurrent write after this read reaches applyCsvSettlement()'s throw.
            $storedCollected = $voucherRow['cod_collected'] ?? null;
            if (!$isExact && $storedCollected !== null && $storedCollected !== ''
                && Money::fromDecimalString((string) $storedCollected)->cents() !== $collectedCents
            ) {
                $unmatched[] = $this->partialCorrectionDiscrepancy($csvRow, $voucherRow, $order);
                continue;
            }
            $settledAtUtc = $alreadyReconciled
                ? (string) $voucherRow['cod_reconciled_at']
                : ($payoutDateUtc ?? gmdate('Y-m-d H:i:s'));

            $identity = self::settlementNotificationIdentity($voucherNo, $collectedCents, $settlementRef);
            // A pending marker written before the UPDATE makes a crash between the UPDATE and
            // the note/event recoverable; a legacy row has no marker and is backfilled silently.
            $willChange = !$this->sameSettlement($voucherRow, $collectedCents, $isExact, $settlementRef);
            $previousMarker = $willChange ? $this->settlementNotificationMarker($voucherId) : '';
            if ($willChange) {
                $this->markSettlementPending($voucherId, $identity);
            }

            // Each voucher update is atomic; the statement is not a transaction. On
            // failure, earlier settlements remain saved and an identical retry is a no-op.
            $changed = $this->applyCsvSettlement(
                $voucherRow, $collectedCents, $isExact, $settlementRef, $isExact ? $settledAtUtc : null
            );
            if ($changed !== true && $willChange
                && $this->settlementNotificationMarker($voucherId) === self::NOTIFICATION_PENDING_PREFIX . $identity
                && ($changed === null || $previousMarker !== '')
            ) {
                // The row was not changed by this import, so its earlier marker stays authoritative.
                $this->restoreSettlementNotificationMarker($voucherId, $previousMarker);
            }
            if ($changed === null) {
                // The conditional UPDATE lost the row to a state change after our lookup.
                $unmatched[] = ($voucherRow['state'] ?? null) === VoucherState::Cancelled->value
                    ? $this->cancelledSettlementDiscrepancy($csvRow, $voucherRow)
                    : $this->ineligibleVoucherDiscrepancy($csvRow, $voucherRow);
                continue;
            }
            $totalExpectedCents += $expectedCents;
            $totalCollectedCents += $collectedCents;

            if ($isExact) {
                // Category (a): Exact Match -> cod_reconciled = 1
                if ($this->shouldEmitSettlementNotification($voucherId, $identity, $changed)) {
                    if ($order instanceof WC_Order) {
                        $order->update_meta_data('_grcs_cod_reconciled_at', $settledAtUtc);
                        $order->add_order_note(
                            sprintf(
                                AdminLocale::__('GR Commerce Suite: COD reconciled (€%s) for voucher %s%s.', 'gr-commerce-suite'),
                                Money::fromCents($collectedCents)->toDecimalString(),
                                $voucherNo,
                                $settlementRef !== null && $settlementRef !== '' ? ' [Ref: ' . $settlementRef . ']' : ''
                            )
                        );
                        $order->save();
                    }

                    $domainResult = new CodReconciliationResult(
                        voucherNo: $voucherNo,
                        status: CodSettlementStatus::Settled,
                        collectedAmountCents: $collectedCents,
                        settlementRef: $settlementRef,
                        settledAt: $this->parseUtcDateTime($settledAtUtc),
                        rawResponse: $csvRow['raw_row'],
                    );

                    if (function_exists('do_action')) {
                        do_action('grcs/cod/reconciled', $voucherId, $domainResult);
                    }
                    $this->markSettlementNotified($voucherId, $identity);
                }

                $totalReconciledCents += $collectedCents;

                $exactMatches[] = [
                    'voucher_id' => $voucherId,
                    'order_id' => $orderId,
                    'voucher_no' => $voucherNo,
                    'courier_slug' => $voucherCourierSlug,
                    'expected_cents' => $expectedCents,
                    'expected_eur' => Money::fromCents($expectedCents)->toDecimalString(),
                    'order_total_eur' => Money::fromCents($orderTotalCents)->toDecimalString(),
                    'collected_cents' => $collectedCents,
                    'collected_eur' => Money::fromCents($collectedCents)->toDecimalString(),
                    'difference_cents' => 0,
                    'difference_eur' => '0.00',
                    'settlement_ref' => $settlementRef,
                    'payout_date' => $settledAtUtc,
                    'cod_reconciled' => 1,
                ];
            } else {
                // Category (b): Amount Mismatch (cod_collected != cod_amount) -> flags exact Euro difference
                $benchmarkCents = $expectedCents;
                $diffCents = $collectedCents - $benchmarkCents;
                $diffEur = Money::fromCents($diffCents)->toDecimalString();
                $absDiffEur = Money::fromCents(abs($diffCents))->toDecimalString();
                $totalDiscrepancyCents += abs($diffCents);

                if ($this->shouldEmitSettlementNotification($voucherId, $identity, $changed)) {
                    if ($order instanceof WC_Order) {
                        $order->add_order_note(
                            sprintf(
                                AdminLocale::__('GR Commerce Suite: COD Amount Mismatch for voucher %s. Expected €%s, courier reported €%s (Difference: €%s).', 'gr-commerce-suite'),
                                $voucherNo,
                                Money::fromCents($benchmarkCents)->toDecimalString(),
                                Money::fromCents($collectedCents)->toDecimalString(),
                                $diffEur
                            )
                        );
                        $order->save();
                    }

                    if (function_exists('do_action')) {
                        do_action('grcs/cod/mismatch', $voucherId, $benchmarkCents, $collectedCents);
                    }
                    $this->markSettlementNotified($voucherId, $identity);
                }

                if ($changed) {
                    $this->logger->warning(
                        sprintf(
                            'COD mismatch on voucher %s (order #%d): expected %s EUR, collected %s EUR (diff %s EUR).',
                            $voucherNo,
                            $orderId,
                            Money::fromCents($benchmarkCents)->toDecimalString(),
                            Money::fromCents($collectedCents)->toDecimalString(),
                            $diffEur
                        )
                    );
                }

                $amountMismatches[] = [
                    'voucher_id' => $voucherId,
                    'order_id' => $orderId,
                    'voucher_no' => $voucherNo,
                    'courier_slug' => $voucherCourierSlug,
                    'expected_cents' => $benchmarkCents,
                    'expected_eur' => Money::fromCents($benchmarkCents)->toDecimalString(),
                    'order_total_eur' => Money::fromCents($orderTotalCents)->toDecimalString(),
                    'collected_cents' => $collectedCents,
                    'collected_eur' => Money::fromCents($collectedCents)->toDecimalString(),
                    'difference_cents' => $diffCents,
                    'difference_eur' => $diffEur,
                    'abs_difference_eur' => $absDiffEur,
                    'settlement_ref' => $settlementRef,
                    'payout_date' => $settledAtUtc,
                    'cod_reconciled' => 0,
                ];
            }
        }

        // Category (c): Overdue Unpaid COD (delivered > X configurable days ago, cod_amount > 0, cod_reconciled = 0)
        $overdueUnpaid = $this->getOverdueUnpaidCodVouchers($resolvedOverdueDays, $courier);

        $report = [
            'exact_matches' => $exactMatches,
            'amount_mismatches' => $amountMismatches,
            'overdue_unpaid' => $overdueUnpaid,
            'unmatched' => $unmatched,
            'summary' => [
                'total_rows' => count($parsedRows),
                'exact_match_count' => count($exactMatches),
                'mismatch_count' => count($amountMismatches),
                'overdue_count' => count($overdueUnpaid),
                'unmatched_count' => count($unmatched),
                'total_expected_cents' => $totalExpectedCents,
                'total_expected_eur' => Money::fromCents($totalExpectedCents)->toDecimalString(),
                'total_collected_cents' => $totalCollectedCents,
                'total_collected_eur' => Money::fromCents($totalCollectedCents)->toDecimalString(),
                'total_reconciled_cents' => $totalReconciledCents,
                'total_reconciled_eur' => Money::fromCents($totalReconciledCents)->toDecimalString(),
                'total_discrepancy_cents' => $totalDiscrepancyCents,
                'total_discrepancy_eur' => Money::fromCents($totalDiscrepancyCents)->toDecimalString(),
            ],
        ];

        if (function_exists('update_option')) {
            update_option(self::OPTION_LAST_CSV_REPORT, $report, false);
        }

        $this->logger->info('COD CSV reconciliation completed.', $report['summary']);
        return $report;
    }

    /**
     * Retain the statement evidence without mutating or counting a cancelled voucher.
     * The existing unmatched table displays the reason, amount, reference and date.
     *
     * @param array<string, mixed> $csvRow
     * @param array<string, mixed> $voucherRow
     * @return array<string, mixed>
     */
    private function cancelledSettlementDiscrepancy(array $csvRow, array $voucherRow, bool $conflicting = false): array
    {
        return array_diff_key($csvRow, ['raw_row' => true]) + [
            'voucher_id' => (int) $voucherRow['id'],
            'order_id' => (int) $voucherRow['order_id'],
            'courier_slug' => (string) $voucherRow['courier_slug'],
            'state' => VoucherState::Cancelled->value,
            'cod_amount' => $voucherRow['cod_amount'],
            'cod_collected' => $voucherRow['cod_collected'] ?? null,
            'cod_reconciled' => (int) ($voucherRow['cod_reconciled'] ?? 0),
            'cod_reconciled_at' => $voucherRow['cod_reconciled_at'] ?? null,
            'cod_settlement_ref' => $voucherRow['cod_settlement_ref'] ?? null,
            'voucher_updated_at' => $voucherRow['updated_at'] ?? null,
            'reason' => $conflicting
                ? __('Conflicting courier settlements for a cancelled voucher. Review the statement and cancellation with the courier before recording payment.', 'gr-commerce-suite')
                : __('Courier reported COD for a cancelled voucher. Review the settlement and cancellation with the courier before recording payment.', 'gr-commerce-suite'),
        ];
    }

    /**
     * Retain a settlement reported for a voucher that cannot be reconciled without mutating it.
     * The unmatched table displays the state, amount, reference and date for manual review.
     *
     * @param array<string, mixed> $csvRow
     * @param array<string, mixed> $voucherRow
     * @return array<string, mixed>
     */
    private function ineligibleVoucherDiscrepancy(array $csvRow, array $voucherRow): array
    {
        $state = (string) ($voucherRow['state'] ?? '');

        return array_diff_key($csvRow, ['raw_row' => true]) + [
            'voucher_id' => (int) $voucherRow['id'],
            'order_id' => (int) $voucherRow['order_id'],
            'courier_slug' => (string) $voucherRow['courier_slug'],
            'state' => $state,
            'cod_amount' => $voucherRow['cod_amount'],
            'cod_collected' => $voucherRow['cod_collected'] ?? null,
            'cod_reconciled' => (int) ($voucherRow['cod_reconciled'] ?? 0),
            'cod_reconciled_at' => $voucherRow['cod_reconciled_at'] ?? null,
            'cod_settlement_ref' => $voucherRow['cod_settlement_ref'] ?? null,
            'voucher_updated_at' => $voucherRow['updated_at'] ?? null,
            'reason' => sprintf(
                __('Courier reported COD for a voucher in state "%s". Review the settlement and voucher state with the courier before recording payment.', 'gr-commerce-suite'),
                $state
            ),
        ];
    }

    /**
     * Report a courier correction of an earlier partial settlement without changing the voucher.
     * The note and event are emitted per (voucher, stored, statement, ref); a sequential re-import is
     * silent. Delivery is at-least-once: see claimConflictNotification().
     *
     * @param array<string, mixed> $csvRow
     * @param array<string, mixed> $voucherRow
     * @return array<string, mixed>
     */
    private function partialCorrectionDiscrepancy(array $csvRow, array $voucherRow, ?WC_Order $order): array
    {
        $voucherId = (int) $voucherRow['id'];
        $voucherNo = (string) $csvRow['voucher_no'];
        $storedCents = Money::fromDecimalString((string) $voucherRow['cod_collected'])->cents();
        $collectedCents = (int) $csvRow['collected_cents'];
        $settlementRef = $csvRow['settlement_ref'];
        $storedEur = Money::fromCents($storedCents)->toDecimalString();
        $collectedEur = Money::fromCents($collectedCents)->toDecimalString();

        $identity = self::conflictNotificationIdentity($voucherNo, $storedCents, $collectedCents, $settlementRef);
        $key = self::conflictNotificationOption($voucherId, $identity);
        if ($this->claimConflictNotification($key, $identity)) {
            if ($order instanceof WC_Order) {
                $order->add_order_note(
                    sprintf(
                        AdminLocale::__('GR Commerce Suite: COD statement for voucher %1$s reports €%2$s, but an earlier partial settlement of €%3$s is recorded%4$s. Not applied; review with the courier and resolve manually.', 'gr-commerce-suite'),
                        $voucherNo,
                        $collectedEur,
                        $storedEur,
                        $settlementRef !== null && $settlementRef !== '' ? ' [Ref: ' . $settlementRef . ']' : ''
                    )
                );
                $order->save();
            }
            if (function_exists('do_action')) {
                do_action('grcs/cod/settlement_conflict', $voucherId, $storedCents, $collectedCents, $settlementRef);
            }
            if (function_exists('update_option')) {
                update_option($key, $identity, false);
            }
            $this->logger->warning(sprintf(
                'COD partial correction on voucher %s (order #%d): stored %s EUR, statement %s EUR; not applied.',
                $voucherNo,
                (int) ($voucherRow['order_id'] ?? 0),
                $storedEur,
                $collectedEur
            ));
        }

        return array_diff_key($csvRow, ['raw_row' => true]) + [
            'voucher_id' => $voucherId,
            'order_id' => (int) ($voucherRow['order_id'] ?? 0),
            'courier_slug' => (string) ($voucherRow['courier_slug'] ?? ''),
            'state' => (string) ($voucherRow['state'] ?? ''),
            'cod_amount' => $voucherRow['cod_amount'] ?? null,
            'cod_collected' => $voucherRow['cod_collected'],
            'stored_collected_cents' => $storedCents,
            'stored_collected_eur' => $storedEur,
            'cod_settlement_ref' => $voucherRow['cod_settlement_ref'] ?? null,
            'reason' => sprintf(
                AdminLocale::__('Conflicts with an earlier partial settlement: stored €%1$s, statement €%2$s. Review with the courier and resolve manually.', 'gr-commerce-suite'),
                $storedEur,
                $collectedEur
            ),
        ];
    }

    /** Identity of a partial-correction discrepancy; the completed marker stores it. */
    public static function conflictNotificationIdentity(
        string $voucherNo,
        int $storedCents,
        int $collectedCents,
        ?string $settlementRef,
    ): string {
        return self::settlementNotificationIdentity($voucherNo, $collectedCents, $settlementRef) . '|' . $storedCents;
    }

    /** Option holding the marker for one discrepancy; removed by uninstall's OPTION_NOTIFIED_PREFIX sweep. */
    public static function conflictNotificationOption(int $voucherId, string $identity): string
    {
        return self::OPTION_NOTIFIED_PREFIX . 'conflict_' . md5($voucherId . '|' . $identity);
    }

    /**
     * First stage of the two-stage marker: claim a pending marker, or recover one left by a crash
     * between claim and completion. A completed marker (the plain identity) keeps a re-import silent.
     *
     * At-least-once, not exactly-once: add_option() is not an atomic claim (it checks, then upserts),
     * and a pending marker cannot tell a crashed import from one still in flight. Two imports of the
     * same file at the same moment, or a crash after emission but before completion, can repeat the
     * note/event. No financial state depends on it: the voucher row is never written here.
     */
    private function claimConflictNotification(string $key, string $identity): bool
    {
        if (!function_exists('add_option') || !function_exists('get_option')) {
            return false;
        }
        $pending = self::NOTIFICATION_PENDING_PREFIX . $identity;
        if (add_option($key, $pending, '', false)) {
            return true;
        }
        return (string) get_option($key, '') === $pending;
    }

    /** @param array<string, mixed> $row */
    private function sameSettlement(array $row, int $collectedCents, bool $reconciled, ?string $reference): bool
    {
        return ($row['state'] ?? null) === VoucherState::Created->value
            && isset($row['cod_collected'])
            && Money::fromDecimalString((string) $row['cod_collected'])->cents() === $collectedCents
            && (int) ($row['cod_reconciled'] ?? 0) === (int) $reconciled
            && (string) ($row['cod_settlement_ref'] ?? '') === (string) $reference;
    }

    /**
     * Settlement identity stored after the note and event succeed, so an identical retry stays silent.
     */
    public static function settlementNotificationIdentity(
        string $voucherNo,
        int $collectedCents,
        ?string $settlementRef,
    ): string {
        return $voucherNo . '|' . $collectedCents . '|' . (string) $settlementRef;
    }

    /**
     * Emit the note/event only when this import owns the settlement transition or is recovering
     * a crash between the UPDATE and the emission. A voucher reconciled before markers existed
     * has no marker and is backfilled silently.
     */
    private function shouldEmitSettlementNotification(int $voucherId, string $identity, bool $changed): bool
    {
        if ($changed) {
            return true;
        }

        $marker = $this->settlementNotificationMarker($voucherId);
        if ($marker === '') {
            $this->markSettlementNotified($voucherId, $identity);
            return false;
        }

        return $marker === self::NOTIFICATION_PENDING_PREFIX . $identity;
    }

    private function settlementNotificationMarker(int $voucherId): string
    {
        return function_exists('get_option')
            ? (string) get_option(self::OPTION_NOTIFIED_PREFIX . $voucherId, '')
            : '';
    }

    private function markSettlementNotified(int $voucherId, string $identity): void
    {
        if (function_exists('update_option')) {
            update_option(self::OPTION_NOTIFIED_PREFIX . $voucherId, $identity, false);
        }
    }

    private function markSettlementPending(int $voucherId, string $identity): void
    {
        if (function_exists('update_option')) {
            update_option(
                self::OPTION_NOTIFIED_PREFIX . $voucherId,
                self::NOTIFICATION_PENDING_PREFIX . $identity,
                false
            );
        }
    }

    private function restoreSettlementNotificationMarker(int $voucherId, string $marker): void
    {
        if ($marker !== '') {
            if (function_exists('update_option')) {
                update_option(self::OPTION_NOTIFIED_PREFIX . $voucherId, $marker, false);
            }
            return;
        }
        if (function_exists('delete_option')) {
            delete_option(self::OPTION_NOTIFIED_PREFIX . $voucherId);
        }
    }

    /**
     * Persist before emitting notes or hooks; a concurrent identical import is a no-op.
     *
     * @param array<string, mixed> $row
     * @return bool|null True for a write, false for an identical settlement, null for a state that is no longer eligible.
     */
    private function applyCsvSettlement(array &$row, int $amount, bool $reconciled, ?string $reference, ?string $date): ?bool
    {
        if ($this->sameSettlement($row, $amount, $reconciled, $reference)) {
            return false;
        }
        $id = (int) $row['id'];
        if ($this->repository->updateCodReconciliation($id, $amount, $reconciled, $reference, $date)) {
            return true;
        }
        $current = $this->repository->findById($id);
        if (($current['state'] ?? null) === VoucherState::Cancelled->value) {
            $row = $current;
            return null;
        }
        if ($current !== null && ($current['state'] ?? null) !== VoucherState::Created->value) {
            $row = $current;
            return null;
        }
        if ($current !== null && $this->sameSettlement($current, $amount, $reconciled, $reference)
            && (!$reconciled || ($current['cod_reconciled_at'] ?? null) === $date)) {
            return false;
        }
        throw new RuntimeException(__('COD settlement could not be saved or conflicts with a concurrent update. Earlier entries may already be saved. Please review and retry the import.', 'gr-commerce-suite'));
    }

    /**
     * Parse a courier COD payout CSV statement into normalized rows using customizable column mappings.
     *
     * @param array<string, string> $customMapping
     * @return list<array{
     *     voucher_no: string,
     *     collected_cents: int,
     *     collected_eur: string,
     *     settlement_ref: ?string,
     *     payout_date: ?string,
     *     raw_row: array<string, string>
     * }>
     */
    public function parseCsvStatement(
        string $csvContent,
        ?CourierSlug $courier = null,
        array $customMapping = [],
    ): array {
        LicenseManager::assertLicensed();
        $csvContent = preg_replace('/^\xEF\xBB\xBF/', '', $csvContent) ?? $csvContent;
        $encoding = 'UTF-8';
        if (!mb_check_encoding($csvContent, 'UTF-8')) {
            $encoding = preg_match('/[\x80-\x9F\xA1\xA2]/', $csvContent) === 1 ? 'Windows-1253' : 'ISO-8859-7';
            $csvContent = $this->convertLegacyGreek($csvContent);
        }
        // Strip UTF-8 BOM if present
        $cleaned = preg_replace('/^\xEF\xBB\xBF/', '', $csvContent) ?? $csvContent;
        // Tabs at file boundaries can represent empty TSV columns.
        $cleaned = trim($cleaned, " \r\n");
        if (trim($cleaned) === '') {
            return [];
        }

        $mapping = $this->resolveEffectiveMapping($courier, $customMapping);
        // Parse records from a stream so quoted line breaks remain inside their cells.
        $stream = fopen('php://temp', 'w+');
        if ($stream === false) {
            throw new RuntimeException(__('Unable to open CSV stream.', 'gr-commerce-suite'));
        }
        try {
            fwrite($stream, $cleaned);
            [$delimiter, $headerIndex] = $this->discoverCsvHeader($stream, $mapping, $encoding);
            rewind($stream);
            $records = [];
            while (($record = fgetcsv($stream, 0, $delimiter, '"', '')) !== false) {
                if (array_filter($record, static fn(?string $cell): bool => trim((string) $cell) !== '') !== []) {
                    $records[] = $record;
                }
            }
        } finally {
            fclose($stream);
        }
        if ($records === []) {
            return [];
        }
        $headerCells = array_map(
            static fn(?string $cell): string => trim((string) $cell),
            $records[$headerIndex ?? 0]
        );

        $columnIndices = $this->resolveColumnIndices($headerCells, $mapping);

        // If first row does not look like a header (e.g. first col is a numeric voucher and second is an amount),
        // treat row 0 as data using positional indices 0, 1, 2, 3
        $startRowIndex = ($headerIndex ?? -1) + 1;
        if ($headerIndex === null) {
            $startRowIndex = 0;
            $columnIndices = [
                'voucher_no' => 0,
                'collected_amount' => 1,
                'settlement_ref' => 2,
                'payout_date' => 3,
            ];
        }

        $parsed = [];
        $lineCount = count($records);

        for ($i = $startRowIndex; $i < $lineCount; $i++) {
            $cells = $records[$i];
            if (count($cells) === 1 && trim((string) $cells[0]) === '') {
                continue;
            }

            $rawAssoc = [];
            foreach ($cells as $idx => $val) {
                $colName = $headerCells[$idx] ?? ('col_' . $idx);
                $rawAssoc[$colName] = trim((string) $val);
            }

            $voucherRaw = $this->extractCellByIndex($cells, $columnIndices['voucher_no']);
            if ($voucherRaw === '' || preg_match('/^(TOTAL|SUBTOTAL|ΣΥΝΟΛΟ|ΣΥΝΟΛΑ)(?:\b|\s|:|$)/u', GreekDataNormalizer::stripGreekAccentsUpper($voucherRaw))) {
                continue;
            }
            $voucherNo = $this->normalizeVoucher($voucherRaw);
            if ($voucherNo === '') {
                continue;
            }

            $collectedRaw = $this->extractCellByIndex($cells, $columnIndices['collected_amount']);
            try {
                $collectedCents = $this->parseMonetaryStringToCents($collectedRaw);
            } catch (\InvalidArgumentException) {
                $this->logger->warning('COD CSV row skipped: invalid collected amount.', ['voucher_no' => $voucherNo]);
                continue;
            }

            $settlementRefRaw = $this->extractCellByIndex($cells, $columnIndices['settlement_ref']);
            $settlementRef = $settlementRefRaw !== '' ? $settlementRefRaw : null;

            $payoutDateRaw = $this->extractCellByIndex($cells, $columnIndices['payout_date']);
            $payoutDateUtc = $payoutDateRaw !== '' ? $this->normalizePayoutDateToUtc($payoutDateRaw) : null;

            $parsed[] = [
                'voucher_no' => $voucherNo,
                'collected_cents' => $collectedCents,
                'collected_eur' => Money::fromCents($collectedCents)->toDecimalString(),
                'settlement_ref' => $settlementRef,
                'payout_date' => $payoutDateUtc,
                'raw_row' => $rawAssoc,
            ];
        }

        return $parsed;
    }

    /**
     * Find Overdue Unpaid COD vouchers: `tracking_status = 'delivered'` more than `$overdueDays` ago,
     * `cod_amount > 0`, and `cod_reconciled = 0` (SPEC.md §7, §10).
     *
     * @return list<array<string, mixed>>
     */
    public function getOverdueUnpaidCodVouchers(
        ?int $overdueDays = null,
        ?CourierSlug $courier = null,
    ): array {
        $days = $overdueDays !== null ? max(1, $overdueDays) : $this->getOverdueDaysThreshold();
        $rows = $this->repository->findOverdueUnpaidCodVouchers($days, $courier);
        $nowTs = time();

        $overdueList = [];

        foreach ($rows as $row) {
            $voucherId = (int) ($row['id'] ?? 0);
            $orderId = (int) ($row['order_id'] ?? 0);
            $voucherNo = (string) ($row['voucher_no'] ?? '');
            $courierSlug = (string) ($row['courier_slug'] ?? '');
            $expectedCents = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents();

            $deliveredRefTime = (string) ($row['last_tracked_at'] ?? $row['updated_at'] ?? $row['created_at'] ?? '');
            $deliveredDt = $this->parseUtcDateTime($deliveredRefTime);
            $daysElapsed = $deliveredDt !== null
                ? max($days, (int) floor(($nowTs - $deliveredDt->getTimestamp()) / 86400))
                : $days;

            $overdueList[] = [
                'voucher_id' => $voucherId,
                'order_id' => $orderId,
                'voucher_no' => $voucherNo,
                'courier_slug' => $courierSlug,
                'tracking_status' => (string) ($row['tracking_status'] ?? 'delivered'),
                'expected_cents' => $expectedCents,
                'expected_eur' => Money::fromCents($expectedCents)->toDecimalString(),
                'delivered_at' => $deliveredRefTime,
                'days_overdue' => $daysElapsed,
                'cod_reconciled' => 0,
            ];
        }

        return $overdueList;
    }

    /**
     * Retrieve all flagged COD Amount Mismatches (`cod_collected != cod_amount` and `cod_reconciled = 0`).
     *
     * @return list<array<string, mixed>>
     */
    public function getFlaggedAmountMismatches(?CourierSlug $courier = null): array
    {
        $rows = $this->repository->findCodMismatches($courier);
        $mismatches = [];

        foreach ($rows as $row) {
            $expectedCents = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents();
            $collectedCents = Money::fromDecimalString((string) ($row['cod_collected'] ?? '0.00'))->cents();
            $diffCents = $collectedCents - $expectedCents;

            $mismatches[] = [
                'voucher_id' => (int) ($row['id'] ?? 0),
                'order_id' => (int) ($row['order_id'] ?? 0),
                'voucher_no' => (string) ($row['voucher_no'] ?? ''),
                'courier_slug' => (string) ($row['courier_slug'] ?? ''),
                'expected_cents' => $expectedCents,
                'expected_eur' => Money::fromCents($expectedCents)->toDecimalString(),
                'collected_cents' => $collectedCents,
                'collected_eur' => Money::fromCents($collectedCents)->toDecimalString(),
                'difference_cents' => $diffCents,
                'difference_eur' => Money::fromCents($diffCents)->toDecimalString(),
                'abs_difference_eur' => Money::fromCents(abs($diffCents))->toDecimalString(),
                'settlement_ref' => $row['cod_settlement_ref'] ?? null,
                'updated_at' => (string) ($row['updated_at'] ?? ''),
            ];
        }

        return $mismatches;
    }

    /**
     * Build the comprehensive COD Reconciliation Summary for the Admin Page (`woocommerce_page_grcs-cod-reconciliation`).
     *
     * @return array{
     *     total_expected_cents: int,
     *     total_expected_eur: string,
     *     total_reconciled_cents: int,
     *     total_reconciled_eur: string,
     *     unknown_reconciled_expected_cents: int,
     *     unknown_reconciled_count: int,
     *     total_pending_cents: int,
     *     total_pending_eur: string,
     *     total_discrepancy_cents: int,
     *     total_discrepancy_eur: string,
     *     accepted_difference_cents: int,
     *     accepted_difference_count: int,
     *     total_cod_vouchers: int,
     *     reconciled_count: int,
     *     pending_count: int,
     *     mismatch_count: int,
     *     overdue_count: int,
     *     mismatches: list<array<string, mixed>>,
     *     overdue_unpaid: list<array<string, mixed>>,
     *     vouchers: list<array<string, mixed>>
     * }
     */
    public function getDashboardSummary(?CourierSlug $courier = null, ?int $overdueDays = null): array
    {
        $resolvedOverdueDays = $overdueDays !== null ? max(1, $overdueDays) : $this->getOverdueDaysThreshold();
        $codRows = $this->repository->findCodVouchers($courier, 500);

        $totalExpectedCents = 0;
        $totalReconciledCents = 0;
        $totalPendingCents = 0;
        $totalDiscrepancyCents = 0;
        $reconciledCount = 0;
        $pendingCount = 0;
        $unknownReconciledExpectedCents = 0;
        $unknownReconciledCount = 0;
        // Reconciled vouchers settled at a different amount than expected (approved mismatches).
        // Expected = recorded reconciled + pending + accepted difference + unknown reconciled expected.
        // Pending is expected on all unreconciled rows, including returns; it is not confirmed remittance owed.
        $acceptedDifferenceCents = 0;
        $acceptedDifferenceCount = 0;

        foreach ($codRows as $row) {
            $expectedCents = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents();
            $isReconciled = (int) ($row['cod_reconciled'] ?? 0) === 1;
            $hasCollected = isset($row['cod_collected']) && (string) $row['cod_collected'] !== '';
            $collectedCents = $hasCollected
                ? Money::fromDecimalString((string) $row['cod_collected'])->cents()
                : 0;

            $totalExpectedCents += $expectedCents;

            if ($isReconciled) {
                $reconciledCount++;
                if (!$hasCollected) {
                    $unknownReconciledCount++;
                    $unknownReconciledExpectedCents += $expectedCents;
                    continue;
                }
                $totalReconciledCents += $collectedCents;
                if ($collectedCents !== $expectedCents) {
                    $acceptedDifferenceCents += $expectedCents - $collectedCents;
                    $acceptedDifferenceCount++;
                }
            } else {
                $pendingCount++;
                $totalPendingCents += $expectedCents;
                if ($hasCollected && $collectedCents !== $expectedCents) {
                    $totalDiscrepancyCents += abs($collectedCents - $expectedCents);
                }
            }
        }

        $mismatches = $this->getFlaggedAmountMismatches($courier);
        $overdueUnpaid = $this->getOverdueUnpaidCodVouchers($resolvedOverdueDays, $courier);

        return [
            'total_expected_cents' => $totalExpectedCents,
            'total_expected_eur' => Money::fromCents($totalExpectedCents)->toDecimalString(),
            'total_reconciled_cents' => $totalReconciledCents,
            'total_reconciled_eur' => Money::fromCents($totalReconciledCents)->toDecimalString(),
            'unknown_reconciled_expected_cents' => $unknownReconciledExpectedCents,
            'unknown_reconciled_count' => $unknownReconciledCount,
            'total_pending_cents' => $totalPendingCents,
            'total_pending_eur' => Money::fromCents($totalPendingCents)->toDecimalString(),
            'total_discrepancy_cents' => $totalDiscrepancyCents,
            'total_discrepancy_eur' => Money::fromCents($totalDiscrepancyCents)->toDecimalString(),
            'accepted_difference_cents' => $acceptedDifferenceCents,
            'accepted_difference_count' => $acceptedDifferenceCount,
            'total_cod_vouchers' => count($codRows),
            'reconciled_count' => $reconciledCount,
            'pending_count' => $pendingCount,
            'mismatch_count' => count($mismatches),
            'overdue_count' => count($overdueUnpaid),
            'mismatches' => $mismatches,
            'overdue_unpaid' => $overdueUnpaid,
            'vouchers' => $codRows,
        ];
    }

    /**
     * Manually mark a COD voucher as reconciled (SPEC.md §10.3).
     */
    public function markManuallyReconciled(
        int $voucherId,
        ?string $settlementRef = null,
        ?int $collectedAmountCents = null,
    ): bool {
        LicenseManager::assertLicensed();

        $row = $this->repository->findById($voucherId);
        if ($row === null) {
            return false;
        }

        $expectedCents = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents();
        $finalCollectedCents = $collectedAmountCents ?? (
            isset($row['cod_collected']) && (string) $row['cod_collected'] !== ''
                ? Money::fromDecimalString((string) $row['cod_collected'])->cents()
                : $expectedCents
        );

        $nowUtc = gmdate('Y-m-d H:i:s');
        $effectiveRef = $settlementRef !== null && trim($settlementRef) !== ''
            ? trim($settlementRef)
            : (isset($row['cod_settlement_ref']) ? (string) $row['cod_settlement_ref'] : 'MANUAL');

        $updated = $this->repository->updateCodReconciliation(
            id: $voucherId,
            collectedAmountCents: $finalCollectedCents,
            reconciled: true,
            settlementRef: $effectiveRef,
            reconciledAtUtc: $nowUtc,
        );

        if (!$updated) {
            return false;
        }

        $orderId = (int) ($row['order_id'] ?? 0);
        $order = $this->resolveOrder($orderId);
        if ($order instanceof WC_Order) {
            $userId = function_exists('get_current_user_id') ? (int) get_current_user_id() : 0;
            $user = $userId > 0 && function_exists('get_userdata') ? get_userdata($userId) : false;
            $userName = is_object($user) && isset($user->display_name) ? (string) $user->display_name : '';
            $order->update_meta_data('_grcs_cod_reconciled_at', $nowUtc);
            $difference = $finalCollectedCents - $expectedCents;
            // An accepted shortfall or excess stays readable in the order's audit trail, with a name, not only a user ID.
            $order->add_order_note($difference !== 0
                ? sprintf(
                    AdminLocale::__('GR Commerce Suite: COD reconciled with an accepted difference: collected €%1$s of €%2$s expected (%3$s). Ref: %4$s. By %5$s (user #%6$d).', 'gr-commerce-suite'),
                    Money::fromCents($finalCollectedCents)->toDecimalString(),
                    Money::fromCents($expectedCents)->toDecimalString(),
                    ($difference < 0 ? '−' : '+') . '€' . Money::fromCents(abs($difference))->toDecimalString(),
                    $effectiveRef,
                    $userName !== '' ? $userName : '—',
                    $userId
                )
                : sprintf(
                    AdminLocale::__('GR Commerce Suite: COD manually marked reconciled (€%s, Ref: %s) by user #%d.', 'gr-commerce-suite'),
                    Money::fromCents($finalCollectedCents)->toDecimalString(),
                    $effectiveRef,
                    $userId
                ));
            $order->save();
        }

        return true;
    }

    /**
     * Reconcile a chunk of up to 100 voucher IDs via the courier's API batch endpoint (SPEC.md §10.1–10.2).
     *
     * @param non-empty-list<int> $voucherIds
     */
    public function reconcileChunk(CourierSlug $courier, array $voucherIds): void
    {
        // Scheduled work on existing vouchers runs unlicensed (owner decision 2026-11-03); only issuance is licence-gated.
        if ($this->courierRegistry === null || !$this->courierRegistry->has($courier)) {
            return;
        }

        $rowsByVoucherNo = [];
        $voucherNos = [];

        foreach ($voucherIds as $id) {
            $row = $this->repository->findById($id);
            if ($row === null) {
                continue;
            }

            $voucherNo = trim((string) ($row['voucher_no'] ?? ''));
            if ($voucherNo === '') {
                continue;
            }

            $rowsByVoucherNo[$voucherNo] = $row;
            $voucherNos[] = $voucherNo;
        }

        if ($voucherNos === []) {
            return;
        }

        $provider = $this->courierRegistry->get($courier);
        $batchResults = $provider->reconcileCodBatch($voucherNos);

        foreach ($rowsByVoucherNo as $voucherNo => $row) {
            if (!isset($batchResults[$voucherNo])) {
                continue;
            }

            $result = $batchResults[$voucherNo];
            $voucherId = (int) $row['id'];
            $orderId = (int) $row['order_id'];
            $expectedCents = Money::fromDecimalString((string) ($row['cod_amount'] ?? '0.00'))->cents();

            if ($result->status === CodSettlementStatus::Settled) {
                $collectedCents = $result->collectedAmountCents ?? 0;
                $settledAtUtc = $result->settledAt?->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s')
                    ?? gmdate('Y-m-d H:i:s');

                if ($collectedCents === $expectedCents) {
                    $updated = $this->repository->updateCodReconciliation(
                        id: $voucherId,
                        collectedAmountCents: $collectedCents,
                        reconciled: true,
                        settlementRef: $result->settlementRef,
                        reconciledAtUtc: $settledAtUtc,
                    );
                    if (!$updated) {
                        continue;
                    }

                    $order = $this->resolveOrder($orderId);
                    if ($order instanceof WC_Order) {
                        $order->update_meta_data('_grcs_cod_reconciled_at', $settledAtUtc);
                        $order->save();
                    }

                    if (function_exists('do_action')) {
                        do_action('grcs/cod/reconciled', $voucherId, $result);
                    }
                } else {
                    $updated = $this->repository->updateCodReconciliation(
                        id: $voucherId,
                        collectedAmountCents: $collectedCents,
                        reconciled: false,
                        settlementRef: $result->settlementRef,
                        reconciledAtUtc: null,
                    );
                    if (!$updated) {
                        continue;
                    }

                    if (function_exists('do_action')) {
                        do_action('grcs/cod/mismatch', $voucherId, $expectedCents, $collectedCents);
                    }
                }
            } elseif ($result->status === CodSettlementStatus::CollectedNotSettled) {
                // Skip observations with no financial facts to preserve existing repository evidence
                if ($result->collectedAmountCents === null && $result->settlementRef === null) {
                    continue;
                }
                $this->repository->updateCodReconciliation(
                    id: $voucherId,
                    collectedAmountCents: $result->collectedAmountCents,
                    reconciled: false,
                    settlementRef: $result->settlementRef,
                    reconciledAtUtc: null,
                );
            }
        }
    }

    private function resolveOrder(int $orderId): ?WC_Order
    {
        if ($orderId <= 0) {
            return null;
        }

        if ($this->orderResolver !== null) {
            return ($this->orderResolver)($orderId);
        }

        if (function_exists('wc_get_order')) {
            $order = wc_get_order($orderId);
            if ($order instanceof WC_Order) {
                return $order;
            }
        }

        return null;
    }

    /**
     * @param array<string, string> $customMapping
     * @return array{voucher_no: string, collected_amount: string, settlement_ref: string, payout_date: string}
     */
    private function resolveEffectiveMapping(?CourierSlug $courier, array $customMapping): array
    {
        $base = $courier !== null
            ? $this->getColumnMapping($courier)
            : self::DEFAULT_COURIER_MAPPINGS['acs'];

        return [
            'voucher_no' => isset($customMapping['voucher_no']) && trim($customMapping['voucher_no']) !== ''
                ? trim($customMapping['voucher_no'])
                : $base['voucher_no'],
            'collected_amount' => isset($customMapping['collected_amount']) &&
                 trim($customMapping['collected_amount']) !== ''
                ? trim($customMapping['collected_amount'])
                : $base['collected_amount'],
            'settlement_ref' => isset($customMapping['settlement_ref']) && trim($customMapping['settlement_ref']) !== ''
                ? trim($customMapping['settlement_ref'])
                : $base['settlement_ref'],
            'payout_date' => isset($customMapping['payout_date']) && trim($customMapping['payout_date']) !== ''
                ? trim($customMapping['payout_date'])
                : $base['payout_date'],
        ];
    }

    /**
     * @param resource $stream
     * @param array{voucher_no: string, collected_amount: string, settlement_ref: string, payout_date: string} $mapping
     * @return array{string, ?int}
     */
    private function discoverCsvHeader($stream, array $mapping, string $encoding): array
    {
        $bestDelimiter = ';';
        $bestHeaders = [];
        $bestScore = -1;
        $headerless = null;
        foreach ([';', ',', "\t", '|'] as $delimiter) {
            rewind($stream);
            $row = 0;
            while ($row < 15 && ($cells = fgetcsv($stream, 0, $delimiter, '"', '')) !== false) {
                $headers = array_map(static fn(?string $cell): string => trim((string) $cell), $cells);
                if (array_filter($headers, static fn(string $cell): bool => $cell !== '') === []) {
                    continue;
                }
                $indices = $this->resolveColumnIndices($headers, $mapping);
                if ($indices['voucher_no'] !== null && $indices['collected_amount'] !== null
                    && $indices['voucher_no'] !== $indices['collected_amount']
                    && $this->firstRowIsHeader($headers)) {
                    return [$delimiter, $row];
                }
                if ($row === 0 && !$this->firstRowIsHeader($headers)
                    && preg_match('/\d/', $this->normalizeVoucher($headers[0])) === 1) {
                    $headerless ??= $delimiter;
                }
                $score = count(array_filter($indices, static fn(?int $index): bool => $index !== null)) * 100
                    + min(count($headers), 80);
                if ($score > $bestScore) {
                    $bestScore = $score;
                    $bestDelimiter = $delimiter;
                    $bestHeaders = $headers;
                }
                $row++;
            }
        }
        if ($headerless !== null) {
            return [$headerless, null];
        }
        (new DiagnosticLogger())->record('ERROR', 'RECONCILIATION', 'COD CSV headers could not be matched.', [
            'action' => 'csv_header_detection',
            'encoding' => $encoding,
            'delimiter' => $bestDelimiter === "\t" ? 'tab' : $bestDelimiter,
            'headers' => array_map(static fn(string $header): string => mb_substr(
                preg_replace('/[\x00-\x1F\x7F]/u', '', strip_tags($header)) ?? '', 0, 120, 'UTF-8'
            ), array_slice($bestHeaders, 0, 80)),
        ]);
        throw new InvalidArgumentException(__('CSV headers could not be matched. Choose voucher and collected amount columns; see Diagnostics for detected columns.', 'gr-commerce-suite'));
    }

    private function normalizeVoucher(string $value): string
    {
        $value = trim($value);
        if (preg_match('/^="(.*)"$/sD', $value, $match) === 1) {
            $value = $match[1];
        }
        $value = ltrim($value, "'");
        // Remove Excel's text escape and display separators without losing leading zeroes.
        return preg_replace('/[^\p{L}\p{N}]/u', '', $value) ?? '';
    }

    private function normalizeHeader(string $header): string
    {
        return mb_strtolower(GreekDataNormalizer::stripGreekAccentsUpper(trim($header)), 'UTF-8');
    }

    private function convertLegacyGreek(string $content): string
    {
        // mbstring supports ISO-8859-7 but not Windows-1253. The Greek alphabets largely
        // overlap; C1 punctuation/euro or Windows tonos bytes identify the Windows variant.
        $windows = preg_match('/[\x80-\x9F\xA1\xA2]/', $content) === 1;
        $utf8 = mb_convert_encoding($content, 'UTF-8', 'ISO-8859-7');
        if (!$windows) {
            return $utf8;
        }
        return strtr($utf8, [
            "\u{0080}" => '€', "\u{0082}" => '‚', "\u{0083}" => 'ƒ', "\u{0084}" => '„',
            "\u{0085}" => '…', "\u{0086}" => '†', "\u{0087}" => '‡', "\u{0089}" => '‰',
            "\u{008B}" => '‹', "\u{0091}" => '‘', "\u{0092}" => '’', "\u{0093}" => '“',
            "\u{0094}" => '”', "\u{0095}" => '•', "\u{0096}" => '–', "\u{0097}" => '—',
            "\u{0099}" => '™', "\u{009B}" => '›', '‘' => '΅', '’' => 'Ά',
            '€' => '¤', '₯' => '¥', '΅' => 'µ', 'Ά' => '¶',
        ]);
    }

    /**
     * Map logical field names (`voucher_no`, `collected_amount`, `settlement_ref`, `payout_date`)
     * to zero-based CSV column indices.
     *
     * @param list<string> $headerCells
     * @param array{voucher_no: string, collected_amount: string, settlement_ref: string, payout_date: string} $mapping
     * @return array{voucher_no: ?int, collected_amount: ?int, settlement_ref: ?int, payout_date: ?int}
     */
    private function resolveColumnIndices(array $headerCells, array $mapping): array
    {
        $normalizedHeaders = [];
        foreach ($headerCells as $idx => $header) {
            $normalizedHeaders[$idx] = $this->normalizeHeader($header);
        }

        $indices = [
            'voucher_no' => null,
            'collected_amount' => null,
            'settlement_ref' => null,
            'payout_date' => null,
        ];

        foreach (array_keys($indices) as $field) {
            $configuredName = trim($mapping[$field]);

            // 1. Direct numeric column index if merchant specified e.g. "0", "1"
            if ($configuredName !== '' && ctype_digit($configuredName)) {
                $colIdx = (int) $configuredName;
                if (isset($headerCells[$colIdx])) {
                    $indices[$field] = $colIdx;
                    continue;
                }
            }

            // 2. Exact match on merchant's configured column name (case-insensitive)
            $lowerConfigured = $this->normalizeHeader($configuredName);
            foreach ($normalizedHeaders as $idx => $normHeader) {
                if ($normHeader !== '' && $normHeader === $lowerConfigured) {
                    $indices[$field] = $idx;
                    continue 2;
                }
            }

            // 3. Match against known Greek/English courier CSV header aliases
            $aliases = array_map($this->normalizeHeader(...), self::HEADER_ALIASES[$field] ?? []);
            foreach ($normalizedHeaders as $idx => $normHeader) {
                if (in_array($normHeader, $aliases, true)) {
                    $indices[$field] = $idx;
                    continue 2;
                }
            }
        }

        return $indices;
    }

    /**
     * @param list<string> $headerCells
     */
    private function firstRowIsHeader(array $headerCells): bool
    {
        if (count($headerCells) >= 2) {
            $secondCell = trim($headerCells[1]);
            $cleanedAmount = preg_replace('/(?:EUR|€|[\s.,+\-\x{00A0}\x{202F}])/iu', '', $secondCell) ?? '';
            if ($cleanedAmount !== '' && ctype_digit($cleanedAmount)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param list<string|null> $cells
     */
    private function extractCellByIndex(array $cells, ?int $index): string
    {
        if ($index === null || !isset($cells[$index])) {
            return '';
        }

        return trim((string) $cells[$index]);
    }

    /**
     * Parse a monetary CSV cell (e.g. "49,90", "1.250,50", "49.90 €") into integer cents
     * using string manipulation only (never float casts, per SPEC.md §3 C-6).
     */
    private function parseMonetaryStringToCents(string $raw): int
    {
        $cleaned = preg_replace('/(?:EUR|€|[\s\x{00A0}\x{202F}])/iu', '', trim($raw)) ?? '';
        if ($cleaned === '') {
            throw new InvalidArgumentException(__('CSV amount is empty.', 'gr-commerce-suite'));
        }
        if (preg_match('/^[+-]?[1-9]\d{0,2}(?:\.\d{3})+(?:,\d{1,2})?$/D', $cleaned)) {
            $cleaned = str_replace(['.', ','], ['', '.'], $cleaned);
        } elseif (preg_match('/^[+-]?[1-9]\d{0,2}(?:,\d{3})+(?:\.\d{1,2})?$/D', $cleaned)) {
            $cleaned = str_replace(',', '', $cleaned);
        } elseif (preg_match('/^[+-]?\d+(?:[.,]\d{1,2})?$/D', $cleaned)) {
            $cleaned = str_replace(',', '.', $cleaned);
        } else {
            throw new InvalidArgumentException(__('Invalid CSV currency amount.', 'gr-commerce-suite'));
        }
        $whole = ltrim(explode('.', ltrim($cleaned, '+-'))[0], '0');
        if (strlen($whole) > 10) {
            throw new InvalidArgumentException(__('CSV currency amount exceeds the voucher storage limit.', 'gr-commerce-suite'));
        }
        return Money::fromDecimalString($cleaned)->cents();
    }

    private function normalizePayoutDateToUtc(string $rawDate): ?string
    {
        $trimmed = trim($rawDate);
        if ($trimmed === '') {
            return null;
        }

        $utc = new DateTimeZone('UTC');
        $formats = [
            'Y-m-d H:i:s',
            'Y-m-d',
            'd/m/Y H:i:s',
            'd/m/Y',
            'd-m-Y H:i:s',
            'd-m-Y',
            'd.m.Y',
        ];

        foreach ($formats as $fmt) {
            $dt = DateTimeImmutable::createFromFormat('!' . $fmt, $trimmed, $utc);
            if ($dt instanceof DateTimeImmutable) {
                return $dt->format('Y-m-d H:i:s');
            }
        }

        try {
            $dt = new DateTimeImmutable($trimmed, $utc);

            return $dt->setTimezone($utc)->format('Y-m-d H:i:s');
        } catch (Throwable) {
            return null;
        }
    }

    private function parseUtcDateTime(string $dateTimeStr): ?DateTimeImmutable
    {
        $trimmed = trim($dateTimeStr);
        if ($trimmed === '') {
            return null;
        }

        try {
            return new DateTimeImmutable($trimmed, new DateTimeZone('UTC'));
        } catch (Throwable) {
            return null;
        }
    }
}
