<?php

declare(strict_types=1);

namespace GRCommerceSuite\Database;

use GRCommerceSuite\Feed\FeedSafetyDefaults;
use GRCommerceSuite\Support\Lock;
use Throwable;

/**
 * Network activation: installs the current site inline and the remaining sites in resumable WP-Cron batches, so one request never
 * loops over every site. A failed site keeps its schema version unbumped (maybeUpgrade() on its first admin request stays the safety
 * net) and is retried in later passes. Only reason codes (exception class) are logged. Never drops or alters ledger/voucher tables
 * beyond Schema::install().
 */
final class NetworkInstaller
{
    public const HOOK = 'grcs_network_install_batch';
    public const BATCH_SIZE = 20;
    public const MAX_PASSES = 3;

    public const CURSOR_OPTION = 'grcs_network_install_cursor';

    private const LOCK = 'network_install';
    public const LOCK_TTL = 300;
    private const NEXT_BATCH_DELAY = 5;
    private const RETRY_DELAY = 300;

    /**
     * Starts (or restarts) a network install pass from the first site and schedules the first batch.
     */
    public static function start(): void
    {
        if (!is_multisite()) {
            return;
        }

        update_site_option(self::CURSOR_OPTION, ['last' => 0, 'pass' => 1, 'only' => null, 'failed' => []]);
        self::unschedule();
        self::schedule(self::NEXT_BATCH_DELAY);
    }

    public static function register(): void
    {
        // do_action() passes '' for an argument-less cron event: runBatch(int) would throw a TypeError, so the callback takes none.
        add_action(self::HOOK, static function (): void {
            self::runBatch();
        }, 10, 0);
    }

    /**
     * Processes the next batch. Returns the number of sites it handled (0 when locked, idle or finished).
     */
    public static function runBatch(int $size = self::BATCH_SIZE): int
    {
        if (!is_multisite()) {
            return 0;
        }

        $cursor = get_site_option(self::CURSOR_OPTION, null);
        if (!is_array($cursor)) {
            return 0;
        }

        if (!Lock::acquire(self::LOCK, self::LOCK_TTL)) {
            return 0;
        }

        $nextDelay = null;
        $handled = 0;
        try {
            if (function_exists('wp_cache_delete') && function_exists('get_current_network_id')) {
                wp_cache_delete(get_current_network_id() . ':' . self::CURSOR_OPTION, 'site-options');
            }
            $cursor = get_site_option(self::CURSOR_OPTION, null);
            if (!is_array($cursor)) {
                return 0;
            }

            self::unschedule();
            self::schedule(self::LOCK_TTL);

            $last = (int) ($cursor['last'] ?? 0);
            $pass = max(1, (int) ($cursor['pass'] ?? 1));
            $only = is_array($cursor['only'] ?? null) ? array_values(array_map('intval', $cursor['only'])) : null;
            $failed = is_array($cursor['failed'] ?? null) ? array_map('intval', $cursor['failed']) : [];

            $ids = self::nextSiteIds($last, max(1, $size), $only);
            foreach ($ids as $blogId) {
                if (!self::installSite($blogId)) {
                    $failed[] = $blogId;
                }
                $last = $blogId;
                $handled++;
                // Persist after every site: a crash or timeout resumes right after the last completed site.
                update_site_option(self::CURSOR_OPTION, ['last' => $last, 'pass' => $pass, 'only' => $only, 'failed' => array_values(array_unique($failed))]);
            }

            if (count($ids) >= max(1, $size)) {
                $nextDelay = self::NEXT_BATCH_DELAY;
            } else {
                $failed = array_values(array_unique($failed));
                if ($failed !== [] && $pass < self::MAX_PASSES) {
                    sort($failed);
                    update_site_option(self::CURSOR_OPTION, ['last' => 0, 'pass' => $pass + 1, 'only' => $failed, 'failed' => []]);
                    $nextDelay = self::RETRY_DELAY;
                } else {
                    delete_site_option(self::CURSOR_OPTION);
                    if ($failed !== []) {
                        error_log('GR Commerce Suite: network install gave up on ' . count($failed) . ' site(s); maybeUpgrade() will retry on their first admin request.'); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- support diagnosis, no message text
                    }
                }
            }

            self::unschedule();
            if ($nextDelay !== null) {
                self::schedule($nextDelay);
            }
        } finally {
            if (function_exists('ms_is_switched')) {
                while (ms_is_switched()) {
                    restore_current_blog();
                }
            }
            Lock::release(self::LOCK);
        }

        return $handled;
    }

    /**
     * Installs one site. False means the install failed and the version option was left unbumped.
     */
    public static function installSite(int $blogId): bool
    {
        if (function_exists('get_site')) {
            $site = get_site($blogId);
            if ($site === null) {
                return true;
            }
            if ((int) $site->deleted === 1 || (int) $site->spam === 1 || (int) $site->archived === 1) {
                return true;
            }
        }

        switch_to_blog($blogId);
        try {
            $schema = Schema::fromGlobals();
            if (!$schema->needsUpgrade()) {
                return true; // Already current (e.g. the activating site): never re-run dbDelta.
            }

            $hadHistory = true;
            try {
                $hadHistory = FeedSafetyDefaults::hadInstallHistory();
            } catch (Throwable $e) {
                $hadHistory = true;
            }

            try {
                $schema->install();
            } catch (Throwable $e) {
                error_log('GR Commerce Suite: network schema install failed for site ' . $blogId . ': ' . get_class($e)); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- support diagnosis, no message text
                return false;
            }

            if ($schema->needsUpgrade()) {
                return false;
            }

            try {
                FeedSafetyDefaults::seedForNewInstall($hadHistory);
            } catch (Throwable $e) {
                // Safe fallback: defaults stay OFF.
            }

            return true;
        } catch (Throwable $e) {
            error_log('GR Commerce Suite: network install error for site ' . $blogId . ': ' . get_class($e)); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- support diagnosis, no message text
            return false;
        } finally {
            restore_current_blog();
        }
    }

    /**
     * @param list<int>|null $only Retry pass: restrict to these site ids.
     * @return list<int>
     */
    private static function nextSiteIds(int $after, int $limit, ?array $only): array
    {
        if ($only !== null) {
            $ids = array_values(array_filter($only, static fn(int $id): bool => $id > $after));
            sort($ids);

            return array_slice($ids, 0, $limit);
        }

        global $wpdb;
        $rows = $wpdb->get_col($wpdb->prepare(
            "SELECT blog_id FROM {$wpdb->blogs} WHERE site_id = %d AND blog_id > %d AND deleted = 0 AND spam = 0 AND archived = 0 ORDER BY blog_id ASC LIMIT %d",
            (int) get_current_network_id(),
            $after,
            $limit
        ));

        return array_values(array_map('intval', is_array($rows) ? $rows : []));
    }

    public static function unschedule(): void
    {
        if (function_exists('wp_unschedule_hook')) {
            wp_unschedule_hook(self::HOOK);
        }
        if (function_exists('wp_next_scheduled') && function_exists('wp_unschedule_event')) {
            while ($timestamp = wp_next_scheduled(self::HOOK)) {
                wp_unschedule_event($timestamp, self::HOOK);
            }
        }
    }

    private static function schedule(int $delaySeconds): void
    {
        if (function_exists('wp_next_scheduled') && wp_next_scheduled(self::HOOK)) {
            return;
        }
        if (function_exists('wp_schedule_single_event')) {
            wp_schedule_single_event(time() + max(0, $delaySeconds), self::HOOK);
        }
    }
}
