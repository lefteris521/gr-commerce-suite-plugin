<?php

declare(strict_types=1);

namespace GRCommerceSuite\Database;

use RuntimeException;
use GRCommerceSuite\Payments\LedgerSpec;
use GRCommerceSuite\Support\Lock;
use wpdb;
use WP_Screen;

/**
 * Owns the plugin's custom database schema (SPEC.md §6).
 *
 * Rules:
 *  - This class and the classes under {@see \GRCommerceSuite\Database\Repositories} are the ONLY code
 *    allowed to touch `$wpdb`. Order data is NEVER read or written here (orders go through the
 *    WooCommerce CRUD API: wc_get_order() / get_meta() / update_meta_data() / save()).
 *  - No foreign keys: orders may live in `{prefix}wc_orders` (HPOS) or `{prefix}posts` (legacy/sync),
 *    and WordPress does not guarantee InnoDB. Referential cleanup is done in application code.
 *  - All DATETIME columns store UTC (`gmdate('Y-m-d H:i:s')`) and are written by the application,
 *    not by DEFAULT CURRENT_TIMESTAMP, to stay portable across MySQL 5.7 / 8.x and MariaDB 10.x / 11.x.
 *  - Money is DECIMAL(12,2) in EUR. PHP code uses integer cents; floats are forbidden for money.
 *
 * dbDelta() formatting is load-bearing: one column per line, two spaces after PRIMARY KEY,
 * `KEY` (never `INDEX`), no backticks, and no trailing comma before the closing parenthesis.
 */
final readonly class Schema
{
    /** Standalone fallback; installed sites track the plugin release version. */
    public const VERSION = '1.0.0';

    public const VERSION_OPTION = 'grcs_db_version';

    /** Unprefixed table name. Full name is `$wpdb->prefix . VOUCHERS_TABLE`, e.g. `wp_grcs_vouchers`. */
    public const VOUCHERS_TABLE = 'grcs_vouchers';

    private const UPGRADE_LOCK_OPTION = 'grcs_db_upgrade_lock';

    /** Stored result of the last full ledger readiness verification: ['ready' => bool, 'reason' => string, 'contract' => int, 'checked_at' => int]. */
    public const LEDGER_STATUS_OPTION = 'grcs_payment_ledger_status';

    /** Minimum seconds between automatic readiness re-probes for a not-ready ledger on the normal request path (1 hour). */
    public const LEDGER_RECHECK_INTERVAL = 3600;

    /** Write-once marker proving the payment ledger tables existed on this site (retained on uninstall). */
    public const LEDGER_INSTALLED_OPTION = 'grcs_payment_ledger_installed';

    public function __construct(private wpdb $wpdb)
    {
        self::registerAdminRecheckHooks();
    }

    public static function fromGlobals(): self
    {
        global $wpdb;

        if (!$wpdb instanceof wpdb) {
            throw new RuntimeException(__('GR Commerce Suite: $wpdb is not initialised.', 'gr-commerce-suite'));
        }

        return new self($wpdb);
    }

    public function vouchersTable(): string
    {
        return $this->wpdb->prefix . self::VOUCHERS_TABLE;
    }

    /**
     * FULL inventory: fully-prefixed names of every table owned by the plugin (install, readiness, diagnostics). It is NOT the list of
     * tables that may be deleted - see {@see self::deletionEligibleTableNames()}.
     *
     * @return list<string>
     */
    public function tableNames(): array
    {
        return array_merge([$this->vouchersTable()], $this->ledgerTableNames());
    }

    /** @return list<string> the D1 payment-attempt ledger tables of the CURRENT site (resolved after any switch_to_blog()). */
    public function ledgerTableNames(): array
    {
        return array_map(fn(string $name): string => $this->wpdb->prefix . $name, LedgerSpec::names());
    }

    /**
     * Tables that site deletion (`wpmu_drop_tables`) and uninstall may remove. Voucher/COD history and the whole payment ledger are
     * accounting and financial-history evidence: every one of them is retained (owner decision 6, D1 v4), so this is empty. A table is
     * added here only by an explicit owner-approved retention decision.
     *
     * @return list<string>
     */
    public function deletionEligibleTableNames(): array
    {
        return [];
    }

    /**
     * `wpmu_drop_tables` callback: site deletion drops ordinary site tables only; every retained plugin table (vouchers, the whole payment
     * ledger) is removed from the list whatever other callbacks added. Registered by gr-commerce-suite.php at PHP_INT_MAX. WordPress has
     * already switched to the site being deleted, so the inventory is that site's.
     *
     * @param mixed $tables
     * @return list<string>
     */
    public static function retainFinancialHistory($tables): array
    {
        $schema = self::fromGlobals();
        $retained = array_diff($schema->tableNames(), $schema->deletionEligibleTableNames());

        return array_values(array_diff(is_array($tables) ? $tables : [], $retained));
    }

    /**
     * Create or alter all tables to match the current definition, then record the schema version.
     *
     * @throws RuntimeException When a table is still missing after dbDelta() (permissions, disk, engine errors).
     */
    public function install(): void
    {
        if (!function_exists('dbDelta')) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        }

        /** @var array<string, string> $createErrors table => last database error */
        $createErrors = [];
        foreach ($this->tableDefinitions() as $name => $sql) {
            $this->wpdb->last_error = '';
            dbDelta($sql);
            $error = $this->lastError(); // dbDelta() sets it; a method call keeps static analysis from assuming it is still ''
            if ($error !== '') {
                $createErrors[$name] = $error;
            }
        }

        foreach ($this->tableNames() as $table) {
            if (!$this->createdTableExists($table)) {
                $error = ($createErrors[$table] ?? '') !== '' ? $createErrors[$table] : ($this->wpdb->last_error !== '' ? $this->wpdb->last_error : 'unknown database error');
                throw new RuntimeException(sprintf(__('Table %s could not be created (%s).', 'gr-commerce-suite'), $table, $error));
            }
        }

        // Never throws: an unready ledger only keeps new covered payments closed (and Klarna off); it must not break activation.
        $this->verifyLedgerReadiness();

        update_option(self::VERSION_OPTION, self::currentVersion(), true);
    }

    /**
     * Verifies the ledger against the D1 contract: every table, exact column types and nullability, primary/unique/plain keys, InnoDB,
     * and no foreign keys. Stores the result so later requests answer {@see self::ledgerReady()} with one option read.
     *
     * @return array{ready: bool, reason: string}
     */
    public function verifyLedgerReadiness(): array
    {
        $result = $this->inspectLedger();
        $previous = get_option(self::LEDGER_STATUS_OPTION, null);
        $record = [
            'ready' => $result['ready'],
            'reason' => $result['reason'],
            'contract' => LedgerSpec::CONTRACT_VERSION,
            'checked_at' => time(),
        ];
        $statusChanged = !is_array($previous)
            || ($previous['ready'] ?? null) !== $record['ready']
            || ($previous['reason'] ?? null) !== $record['reason']
            || ($previous['contract'] ?? null) !== $record['contract'];
        if ($statusChanged || ($previous['checked_at'] ?? null) !== $record['checked_at']) {
            update_option(self::LEDGER_STATUS_OPTION, $record, true);
        }
        if ($statusChanged && !$result['ready']) {
            error_log('GR Commerce Suite: payment ledger not ready: ' . $result['reason']); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- once per change, for support diagnosis
        }
        if (!str_starts_with($result['reason'], 'table_missing:') && $result['reason'] !== 'inspection_query_failed') {
            add_option(self::LEDGER_INSTALLED_OPTION, '1', '', false);
        }

        return $result;
    }

    /**
     * The stored verification result only: true / false, or null when none is stored for this contract version. Needs no database object,
     * so runtimes without one (standalone checks) can still read it.
     */
    public static function storedLedgerReady(): ?bool
    {
        self::registerAdminRecheckHooks();

        return self::cachedLedgerReady(false);
    }

    /**
     * True when the payment ledger was installed at some point on this site (marker, stored status ready, or attempts table present).
     * Fail-closed callers use it to tell "tables vanished or unreadable" (veto) from "ledger never installed" (nothing to protect).
     */
    public static function ledgerWasInstalled(): bool
    {
        if (get_option(self::LEDGER_INSTALLED_OPTION, null) === '1') {
            return true;
        }

        $stored = get_option(self::LEDGER_STATUS_OPTION, null);
        if (is_array($stored) && ($stored['ready'] ?? false) === true) {
            return true;
        }

        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return false;
        }

        $table = $wpdb->prefix . LedgerSpec::ATTEMPTS;
        $suppress = $wpdb->suppress_errors(true);
        try {
            $wpdb->last_error = '';
            $result = $wpdb->query("SELECT 1 FROM `{$table}` LIMIT 0"); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
            if ($result !== false && self::wpdbLastError($wpdb) === '') {
                return true;
            }

            $wpdb->last_error = '';
            $found = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
            if (self::wpdbLastError($wpdb) !== '') {
                return true;
            }

            return $found === $table;
        } finally {
            $wpdb->suppress_errors($suppress);
        }
    }

    /**
     * Cheap readiness answer from the stored verification. A ready record for the current contract version is never
     * re-probed on the request path; a not-ready record is re-probed at most once per hour (or when missing checked_at)
     * and on plugin admin screen loads or admin settings saves.
     */
    public function ledgerReady(): bool
    {
        $cached = self::cachedLedgerReady(true);
        if ($cached !== null) {
            return $cached;
        }

        return $this->probeLedgerReadiness();
    }

    private function probeLedgerReadiness(): bool
    {
        $result = $this->verifyLedgerReadiness();
        if (!$result['ready'] && str_starts_with($result['reason'], 'table_missing:') && Lock::acquire('db_upgrade', 120)) {
            // A site updated by ZIP at the same plugin version never ran install() for the new tables: create them once, then re-verify.
            try {
                $this->install();
            } catch (RuntimeException) {
                // reported through the readiness record
            } finally {
                Lock::release('db_upgrade');
            }
            $result = $this->verifyLedgerReadiness();
        }

        return $result['ready'];
    }

    private static function cachedLedgerReady(bool $canProbe): ?bool
    {
        $stored = get_option(self::LEDGER_STATUS_OPTION, null);
        if (!is_array($stored) || ($stored['contract'] ?? 0) !== LedgerSpec::CONTRACT_VERSION) {
            return null;
        }

        if (($stored['ready'] ?? false) === true) {
            return true;
        }
        // Unchanged from before the hourly throttle: a missing table or failed inspection is re-verified (and repaired) every time.
        $reason = (string) ($stored['reason'] ?? '');
        if (str_starts_with($reason, 'table_missing:') || $reason === 'inspection_query_failed') {
            return null;
        }

        if (!$canProbe) {
            return false;
        }

        $checkedAt = $stored['checked_at'] ?? null;
        if (!is_int($checkedAt) || $checkedAt <= 0) {
            return null;
        }

        $age = time() - $checkedAt;
        if ($age < -300 || $age >= self::LEDGER_RECHECK_INTERVAL) {
            return null;
        }

        if (self::isAdminRecheckContext()) {
            return null;
        }

        return false;
    }

    public static function registerAdminRecheckHooks(): void
    {
        if (!function_exists('add_action') || !function_exists('has_action')) {
            return;
        }

        foreach ([
            'woocommerce_settings_saved',
            'woocommerce_update_options_gr_commerce_suite',
            'woocommerce_settings_save_gr_commerce_suite',
            'woocommerce_update_options_payment_gateways_grcs_klarna',
        ] as $saveHook) {
            if (has_action($saveHook, [self::class, 'recheckUnreadyLedger']) === false) {
                add_action($saveHook, [self::class, 'recheckUnreadyLedger']);
            }
        }

        foreach (['current_screen', 'admin_init', 'admin_enqueue_scripts'] as $screenHook) {
            if (has_action($screenHook, [self::class, 'recheckOnPluginAdminScreen']) === false) {
                add_action($screenHook, [self::class, 'recheckOnPluginAdminScreen']);
            }
        }
    }

    /**
     * Re-probes a not-ready ledger when a plugin admin screen loads. Ready records are never re-probed.
     */
    public static function recheckOnPluginAdminScreen(mixed $context = null): void
    {
        $hook = is_string($context) ? $context : '';
        if (!self::isPluginAdminScreen($hook) && !self::isAdminSettingsSave()) {
            return;
        }

        self::recheckUnreadyLedger();
    }

    /**
     * Re-probes the payment ledger only when a stored record is missing or marked not-ready.
     * A ready record for the current contract version is never re-probed on the request path.
     */
    public static function recheckUnreadyLedger(): void
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return;
        }

        $stored = get_option(self::LEDGER_STATUS_OPTION, null);
        if (is_array($stored) && ($stored['contract'] ?? 0) === LedgerSpec::CONTRACT_VERSION && ($stored['ready'] ?? false) === true) {
            return;
        }

        (new self($wpdb))->probeLedgerReadiness();
    }

    private static function isAdminRecheckContext(): bool
    {
        return self::isPluginAdminScreen() || self::isAdminSettingsSave();
    }

    private static function isPluginAdminScreen(string $hook = ''): bool
    {
        if (!function_exists('is_admin') || !is_admin()) {
            return false;
        }

        if ((function_exists('wp_doing_ajax') && wp_doing_ajax())
            || (function_exists('wp_doing_cron') && wp_doing_cron())
            || (defined('REST_REQUEST') && REST_REQUEST)) {
            return false;
        }

        if ($hook !== '' && (str_contains($hook, 'grcs-') || str_contains($hook, 'gr_commerce_suite'))) {
            return true;
        }

        $screenId = '';
        if (function_exists('get_current_screen')) {
            $screen = get_current_screen();
            if ($screen instanceof WP_Screen) {
                $screenId = (string) $screen->id;
                if ($screenId !== '' && (str_contains($screenId, 'grcs-') || str_contains($screenId, 'gr_commerce_suite'))) {
                    return true;
                }
            }
        }

        $page = isset($_GET['page']) && is_string($_GET['page']) ? $_GET['page'] : '';
        if (in_array($page, ['grcs-cod-reconciliation', 'grcs-customer-360', 'grcs-payment-reservations'], true)) {
            return true;
        }

        if ($page === 'wc-settings' || $screenId === 'woocommerce_page_wc-settings') {
            $tab = isset($_GET['tab']) && is_string($_GET['tab']) ? $_GET['tab'] : '';
            $section = isset($_GET['section']) && is_string($_GET['section']) ? $_GET['section'] : '';
            if ($tab === 'gr_commerce_suite' || ($tab === 'checkout' && $section === 'grcs_klarna')) {
                return true;
            }
        }

        return false;
    }

    private static function isAdminSettingsSave(): bool
    {
        if (function_exists('doing_action')) {
            foreach ([
                'woocommerce_settings_saved',
                'woocommerce_update_options',
                'woocommerce_update_options_gr_commerce_suite',
                'woocommerce_settings_save_gr_commerce_suite',
                'woocommerce_update_options_payment_gateways_grcs_klarna',
            ] as $action) {
                if (doing_action($action)) {
                    return true;
                }
            }
        }

        if (!function_exists('is_admin') || !is_admin()) {
            return false;
        }

        if ((function_exists('wp_doing_ajax') && wp_doing_ajax())
            || (function_exists('wp_doing_cron') && wp_doing_cron())
            || (defined('REST_REQUEST') && REST_REQUEST)) {
            return false;
        }

        if (isset($_POST['grcs_modules_form']) || isset($_POST['woocommerce_grcs_klarna_enabled'])) {
            return true;
        }

        $page = isset($_GET['page']) && is_string($_GET['page']) ? $_GET['page'] : '';

        return $page === 'wc-settings' && !empty($_POST['save']);
    }

    /** @return array{ready: bool, reason: string} reason is a short code: table_missing:x, engine:x=y, column:x.y, key:x.y, foreign_key_present, ok */
    public function inspectLedger(): array
    {
        $fail = static fn(string $reason): array => ['ready' => false, 'reason' => $reason];
        $names = $this->ledgerTableNames();
        $marks = implode(',', array_fill(0, count($names), '%s'));

        // phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.DirectDatabaseQuery -- fixed information_schema reads; names are bound
        $engines = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT TABLE_NAME AS t, ENGINE AS e FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ({$marks})",
            ...$names
        ), 'ARRAY_A');
        $columns = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT TABLE_NAME AS t, COLUMN_NAME AS c, COLUMN_TYPE AS ty, IS_NULLABLE AS n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ({$marks})",
            ...$names
        ), 'ARRAY_A');
        $stats = $this->wpdb->get_results($this->wpdb->prepare(
            "SELECT TABLE_NAME AS t, INDEX_NAME AS i, NON_UNIQUE AS nu, SEQ_IN_INDEX AS s, COLUMN_NAME AS c FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN ({$marks})",
            ...$names
        ), 'ARRAY_A');
        $foreign = $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA = DATABASE() AND CONSTRAINT_TYPE = 'FOREIGN KEY' AND TABLE_NAME IN ({$marks})",
            ...$names
        ));
        // phpcs:enable
        if (!is_array($engines) || !is_array($columns) || !is_array($stats) || $foreign === null) {
            return $fail('inspection_query_failed');
        }

        $engineByTable = [];
        foreach ($engines as $row) {
            $engineByTable[(string) $row['t']] = strtolower((string) $row['e']);
        }
        $colsByTable = [];
        foreach ($columns as $row) {
            $colsByTable[(string) $row['t']][(string) $row['c']] = [LedgerSpec::normalizeType((string) $row['ty']), strtoupper((string) $row['n']) === 'YES'];
        }
        $keysByTable = [];
        foreach ($stats as $row) {
            $keysByTable[(string) $row['t']][(string) $row['i']]['unique'] = (int) $row['nu'] === 0;
            $keysByTable[(string) $row['t']][(string) $row['i']]['cols'][(int) $row['s']] = (string) $row['c'];
        }

        foreach (LedgerSpec::tables() as $name => $spec) {
            $table = $this->wpdb->prefix . $name;
            if (!isset($engineByTable[$table])) {
                return $fail('table_missing:' . $name);
            }
            if ($engineByTable[$table] !== 'innodb') {
                return $fail('engine:' . $name . '=' . $engineByTable[$table]);
            }
            $actual = $colsByTable[$table] ?? [];
            foreach ($spec['columns'] as $column => [$type, $nullable]) {
                if (($actual[$column] ?? null) !== [$type, $nullable]) {
                    return $fail('column:' . $name . '.' . $column);
                }
            }
            $keys = $keysByTable[$table] ?? [];
            $expected = ['PRIMARY' => [true, $spec['primary']]];
            foreach ($spec['unique'] as $key => $cols) {
                $expected[$key] = [true, $cols];
            }
            foreach ($spec['index'] as $key => $cols) {
                $expected[$key] = [false, $cols];
            }
            foreach ($expected as $key => [$unique, $cols]) {
                $found = $keys[$key] ?? null;
                if (is_array($found)) {
                    ksort($found['cols']); // by SEQ_IN_INDEX
                }
                if ($found === null || $found['unique'] !== $unique || array_values($found['cols']) !== $cols) {
                    return $fail('key:' . $name . '.' . $key);
                }
            }
        }
        if ((int) $foreign > 0) {
            return $fail('foreign_key_present');
        }

        return ['ready' => true, 'reason' => 'ok'];
    }

    private static function wpdbLastError(wpdb $wpdb): string
    {
        return (string) $wpdb->last_error;
    }

    private function lastError(): string
    {
        return self::wpdbLastError($this->wpdb);
    }

    public function needsUpgrade(): bool
    {
        $installed = get_option(self::VERSION_OPTION, '');

        return $installed !== self::currentVersion();
    }

    private static function currentVersion(): string
    {
        return defined('GRCS_VERSION') ? (string) GRCS_VERSION : self::VERSION;
    }

    /**
     * Cheap per-request check (one autoloaded option read). Runs dbDelta() only when the stored schema
     * version is behind. An atomic add_option() lock prevents concurrent requests from stampeding
     * dbDelta() right after a plugin update on busy stores.
     *
     * @return bool True when an upgrade was executed in this request.
     *
     * @throws RuntimeException Propagated from install().
     */
    public function maybeUpgrade(): bool
    {
        if (!$this->needsUpgrade()) {
            return false;
        }

        if (!Lock::acquire('db_upgrade', 120)) {
            return false;
        }

        try {
            $this->install();
        } finally {
            Lock::release('db_upgrade');
        }

        return true;
    }

    /**
     * Drop the deletion-eligible plugin tables (none today) and the schema markers.
     *
     * MUST only be called from uninstall.php when the merchant explicitly opted in to data removal
     * (option `grcs_delete_data_on_uninstall` === 'yes'). Voucher/COD history and the payment ledger are financial evidence and survive.
     */
    public function drop(): void
    {
        foreach ($this->deletionEligibleTableNames() as $table) {
            // Table names are built from $wpdb->prefix + a class constant: not user input.
            $this->wpdb->query("DROP TABLE IF EXISTS {$table}"); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery.SchemaChange
        }

        delete_option(self::VERSION_OPTION);
        delete_option(self::UPGRADE_LOCK_OPTION);
        delete_option(self::LEDGER_STATUS_OPTION);
    }

    public function tableExists(string $table): bool
    {
        $found = $this->wpdb->get_var(
            $this->wpdb->prepare('SHOW TABLES LIKE %s', $this->wpdb->esc_like($table))
        );

        return $found === $table;
    }

    /**
     * install() only: SHOW TABLES never lists TEMPORARY tables (WordPress's PHPUnit harness creates site tables as such), so a table that
     * SHOW TABLES does not list is confirmed with SHOW CREATE TABLE before install() reports it as not created.
     */
    private function createdTableExists(string $table): bool
    {
        if ($this->tableExists($table)) {
            return true;
        }
        $created = $this->wpdb->get_var('SHOW CREATE TABLE `' . str_replace('`', '', $table) . '`'); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- identifier from the site prefix and a class constant

        return $created === $table;
    }

    /** Read-only support inspection; do not select customer rows or expose SQL errors.
     * @return array<string, mixed>
     */
    public function diagnosticIntegrity(): array
    {
        $result = [];
        foreach (['grcs_vouchers' => ['id', 'order_id', 'courier_slug', 'voucher_no', 'state', 'tracking_status',
            'cod_amount', 'cod_collected', 'cod_reconciled', 'cod_reconciled_at', 'cod_settlement_ref', 'is_printed',
            'printed_at', 'idempotency_key', 'attempts', 'last_error', 'raw_response', 'last_tracked_at', 'created_at', 'updated_at'],
            'grcs_cod_blacklist' => []] as $suffix => $required) {
            $table = $this->wpdb->prefix . $suffix;
            if (!$this->tableExists($table)) {
                $result[$suffix] = ['status' => 'Missing', 'row_count' => null, 'required_by_current_release' => $suffix === 'grcs_vouchers'];
                continue;
            }
            $columns = $this->wpdb->get_col(PreparedQuery::prepare($this->wpdb, 'SHOW COLUMNS FROM %i', $table));
            $count = $this->wpdb->get_var(PreparedQuery::prepare($this->wpdb, 'SELECT COUNT(*) FROM %i', $table));
            $missing = array_values(array_diff($required, is_array($columns) ? $columns : []));
            $result[$suffix] = ['status' => $columns !== [] && $missing === [] && is_numeric($count) ? 'OK' : 'Schema/query error',
                'missing_columns' => $missing, 'row_count' => is_numeric($count) ? (int) $count : null];
        }
        // Current releases intentionally keep blacklist identities in non-autoloaded options.
        $count = $this->wpdb->get_var(PreparedQuery::prepare($this->wpdb,
            'SELECT COUNT(*) FROM %i WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s',
            $this->wpdb->options, $this->wpdb->esc_like('grcs_cod_blacklist_phone_') . '%',
            $this->wpdb->esc_like('grcs_cod_blacklist_email_') . '%', $this->wpdb->esc_like('grcs_cod_blacklist_ip_') . '%'));
        $result['Blacklist storage'] = ['backend' => 'Indexed wp_options (grcs_cod_blacklist table is not used by this release)',
            'row_count' => is_numeric($count) ? (int) $count : null];
        return $result;
    }

    /**
     * dbDelta()-compatible CREATE TABLE statements, keyed by fully-prefixed table name.
     *
     * Column semantics, allowed values and index rationale are normative in SPEC.md §6.2–§6.4.
     *
     * @return array<string, string>
     */
    public function tableDefinitions(): array
    {
        $table   = $this->vouchersTable();
        $collate = $this->wpdb->get_charset_collate();

        $vouchers = <<<SQL
CREATE TABLE {$table} (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  order_id bigint(20) unsigned NOT NULL,
  courier_slug varchar(20) NOT NULL,
  voucher_no varchar(64) NULL DEFAULT NULL,
  state varchar(20) NOT NULL DEFAULT 'reserved',
  tracking_status varchar(32) NOT NULL DEFAULT 'pending',
  cod_amount decimal(12,2) NOT NULL DEFAULT '0.00',
  cod_collected decimal(12,2) NULL DEFAULT NULL,
  cod_reconciled tinyint(1) unsigned NOT NULL DEFAULT 0,
  cod_reconciled_at datetime NULL DEFAULT NULL,
  cod_settlement_ref varchar(64) NULL DEFAULT NULL,
  is_printed tinyint(1) unsigned NOT NULL DEFAULT 0,
  printed_at datetime NULL DEFAULT NULL,
  idempotency_key char(64) NOT NULL,
  attempts smallint(5) unsigned NOT NULL DEFAULT 0,
  last_error text NULL,
  raw_response longtext NULL,
  last_tracked_at datetime NULL DEFAULT NULL,
  created_at datetime NOT NULL,
  updated_at datetime NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY idempotency_key (idempotency_key),
  UNIQUE KEY courier_voucher (courier_slug,voucher_no),
  KEY order_id (order_id),
  KEY tracking_poll (state,tracking_status,last_tracked_at),
  KEY cod_queue (cod_reconciled,courier_slug,tracking_status),
  KEY print_queue (is_printed,courier_slug,created_at)
) {$collate};
SQL;

        $definitions = [$table => $vouchers];
        foreach (LedgerSpec::names() as $name) {
            $definitions[$this->wpdb->prefix . $name] = LedgerSpec::createSql($name, $this->wpdb->prefix, $collate);
        }

        return $definitions;
    }
}
