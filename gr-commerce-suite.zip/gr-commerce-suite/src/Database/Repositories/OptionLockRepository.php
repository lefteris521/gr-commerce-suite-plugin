<?php

declare(strict_types=1);

namespace GRCommerceSuite\Database\Repositories;

use wpdb;

/** Compare-and-swap prevents two workers taking over the same expired option lock. */
final class OptionLockRepository
{
    /** Insert-only acquisition; WordPress add_option() may upsert a concurrent worker's value. */
    public static function insert(string $name, string $value, bool $acrossSites = false): bool
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return false;
        }
        $sql = \GRCommerceSuite\Database\PreparedQuery::prepare(
            $wpdb,
            "INSERT IGNORE INTO %i (option_name, option_value, autoload) VALUES (%s, %s, 'off')",
            $acrossSites ? $wpdb->base_prefix . 'options' : $wpdb->options,
            $name,
            $value
        );
        if ($wpdb->query($sql) !== 1) {
            return false;
        }
        if (!$acrossSites && function_exists('wp_cache_delete')) {
            wp_cache_delete($name, 'options');
            wp_cache_delete('notoptions', 'options');
        }
        return true;
    }

    /** Direct SQL read of current row, bypassing WordPress object cache. */
    public static function get(string $name, bool $acrossSites = false): ?string
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return null;
        }
        $sql = \GRCommerceSuite\Database\PreparedQuery::prepare(
            $wpdb,
            "SELECT option_value FROM %i WHERE option_name = %s LIMIT 1",
            $acrossSites ? $wpdb->base_prefix . 'options' : $wpdb->options,
            $name
        );
        $value = $wpdb->get_var($sql);
        return is_string($value) ? $value : null;
    }

    public static function replace(string $name, string $expected, ?string $replacement, bool $acrossSites = false): bool
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return false;
        }
        $sql = $replacement === null
            ? \GRCommerceSuite\Database\PreparedQuery::prepare(
                $wpdb,
                "DELETE FROM %i WHERE option_name = %s AND option_value = %s",
                $acrossSites ? $wpdb->base_prefix . 'options' : $wpdb->options,
                $name,
                $expected
            )
            : \GRCommerceSuite\Database\PreparedQuery::prepare(
                $wpdb,
                "UPDATE %i SET option_value = %s WHERE option_name = %s AND option_value = %s",
                $acrossSites ? $wpdb->base_prefix . 'options' : $wpdb->options,
                $replacement,
                $name,
                $expected
            );
        if ($wpdb->query($sql) !== 1) {
            return false;
        }
        if (!$acrossSites && function_exists('wp_cache_delete')) {
            wp_cache_delete($name, 'options');
            if ($replacement === null) {
                wp_cache_delete('notoptions', 'options');
            }
        }
        return true;
    }
}
