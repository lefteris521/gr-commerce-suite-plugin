<?php

declare(strict_types=1);

namespace GRCommerceSuite\Database\Repositories;

use GRCommerceSuite\Database\PreparedQuery;
use wpdb;

/**
 * Concurrency-safe integer rate counter stored as an option row.
 *
 * reserve() is a single atomic INSERT ... ON DUPLICATE KEY UPDATE statement that
 * increments the stored integer and exposes the new value through LAST_INSERT_ID().
 * refund() is a single guarded UPDATE that decrements the stored integer only while
 * it is positive. Both operations are O(1) and the row stays a plain integer.
 *
 * The SQL behaves as described only on a real MySQL/MariaDB connection. The
 * standalone smoke test exercises PHP control flow with a fake $wpdb and does not
 * execute SQL; tests/WooCommerce/KlarnaStatusLimiterConcurrencyTest.php is the
 * proof against a real database, including a semantic mutant of the refund guard.
 */
final class RateCounterRepository
{
    /**
     * Atomically increment the counter and return its post-increment value.
     *
     * In MySQL:
     *  - On insert, option_value starts at 1 and rows_affected is 1.
     *  - On duplicate key, option_value is incremented and LAST_INSERT_ID(expr)
     *    makes the new value available as $wpdb->insert_id.
     * This single statement guarantees zero lost increments under concurrent bursts.
     *
     * @param string $name Option name of the rate limit bucket.
     * @param bool $acrossSites Whether to use the base options table across multisite.
     * @return int Post-increment count, or PHP_INT_MAX when storage is unavailable or the statement fails (fail closed).
     */
    public static function reserve(string $name, bool $acrossSites = false): int
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return PHP_INT_MAX;
        }

        $table = $acrossSites ? $wpdb->base_prefix . 'options' : $wpdb->options;
        $sql = PreparedQuery::prepare(
            $wpdb,
            "INSERT INTO %i (option_name, option_value, autoload) VALUES (%s, '1', 'off') " .
            "ON DUPLICATE KEY UPDATE option_value = LAST_INSERT_ID(CAST(option_value AS UNSIGNED) + 1)",
            $table,
            $name
        );

        $result = $wpdb->query($sql);
        if ($result === false) {
            return PHP_INT_MAX; // Fail closed on database error.
        }

        if (!$acrossSites && function_exists('wp_cache_delete')) {
            wp_cache_delete($name, 'options');
        }

        if ($wpdb->rows_affected === 1) {
            if (!$acrossSites && function_exists('wp_cache_delete')) {
                wp_cache_delete('notoptions', 'options');
            }
            return 1;
        }

        $count = (int) $wpdb->insert_id;
        return $count > 0 ? $count : PHP_INT_MAX; // A duplicate without a usable LAST_INSERT_ID() is a storage failure.
    }

    /**
     * Decrement the counter by one, but never below zero.
     *
     * One guarded UPDATE: the "option_value > 0" predicate is evaluated by the
     * database in the same statement as the decrement, so concurrent failures cannot
     * be lost and the value cannot become negative. The caller must use the exact
     * key it reserved and must call this at most once per request.
     *
     * WordPress' $wpdb automatically reconnects and replays a statement after a lost
     * connection. If that happens to this statement, the replay decrements one extra
     * time: the accepted bound is at most +1 admitted failure per reconnect. Order
     * keys are ~77 bits, so the extra slot does not let an unauthorised client reach
     * an order it could not already reach.
     *
     * @param string $name Option name of the rate limit bucket.
     * @param bool $acrossSites Whether to use the base options table across multisite.
     * @return bool True only when this execution decremented the counter; false when the row was absent, already zero, or the write failed.
     */
    public static function refund(string $name, bool $acrossSites = false): bool
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return false;
        }

        $table = $acrossSites ? $wpdb->base_prefix . 'options' : $wpdb->options;
        $sql = PreparedQuery::prepare(
            $wpdb,
            "UPDATE %i SET option_value = option_value - 1 WHERE option_name = %s AND option_value > 0",
            $table,
            $name
        );

        $result = $wpdb->query($sql);

        if (!$acrossSites && function_exists('wp_cache_delete')) {
            wp_cache_delete($name, 'options');
        }

        return $result === 1;
    }

    /**
     * Read the current counter, distinguishing an absent bucket from a failed read.
     *
     * @param string $name Option name.
     * @param bool $acrossSites Whether to use the base options table.
     * @return int|null Current count, 0 when the bucket does not exist, or null when the read failed.
     */
    public static function get(string $name, bool $acrossSites = false): ?int
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return null; // No storage: fail closed.
        }

        $table = $acrossSites ? $wpdb->base_prefix . 'options' : $wpdb->options;
        $sql = PreparedQuery::prepare(
            $wpdb,
            "SELECT option_value FROM %i WHERE option_name = %s",
            $table,
            $name
        );

        $val = $wpdb->get_var($sql);
        if ($val !== null) {
            return max(0, (int) $val);
        }

        return $wpdb->last_error === '' ? 0 : null; // Absent bucket vs failed read.
    }

    /**
     * Bounded opportunistic cleanup of buckets older than the previous window.
     *
     * Strictly bounded to LIMIT <= 100, uses esc_like prefix matching and regex check
     * to guarantee that only valid rate limit bucket options are deleted.
     *
     * @param string $prefix Option name prefix (e.g. 'grcs_klarna_rl_').
     * @param int $olderThanBucket Delete buckets strictly less than this bucket number.
     * @param int $limit Maximum number of rows to delete per call (capped at 100).
     * @param bool $acrossSites Whether to clean up on the base options table.
     * @return int Number of deleted rows.
     */
    public static function cleanup(string $prefix, int $olderThanBucket, int $limit = 100, bool $acrossSites = false): int
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return 0;
        }

        $cappedLimit = max(1, min(100, $limit));
        $table = $acrossSites ? $wpdb->base_prefix . 'options' : $wpdb->options;

        $sql = PreparedQuery::prepare(
            $wpdb,
            "DELETE FROM %i WHERE option_name LIKE %s AND option_name REGEXP '^[A-Za-z0-9_]+_[0-9]+$' AND CAST(SUBSTRING_INDEX(option_name, '_', -1) AS UNSIGNED) < %d LIMIT %d",
            $table,
            $wpdb->esc_like($prefix) . '%',
            $olderThanBucket,
            $cappedLimit
        );

        $result = $wpdb->query($sql);
        return is_int($result) ? $result : 0;
    }
}
