<?php

declare(strict_types=1);

namespace GRCommerceSuite\Database\Repositories;

use wpdb;

/**
 * Read-only listing of COD blacklist records stored as non-autoloaded options
 * (`grcs_cod_blacklist_{phone|email}_{sha256}`) for the admin "Μαύρη Λίστα" overview.
 */
final class CodBlacklistRepository
{
    /** Bounded admin search; checkout continues using the unique option-name index.
     * @return list<array{option_name: string, option_value: string}>
     */
    public static function findEntries(string $search = '', string $courier = '', string $reason = '', string $status = '', int $offset = 0): array
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return [];
        }
        $where = ['(option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s)',
            '(option_value LIKE %s OR option_value LIKE %s)'];
        $args = [$wpdb->options];
        foreach (['phone', 'email', 'ip'] as $type) {
            $args[] = $wpdb->esc_like('grcs_cod_blacklist_' . $type . '_') . '%';
        }
        $args[] = '%' . $wpdb->esc_like('s:7:"blocked";b:1;') . '%';
        $args[] = '%' . $wpdb->esc_like('s:11:"whitelisted";b:1;') . '%';
        foreach (['courier' => $courier, 'reason' => $reason] as $field => $value) {
            if ($value === '') {
                continue;
            }
            $where[] = 'option_value LIKE %s';
            $fragment = $value === 'whitelist' ? 's:11:"whitelisted";b:1;'
                : 's:' . strlen($field) . ':"' . $field . '";s:' . strlen($value) . ':"' . $value . '";';
            $args[] = '%' . $wpdb->esc_like($fragment) . '%';
        }
        if (in_array($status, ['blacklisted', 'whitelisted'], true)) {
            $where[] = 'option_value ' . ($status === 'blacklisted' ? 'NOT LIKE' : 'LIKE') . ' %s';
            $args[] = '%' . $wpdb->esc_like('s:11:"whitelisted";b:1;') . '%';
        }
        if ($search !== '') {
            $where[] = 'option_value LIKE %s';
            $args[] = '%' . $wpdb->esc_like($search) . '%';
        }
        $args[] = max(0, $offset);
        $sql = \GRCommerceSuite\Database\PreparedQuery::prepare(
            $wpdb,
            'SELECT option_name, option_value FROM %i WHERE ' . implode(' AND ', $where) . ' ORDER BY option_id DESC LIMIT 600 OFFSET %d',
            ...$args
        );
        $rows = $wpdb->get_results($sql, 'ARRAY_A');
        $result = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            if (is_array($row) && isset($row['option_name'], $row['option_value'])) {
                $result[] = ['option_name' => (string) $row['option_name'], 'option_value' => (string) $row['option_value']];
            }
        }
        return $result;
    }

    /**
     * @return list<array{option_name: string, option_value: string}>
     */
    public static function findByPrefixes(string $phonePrefix, string $emailPrefix, int $limit = 200): array
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return [];
        }

        $sql = \GRCommerceSuite\Database\PreparedQuery::prepare(
            $wpdb,
            "SELECT option_name, option_value FROM %i
             WHERE (option_name LIKE %s OR option_name LIKE %s) AND option_value LIKE %s
             ORDER BY option_id DESC LIMIT %d",
            $wpdb->options,
            $wpdb->esc_like($phonePrefix) . '%',
            $wpdb->esc_like($emailPrefix) . '%',
            '%' . $wpdb->esc_like('s:7:"blocked";b:1;') . '%',
            max(1, $limit)
        );

        $rows = $wpdb->get_results($sql, 'ARRAY_A');
        if (!is_array($rows)) {
            return [];
        }

        $result = [];
        foreach ($rows as $row) {
            if (!is_array($row) || !isset($row['option_name'], $row['option_value'])) {
                continue;
            }
            $result[] = [
                'option_name' => (string) $row['option_name'],
                'option_value' => (string) $row['option_value'],
            ];
        }

        return $result;
    }
}
