<?php

declare(strict_types=1);

namespace GRCommerceSuite\Database\Repositories;

use GRCommerceSuite\Jobs\JobDispatcher;
use wpdb;

/** Uninstall fallback when WooCommerce (and its scheduler API) is inactive. */
final class SchedulerRepository
{
    public static function cancelPending(): void
    {
        global $wpdb;
        if (!$wpdb instanceof wpdb) {
            return;
        }
        $actions = $wpdb->prefix . 'actionscheduler_actions';
        $groups = $wpdb->prefix . 'actionscheduler_groups';
        foreach ([$actions, $groups] as $table) {
            if (
                $wpdb->get_var(\GRCommerceSuite\Database\PreparedQuery::prepare(
                    $wpdb,
                    'SHOW TABLES LIKE %s',
                    $wpdb->esc_like($table)
                )) !== $table
            ) {
                return;
            }
        }
        $wpdb->query(\GRCommerceSuite\Database\PreparedQuery::prepare(
            $wpdb,
            "UPDATE %i a INNER JOIN %i g ON a.group_id = g.group_id
             SET a.status = %s WHERE g.slug = %s AND a.status = %s",
            $actions,
            $groups,
            'canceled',
            JobDispatcher::GROUP,
            'pending'
        ));
    }
}
