<?php

declare(strict_types=1);

namespace GRCommerceSuite\Database\Repositories;

use GRCommerceSuite\Contracts\VoucherStateTrackerInterface;
use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Tracking\TrackingStatus;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Support\Money;
use RuntimeException;
use wpdb;

/**
 * Repository owning all reads and writes to `{prefix}grcs_vouchers` (SPEC.md §3 C-3, §6, §7).
 *
 * Rules:
 *  - Only this repository and Schema may touch `$wpdb`.
 *  - Every query uses `\GRCommerceSuite\Database\PreparedQuery::prepare($this->wpdb, )` for parameterised values.
 *  - State transitions use optimistic concurrency (`WHERE id = %d AND state = %s`).
 *  - All timestamps are UTC (`gmdate('Y-m-d H:i:s')`).
 */
final readonly class VoucherRepository implements VoucherStateTrackerInterface
{
    public function __construct(
        private wpdb $wpdb,
        private Schema $schema,
    ) {
    }

    public static function fromGlobals(?Schema $schema = null): self
    {
        global $wpdb;

        if (!$wpdb instanceof wpdb) {
            throw new RuntimeException(__('GR Commerce Suite: $wpdb is not initialised.', 'gr-commerce-suite'));
        }

        return new self($wpdb, $schema ?? new Schema($wpdb));
    }

    /**
     * Atomically reserve a voucher row by unique `idempotency_key` (SPEC.md §7).
     *
     * @return array{inserted: bool, row: array<string, mixed>}
     */
    public function reserve(
        int $orderId,
        CourierSlug $courier,
        string $idempotencyKey,
        int $codAmountCents,
    ): array {
        $existing = $this->findByIdempotencyKey($idempotencyKey);
        if ($existing !== null) {
            return ['inserted' => false, 'row' => $existing];
        }

        $table = $this->schema->vouchersTable();
        $now = gmdate('Y-m-d H:i:s');
        $codDecimal = Money::fromCents($codAmountCents)->toDecimalString();

        $sql = \GRCommerceSuite\Database\PreparedQuery::prepare(
            $this->wpdb,
            "INSERT IGNORE INTO %i
                (order_id, courier_slug, voucher_no, state, tracking_status, cod_amount, cod_collected,
                 cod_reconciled, cod_reconciled_at, cod_settlement_ref, is_printed, printed_at, idempotency_key,
                 attempts, last_error, raw_response, last_tracked_at, created_at, updated_at)
             VALUES
                (%d, %s, NULL, %s, %s, %s, NULL, 0, NULL, NULL, 0, NULL, %s, 1, NULL, NULL, NULL, %s, %s)",
            $table,
            $orderId,
            $courier->value,
            VoucherState::Reserved->value,
            TrackingStatus::Pending->value,
            $codDecimal,
            $idempotencyKey,
            $now,
            $now
        );

        $affected = $this->wpdb->query($sql);
        $row = $this->findByIdempotencyKey($idempotencyKey);

        if ($row === null) {
            throw new RuntimeException(__('Failed to reserve or locate voucher row for idempotency key.', 'gr-commerce-suite'));
        }

        return [
            'inserted' => $affected === 1,
            'row' => $row,
        ];
    }

    /**
     * Perform an optimistic-concurrency state transition (`UPDATE ... WHERE id = %d AND state = %s`) (SPEC.md §6.3).
     *
     * @param array<string, scalar|null> $changes Optional column updates (`voucher_no`, `cod_amount`, `cod_collected`, `cod_settlement_ref`, `attempts`, `last_error`, `raw_response`, `last_tracked_at`, `tracking_status`).
     */
    public function transition(
        int $id,
        VoucherState $from,
        VoucherState $to,
        array $changes = [],
    ): bool {
        // The amount may be finalized as the reservation becomes a voucher, but
        // a later state change must never rewrite the issued voucher's price.
        if ($from !== VoucherState::Reserved && array_key_exists('cod_amount', $changes)) {
            throw new \InvalidArgumentException('The COD amount of an issued voucher cannot be changed.');
        }
        $table = $this->schema->vouchersTable();
        $now = gmdate('Y-m-d H:i:s');
        if ($from !== VoucherState::Created && $to === VoucherState::Created) {
            $changes['created_at'] = $now;
        }

        $allowedColumns = [
            'voucher_no' => '%s',
            'created_at' => '%s',
            'tracking_status' => '%s',
            'cod_amount' => '%s',
            'cod_collected' => '%s',
            'cod_reconciled' => '%d',
            'cod_reconciled_at' => '%s',
            'cod_settlement_ref' => '%s',
            'is_printed' => '%d',
            'printed_at' => '%s',
            'attempts' => '%d',
            'last_error' => '%s',
            'raw_response' => '%s',
            'last_tracked_at' => '%s',
        ];

        $setClauses = ['state = %s', 'updated_at = %s'];
        $values = [$to->value, $now];

        foreach ($changes as $column => $value) {
            if (!isset($allowedColumns[$column])) {
                continue;
            }

            if ($value === null) {
                $setClauses[] = '%i = NULL';
                $values[] = $column;
                continue;
            }

            $setClauses[] = '%i = ' . $allowedColumns[$column];
            $values[] = $column;
            $values[] = $value;
        }

        $values[] = $id;
        $values[] = $from->value;

        $setSql = implode(', ', $setClauses);
        $query = \GRCommerceSuite\Database\PreparedQuery::prepare(
            $this->wpdb,
            "UPDATE %i SET {$setSql} WHERE id = %d AND state = %s",
            $table,
            ...$values
        );

        $affected = $this->wpdb->query($query);

        return $affected === 1;
    }

    /**
     * Transition a voucher row to `state = 'unknown'` when an HTTP request times out after transmission (SPEC.md §7).
     * Never blindly retries: ensures the voucher row is persisted with `state = 'unknown'` and `last_error`.
     */
    public function markUnknownOnTimeout(
        int $orderId,
        CourierSlug $courier,
        string $errorMessage,
        ?string $idempotencyKey = null,
    ): void {
        $table = $this->schema->vouchersTable();
        $now = gmdate('Y-m-d H:i:s');

        if ($idempotencyKey !== null && $idempotencyKey !== '') {
            $existing = $this->findByIdempotencyKey($idempotencyKey);
            if ($existing !== null) {
                $id = (int) $existing['id'];
                $currentState = VoucherState::tryFrom((string) $existing['state']) ?? VoucherState::Reserved;
                $attempts = max(1, (int) ($existing['attempts'] ?? 1));

                $this->transition(
                    $id,
                    $currentState,
                    VoucherState::Unknown,
                    [
                        'attempts' => $attempts,
                        'last_error' => $errorMessage,
                    ]
                );

                return;
            }
        }

        // Check for an active reserved row for this order and courier.
        $reservedRow = $this->wpdb->get_row(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT * FROM %i WHERE order_id = %d AND courier_slug = %s AND state = %s ORDER BY id DESC LIMIT 1",
                $table,
                $orderId,
                $courier->value,
                VoucherState::Reserved->value
            ),
            'ARRAY_A'
        );

        if (is_array($reservedRow) && isset($reservedRow['id'])) {
            $this->transition(
                (int) $reservedRow['id'],
                VoucherState::Reserved,
                VoucherState::Unknown,
                [
                    'attempts' => max(1, (int) ($reservedRow['attempts'] ?? 1)),
                    'last_error' => $errorMessage,
                ]
            );

            return;
        }

        // Direct adapter invocation without prior reservation: insert row directly in `unknown` state.
        $derivedKey = $idempotencyKey !== null && strlen($idempotencyKey) === 64
            ? $idempotencyKey
            : hash('sha256', sprintf('grcs|v1|%d|%s|0|1', $orderId, $courier->value));

        $sql = \GRCommerceSuite\Database\PreparedQuery::prepare(
            $this->wpdb,
            "INSERT INTO %i
                (order_id, courier_slug, voucher_no, state, tracking_status, cod_amount, cod_collected,
                 cod_reconciled, cod_reconciled_at, cod_settlement_ref, is_printed, printed_at, idempotency_key,
                 attempts, last_error, raw_response, last_tracked_at, created_at, updated_at)
             VALUES
                (%d, %s, NULL, %s, %s, '0.00', NULL, 0, NULL, NULL, 0, NULL, %s, 1, %s, NULL, NULL, %s, %s)
             ON DUPLICATE KEY UPDATE
                state = VALUES(state),
                attempts = attempts + 1,
                last_error = VALUES(last_error),
                updated_at = VALUES(updated_at)",
            $table,
            $orderId,
            $courier->value,
            VoucherState::Unknown->value,
            TrackingStatus::Pending->value,
            $derivedKey,
            $errorMessage,
            $now,
            $now
        );

        $this->wpdb->query($sql);
    }

    /**
     * Increment retry `attempts` and record `last_error` on a reserved voucher row.
     */
    public function incrementAttempts(int $id, string $lastError): void
    {
        $table = $this->schema->vouchersTable();
        $now = gmdate('Y-m-d H:i:s');

        $this->wpdb->query(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "UPDATE %i SET attempts = attempts + 1, last_error = %s, updated_at = %s WHERE id = %d",
                $table,
                $lastError,
                $now,
                $id
            )
        );
    }

    /**
     * Refresh `updated_at` of a still-`reserved` row immediately before it is dispatched again, so the
     * stale-reservation sweeper never treats an in-flight request as abandoned.
     */
    public function touchReserved(int $id): bool
    {
        $affected = $this->wpdb->query(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "UPDATE %i SET updated_at = %s WHERE id = %d AND state = %s",
                $this->schema->vouchersTable(),
                gmdate('Y-m-d H:i:s'),
                $id,
                VoucherState::Reserved->value
            )
        );

        return $affected === 1;
    }

    /**
     * Update tracking status and `last_tracked_at` when `state = 'created'` (SPEC.md §6.3, §11.2).
     */
    public function updateTracking(
        int $id,
        TrackingStatus $status,
        ?string $rawResponseJson = null,
    ): bool {
        $table = $this->schema->vouchersTable();
        $now = gmdate('Y-m-d H:i:s');

        if ($rawResponseJson !== null) {
            $query = \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "UPDATE %i
                 SET tracking_status = %s, last_tracked_at = %s, raw_response = %s, updated_at = %s
                 WHERE id = %d AND state = %s",
                $table,
                $status->value,
                $now,
                $rawResponseJson,
                $now,
                $id,
                VoucherState::Created->value
            );
        } else {
            $query = \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "UPDATE %i
                 SET tracking_status = %s, last_tracked_at = %s, updated_at = %s
                 WHERE id = %d AND state = %s",
                $table,
                $status->value,
                $now,
                $now,
                $id,
                VoucherState::Created->value
            );
        }

        $updated = $this->wpdb->query($query) !== false;
        if ($updated && function_exists('do_action')) {
            do_action('grcs/tracking/updated', $id, $status);
        }
        return $updated;
    }

    /**
     * Update COD collection & settlement columns (`cod_collected`, `cod_reconciled`, `cod_reconciled_at`, `cod_settlement_ref`) (SPEC.md §10).
     * Returns false for zero affected rows; database execution failures throw.
     *
     * @throws RuntimeException
     */
    public function updateCodReconciliation(
        int $id,
        ?int $collectedAmountCents,
        bool $reconciled,
        ?string $settlementRef,
        ?string $reconciledAtUtc = null,
    ): bool {
        $table = $this->schema->vouchersTable();
        $now = gmdate('Y-m-d H:i:s');

        $reconciledFlag = $reconciled ? 1 : 0;
        $reconciledAt = $reconciled ? ($reconciledAtUtc ?? $now) : null;

        $setClauses = [];
        $setArgs = [];
        $predClauses = [];
        $predArgs = [];

        // Atomically preserve cod_collected when incoming amount is null; write explicit decimal (including zero) when non-null
        if ($collectedAmountCents !== null) {
            $collectedDecimal = Money::fromCents($collectedAmountCents)->toDecimalString();
            $setClauses[] = 'cod_collected = %s';
            $setArgs[] = $collectedDecimal;
            $predClauses[] = 'cod_collected <=> %s';
            $predArgs[] = $collectedDecimal;
        } else {
            $setClauses[] = 'cod_collected = cod_collected';
        }

        // Reconciliation flag and timestamp
        $setClauses[] = 'cod_reconciled = %d';
        $setArgs[] = $reconciledFlag;
        $predClauses[] = 'cod_reconciled = %d';
        $predArgs[] = $reconciledFlag;

        if ($reconciledAt !== null) {
            $setClauses[] = 'cod_reconciled_at = %s';
            $setArgs[] = $reconciledAt;
        } else {
            $setClauses[] = 'cod_reconciled_at = NULL';
        }

        // Atomically preserve cod_settlement_ref when incoming ref is null; write value when non-null
        if ($settlementRef !== null) {
            $cleanRef = trim($settlementRef);
            if ($cleanRef !== '') {
                $setClauses[] = 'cod_settlement_ref = %s';
                $setArgs[] = $cleanRef;
                $predClauses[] = 'cod_settlement_ref <=> %s';
                $predArgs[] = $cleanRef;
            } else {
                $setClauses[] = 'cod_settlement_ref = NULL';
                $predClauses[] = 'cod_settlement_ref IS NULL';
            }
        } else {
            $setClauses[] = 'cod_settlement_ref = cod_settlement_ref';
        }

        $setClauses[] = 'updated_at = %s';
        $setArgs[] = $now;

        $setString = implode(', ', $setClauses);
        $predString = implode(' AND ', $predClauses);

        // Preserve the first partial amount; a final settlement may still promote it.
        $partialGuard = '';
        $partialArgs = [];
        if (!$reconciled && $collectedAmountCents !== null) {
            $partialGuard = ' AND (cod_collected IS NULL OR cod_collected <=> %s)';
            $partialArgs[] = Money::fromCents($collectedAmountCents)->toDecimalString();
        }

        // Settled payouts are immutable. Suppress unchanged mismatches atomically, too:
        // concurrent imports must not both claim a financial transition.
        $sql = "UPDATE %i SET {$setString}
                 WHERE id = %d AND state = %s AND cod_reconciled = 0{$partialGuard}
                   AND NOT ({$predString})";

        $params = array_merge(
            [$table],
            $setArgs,
            [$id, VoucherState::Created->value],
            $partialArgs,
            $predArgs
        );

        $query = \GRCommerceSuite\Database\PreparedQuery::prepare(
            $this->wpdb,
            $sql,
            ...$params
        );
        $updated = $this->wpdb->query($query);
        if ($updated === false) {
            // A database failure must not be mistaken for an unchanged/concurrent row.
            throw new RuntimeException(__('COD settlement database update failed. Earlier entries may already be saved. Please review and retry.', 'gr-commerce-suite'));
        }
        return $updated === 1;
    }

    /**
     * Mark vouchers as printed (`is_printed = 1`, `printed_at = UTC`) (SPEC.md §6.1).
     *
     * @param non-empty-list<string> $voucherNos
     */
    public function markPrinted(array $voucherNos, CourierSlug $courier): void
    {
        if ($voucherNos === []) {
            return;
        }

        $table = $this->schema->vouchersTable();
        $now = gmdate('Y-m-d H:i:s');
        $placeholders = implode(', ', array_fill(0, count($voucherNos), '%s'));

        $params = array_merge([$now, $now, $courier->value], array_values($voucherNos), [VoucherState::Created->value]);

        $this->wpdb->query(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "UPDATE %i
                 SET is_printed = 1, printed_at = %s, updated_at = %s
                 WHERE courier_slug = %s AND voucher_no IN ({$placeholders}) AND state = %s",
                $table,
                ...$params
            )
        );
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findById(int $id): ?array
    {
        $table = $this->schema->vouchersTable();
        $row = $this->wpdb->get_row(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT * FROM %i WHERE id = %d LIMIT 1",
                $table,
                $id
            ),
            'ARRAY_A'
        );

        return is_array($row) ? $row : null;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findByIdempotencyKey(string $idempotencyKey): ?array
    {
        $table = $this->schema->vouchersTable();
        $row = $this->wpdb->get_row(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT * FROM %i WHERE idempotency_key = %s LIMIT 1",
                $table,
                $idempotencyKey
            ),
            'ARRAY_A'
        );

        return is_array($row) ? $row : null;
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findByVoucherNo(CourierSlug $courier, string $voucherNo): ?array
    {
        $table = $this->schema->vouchersTable();
        $row = $this->wpdb->get_row(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT * FROM %i WHERE courier_slug = %s AND voucher_no = %s LIMIT 1",
                $table,
                $courier->value,
                $voucherNo
            ),
            'ARRAY_A'
        );

        return is_array($row) ? $row : null;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function findByOrderId(int $orderId): array
    {
        $table = $this->schema->vouchersTable();
        $rows = $this->wpdb->get_results(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT * FROM %i WHERE order_id = %d ORDER BY id DESC",
                $table,
                $orderId
            ),
            'ARRAY_A'
        );

        return is_array($rows) ? array_values($rows) : [];
    }

    /**
     * Count terminal (`failed` or `cancelled`) rows for an order + courier to compute `n` in idempotency key (SPEC.md §7).
     */
    public function countFailedOrCancelled(int $orderId, CourierSlug $courier): int
    {
        $table = $this->schema->vouchersTable();
        $count = $this->wpdb->get_var(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT COUNT(*) FROM %i WHERE order_id = %d AND courier_slug = %s AND state IN (%s, %s)",
                $table,
                $orderId,
                $courier->value,
                VoucherState::Failed->value,
                VoucherState::Cancelled->value
            )
        );

        return (int) $count;
    }

    /**
     * Candidate `reserved` rows for the stale sweeper, based on the last attempt (`updated_at`), not creation.
     *
     * The sweep decision and its CAS transition belong to `VoucherLockService`, which holds the per-order
     * operation lock and knows whether a transmission was attempted.
     *
     * @return list<array<string, mixed>>
     */
    public function findStaleReserved(string $updatedBeforeUtc, int $limit = 100): array
    {
        $table = $this->schema->vouchersTable();
        $rows = $this->wpdb->get_results(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT * FROM %i WHERE state = %s AND updated_at < %s ORDER BY id ASC LIMIT %d",
                $table,
                VoucherState::Reserved->value,
                $updatedBeforeUtc,
                max(1, min(500, $limit))
            ),
            'ARRAY_A'
        );

        return is_array($rows) ? array_values($rows) : [];
    }

    /**
     * Locate a voucher by `voucher_no`, restricted to the selected courier when supplied (SPEC.md §6.2, §10).
     *
     * @return array<string, mixed>|null
     */
    public function findByVoucherNoAnyCourier(string $voucherNo, ?CourierSlug $courier = null): ?array
    {
        $trimmed = trim($voucherNo);
        if ($trimmed === '') {
            return null;
        }

        if ($courier !== null) {
            return $this->findByVoucherNo($courier, $trimmed);
        }

        $table = $this->schema->vouchersTable();
        $row = $this->wpdb->get_row(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT * FROM %i WHERE voucher_no = %s ORDER BY id DESC LIMIT 1",
                $table,
                $trimmed
            ),
            'ARRAY_A'
        );

        return is_array($row) ? $row : null;
    }

    /**
     * Find all vouchers currently in `state = 'unknown'` requiring admin or automated resolution (SPEC.md §6.3, §7).
     *
     * @return list<array<string, mixed>>
     */
    public function findUnknownVouchers(?CourierSlug $courier = null, int $limit = 100): array
    {
        $table = $this->schema->vouchersTable();
        $safeLimit = max(1, min(500, $limit));

        if ($courier !== null) {
            $rows = $this->wpdb->get_results(
                \GRCommerceSuite\Database\PreparedQuery::prepare(
                    $this->wpdb,
                    "SELECT * FROM %i WHERE state = %s AND courier_slug = %s ORDER BY id DESC LIMIT %d",
                    $table,
                    VoucherState::Unknown->value,
                    $courier->value,
                    $safeLimit
                ),
                'ARRAY_A'
            );
        } else {
            $rows = $this->wpdb->get_results(
                \GRCommerceSuite\Database\PreparedQuery::prepare(
                    $this->wpdb,
                    "SELECT * FROM %i WHERE state = %s ORDER BY id DESC LIMIT %d",
                    $table,
                    VoucherState::Unknown->value,
                    $safeLimit
                ),
                'ARRAY_A'
            );
        }

        return is_array($rows) ? array_values($rows) : [];
    }

    /**
     * Find overdue unpaid COD vouchers where `tracking_status = 'delivered'` more than `$overdueDays` ago,
     * `cod_amount > 0`, and `cod_reconciled = 0` (SPEC.md §10).
     *
     * @return list<array<string, mixed>>
     */
    public function findOverdueUnpaidCodVouchers(
        int $overdueDays = 7,
        ?CourierSlug $courier = null,
        int $limit = 200,
    ): array {
        $table = $this->schema->vouchersTable();
        $safeDays = max(1, $overdueDays);
        $safeLimit = max(1, min(500, $limit));
        $cutoffUtc = gmdate('Y-m-d H:i:s', time() - ($safeDays * 86400));

        if ($courier !== null) {
            $rows = $this->wpdb->get_results(
                \GRCommerceSuite\Database\PreparedQuery::prepare(
                    $this->wpdb,
                    "SELECT * FROM %i
                     WHERE state = %s
                       AND tracking_status = %s
                       AND cod_amount > 0
                       AND cod_reconciled = 0
                       AND courier_slug = %s
                       AND COALESCE(last_tracked_at, updated_at, created_at) <= %s
                     ORDER BY id ASC
                     LIMIT %d",
                    $table,
                    VoucherState::Created->value,
                    TrackingStatus::Delivered->value,
                    $courier->value,
                    $cutoffUtc,
                    $safeLimit
                ),
                'ARRAY_A'
            );
        } else {
            $rows = $this->wpdb->get_results(
                \GRCommerceSuite\Database\PreparedQuery::prepare(
                    $this->wpdb,
                    "SELECT * FROM %i
                     WHERE state = %s
                       AND tracking_status = %s
                       AND cod_amount > 0
                       AND cod_reconciled = 0
                       AND COALESCE(last_tracked_at, updated_at, created_at) <= %s
                     ORDER BY id ASC
                     LIMIT %d",
                    $table,
                    VoucherState::Created->value,
                    TrackingStatus::Delivered->value,
                    $cutoffUtc,
                    $safeLimit
                ),
                'ARRAY_A'
            );
        }

        return is_array($rows) ? array_values($rows) : [];
    }

    /**
     * Find COD vouchers with amount mismatches (`cod_collected IS NOT NULL AND cod_collected != cod_amount AND cod_reconciled = 0`).
     *
     * @return list<array<string, mixed>>
     */
    public function findCodMismatches(?CourierSlug $courier = null, int $limit = 200): array
    {
        $table = $this->schema->vouchersTable();
        $safeLimit = max(1, min(500, $limit));

        if ($courier !== null) {
            $rows = $this->wpdb->get_results(
                \GRCommerceSuite\Database\PreparedQuery::prepare(
                    $this->wpdb,
                    "SELECT * FROM %i
                     WHERE state = %s
                       AND cod_reconciled = 0
                       AND cod_collected IS NOT NULL
                       AND cod_collected <> cod_amount
                       AND courier_slug = %s
                     ORDER BY id DESC
                     LIMIT %d",
                    $table,
                    VoucherState::Created->value,
                    $courier->value,
                    $safeLimit
                ),
                'ARRAY_A'
            );
        } else {
            $rows = $this->wpdb->get_results(
                \GRCommerceSuite\Database\PreparedQuery::prepare(
                    $this->wpdb,
                    "SELECT * FROM %i
                     WHERE state = %s
                       AND cod_reconciled = 0
                       AND cod_collected IS NOT NULL
                       AND cod_collected <> cod_amount
                     ORDER BY id DESC
                     LIMIT %d",
                    $table,
                    VoucherState::Created->value,
                    $safeLimit
                ),
                'ARRAY_A'
            );
        }

        return is_array($rows) ? array_values($rows) : [];
    }

    /**
     * Find all created COD vouchers (`state = 'created' AND cod_amount > 0`) for summary and reporting.
     *
     * @return list<array<string, mixed>>
     */
    public function findCodVouchers(?CourierSlug $courier = null, int $limit = 500): array
    {
        $table = $this->schema->vouchersTable();
        $safeLimit = max(1, min(1000, $limit));

        if ($courier !== null) {
            $rows = $this->wpdb->get_results(
                \GRCommerceSuite\Database\PreparedQuery::prepare(
                    $this->wpdb,
                    "SELECT * FROM %i
                     WHERE state = %s AND cod_amount > 0 AND courier_slug = %s
                     ORDER BY id DESC
                     LIMIT %d",
                    $table,
                    VoucherState::Created->value,
                    $courier->value,
                    $safeLimit
                ),
                'ARRAY_A'
            );
        } else {
            $rows = $this->wpdb->get_results(
                \GRCommerceSuite\Database\PreparedQuery::prepare(
                    $this->wpdb,
                    "SELECT * FROM %i
                     WHERE state = %s AND cod_amount > 0
                     ORDER BY id DESC
                     LIMIT %d",
                    $table,
                    VoucherState::Created->value,
                    $safeLimit
                ),
                'ARRAY_A'
            );
        }

        return is_array($rows) ? array_values($rows) : [];
    }

    /**
     * Find recent vouchers across all states and couriers for admin table display.
     *
     * @return list<array<string, mixed>>
     */
    public function findRecentVouchers(int $limit = 100): array
    {
        $table = $this->schema->vouchersTable();
        $safeLimit = max(1, min(500, $limit));

        $rows = $this->wpdb->get_results(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "SELECT * FROM %i ORDER BY id DESC LIMIT %d",
                $table,
                $safeLimit
            ),
            'ARRAY_A'
        );

        return is_array($rows) ? array_values($rows) : [];
    }

    /**
     * Delete all voucher records associated with a deleted WooCommerce order (SPEC.md §3 C-2).
     */
    /**
     * Cursor pagination keeps background dispatch bounded even on stores with years of voucher history.
     * @return list<array<string, mixed>>
     */
    /**
     * Read-only: vouchers still in flight per courier (reserved/unknown, or created but not yet delivered/returned/cancelled),
     * plus delivered COD vouchers not yet reconciled. Used only for the Modules screen warnings.
     *
     * @return array{open: array<string, int>, cod_unreconciled: int}
     */
    public function countOpenWork(): array
    {
        $table = $this->schema->vouchersTable();
        $rows = $this->wpdb->get_results(\GRCommerceSuite\Database\PreparedQuery::prepare(
            $this->wpdb,
            "SELECT courier_slug, COUNT(*) AS total FROM %i
             WHERE state IN (%s, %s) OR (state = %s AND tracking_status NOT IN ('delivered', 'returned', 'cancelled'))
             GROUP BY courier_slug",
            $table,
            VoucherState::Reserved->value,
            VoucherState::Unknown->value,
            VoucherState::Created->value
        ), 'ARRAY_A');
        $open = [];
        foreach (is_array($rows) ? $rows : [] as $row) {
            $open[(string) $row['courier_slug']] = (int) $row['total'];
        }
        $cod = $this->wpdb->get_var(\GRCommerceSuite\Database\PreparedQuery::prepare(
            $this->wpdb,
            "SELECT COUNT(*) FROM %i WHERE state = %s AND cod_amount > 0 AND cod_reconciled = 0 AND tracking_status = 'delivered'",
            $table,
            VoucherState::Created->value
        ));
        return ['open' => $open, 'cod_unreconciled' => (int) $cod];
    }

    /** @return list<array<string, mixed>> */
    public function findBackgroundPage(int $afterId, bool $codOnly, int $limit = 100): array
    {
        $table = $this->schema->vouchersTable();
        $condition = $codOnly
            ? "cod_amount > 0 AND cod_reconciled = 0 AND tracking_status = 'delivered'"
            : "tracking_status NOT IN ('delivered', 'returned', 'cancelled')";
        $rows = $this->wpdb->get_results(\GRCommerceSuite\Database\PreparedQuery::prepare(
            $this->wpdb,
            "SELECT id, courier_slug FROM %i WHERE id > %d AND state = %s
             AND {$condition} ORDER BY id ASC LIMIT %d",
            $table,
            max(0, $afterId),
            VoucherState::Created->value,
            max(1, min(100, $limit))
        ), 'ARRAY_A');
        return is_array($rows) ? array_values($rows) : [];
    }

    /**
     * Complete day query, with local midnight boundaries converted by the caller to UTC.
     * @return list<array<string, mixed>>
     */
    public function findIssuedBetween(string $startUtc, string $endUtc, ?CourierSlug $courier = null): array
    {
        $table = $this->schema->vouchersTable();
        $condition = $courier !== null ? ' AND courier_slug = %s' : '';
        $params = [$table, 'created', $startUtc, $endUtc];
        if ($courier !== null) {
            $params[] = $courier->value;
        }
        $rows = $this->wpdb->get_results(\GRCommerceSuite\Database\PreparedQuery::prepare(
            $this->wpdb,
            "SELECT * FROM %i WHERE state = %s AND voucher_no IS NOT NULL
             AND created_at >= %s AND created_at < %s{$condition} ORDER BY courier_slug, id ASC",
            ...$params
        ), 'ARRAY_A');
        return is_array($rows) ? array_values($rows) : [];
    }

    public function deleteByOrderId(int $orderId): void
    {
        $table = $this->schema->vouchersTable();
        $this->wpdb->query(
            \GRCommerceSuite\Database\PreparedQuery::prepare(
                $this->wpdb,
                "DELETE FROM %i WHERE order_id = %d",
                $table,
                $orderId
            )
        );
    }
}
