<?php

declare(strict_types=1);

namespace GRCommerceSuite\Database;

use RuntimeException;
use wpdb;

final class PreparedQuery
{
    /** @param literal-string $query */
    public static function prepare(wpdb $db, string $query, mixed ...$args): string
    {
        $prepared = $db->prepare($query, ...$args);
        if (!is_string($prepared) || $prepared === '') {
            throw new RuntimeException(__('Could not prepare the database query.', 'gr-commerce-suite'));
        }
        return $prepared;
    }
}
