<?php

declare(strict_types=1);

namespace GRCommerceSuite;

use GRCommerceSuite\I18n\AdminLocale;

use Automattic\WooCommerce\Utilities\OrderUtil;
use DateTimeImmutable;
use DateTimeZone;
use GRCommerceSuite\Admin\AdminUiAssets;
use GRCommerceSuite\Admin\CodReconciliationPage;
use GRCommerceSuite\Admin\Customer360Page;
use GRCommerceSuite\Admin\OrderMetaboxAndBulkActions;
use GRCommerceSuite\Admin\SettingsPage;
use GRCommerceSuite\Admin\DiagnosticsPanel;
use GRCommerceSuite\Services\DiagnosticLogger;
use GRCommerceSuite\Contracts\CourierProviderInterface;
use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Contracts\VoucherStateTrackerInterface;
use GRCommerceSuite\Contracts\WebhookReceiverInterface;
use GRCommerceSuite\Couriers\AcsProvider;
use GRCommerceSuite\Couriers\BoxNowProvider;
use GRCommerceSuite\Couriers\GenikiProvider;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Database\Schema;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Feed\SkroutzXmlGenerator;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Http\WpHttpClient;
use GRCommerceSuite\Jobs\JobDispatcher;
use GRCommerceSuite\Jobs\BackgroundJobs;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Pdf\PdfMerger;
use GRCommerceSuite\Reconciliation\CodReconciliationService;
use GRCommerceSuite\Sandbox\MockCourierRestController;
use GRCommerceSuite\Security\CredentialVault;
use GRCommerceSuite\Services\CodReconciliationService as LegacyCodReconciliationService;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\CodBlacklistService;
use GRCommerceSuite\Frontend\BankTransferAccounts;
use GRCommerceSuite\Frontend\BoxNowCheckoutPicker;
use GRCommerceSuite\Frontend\CheckoutPaymentRules;
use GRCommerceSuite\Frontend\GreekInvoiceCheckout;
use GRCommerceSuite\Services\AadeRegistryLookup;
use GRCommerceSuite\Admin\CourierConnectionTest;
use GRCommerceSuite\Services\TrackingService;
use GRCommerceSuite\Services\VoucherLockService;
use GRCommerceSuite\Services\VoucherService;
use GRCommerceSuite\Support\Logger;
use InvalidArgumentException;
use Throwable;
use WC_Order;
use WC_Settings_Page;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Main Plugin Kernel (SPEC.md §5.2).
 *
 * Builds the service container, registers courier providers, runs idempotent versioned migrations,
 * and wires all HookSubscriberInterface services, REST routes, and WooCommerce / Action Scheduler hooks.
 */
final class Plugin implements HookSubscriberInterface
{
    public const REST_NAMESPACE = 'grcs/v1';

    private static bool $booted = false;

    private static ?self $instance = null;

    /**
     * @var array<string, object>
     */
    private array $services = [];

    /**
     * @var list<HookSubscriberInterface>
     */
    private array $subscribers = [];

    private bool $runtimeReady = false;

    private bool $checkoutReady = false;

    private function __construct(
        private readonly string $pluginFile,
    ) {
    }

    /**
     * True for provider callback REST routes (`grcs/v1/webhooks/*`, `grcs/v1/klarna/*`). Detected from the URL because
     * REST_REQUEST is not defined yet at plugins_loaded; covers pretty (`/wp-json/`) and plain (`?rest_route=`) forms.
     */
    private static function isProviderCallbackRequest(): bool
    {
        $candidates = [];
        foreach ([$_GET['rest_route'] ?? null, $_SERVER['REQUEST_URI'] ?? null] as $value) {
            if (is_string($value)) {
                $candidates[] = rawurldecode($value);
            }
        }
        $prefix = function_exists('rest_get_url_prefix') ? rest_get_url_prefix() : 'wp-json';
        // /wp-json/grcs/v1/..., /index.php?rest_route=/grcs/v1/..., or a bare rest_route value (/grcs/v1/...).
        $pattern = '#(?:^|[/=])(?:' . preg_quote($prefix, '#') . '/|rest_route=/?)?grcs/v1/(?:webhooks|klarna)(?:[/?&]|$)#';
        foreach ($candidates as $candidate) {
            if (preg_match($pattern, $candidate) === 1) {
                return true;
            }
        }
        return false;
    }

    /** Hook target for woocommerce_order_status_changed (see boot()). */
    public static function noteDeadOrderVouchers(int $orderId, string $from = '', string $to = '', mixed $order = null): void
    {
        if (!in_array($to, ['cancelled', 'refunded', 'failed'], true)) {
            return;
        }
        (new OrderMetaboxAndBulkActions(voucherRepository: VoucherRepository::fromGlobals()))
            ->noteActiveVoucherOnDeadOrder($orderId, $from, $to, $order);
    }

    /**
     * Idempotent kernel entry point invoked by `gr-commerce-suite.php` on `plugins_loaded@20` (SPEC.md §5.2).
     */
    public static function boot(string $pluginFile): void
    {
        if (self::$booted) {
            return;
        }

        self::$booted = true;
        $kernel = new self($pluginFile);
        self::$instance = $kernel;

        // ZIP updates do not fire activation hooks. Check on plugins_loaded for every request.
        // A database upgrade failure must not suppress customer checkout hooks.
        try {
            // Provider callbacks never run DDL (decision 2026-11-02 e); the next normal request upgrades.
            if (get_option(Schema::VERSION_OPTION, '') !== GRCS_VERSION && !self::isProviderCallbackRequest()) {
                Schema::fromGlobals()->maybeUpgrade();
            }
        } catch (Throwable $error) {
            (new Logger('gr-commerce-suite'))->error('Schema upgrade failed: ' . $error->getMessage());
            add_action('admin_notices', static function (): void {
                if (current_user_can('manage_woocommerce')) {
                    echo '<div class="notice notice-warning"><p>'
                        . AdminLocale::esc_html__('GR Commerce Suite database upgrade failed. Review the logs and database permissions; the upgrade will retry automatically.', 'gr-commerce-suite')
                        . '</p></div>';
                }
            });
        }

        (new \GRCommerceSuite\Shipping\ShippingMethods())->register();

        // Klarna payments: historical order operations (refund, capture, cancel) are always wired; the checkout surface and
        // callback routes only while the module is on. NEW Klarna sessions/authorisations/orders additionally need an active GRCS licence
        // (checked inside the Klarna module); callbacks, capture, cancel, refund and reconciliation of existing orders never do.
        (new \GRCommerceSuite\Modules\Klarna\KlarnaLifecycle())->register();
        if (ModuleRegistry::isEnabled(ModuleRegistry::KLARNA)) {
            (new \GRCommerceSuite\Modules\Klarna\KlarnaSubscriber())->register();
            (new \GRCommerceSuite\Modules\Klarna\KlarnaRestController(
                \GRCommerceSuite\Modules\Klarna\KlarnaServices::sessions(),
                \GRCommerceSuite\Modules\Klarna\KlarnaServices::logger()
            ))->register();
        }

        // WooCommerce can send emails from a public request before checkout/runtime is loaded.
        (new GreekInvoiceCheckout())->registerEmailHooks();
        (new BankTransferAccounts())->registerEmailHooks();
        (new CheckoutPaymentRules())->registerInstructionHooks();
        (new BoxNowCheckoutPicker(new CourierRegistry()))->registerOrderHooks();

        // Dead-order voucher note (cancelled/refunded/failed): always on, so storefront payment callbacks and
        // expired licences are covered. One note per voucher row (deduplicated); never calls a courier.
        add_action('woocommerce_order_status_changed', [self::class, 'noteDeadOrderVouchers'], 10, 4);

        if (is_admin() || wp_doing_cron() || defined('REST_REQUEST') || (defined('WP_CLI') && WP_CLI)) {
            $kernel->initializeRuntime();
        } else {
            // REST_REQUEST is defined after plugins_loaded. Wait for the actual REST bootstrap.
            add_action('woocommerce_order_status_completed', static function (int $orderId, \WC_Order $order) use ($kernel): void {
                if (
                    !$kernel->runtimeReady && LicenseManager::isLicensed()
                    && get_option(\GRCommerceSuite\Services\ShippingOptions::AUTO_ISSUE, 'no') === 'yes'
                ) {
                    $kernel->initializeRuntime();
                    $kernel->orderMetaboxAndBulkActions()->autoIssueCompleted($orderId, $order);
                }
            }, 0, 2);
            add_action('rest_api_init', [$kernel, 'initializeRuntime'], 0);
            add_action('wp', [$kernel, 'initializeCheckout'], 0);
        }
    }

    public function initializeRuntime(): void
    {
        if ($this->runtimeReady) {
            return;
        }
        if (CredentialVault::encryptionAvailable()) {
            (new CredentialVault())->migrateLegacySecrets();
        } else {
            add_action('admin_notices', static function (): void {
                if (current_user_can('manage_woocommerce') || current_user_can('grcs_manage_settings')) {
                    echo '<div class="notice notice-error"><p>'
                        . AdminLocale::esc_html__('GR Commerce Suite: ', 'gr-commerce-suite')
                        . AdminLocale::esc_html__(CredentialVault::ENCRYPTION_UNAVAILABLE, 'gr-commerce-suite') . '</p></div>';
                }
            });
        }
        $this->runInstallMigrations();
        $this->buildContainer();
        foreach ($this->subscribers as $subscriber) {
            $subscriber->register();
        }
        $this->runtimeReady = true;
    }

    public function initializeCheckout(): void
    {
        if ($this->runtimeReady || $this->checkoutReady || !BoxNowCheckoutPicker::isCheckoutRequest()) {
            return;
        }
        $this->checkoutReady = true;
        $registry = new CourierRegistry();
        $registry->register(CourierSlug::BoxNow, static function (): CourierProviderInterface {
            return new BoxNowProvider(new WpHttpClient(), (new CredentialVault())->getForCourier(CourierSlug::BoxNow));
        });
        $blacklist = new CodBlacklistService();
        $picker = new BoxNowCheckoutPicker($registry);
        $invoice = new GreekInvoiceCheckout(new AadeRegistryLookup(new WpHttpClient(), new CredentialVault()));
        $this->services = [CodBlacklistService::class => $blacklist, BoxNowCheckoutPicker::class => $picker,
            GreekInvoiceCheckout::class => $invoice];
        if (LicenseManager::isLicensed()) {
            $blacklist->registerCheckoutHooks();
        }
        if (ModuleRegistry::anyCourierEnabled()) {
            (new \GRCommerceSuite\Shipping\CheckoutShippingValidation())->register();
        }
        if (ModuleRegistry::courierCanCreate(CourierSlug::BoxNow)) {
            $picker->register();
            $picker->registerBlockField();
        }
        $invoice->register();
        $invoice->registerBlockFields();
        (new CheckoutPaymentRules())->register();
        $bank = new BankTransferAccounts();
        $bank->register();
        $bank->registerBlockFields();
    }

    public static function instance(): ?self
    {
        return self::$instance;
    }

    public static function isBooted(): bool
    {
        return self::$booted;
    }

    public function pluginFile(): string
    {
        return $this->pluginFile;
    }

    /**
     * Retrieve a wired service from the kernel container.
     */
    public function get(string $id): object
    {
        if (!isset($this->services[$id])) {
            throw new InvalidArgumentException(sprintf(__('Service "%s" is not registered in the GRCS container.', 'gr-commerce-suite'), $id));
        }

        return $this->services[$id];
    }

    public function has(string $id): bool
    {
        return isset($this->services[$id]);
    }

    public function courierRegistry(): CourierRegistry
    {
        /** @var CourierRegistry $registry */
        $registry = $this->get(CourierRegistry::class);

        return $registry;
    }

    public function voucherRepository(): VoucherRepository
    {
        /** @var VoucherRepository $repository */
        $repository = $this->get(VoucherRepository::class);

        return $repository;
    }

    public function voucherLockService(): VoucherLockService
    {
        /** @var VoucherLockService $service */
        $service = $this->get(VoucherLockService::class);

        return $service;
    }

    public function voucherService(): VoucherService
    {
        /** @var VoucherService $service */
        $service = $this->get(VoucherService::class);

        return $service;
    }

    public function trackingService(): TrackingService
    {
        /** @var TrackingService $service */
        $service = $this->get(TrackingService::class);

        return $service;
    }

    public function codReconciliationService(): CodReconciliationService
    {
        /** @var CodReconciliationService $service */
        $service = $this->get(CodReconciliationService::class);

        return $service;
    }

    public function codReconciliationPage(): CodReconciliationPage
    {
        /** @var CodReconciliationPage $page */
        $page = $this->get(CodReconciliationPage::class);

        return $page;
    }

    public function sandboxController(): MockCourierRestController
    {
        /** @var MockCourierRestController $controller */
        $controller = $this->get(MockCourierRestController::class);

        return $controller;
    }

    public function skroutzXmlGenerator(): SkroutzXmlGenerator
    {
        /** @var SkroutzXmlGenerator $service */
        $service = $this->get(SkroutzXmlGenerator::class);

        return $service;
    }

    public function orderMetaboxAndBulkActions(): OrderMetaboxAndBulkActions
    {
        /** @var OrderMetaboxAndBulkActions $service */
        $service = $this->get(OrderMetaboxAndBulkActions::class);

        return $service;
    }

    public function licenseManager(): LicenseManager
    {
        /** @var LicenseManager $service */
        $service = $this->get(LicenseManager::class);

        return $service;
    }

    /**
     * Register core kernel hooks (REST API, Action Scheduler recurring jobs, HPOS order lifecycle & search).
     */
    public function register(): void
    {
        if (!function_exists('add_action') || !function_exists('add_filter')) {
            return;
        }

        // WooCommerce Settings Tab (lazy-loaded after WC_Settings_Page is initialized)
        add_filter('woocommerce_get_settings_pages', [$this, 'registerSettingsPage']);
        // Before the licence gate: tracking/COD schedules on existing vouchers run unlicensed; the job gates the rest itself.
        add_action('action_scheduler_init', [$this, 'registerRecurringJobs']);

        if (!LicenseManager::isLicensed()) {
            return;
        }

        add_action('rest_api_init', [$this, 'registerRestRoutes']);

        // HPOS and legacy CRUD order deletion cleanup (SPEC.md §3 C-2)
        add_action('woocommerce_before_delete_order', [$this, 'handleOrderDelete'], 10, 1);
        add_action('before_delete_post', [$this, 'handleLegacyOrderDelete'], 10, 1);

        // Register `_grcs_last_voucher_no` for admin order search in HPOS and legacy storage (SPEC.md §6.5)
        add_filter('woocommerce_order_table_search_query_meta_keys', [$this, 'registerOrderSearchMetaKeys']);
        $legacySearchHook = 'woocommerce_shop' . '_order_search_fields';
        add_filter($legacySearchHook, [$this, 'registerOrderSearchMetaKeys']);

        // Background job handlers (SPEC.md §9.1)
        add_action(JobDispatcher::HOOK_SWEEP_STALE, [$this, 'handleSweepStaleVouchers']);
    }

    /**
     * @param list<WC_Settings_Page> $settings
     * @return list<WC_Settings_Page>
     */
    public function registerSettingsPage(array $settings): array
    {
        $settings[] = new SettingsPage();

        return $settings;
    }

    /**
     * Register core REST routes under `grcs/v1` (SPEC.md §9.6, §15.3).
     */
    public function registerRestRoutes(): void
    {
        if (!LicenseManager::isLicensed() || !function_exists('register_rest_route')) {
            return;
        }

        register_rest_route(
            self::REST_NAMESPACE,
            '/batches/(?P<id>[a-fA-F0-9-]{8,64})',
            [
                'methods' => 'GET',
                'callback' => [$this, 'handleGetBatchStatus'],
                'permission_callback' => [$this, 'canManageVouchers'],
            ]
        );

        register_rest_route(
            self::REST_NAMESPACE,
            '/vouchers',
            [
                'methods' => 'POST',
                'callback' => [$this, 'handleCreateVoucherRest'],
                'permission_callback' => [$this, 'canManageVouchers'],
            ]
        );

        // A disabled module exposes no endpoint at all (404), not an authenticated no-op.
        if (ModuleRegistry::isEnabled(ModuleRegistry::BOXNOW)) {
            register_rest_route(
                self::REST_NAMESPACE,
                '/webhooks/boxnow',
                [
                    'methods' => 'POST',
                    'callback' => [$this, 'handleBoxNowWebhook'],
                    'permission_callback' => [$this, 'verifyBoxNowWebhookSignature'],
                ]
            );
        }

        if (ModuleRegistry::isEnabled(ModuleRegistry::SKROUTZ)) {
            register_rest_route(
                self::REST_NAMESPACE,
                '/feeds/skroutz/generate',
                [
                    'methods' => 'POST',
                    'callback' => [$this, 'handleGenerateSkroutzFeedRest'],
                    'permission_callback' => [$this, 'canManageSettings'],
                ]
            );
        }
    }

    public function handleGenerateSkroutzFeedRest(): WP_REST_Response|WP_Error
    {
        try {
            $path = $this->skroutzXmlGenerator()->generateAll();
            $report = get_option(SkroutzXmlGenerator::OPTION_LAST_RUN, []);
            $count = is_array($report) ? (int) ($report['products_written'] ?? 0) : 0;

            return new WP_REST_Response(
                [
                    'generated' => true,
                    'items_count' => $count,
                    'path' => $path,
                ],
                200
            );
        } catch (Throwable $e) {
            return new WP_Error('grcs_feed_error', $e->getMessage(), ['status' => 500]);
        }
    }

    public function canManageSettings(): bool
    {
        return LicenseManager::isLicensed() && (current_user_can('manage_woocommerce') || current_user_can('grcs_manage_settings'));
    }

    public function canManageVouchers(): bool
    {
        if (!LicenseManager::isLicensed() || !function_exists('current_user_can')) {
            return false;
        }

        return current_user_can('manage_woocommerce') || current_user_can('grcs_manage_vouchers');
    }

    public function handleGetBatchStatus(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $batchId = function_exists('sanitize_text_field')
            ? sanitize_text_field((string) $request->get_param('id'))
            : trim((string) $request->get_param('id'));

        $optionName = 'grcs_batch_' . $batchId;
        $progress = function_exists('get_option') ? get_option($optionName, null) : null;

        if (!is_array($progress)) {
            return new WP_Error('grcs_batch_not_found', 'Batch not found.', ['status' => 404]);
        }

        return new WP_REST_Response($progress, 200);
    }

    public function handleCreateVoucherRest(WP_REST_Request $request): WP_REST_Response|WP_Error
    {
        $orderId = function_exists('absint')
            ? absint($request->get_param('order_id'))
            : max(0, (int) $request->get_param('order_id'));

        $courierRaw = function_exists('sanitize_text_field')
            ? sanitize_text_field((string) $request->get_param('courier'))
            : trim((string) $request->get_param('courier'));

        $courier = CourierSlug::tryFrom(strtolower($courierRaw));
        if ($orderId <= 0 || $courier === null) {
            return new WP_Error(
                'grcs_invalid_params',
                'Valid order_id and courier slug are required.',
                ['status' => 400]
            );
        }

        if (!function_exists('wc_get_order')) {
            return new WP_Error('grcs_wc_missing', 'WooCommerce order API is unavailable.', ['status' => 500]);
        }

        $order = wc_get_order($orderId);
        if (!$order instanceof WC_Order) {
            return new WP_Error('grcs_order_not_found', 'Order not found.', ['status' => 404]);
        }

        try {
            $result = $this->voucherService()->createForOrder($order, $courier);

            return new WP_REST_Response(
                [
                    'voucher_no' => $result->voucherNo,
                    'courier' => $result->courier->value,
                    'cod_amount_cents' => $result->codAmountCents,
                    'parcel_count' => $result->parcelCount,
                    'tracking_url' => $result->trackingUrl,
                    'locker_id' => $result->lockerId,
                ],
                201
            );
        } catch (Throwable $e) {
            return new WP_Error(
                'grcs_voucher_error',
                $e->getMessage(),
                ['status' => 422]
            );
        }
    }

    /**
     * Verify BOX NOW webhook HMAC signature with `hash_equals` and reject replays > 5 min (SPEC.md §15.3).
     */
    public function verifyBoxNowWebhookSignature(WP_REST_Request $request): bool
    {
        if (!LicenseManager::isLicensed()) {
            return false;
        }

        /** @var CredentialVault $vault */
        $vault = $this->get(CredentialVault::class);
        $credentials = $vault->getForCourier(CourierSlug::BoxNow);
        $secret = trim((string) ($credentials['webhook_secret'] ?? ''));

        if ($secret === '') {
            return false;
        }

        $signature = trim((string) ($request->get_header('x-boxnow-signature') ?? ''));
        if ($signature === '') {
            return false;
        }

        $timestampHeader = trim((string) ($request->get_header('x-boxnow-timestamp') ?? ''));
        if ($timestampHeader === '' || !ctype_digit($timestampHeader) || abs(time() - (int) $timestampHeader) > 300) {
            return false;
        }

        $computed = hash_hmac('sha256', (string) $request->get_body(), $secret);

        return hash_equals($computed, $signature);
    }

    public function handleBoxNowWebhook(WP_REST_Request $request): WP_REST_Response
    {
        LicenseManager::assertLicensed();

        $provider = $this->courierRegistry()->get(CourierSlug::BoxNow);
        if ($provider instanceof WebhookReceiverInterface) {
            $results = $provider->parseWebhook($request);
            foreach ($results as $trackingResult) {
                $row = $this->voucherRepository()->findByVoucherNo(CourierSlug::BoxNow, $trackingResult->voucherNo);
                if ($row !== null && isset($row['id'])) {
                    if (count(\GRCommerceSuite\Services\ShippingOptions::voucherNumbers($row)) > 1) {
                        // A single parcel event cannot establish delivery of the whole shipment.
                        try {
                            $this->trackingService()->pollVoucherById((int) $row['id']);
                        } catch (\Throwable) {
                            (new Logger('gr-commerce-suite'))->warning('Multi-parcel webhook sync deferred to tracking poll.', [
                                'voucher_id' => (int) $row['id'],
                            ]);
                        }
                        continue;
                    }
                    $this->voucherRepository()->updateTracking((int) $row['id'], $trackingResult->status);
                }
            }
        }

        return new WP_REST_Response(['accepted' => true], 202);
    }

    /**
     * Register recurring Action Scheduler jobs when `grcs_recurring_jobs_version !== GRCS_VERSION` (SPEC.md §5.2, §9.1).
     */
    public function registerRecurringJobs(): void
    {
        if (!function_exists('get_option') || !function_exists('update_option')) {
            return;
        }

        $version = defined('GRCS_VERSION') ? (string) constant('GRCS_VERSION') : '0.1.0';
        $registeredVersion = (string) get_option('grcs_recurring_jobs_version', '');

        /** @var JobDispatcher $dispatcher */
        $dispatcher = $this->get(JobDispatcher::class);
        $now = time();

        // Licence-gated: stale reservation sweeper every 15 minutes
        if (LicenseManager::isLicensed()) {
            $dispatcher->ensureRecurring($now + 60, 15 * 60, JobDispatcher::HOOK_SWEEP_STALE);
        } else {
            ModuleRegistry::cancelPending(JobDispatcher::HOOK_SWEEP_STALE);
        }

        // Modules: schedules exist only for enabled modules. Evaluated on every init, so re-enabling heals by itself.
        // 2. Tracking poll dispatcher every 2 hours (any courier module) — ungated per owner decision 2026-11-03.
        if (ModuleRegistry::anyCourierEnabled()) {
            $dispatcher->ensureRecurring($now + 120, 2 * 3600, JobDispatcher::HOOK_TRACKING_DISPATCH);
        } else {
            ModuleRegistry::cancelPending(JobDispatcher::HOOK_TRACKING_DISPATCH);
        }

        // 3. COD reconciliation dispatcher daily at 06:00 Europe/Athens (wp_timezone()) — ungated per owner decision 2026-11-03.
        if (ModuleRegistry::isEnabled(ModuleRegistry::COD_AUTO) && ModuleRegistry::anyCourierEnabled()) {
            $nextSixAmUtc = $this->computeNextSixAmUtcTimestamp();
            $dispatcher->ensureRecurring($nextSixAmUtc, 24 * 3600, JobDispatcher::HOOK_COD_DISPATCH);
        } else {
            ModuleRegistry::cancelPending(JobDispatcher::HOOK_COD_DISPATCH);
        }

        // 4. Skroutz feed refresh every 12 h (D7, owner-approved 2026-11-04): only when licensed, module on, feed enabled and
        // the auto-refresh option on. Any other state withdraws the pending schedule (settings and published files stay).
        if ($this->skroutzXmlGenerator()->autoRefreshEnabled()) {
            $dispatcher->ensureRecurring($now + 300, SkroutzXmlGenerator::AUTO_REFRESH_INTERVAL, SkroutzXmlGenerator::HOOK_SCHEDULED);
        } else {
            ModuleRegistry::cancelPending(SkroutzXmlGenerator::HOOK_SCHEDULED);
        }

        // Retire the old no-op purge hook. Financial history is never purged on a timer.
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions(JobDispatcher::HOOK_MAINTENANCE_PURGE, [], JobDispatcher::GROUP);
        }

        // Version option write stays licence-gated (only update when licensed to avoid unnecessary writes).
        if (LicenseManager::isLicensed() && $registeredVersion !== $version) {
            update_option('grcs_recurring_jobs_version', $version, true);
        }
    }

    /**
     * Clean up voucher records when an order is deleted via HPOS / WooCommerce CRUD (SPEC.md §3 C-2).
     */
    public function handleOrderDelete(mixed $orderId): void
    {
        $id = is_numeric($orderId) ? (int) $orderId : 0;
        if ($id > 0) {
            $this->voucherRepository()->deleteByOrderId($id);
        }
    }

    /**
     * Clean up voucher records when an order is deleted via legacy post deletion, guarded by `OrderUtil::is_order` (SPEC.md §3 C-2).
     */
    public function handleLegacyOrderDelete(mixed $postId): void
    {
        $id = is_numeric($postId) ? (int) $postId : 0;
        if ($id <= 0) {
            return;
        }

        if (class_exists(OrderUtil::class)) {
            if (!OrderUtil::is_order($id)) {
                return;
            }
        }

        $this->voucherRepository()->deleteByOrderId($id);
    }

    /**
     * Append `_grcs_last_voucher_no` to WooCommerce admin order search fields (SPEC.md §6.5).
     *
     * @param array<int|string, mixed> $searchFields
     * @return array<int|string, mixed>
     */
    public function registerOrderSearchMetaKeys(array $searchFields): array
    {
        if (!in_array('_grcs_last_voucher_no', $searchFields, true)) {
            $searchFields[] = '_grcs_last_voucher_no';
        }

        return $searchFields;
    }

    /**
     * Sweeper handler moving `reserved` rows older than 10 minutes to `state = 'unknown'` (SPEC.md §7).
     */
    public function handleSweepStaleVouchers(): void
    {
        LicenseManager::assertLicensed();

        $this->voucherLockService()->sweepStaleReservations();
    }

    /**
     * Build the service container and wire all Phase 1 dependencies (SPEC.md §4.1, §5.2).
     */
    private function buildContainer(): void
    {
        $schema = Schema::fromGlobals();
        $repository = VoucherRepository::fromGlobals($schema);
        $logger = new Logger('gr-commerce-suite');
        $vault = new CredentialVault();
        $httpClient = new WpHttpClient();
        $pdfMerger = new PdfMerger();
        $jobDispatcher = new JobDispatcher();

        $registry = new CourierRegistry();
        $voucherLockService = new VoucherLockService($repository, $registry, $jobDispatcher, $logger);

        $registry->register(
            CourierSlug::Acs,
            static function () use (
                $httpClient,
                $vault,
                $logger,
                $pdfMerger,
                $voucherLockService
            ): CourierProviderInterface {
                /** @var array{api_key?: string, company_id?: string, company_password?: string, user_id?: string, user_password?: string, billing_code?: string, sender_name?: string, language?: string, endpoint_url?: string, cod_cash_limit_cents?: int} $acsCreds */
                $acsCreds = $vault->getForCourier(CourierSlug::Acs);

                return new AcsProvider(
                    httpClient: $httpClient,
                    credentials: $acsCreds,
                    logger: $logger->withSource('grcs-acs'),
                    pdfMerger: $pdfMerger,
                    stateTracker: $voucherLockService,
                );
            }
        );

        $registry->register(
            CourierSlug::BoxNow,
            static function () use (
                $httpClient,
                $vault,
                $logger,
                $pdfMerger,
                $voucherLockService
            ): CourierProviderInterface {
                /** @var array{client_id?: string, client_secret?: string, partner_id?: string, origin_location_id?: string, origin_contact_name?: string, origin_contact_phone?: string, origin_contact_email?: string, webhook_secret?: string, environment?: string, base_url?: string, cod_cash_limit_cents?: int} $boxNowCreds */
                $boxNowCreds = $vault->getForCourier(CourierSlug::BoxNow);

                return new BoxNowProvider(
                    httpClient: $httpClient,
                    credentials: $boxNowCreds,
                    logger: $logger->withSource('grcs-boxnow'),
                    pdfMerger: $pdfMerger,
                    stateTracker: $voucherLockService,
                );
            }
        );

        $registry->register(CourierSlug::Geniki, static function () use ($httpClient, $vault, $logger, $pdfMerger, $voucherLockService): CourierProviderInterface {
            /** @var array{username?: string, password?: string, application_key?: string, environment?: string, endpoint_url?: string, default_service_code?: string, cod_service_code?: string, cod_cash_limit_cents?: int|string} $genikiCredentials */
            $genikiCredentials = $vault->getForCourier(CourierSlug::Geniki);
            return new GenikiProvider(
                httpClient: $httpClient,
                credentials: $genikiCredentials,
                logger: $logger->withSource('grcs-geniki'),
                pdfMerger: $pdfMerger,
                stateTracker: $voucherLockService,
            );
        });
        if (function_exists('do_action')) {
            do_action('grcs/couriers/register', $registry);
        }

        $voucherService = new VoucherService($repository, $registry, $jobDispatcher, $logger);
        $trackingService = new TrackingService($repository, $registry, $logger);
        $codReconciliationService = new CodReconciliationService($repository, $registry, $logger);
        $legacyCodService = new LegacyCodReconciliationService($repository, $registry, $logger);
        $blacklist = LicenseManager::isLicensed() ? new CodBlacklistService($repository, $jobDispatcher) : null;
        $codReconciliationPage = new CodReconciliationPage(
            reconciliationService: $codReconciliationService,
            voucherLockService: $voucherLockService,
            logger: $logger,
            voucherRepository: $repository,
            blacklist: $blacklist,
        );
        add_action('grcs/voucher/created', [\GRCommerceSuite\Pdf\VoucherLabelGenerator::class, 'voucherCreated'], 10, 3);
        $sandboxController = new MockCourierRestController($voucherLockService);
        $skroutzGenerator = new SkroutzXmlGenerator($jobDispatcher, $logger);
        $orderMetaboxAndBulkActions = new OrderMetaboxAndBulkActions(
            voucherService: $voucherService,
            voucherRepository: $repository,
            courierRegistry: $registry,
            logger: $logger,
            pdfMerger: $pdfMerger,
            blacklist: $blacklist,
        );
        $licenseManager = new LicenseManager();

        $this->services = [
            Schema::class => $schema,
            VoucherRepository::class => $repository,
            VoucherLockService::class => $voucherLockService,
            VoucherStateTrackerInterface::class => $voucherLockService,
            Logger::class => $logger,
            LoggerInterface::class => $logger,
            CredentialVault::class => $vault,
            WpHttpClient::class => $httpClient,
            HttpClientInterface::class => $httpClient,
            PdfMerger::class => $pdfMerger,
            CourierRegistry::class => $registry,
            JobDispatcher::class => $jobDispatcher,
            VoucherService::class => $voucherService,
            TrackingService::class => $trackingService,
            CodReconciliationService::class => $codReconciliationService,
            LegacyCodReconciliationService::class => $legacyCodService,
            CodReconciliationPage::class => $codReconciliationPage,
            MockCourierRestController::class => $sandboxController,
            SkroutzXmlGenerator::class => $skroutzGenerator,
            OrderMetaboxAndBulkActions::class => $orderMetaboxAndBulkActions,
            LicenseManager::class => $licenseManager,
        ];

        $this->subscribers = [
            $this,
            $licenseManager,
            $codReconciliationPage,
            new Customer360Page(vouchers: $repository),
            // Shared admin stylesheet/script for plugin screens (loaded even when locked for the license banner).
            new AdminUiAssets(),
            new DiagnosticLogger(),
            new DiagnosticsPanel(),
            new \GRCommerceSuite\Modules\Geniki\MerchantFinalization($registry, $vault),
        ];

        // Storefront shipping, locker and invoice capture survive license expiry/outages.
        $picker = new BoxNowCheckoutPicker($registry);
        $aadeLookup = new AadeRegistryLookup($httpClient, $vault);
        $invoice = new GreekInvoiceCheckout($aadeLookup);
        if (is_admin() && ModuleRegistry::isEnabled(ModuleRegistry::AADE_B2B)) {
            $this->subscribers[] = \GRCommerceSuite\Modules\AadeB2b\Module::create($aadeLookup, $vault);
        }
        $this->services[BoxNowCheckoutPicker::class] = $picker;
        $this->services[GreekInvoiceCheckout::class] = $invoice;
        if (ModuleRegistry::anyCourierEnabled()) {
            $this->subscribers[] = new \GRCommerceSuite\Shipping\CheckoutShippingValidation();
        }
        if (ModuleRegistry::courierCanCreate(CourierSlug::BoxNow)) {
            $this->subscribers[] = $picker;
        }
        // initializeCheckout() already registered this subscriber when it ran first.
        if (!$this->checkoutReady) {
            $this->subscribers[] = $invoice;
        }
        $this->subscribers[] = new CheckoutPaymentRules();
        $this->subscribers[] = new BankTransferAccounts();

        // Always wired (owner decision 2026-11-03): tracking, lookupUnknown and COD work on existing vouchers survive
        // licence expiry; register() adds handlers per enabled module and keeps retryVoucher (issuance) licence-gated.
        $background = new BackgroundJobs(
            $repository,
            $registry,
            $jobDispatcher,
            $trackingService,
            $legacyCodService,
            $voucherLockService
        );
        $this->services[BackgroundJobs::class] = $background;
        $this->subscribers[] = $background;

        if ($blacklist !== null) {
            $connectionTest = new CourierConnectionTest($httpClient, $vault);
            $this->services[CodBlacklistService::class] = $blacklist;
            $this->services[BoxNowCheckoutPicker::class] = $picker;
            $this->services[GreekInvoiceCheckout::class] = $invoice;
            $this->services[CourierConnectionTest::class] = $connectionTest;
            $this->subscribers[] = $blacklist;
            if (ModuleRegistry::anyCourierEnabled()) {
                $this->subscribers[] = $connectionTest;
            }
            $this->subscribers[] = $sandboxController;
            if (ModuleRegistry::isEnabled(ModuleRegistry::SKROUTZ)) {
                $this->subscribers[] = $skroutzGenerator;
            }
        }
        // Always wired: view/print/cancel of existing vouchers survive licence expiry; only issuance is gated inside.
        $this->subscribers[] = $orderMetaboxAndBulkActions;
    }

    /**
     * Run idempotent versioned migrations when `grcs_install_version !== GRCS_VERSION` (SPEC.md §5.2, §15.1).
     */
    private function runInstallMigrations(): void
    {
        if (!function_exists('get_option') || !function_exists('update_option')) {
            return;
        }

        $version = defined('GRCS_VERSION') ? (string) constant('GRCS_VERSION') : '0.1.0';
        $installedVersion = (string) get_option('grcs_install_version', '');

        if ($installedVersion === $version) {
            return;
        }

        $this->registerCapabilities();

        $existingSettings = get_option('grcs_settings', null);
        if (!is_array($existingSettings)) {
            $defaultSandbox = (defined('GRCS_SANDBOX_MODE') && !(bool) constant('GRCS_SANDBOX_MODE')) ? 'no' : 'yes';
            update_option(
                'grcs_settings',
                [
                    'sandbox_mode' => $defaultSandbox,
                    'cod_cash_limit_cents' => 50000,
                ],
                true
            );
        }

        if (get_option('grcs_sandbox_mode', null) === null) {
            $defaultSandbox = (new LicenseManager())->isSandboxEnabled() ? 'yes' : 'no';
            update_option('grcs_sandbox_mode', $defaultSandbox, true);
        }

        update_option('grcs_install_version', $version, true);
    }

    /**
     * Grant plugin capabilities to `administrator` and `shop_manager` roles (SPEC.md §15.1).
     */
    private function registerCapabilities(): void
    {
        if (!function_exists('get_role')) {
            return;
        }

        $adminRole = get_role('administrator');
        if (is_object($adminRole) && method_exists($adminRole, 'add_cap')) {
            $adminRole->add_cap('grcs_manage_vouchers');
            $adminRole->add_cap('grcs_reconcile_cod');
            $adminRole->add_cap('grcs_manage_settings');
        }

        $shopManagerRole = get_role('shop_manager');
        if (is_object($shopManagerRole) && method_exists($shopManagerRole, 'add_cap')) {
            $shopManagerRole->add_cap('grcs_manage_vouchers');
            $shopManagerRole->add_cap('grcs_reconcile_cod');
        }
    }

    /**
     * Compute the next 06:00 store-local (Europe/Athens) timestamp in UTC (SPEC.md §6.4, §9.1).
     */
    private function computeNextSixAmUtcTimestamp(): int
    {
        try {
            $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('Europe/Athens');
            $nowLocal = new DateTimeImmutable('now', $tz);
            $targetLocal = $nowLocal->setTime(6, 0, 0);

            if ($targetLocal <= $nowLocal) {
                $targetLocal = $targetLocal->modify('+1 day');
            }

            return $targetLocal->getTimestamp();
        } catch (Throwable) {
            return time() + 3600;
        }
    }
}
