<?php

declare(strict_types=1);

namespace GRCommerceSuite\Pdf;

use GRCommerceSuite\Domain\Voucher\VoucherResult;
use GRCommerceSuite\Services\ShippingOptions;
use GRCommerceSuite\Support\Money;
use InvalidArgumentException;
use RuntimeException;
use WC_Order;

/** Local vouchers only. Courier-issued production PDFs always pass through unchanged. */
final class VoucherLabelGenerator
{
    /** @var array<string, WC_Order> */
    private static array $orders = [];

    /** @param non-empty-list<string> $numbers */
    public static function rememberOrder(WC_Order $order, array $numbers): void
    {
        foreach ($numbers as $number) {
            self::$orders[$number] = $order;
            if (function_exists('set_transient')) {
                set_transient('grcs_label_order_' . hash('sha256', $number), $order->get_id(), 86400);
            }
        }
    }

    public static function voucherCreated(int $id, VoucherResult $result, int $orderId): void
    {
        $order = wc_get_order($orderId);
        if ($order instanceof WC_Order) {
            self::rememberOrder($order, ShippingOptions::resultVoucherNumbers($result));
        }
    }

    private static function orderForVoucher(string $number): ?WC_Order
    {
        if (isset(self::$orders[$number])) {
            return self::$orders[$number];
        }
        $id = function_exists('get_transient') ? get_transient('grcs_label_order_' . hash('sha256', $number)) : false;
        if (is_numeric($id) && function_exists('wc_get_order')) {
            $order = wc_get_order((int) $id);
            if ($order instanceof WC_Order) {
                return $order;
            }
        }
        if (isset($GLOBALS['wpdb']) && function_exists('wc_get_orders')) {
            $orders = wc_get_orders(['limit' => 1, 'meta_query' => [['key' => '_grcs_last_voucher_no', 'value' => $number]]]);
            if (is_array($orders) && ($orders[0] ?? null) instanceof WC_Order) {
                return $orders[0];
            }
        }
        return null;
    }

    /** @return array<string, string> */
    public static function orderDetails(?WC_Order $order): array
    {
        $option = static fn(string $key, string $default = ''): string => function_exists('get_option') ? (string) get_option($key, $default) : $default;
        $details = [
            'sender' => $option('grcs_sender_name') ?: $option('blogname', 'Store'),
            'sender_address' => trim($option('woocommerce_store_address') . ' ' . $option('woocommerce_store_address_2')),
            // Omit empty parts so an unconfigured store address never prints a bare ", ΤΚ".
            'sender_city' => trim($option('woocommerce_store_city') . ($option('woocommerce_store_postcode') !== '' ? ' ΤΚ ' . $option('woocommerce_store_postcode') : '')),
            'sender_phone' => $option('woocommerce_store_phone') ?: $option('grcs_sender_phone'),
            'recipient' => 'Recipient unavailable', 'address' => '', 'city' => '', 'postcode' => '', 'phone' => '',
            'weight' => '1.00', 'cod' => '0.00', 'flags' => '', 'order' => '', 'notes' => '', 'locker' => '',
        ];
        if ($order === null) {
            return $details;
        }
        foreach (['recipient' => 'name', 'address' => 'address_1', 'city' => 'city', 'postcode' => 'postcode', 'phone' => 'phone'] as $key => $field) {
            if ($field === 'name') {
                $value = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
                $details[$key] = $value !== '' ? $value : trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
                continue;
            }
            $shippingMethod = 'get_shipping_' . $field;
            $billingMethod = 'get_billing_' . $field;
            $details[$key] = (string) ($order->$shippingMethod() ?: $order->$billingMethod());
        }
        $details['address'] = trim($details['address'] . ' ' . ($order->get_shipping_address_2() ?: $order->get_billing_address_2()));
        $details['weight'] = number_format(ShippingOptions::weightKg($order), 2, '.', '');
        $override = $order->get_meta('_grcs_custom_cod_amount', true);
        $details['cod'] = $override !== '' && $override !== null ? Money::fromDecimalString((string) $override)->toDecimalString()
            : ($order->get_payment_method() === 'cod' ? Money::fromDecimalString((string) $order->get_total())->toDecimalString() : '0.00');
        $details['flags'] = implode('  /  ', ShippingOptions::acsProducts($order, false));
        $details['flags'] = str_replace('SAT', 'ΣΑΒΒΑΤΟ', $details['flags']);
        $details['order'] = '#' . $order->get_order_number();
        $details['notes'] = $order->get_customer_note();
        $details['locker'] = (string) $order->get_meta('_grcs_boxnow_locker_id', true);
        return $details;
    }

    /**
     * @param non-empty-list<string> $numbers
     * @return non-empty-string
     */
    public function generate(array $numbers, string $courier = 'ACS SANDBOX', string $format = 'a4', ?WC_Order $order = null): string
    {
        if ($numbers === [] || count($numbers) > 100 || !in_array(strtolower($format), ['a4', 'a6', 'thermal'], true)) {
            throw new InvalidArgumentException(__('Choose A4, A6 or thermal and between 1 and 100 vouchers.', 'gr-commerce-suite'));
        }
        foreach ($numbers as $number) {
            if (!preg_match('/^[\x20-\x7e]{1,64}$/D', $number) || trim($number) === '') {
                throw new InvalidArgumentException(__('Voucher AWB must contain 1 to 64 printable ASCII characters.', 'gr-commerce-suite'));
            }
        }
        if (!class_exists(\GRCS_Vendor_TCPDF::class)) {
            throw new RuntimeException(__('The Unicode voucher PDF library is unavailable. Reinstall the release.', 'gr-commerce-suite'));
        }
        $a4 = strtolower($format) === 'a4';
        $pdf = new \GRCS_Vendor_TCPDF('P', 'mm', $a4 ? 'A4' : [100, 150], true, 'UTF-8', false);
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);
        $pdf->SetAutoPageBreak(false, 0);
        $pdf->SetMargins(0, 0, 0);
        $pdf->SetCreator('GR Commerce Suite');
        $pdf->SetTitle('Courier voucher');
        $pdf->setFontSubsetting(true);
        foreach ($numbers as $index => $number) {
            $pdf->AddPage();
            $details = self::orderDetails($order ?? self::orderForVoucher($number));
            $this->draw($pdf, $number, $courier, $details, $a4 ? 55 : 0, $a4 ? 18 : 0, $index + 1, count($numbers));
        }
        $bytes = $pdf->Output('', 'S');
        if ($bytes === '' || !PdfMerger::isValidPdf($bytes)) {
            throw new RuntimeException(__('Voucher PDF generation failed.', 'gr-commerce-suite'));
        }
        return $bytes;
    }

    /** @param array<string, string> $d */
    private function draw(\GRCS_Vendor_TCPDF $pdf, string $number, string $courier, array $d, float $ox, float $oy, int $parcel, int $total): void
    {
        $boxNow = str_contains(strtoupper($courier), 'BOX NOW') || str_starts_with(strtoupper($courier), 'BOXNOW');
        $sandbox = str_contains(strtoupper($courier), 'SANDBOX');
        $pdf->SetDrawColor(30, 41, 59);
        $pdf->SetLineWidth(0.25);
        $rect = static function (float $x, float $y, float $w, float $h) use ($pdf, $ox, $oy): void {
            $pdf->Rect($ox + $x, $oy + $y, $w, $h);
        };
        // Multicell fitting bounds every field, including long Greek addresses and notes.
        $text = static function (float $x, float $y, float $w, float $h, string $value, float $size = 8, bool $bold = false) use ($pdf, $ox, $oy): void {
            $pdf->SetFont('dejavusans', $bold ? 'B' : '', $size);
            $pdf->SetXY($ox + $x, $oy + $y);
            $value = preg_replace('/[\x00-\x1f]/u', ' ', mb_scrub($value, 'UTF-8')) ?? '';
            $pdf->MultiCell($w, $h, mb_substr($value, 0, 300, 'UTF-8'), 0, 'L', false, 1, null, null, true, 0, false, true, $h, 'M', true);
        };
        $rect(3, 3, 94, 143);
        $pdf->SetFillColor(...($boxNow ? [132, 204, 22] : [190, 18, 60]));
        $pdf->Rect($ox + 3, $oy + 3, 94, 12, 'F');
        $pdf->SetTextColor(...($boxNow ? [15, 23, 42] : [255, 255, 255]));
        // A simple vector brand mark remains crisp on monochrome thermal printers.
        $pdf->SetDrawColor(...($boxNow ? [15, 23, 42] : [255, 255, 255]));
        $pdf->Rect($ox + 6, $oy + 6, 6, 6);
        $pdf->Line($ox + 9, $oy + 6, $ox + 9, $oy + 12);
        $text(14, 5, 80, 8, $boxNow ? 'BOX NOW LOCKERS' : 'ACS COURIER', 14, true);
        $pdf->SetTextColor(15, 23, 42);
        $pdf->SetDrawColor(30, 41, 59);
        $text(5, 16, 65, 5, 'ΑΡΙΘ. ΑΠΟΣΤΟΛΗΣ (AWB)', 8, true);
        $text(5, 21, 64, 9, $number, 17, true);
        $route = $boxNow ? ($d['locker'] ?: 'LOCKER') : (str_starts_with($d['postcode'], '5') ? 'ΘΕ' : (str_starts_with($d['postcode'], '1') ? 'ΑΘ' : ($d['postcode'] ?: 'GR')));
        $rect(71, 16, 24, 20);
        $text(72, 17, 22, 5, 'ΠΡΟΟΡΙΣΜΟΣ', 6.5, true);
        $text(72, 23, 22, 11, $route, 16, true);
        $date = function_exists('wp_date') ? wp_date('d/m/Y H:i') : gmdate('d/m/Y H:i');
        $text(5, 31, 64, 5, 'ΕΚΔΟΣΗ: ' . $date, 7);
        $rect(3, 38, 94, 22);
        $text(5, 39, 90, 4, 'ΑΠΟΣΤΟΛΕΑΣ (SENDER)', 7, true);
        $text(5, 43, 90, 5, $d['sender'], 9, true);
        $text(5, 48, 90, 5, implode(', ', array_filter([trim($d['sender_address']), trim($d['sender_city'])], static fn(string $part): bool => $part !== '')), 7);
        if (trim($d['sender_phone']) !== '') {
            $text(5, 54, 90, 5, 'ΤΗΛ: ' . $d['sender_phone'], 7);
        }
        $rect(3, 60, 94, 30);
        $text(5, 61, 90, 4, 'ΠΑΡΑΛΗΠΤΗΣ (RECIPIENT)', 7, true);
        $text(5, 65, 90, 6, $d['recipient'], 11, true);
        $text(5, 71, 90, 8, $d['address'], 9);
        $text(5, 79, 90, 5, $d['city'] . '  ΤΚ ' . $d['postcode'], 9, true);
        $text(5, 84, 90, 5, 'ΤΗΛ: ' . $d['phone'], 9, true);
        $rect(3, 90, 94, 14);
        $text(5, 91, 25, 4, 'ΒΑΡΟΣ (KG)', 6, true);
        $text(31, 91, 24, 4, 'ΤΕΜΑΧΙΑ', 6, true);
        $text(56, 91, 39, 4, 'ΠΟΣΟ ΑΝΤΙΚΑΤΑΒΟΛΗΣ / COD €', 5.7, true);
        $text(5, 96, 25, 6, $d['weight'], 10, true);
        $text(31, 96, 24, 6, $parcel . '/' . $total, 10, true);
        $text(56, 96, 39, 6, (float) $d['cod'] > 0 ? ($boxNow ? 'PAY ON THE GO €' . $d['cod'] : '€' . $d['cod'] . ' ΜΕΤΡΗΤΑ') : 'ΕΛΕΥΘΕΡΟ / PREPAID', 8, true);
        $text(5, 105, 90, 5, $d['order'] . '  ' . $d['flags'], 8, true);
        $text(5, 110, 90, 7, $d['notes'], 7);
        $barcodeWidth = 66.0;
        // Code 128 and QR render as PDF rectangle operators, with quiet zones.
        $pdf->write1DBarcode($number, 'C128', $ox + 5, $oy + 120, $barcodeWidth, 18, 0.25,
            ['border' => false, 'padding' => 2, 'stretch' => true, 'fgcolor' => [0, 0, 0], 'bgcolor' => [255, 255, 255], 'text' => false], 'N');
        $text(7, 138, 62, 5, $number, 8, true);
        $pdf->write2DBarcode($number, 'QRCODE,M', $ox + 74, $oy + 120, 21, 21,
            ['border' => false, 'padding' => 2, 'fgcolor' => [0, 0, 0], 'bgcolor' => [255, 255, 255]], 'N');
        $text(5, 143, 90, 3, $sandbox ? 'SANDBOX / ΔΟΚΙΜΑΣΤΙΚΟ - ΔΕΝ ΙΣΧΥΕΙ ΓΙΑ ΑΠΟΣΤΟΛΗ' : 'LOCAL VOUCHER / GR COMMERCE SUITE', 5, true);
    }
}
