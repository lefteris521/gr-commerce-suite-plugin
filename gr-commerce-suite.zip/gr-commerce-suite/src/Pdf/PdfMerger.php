<?php

declare(strict_types=1);

namespace GRCommerceSuite\Pdf;

use InvalidArgumentException;
use RuntimeException;
use Throwable;

/**
 * Merges multiple binary PDF labels into a single PDF document and generates sample/merged PDFs (SPEC.md §8.2).
 */
final class PdfMerger
{
    public const PDF_MAGIC_BYTES = '%PDF-';

    /**
     * Verify whether a binary string starts with the `%PDF-` magic header.
     */
    public static function isValidPdf(string $binary): bool
    {
        return str_starts_with($binary, self::PDF_MAGIC_BYTES);
    }

    /**
     * Merge one or more binary PDF documents into a single PDF document.
     *
     * @param non-empty-list<non-empty-string> $pdfDocuments
     * @return non-empty-string
     */
    public function merge(array $pdfDocuments): string
    {
        if ($pdfDocuments === []) {
            throw new InvalidArgumentException(__('At least one PDF document is required to merge.', 'gr-commerce-suite'));
        }

        foreach ($pdfDocuments as $index => $doc) {
            if (!self::isValidPdf($doc)) {
                throw new InvalidArgumentException(
                    sprintf(__('Document at index %d does not start with %s magic bytes.', 'gr-commerce-suite'), $index, self::PDF_MAGIC_BYTES)
                );
            }
        }

        if (count($pdfDocuments) === 1) {
            return $pdfDocuments[0];
        }

        $fpdiClass = $this->resolveFpdiClass();
        if ($fpdiClass === null) {
            throw new RuntimeException(__('The PDF library is unavailable. Reinstall the production release.', 'gr-commerce-suite'));
        }
        // A failed import must never replace shipping barcodes with a synthetic text-only document.
        return $this->mergeWithFpdi($fpdiClass, $pdfDocuments);
    }

    /**
     * Generate a clean, standards-compliant PDF-1.4 label document for given voucher numbers.
     *
     * @param non-empty-list<string> $voucherNos
     * @return non-empty-string
     */
    public static function generateSampleLabelPdf(
        array $voucherNos,
        string $courierLabel = 'COURIER',
        string $format = 'a4'
    ): string {
        return (new VoucherLabelGenerator())->generate($voucherNos, $courierLabel, strtolower($format));
    }

    /**
     * @return class-string|null
     */
    private function resolveFpdiClass(): ?string
    {
        if (class_exists('GRCommerceSuite\\Vendor\\setasign\\Fpdi\\Fpdi')) {
            return \GRCommerceSuite\Vendor\setasign\Fpdi\Fpdi::class;
        }

        $standard = \GRCommerceSuite\Vendor\setasign\Fpdi\Fpdi::class;
        if (class_exists($standard)) {
            return $standard;
        }

        return null;
    }

    /**
     * @param class-string                     $fpdiClass
     * @param non-empty-list<non-empty-string> $pdfDocuments
     * @return non-empty-string
     */
    private function mergeWithFpdi(string $fpdiClass, array $pdfDocuments): string
    {
        $readerClass = str_starts_with($fpdiClass, 'GRCommerceSuite\\Vendor\\')
            ? 'GRCommerceSuite\\Vendor\\setasign\\Fpdi\\PdfParser\\StreamReader'
            : 'GRCommerceSuite\\Vendor\\setasign\\Fpdi\\PdfParser\\StreamReader';

        $pdf = new $fpdiClass();
        if (
            !method_exists($pdf, 'setSourceFile') || !method_exists($pdf, 'importPage')
            || !method_exists($pdf, 'getTemplateSize') || !method_exists($pdf, 'AddPage')
            || !method_exists($pdf, 'useTemplate') || !method_exists($pdf, 'Output')
        ) {
            throw new RuntimeException(__('The installed PDF library does not support label merging.', 'gr-commerce-suite'));
        }

        foreach ($pdfDocuments as $binary) {
            $stream = $readerClass::createByString($binary);
            /** @var int $pageCount */
            $pageCount = $pdf->setSourceFile($stream);

            for ($pageNo = 1; $pageNo <= $pageCount; $pageNo++) {
                $templateId = $pdf->importPage($pageNo);
                /** @var array{width: float, height: float, orientation: string} $size */
                $size = $pdf->getTemplateSize($templateId);
                $pdf->AddPage($size['orientation'], [$size['width'], $size['height']]);
                $pdf->useTemplate($templateId);
            }
        }

        $output = $pdf->Output('S');
        if (!is_string($output) || $output === '' || !self::isValidPdf($output)) {
            throw new InvalidArgumentException(__('Merged FPDI output is not a valid PDF.', 'gr-commerce-suite'));
        }

        return $output;
    }

}
