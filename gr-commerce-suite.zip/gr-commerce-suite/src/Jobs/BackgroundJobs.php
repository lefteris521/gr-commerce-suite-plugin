<?php

declare(strict_types=1);

namespace GRCommerceSuite\Jobs;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Contracts\VoucherLookupInterface;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\TrackingService;
use GRCommerceSuite\Services\CodReconciliationService;
use GRCommerceSuite\Services\VoucherLockService;
use GRCommerceSuite\Services\VoucherStatusRule;
use InvalidArgumentException;
use WC_Order;

/** Wire scheduled work to real handlers; each courier job performs at most one voucher operation. */
final readonly class BackgroundJobs implements HookSubscriberInterface
{
    public function __construct(
        private VoucherRepository $repository,
        private CourierRegistry $registry,
        private JobDispatcher $jobs,
        private TrackingService $tracking,
        private CodReconciliationService $cod,
        private VoucherLockService $vouchers,
    ) {
    }

    public function register(): void
    {
        // Tracking dispatch/poll, lookupUnknown, and COD dispatch/reconcile always registered (module checks stay);
        // licence gate removed from handlers per owner decision 2026-11-03.
        if (ModuleRegistry::anyCourierEnabled()) {
            add_action(JobDispatcher::HOOK_TRACKING_DISPATCH, [$this, 'dispatchTracking']);
            add_action(JobDispatcher::HOOK_TRACKING_POLL_CHUNK, [$this, 'pollTracking']);
            add_action(JobDispatcher::HOOK_LOOKUP_UNKNOWN, [$this, 'lookupUnknown']);
        }
        if (ModuleRegistry::isEnabled(ModuleRegistry::COD_AUTO) && ModuleRegistry::anyCourierEnabled()) {
            add_action(JobDispatcher::HOOK_COD_DISPATCH, [$this, 'dispatchCod']);
            add_action(JobDispatcher::HOOK_COD_RECONCILE_CHUNK, [$this, 'reconcileCod']);
        }

        // Licence-gated operations: only retryVoucher stays gated.
        if (LicenseManager::isLicensed()) {
            if (ModuleRegistry::anyCourierEnabled()) {
                add_action(JobDispatcher::HOOK_RETRY_VOUCHER, [$this, 'retryVoucher']);
            }
        }
    }

    /** @param array<string, mixed> $payload */
    public function dispatchTracking(array $payload = []): void
    {
        $this->dispatch($payload, false);
    }

    /** @param array<string, mixed> $payload */
    public function dispatchCod(array $payload = []): void
    {
        $this->dispatch($payload, true);
    }

    /** @param array<string, mixed> $payload */
    private function dispatch(array $payload, bool $cod): void
    {
        // A callback already loaded before a toggle must not start another page of disabled work.
        if (!ModuleRegistry::anyCourierEnabled() || ($cod && !ModuleRegistry::isEnabled(ModuleRegistry::COD_AUTO))) {
            return;
        }
        // Licence gate removed for both tracking and COD per owner decision 2026-11-03.
        $dispatch = $cod ? JobDispatcher::HOOK_COD_DISPATCH : JobDispatcher::HOOK_TRACKING_DISPATCH;
        $worker = $cod ? JobDispatcher::HOOK_COD_RECONCILE_CHUNK : JobDispatcher::HOOK_TRACKING_POLL_CHUNK;
        $size = $this->jobs->chunkSizeFor($dispatch);
        $rows = $this->repository->findBackgroundPage((int) ($payload['after_id'] ?? 0), $cod, $size);
        foreach ($rows as $row) {
            // Paging below uses the FETCHED row count; skipping a disabled courier's voucher must not end the walk early.
            $courier = CourierSlug::tryFrom((string) $row['courier_slug']);
            if ($courier === null || !ModuleRegistry::courierEnabled($courier)) {
                continue;
            }
            $this->jobs->enqueueAsync($worker, ['voucher_id' => (int) $row['id'], 'courier' => $row['courier_slug']]);
        }
        if (count($rows) === $size) {
            $this->jobs->enqueueAsync($dispatch, ['after_id' => (int) $rows[count($rows) - 1]['id']]);
        }
    }

    /** @param array<string, mixed> $payload */
    public function pollTracking(array $payload): void
    {
        if (!$this->courierModuleOn($payload)) {
            return;
        }
        $this->tracking->pollVoucherById((int) ($payload['voucher_id'] ?? 0));
    }

    /** @param array<string, mixed> $payload */
    private function courierModuleOn(array $payload): bool
    {
        $slug = CourierSlug::tryFrom((string) ($payload['courier'] ?? ''));
        if ($slug === null) { // payload without a courier: resolve it from the voucher row
            $row = $this->repository->findById((int) ($payload['voucher_id'] ?? 0));
            $slug = $row === null ? null : CourierSlug::tryFrom((string) $row['courier_slug']);
        }
        return $slug !== null && ModuleRegistry::courierEnabled($slug);
    }

    /** @param array<string, mixed> $payload */
    public function reconcileCod(array $payload): void
    {
        $slug = CourierSlug::tryFrom((string) ($payload['courier'] ?? ''));
        if ($slug !== null && ModuleRegistry::isEnabled(ModuleRegistry::COD_AUTO) && ModuleRegistry::courierEnabled($slug)) {
            $this->cod->reconcileChunk($slug, [(int) ($payload['voucher_id'] ?? 0)]);
        }
    }

    /** @param array<string, mixed> $payload */
    public function retryVoucher(array $payload): void
    {
        LicenseManager::assertLicensed();
        $row = $this->repository->findById((int) ($payload['voucher_id'] ?? 0));
        if ($row === null || ($row['state'] ?? '') !== 'reserved') {
            return;
        }
        $courier = CourierSlug::tryFrom((string) $row['courier_slug']);
        $order = wc_get_order((int) $row['order_id']);
        if (
            $order instanceof WC_Order && $courier !== null && ModuleRegistry::courierEnabled($courier)
            && $this->vouchers->deriveIdempotencyKey(
                (int) $row['order_id'],
                $courier,
                (int) $order->get_meta('_grcs_voucher_series', true)
            ) === $row['idempotency_key']
        ) {
            // Status rule (decision 2026-11-06): a scheduled retry is never confirmed. Refused: log once, no
            // courier call, no reschedule; the reserved row is left as is for the stale sweeper / operator.
            $refusal = VoucherStatusRule::refusal($order, $courier);
            if ($refusal !== null) {
                (new \GRCommerceSuite\Support\Logger('gr-commerce-suite'))->warning(sprintf(
                    'Scheduled voucher retry for order #%d (voucher #%d) not run: %s',
                    (int) $row['order_id'],
                    (int) $row['id'],
                    $refusal
                ));
                return;
            }
            $this->vouchers->createVoucherWithLock($order, $courier, isScheduledRetry: true);
        }
    }

    /** @param array<string, mixed> $payload */
    public function lookupUnknown(array $payload): void
    {
        $row = $this->repository->findById((int) ($payload['voucher_id'] ?? 0));
        if ($row === null || ($row['state'] ?? '') !== 'unknown') {
            return;
        }
        $courier = CourierSlug::tryFrom((string) $row['courier_slug']);
        if ($courier === null || !$this->registry->has($courier) || !ModuleRegistry::courierEnabled($courier)) {
            return;
        }
        $provider = $this->registry->get($courier);
        if ($provider instanceof VoucherLookupInterface) {
            $result = $provider->findVoucherByReference(substr((string) $row['idempotency_key'], 0, 16));
            if ($result !== null) {
                // Same recovery contract as reconcileUnknownWithPickupList(): a Geniki result carries the
                // primary plus child vouchers, so the snapshot/meta/hook must see it. Passing only the
                // number would persist the primary alone and only one label would print.
                try {
                    // A lost link (row cleared meanwhile) records the number as an orphan instead of dropping it.
                    $this->vouchers->linkFoundVoucher(
                        (int) $row['id'],
                        $result->voucherNo,
                        $result->courier === CourierSlug::Geniki ? $result : null,
                    );
                } catch (InvalidArgumentException $e) {
                    // Another active voucher already owns this order: the row must stay `unknown` and the
                    // job must finish (not fail/loop). No reschedule; the operator resolves it manually.
                    $voucherId = (int) $row['id'];
                    $orderId = (int) ($row['order_id'] ?? 0);
                    (new \GRCommerceSuite\Support\Logger('gr-commerce-suite'))->error(sprintf(
                        'Background lookup refused to create a second active voucher for order #%d (voucher #%d): %s',
                        $orderId,
                        $voucherId,
                        $e->getMessage()
                    ));
                    if ($orderId > 0 && function_exists('wc_get_order')) {
                        $order = wc_get_order($orderId);
                        if ($order instanceof WC_Order) {
                            $noteKey = '_grcs_background_lookup_refused_' . $voucherId;
                            if (!$order->get_meta($noteKey, true)) {
                                $order->add_order_note(sprintf(
                                    \GRCommerceSuite\I18n\AdminLocale::__('GR Commerce Suite: background lookup found a %1$s voucher (%2$s) for this order, but another active voucher already exists. The uncertain request was left as Unknown for manual review; no COD amount was changed and no job was cancelled.', 'gr-commerce-suite'),
                                    $courier->label(),
                                    $result->voucherNo
                                ));
                                $order->update_meta_data($noteKey, 'yes');
                                $order->save();
                            }
                        }
                    }
                }
            }
        }
    }
}
