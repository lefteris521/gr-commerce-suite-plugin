<?php

declare(strict_types=1);

namespace GRCommerceSuite\Jobs;

/**
 * Single choke point for scheduling Action Scheduler jobs in group `gr-commerce-suite` (SPEC.md §3 C-4, §9).
 *
 * Enforces the hard chunk limit of 100 items per action (`GRCS_JOB_CHUNK_SIZE`).
 */
final class JobDispatcher
{
    public const GROUP = 'gr-commerce-suite';
    public const HARD_MAX_CHUNK_SIZE = 100;
    public const PAYLOAD_SCHEMA_VERSION = 1;

    public const HOOK_CREATE_BATCH = 'grcs/vouchers/create_batch';
    public const HOOK_RETRY_VOUCHER = 'grcs/vouchers/retry';
    public const HOOK_LOOKUP_UNKNOWN = 'grcs/vouchers/lookup_unknown';
    public const HOOK_SWEEP_STALE = 'grcs/vouchers/sweep_stale';
    public const HOOK_PRINT_MERGE_BATCH = 'grcs/print/merge_batch';
    public const HOOK_TRACKING_DISPATCH = 'grcs/tracking/dispatch';
    public const HOOK_TRACKING_POLL_CHUNK = 'grcs/tracking/poll_chunk';
    public const HOOK_COD_DISPATCH = 'grcs/cod/dispatch';
    public const HOOK_COD_RECONCILE_CHUNK = 'grcs/cod/reconcile_chunk';
    public const HOOK_MAINTENANCE_PURGE = 'grcs/maintenance/purge';

    /** Cancel this plugin's group, including jobs with payloads; keep voucher/COD history. */
    public static function unscheduleAll(bool $networkWide = false): void
    {
        if ($networkWide && is_multisite()) {
            $offset = 0;
            do {
                $sites = get_sites(['fields' => 'ids', 'number' => 100, 'offset' => $offset]);
                foreach ($sites as $siteId) {
                    switch_to_blog((int) $siteId);
                    try {
                        self::unscheduleAll();
                    } finally {
                        restore_current_blog();
                    }
                }
                $offset += 100;
            } while (count($sites) === 100);
            return;
        }
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions('', [], self::GROUP);
        } else {
            \GRCommerceSuite\Database\Repositories\SchedulerRepository::cancelPending();
        }
        delete_option('grcs_recurring_jobs_version');
    }

    /**
     * Resolve effective chunk size for a job hook, clamped strictly to `[1, 100]` (SPEC.md §9.2).
     */
    public function chunkSizeFor(string $hook): int
    {
        $default = defined('GRCS_JOB_CHUNK_SIZE') ? (int) constant('GRCS_JOB_CHUNK_SIZE') : self::HARD_MAX_CHUNK_SIZE;
        $filtered = function_exists('apply_filters')
            ? (int) apply_filters('grcs/jobs/chunk_size', $default, $hook)
            : $default;

        return max(1, min(self::HARD_MAX_CHUNK_SIZE, $filtered));
    }

    /**
     * Enqueue an immediate asynchronous Action Scheduler action.
     *
     * @param array<string, mixed> $payload
     */
    public function enqueueAsync(string $hook, array $payload, bool $unique = false): int
    {
        $payload['v'] = self::PAYLOAD_SCHEMA_VERSION;
        $group = defined('GRCS_AS_GROUP') ? (string) constant('GRCS_AS_GROUP') : self::GROUP;

        if (!function_exists('as_enqueue_async_action')) {
            return 0;
        }

        return (int) as_enqueue_async_action($hook, [$payload], $group, $unique);
    }

    /**
     * Schedule a single delayed Action Scheduler action.
     *
     * @param array<string, mixed> $payload
     */
    public function scheduleSingle(int $timestampUtc, string $hook, array $payload, bool $unique = true): int
    {
        $payload['v'] = self::PAYLOAD_SCHEMA_VERSION;
        $group = defined('GRCS_AS_GROUP') ? (string) constant('GRCS_AS_GROUP') : self::GROUP;

        if (!function_exists('as_schedule_single_action')) {
            return 0;
        }

        return (int) as_schedule_single_action($timestampUtc, $hook, [$payload], $group, $unique);
    }

    /**
     * Schedule a recurring Action Scheduler action if not already scheduled.
     *
     * @param array<string, mixed> $payload
     */
    public function ensureRecurring(
        int $firstTimestampUtc,
        int $intervalSeconds,
        string $hook,
        array $payload = []
    ): void {
        $payload['v'] = self::PAYLOAD_SCHEMA_VERSION;
        $group = defined('GRCS_AS_GROUP') ? (string) constant('GRCS_AS_GROUP') : self::GROUP;

        if (!function_exists('as_schedule_recurring_action')) {
            return;
        }

        if (function_exists('as_has_scheduled_action') && as_has_scheduled_action($hook, [$payload], $group)) {
            return;
        }

        as_schedule_recurring_action($firstTimestampUtc, max(60, $intervalSeconds), $hook, [$payload], $group, true);
    }
}
