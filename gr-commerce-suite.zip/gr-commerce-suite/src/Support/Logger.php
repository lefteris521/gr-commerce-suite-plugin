<?php

declare(strict_types=1);

namespace GRCommerceSuite\Support;

use GRCommerceSuite\Contracts\LoggerInterface;

/**
 * Logger backed by WooCommerce's `wc_get_logger()` with automatic PII/credential redaction (SPEC.md §16).
 */
final readonly class Logger implements LoggerInterface
{
    public function __construct(private string $source = 'gr-commerce-suite')
    {
    }

    public function withSource(string $source): self
    {
        return new self($source);
    }

    public function debug(string $message, array $context = []): void
    {
        $this->log('debug', $message, $context);
    }

    public function info(string $message, array $context = []): void
    {
        $this->log('info', $message, $context);
    }

    public function notice(string $message, array $context = []): void
    {
        $this->log('notice', $message, $context);
    }

    public function warning(string $message, array $context = []): void
    {
        $this->log('warning', $message, $context);
    }

    public function error(string $message, array $context = []): void
    {
        $this->log('error', $message, $context);
    }

    public function critical(string $message, array $context = []): void
    {
        $this->log('critical', $message, $context);
    }

    /**
     * @param array<string, mixed> $context
     */
    private function log(string $level, string $message, array $context): void
    {
        $source = strtolower($this->source . ' ' . $message);
        $category = 'SYSTEM';
        foreach (['blacklist' => 'BLACKLIST', 'invoice' => 'INVOICE', 'aade' => 'INVOICE', 'boxnow' => 'BOXNOW', 'box now' => 'BOXNOW', 'acs' => 'ACS', 'cod' => 'RECONCILIATION', 'xml' => 'XML', 'grcs-feeds' => 'XML', 'license' => 'LICENSE'] as $needle => $name) {
            if (str_contains($source, $needle)) {
                $category = $name;
                break;
            }
        }
        (new \GRCommerceSuite\Services\DiagnosticLogger())->record($level, $category, $message, $context);
        if (!function_exists('wc_get_logger')) {
            return;
        }

        $safeContext = \GRCommerceSuite\Services\DiagnosticSanitizer::mask($context);
        $safeContext['source'] = \GRCommerceSuite\Services\DiagnosticSanitizer::source($this->source);

        $logger = wc_get_logger();
        if (is_object($logger) && method_exists($logger, 'log')) {
            $logger->log($level, \GRCommerceSuite\Services\DiagnosticLogger::maskText($message), $safeContext);
        }
    }
}
