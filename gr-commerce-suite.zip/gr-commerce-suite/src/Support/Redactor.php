<?php

declare(strict_types=1);

namespace GRCommerceSuite\Support;

/**
 * Redacts credentials, tokens, and recipient PII before persistence in `raw_response` or logs (SPEC.md §15.4).
 */
final class Redactor
{
    private const REDACTED_VALUE = '[REDACTED]';

    private const CREDENTIAL_KEY = '[\w.-]*(?:password|passwd|secret|token|api[_.-]?key|license[_.-]?key|authorization|cookie|credential|vault|username|company[_.-]?id|user[_.-]?id|client[_.-]?id)[\w.-]*';

    /**
     * Case-insensitive field names containing secrets or personal data.
     *
     * @var list<string>
     */
    private const SENSITIVE_KEYS = [
        'acsapikey',
        'company_password',
        'user_password',
        'password',
        'passwd',
        'secret',
        'client_secret',
        'access_token',
        'refresh_token',
        'token',
        'authorization',
        'api_key',
        'apikey',
        'recipient_name',
        'recipient_address',
        'recipient_phone',
        'recipient_cell_phone',
        'recipient_email',
        'contactname',
        'contactnumber',
        'contactemail',
        'fullname',
        'phonenumber',
        'emailaddress',
        'phone',
        'mobile',
        'email',
        'address',
        'addressline1',
        'addressline2',
    ];

    /**
     * Recursively redact sensitive keys from an associative array.
     *
     * @param array<mixed> $data
     * @return array<string, mixed>
     */
    public static function redactArray(array $data, int $depth = 0): array
    {
        if ($depth > 5) {
            return ['omitted' => self::REDACTED_VALUE];
        }
        $result = [];

        foreach ($data as $key => $value) {
            $normalizedKey = strtolower((string) $key);

            if (self::isSensitiveKey($normalizedKey)) {
                $result[(string) $key] = self::REDACTED_VALUE;
                continue;
            }

            if (is_array($value)) {
                $result[(string) $key] = self::redactArray($value, $depth + 1);
                continue;
            }

            if (is_string($value) && strlen($value) > 2048 && str_starts_with($value, '%PDF-')) {
                $result[(string) $key] = '[BINARY_PDF_OMITTED]';
                continue;
            }

            if (is_string($value)) {
                $json = json_decode($value, true);
                $result[(string) $key] = is_array($json)
                    ? json_encode(self::redactArray($json, $depth + 1), JSON_INVALID_UTF8_SUBSTITUTE | JSON_UNESCAPED_UNICODE)
                    : self::redactText($value);
            } else {
                $result[(string) $key] = is_scalar($value) || $value === null ? $value : '[object omitted]';
            }
        }

        return $result;
    }

    public static function isSensitiveKey(string $key): bool
    {
        return in_array(strtolower($key), self::SENSITIVE_KEYS, true)
            || preg_match('/' . self::CREDENTIAL_KEY . '|phone|mobile|email|address|contact|recipient|customer|billing|shipping|ip(?:_address)?$/i', $key) === 1;
    }

    /** Redact whole quoted values (including escaped quotes) before truncation or persistence. */
    public static function redactText(string $text): string
    {
        // Header values can contain several credentials, e.g. Digest auth or multiple cookies.
        $text = preg_replace('/\b((?:[\w.-]*authorization|(?:set-)?cookie)\s*:\s*)[^\r\n]+/i', '$1***', $text) ?? '';
        $text = preg_replace('/(Bearer|Basic)\s+[A-Za-z0-9+\/_=.\-]+/i', '$1 ***', $text) ?? '';
        $key = self::CREDENTIAL_KEY;
        $text = preg_replace(
            '~(' . $key . '["\']?\s*[:=]\s*)(?:"(?:\\\\.|[^"\\\\])*"|\'(?:\\\\.|[^\'\\\\])*\'|[^\s,"\'&};]+)~i',
            '$1***',
            $text
        ) ?? '';
        $text = preg_replace('~(<((?:[\w.-]+:)?' . $key . ')\b[^>]*>).*?(</\2\s*>)~is', '$1***$3', $text) ?? '';
        $text = preg_replace('~(https?://)[^\s/@]+@~i', '$1***@', $text) ?? '';
        return preg_replace('/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i', '***', $text) ?? '';
    }

    /**
     * Encode redacted array as a JSON string safe for `raw_response` storage.
     *
     * @param array<mixed> $data
     */
    public static function toRedactedJson(array $data): string
    {
        $redacted = self::redactArray($data);

        if (function_exists('wp_json_encode')) {
            $encoded = wp_json_encode($redacted);
            if (is_string($encoded)) {
                return $encoded;
            }
        }

        return json_encode($redacted, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
    }
}
