<?php

declare(strict_types=1);

namespace GRCommerceSuite\Support;

/**
 * Enforces wall-clock time and memory ceilings inside Action Scheduler chunk handlers (SPEC.md §9.3).
 */
final class TimeBudget
{
    private readonly float $startedAt;

    private readonly float $budgetSeconds;

    private readonly int $memoryCeilingBytes;

    public function __construct(?float $maxSeconds = null, ?int $memoryCeilingBytes = null)
    {
        $this->startedAt = microtime(true);
        $this->budgetSeconds = $maxSeconds ?? self::resolveDefaultTimeBudget();
        $this->memoryCeilingBytes = $memoryCeilingBytes ?? self::resolveDefaultMemoryCeiling();
    }

    public function isExhausted(): bool
    {
        $elapsed = microtime(true) - $this->startedAt;
        if ($elapsed >= $this->budgetSeconds) {
            return true;
        }

        return memory_get_usage(true) >= $this->memoryCeilingBytes;
    }

    private static function resolveDefaultTimeBudget(): float
    {
        $maxExec = (int) ini_get('max_execution_time');
        if ($maxExec <= 0) {
            return 20.0;
        }

        return min(20.0, 0.6 * $maxExec);
    }

    private static function resolveDefaultMemoryCeiling(): int
    {
        $rawLimit = (string) ini_get('memory_limit');
        if ($rawLimit === '' || $rawLimit === '-1') {
            return 256 * 1024 * 1024;
        }

        if (function_exists('wp_convert_hr_to_bytes')) {
            $bytes = (int) wp_convert_hr_to_bytes($rawLimit);
        } else {
            $bytes = self::parseMemoryBytes($rawLimit);
        }

        if ($bytes <= 0) {
            return 128 * 1024 * 1024;
        }

        return (int) ($bytes * 0.8);
    }

    private static function parseMemoryBytes(string $value): int
    {
        $trimmed = trim($value);
        $unit = strtolower(substr($trimmed, -1));
        $number = (int) $trimmed;

        return match ($unit) {
            'g' => $number * 1024 * 1024 * 1024,
            'm' => $number * 1024 * 1024,
            'k' => $number * 1024,
            default => $number,
        };
    }
}
