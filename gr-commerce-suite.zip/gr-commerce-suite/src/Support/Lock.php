<?php

declare(strict_types=1);

namespace GRCommerceSuite\Support;

use GRCommerceSuite\Database\Repositories\OptionLockRepository;
use wpdb;

/**
 * Atomic option-based mutex lock for shared-hosting environments without persistent object cache (SPEC.md §9.4).
 */
final class Lock
{
    /** @var array<string, string> */
    private static array $owned = [];

    public static function acquire(string $name, int $ttlSeconds = 120): bool
    {
        global $wpdb;

        $optionName = self::optionKey($name);
        $now = time();
        $ttl = max(1, $ttlSeconds);
        $expiresAt = $now + $ttl;
        $token = bin2hex(random_bytes(16));
        $lockValue = $expiresAt . ':' . $token;

        // Non-WordPress fallback (no wpdb instance, standalone smokes)
        if (!$wpdb instanceof wpdb) {
            if (!function_exists('add_option')) {
                return true;
            }

            if (add_option($optionName, $lockValue, '', false)) {
                self::$owned[self::ownerKey($optionName)] = $lockValue;
                return true;
            }

            $existing = (string) (function_exists('get_option') ? get_option($optionName, '0') : '0');
            $existingExpiry = self::parseExpiry($existing);
            if ($existingExpiry > $now) {
                return false;
            }

            if (function_exists('update_option') && update_option($optionName, $lockValue)) {
                self::$owned[self::ownerKey($optionName)] = $lockValue;
                return true;
            }

            return false;
        }

        // WordPress atomic lock acquisition: insert-only prevents upsert races
        if (OptionLockRepository::insert($optionName, $lockValue)) {
            self::$owned[self::ownerKey($optionName)] = $lockValue;
            return true;
        }

        // On insert failure, read current row with direct SQL (bypassing object-cache staleness)
        $currentValue = OptionLockRepository::get($optionName);
        if ($currentValue === null) {
            return false;
        }

        $existingExpiry = self::parseExpiry($currentValue);
        if ($existingExpiry > $now) {
            return false;
        }

        // Expired lock: CAS replace(exact current value -> new value). Exactly one winner.
        if (!OptionLockRepository::replace($optionName, $currentValue, $lockValue)) {
            return false;
        }

        self::$owned[self::ownerKey($optionName)] = $lockValue;
        return true;
    }

    public static function release(string $name): void
    {
        $optionName = self::optionKey($name);
        $owner = self::ownerKey($optionName);
        $expected = self::$owned[$owner] ?? null;
        unset(self::$owned[$owner]);
        if ($expected === null) {
            return;
        }

        global $wpdb;
        if ($wpdb instanceof wpdb) {
            // CAS on the exact value this request stored; a stale owner never frees a successor's lock.
            OptionLockRepository::replace($optionName, $expected, null);
        } elseif (function_exists('delete_option')) {
            if (!function_exists('get_option') || (string) get_option($optionName, '') === $expected) {
                delete_option($optionName);
            }
        }
    }

    /**
     * Parses the expiry timestamp from either new format ("<expiry>:<token>")
     * or old format ("<expiry>").
     */
    public static function parseExpiry(string $value): int
    {
        $parts = explode(':', $value, 2);
        $raw = $parts[0];
        if (ctype_digit($raw)) {
            return (int) $raw;
        }
        if (is_numeric($raw)) {
            return max(0, (int) (float) $raw);
        }
        return 0;
    }

    private static function ownerKey(string $name): string
    {
        return (function_exists('get_current_blog_id') ? get_current_blog_id() : 0) . ':' . $name;
    }

    private static function optionKey(string $name): string
    {
        $sanitized = preg_replace('/[^a-zA-Z0-9_-]/', '_', $name) ?? $name;

        return 'grcs_lock_' . $sanitized;
    }
}
