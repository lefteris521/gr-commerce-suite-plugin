<?php

declare(strict_types=1);

namespace GRCommerceSuite\Support;

use InvalidArgumentException;

/**
 * Cent-exact EUR money value object using integer cents and string arithmetic only (SPEC.md §3 C-6, §6.4).
 * Floats are strictly forbidden for monetary values.
 */
final readonly class Money
{
    public function __construct(private int $cents)
    {
    }

    public static function fromCents(int $cents): self
    {
        return new self($cents);
    }

    public static function zero(): self
    {
        return new self(0);
    }

    /**
     * Parse a decimal EUR string (e.g. "49.90", "49,90", "120", "0.00") into integer cents
     * using string manipulation only (never float casts).
     */
    public static function fromDecimalString(string $decimal): self
    {
        $trimmed = trim($decimal);
        if ($trimmed === '') {
            return new self(0);
        }

        if (preg_match('/^([+-])?(\d+)(?:[.,](\d+))?$/', $trimmed, $matches) !== 1) {
            throw new InvalidArgumentException(sprintf(__('Invalid monetary decimal string: "%s".', 'gr-commerce-suite'), $decimal));
        }

        $sign = $matches[1] === '-' ? -1 : 1;
        $whole = ltrim($matches[2], '0');
        $whole = $whole === '' ? '0' : $whole;
        $fractionRaw = $matches[3] ?? '00';

        $padded = str_pad($fractionRaw, 3, '0', STR_PAD_RIGHT);
        $twoDigits = (int) substr($padded, 0, 2);
        $thirdDigit = (int) substr($padded, 2, 1);

        if ($thirdDigit >= 5) {
            $twoDigits++;
        }

        $maxWhole = (string) intdiv(PHP_INT_MAX - $twoDigits, 100);
        if (
            strlen($whole) > strlen($maxWhole)
            || (strlen($whole) === strlen($maxWhole) && strcmp($whole, $maxWhole) > 0)
        ) {
            throw new InvalidArgumentException(__('Monetary amount exceeds the supported integer range.', 'gr-commerce-suite'));
        }
        $totalCents = ((int) $whole * 100) + $twoDigits;

        return new self($sign * $totalCents);
    }

    public function cents(): int
    {
        return $this->cents;
    }

    public function isPositive(): bool
    {
        return $this->cents > 0;
    }

    public function isZero(): bool
    {
        return $this->cents === 0;
    }

    public function equals(self $other): bool
    {
        return $this->cents === $other->cents;
    }

    /**
     * Format integer cents to SQL DECIMAL(12,2) string (e.g. "49.90") via integer math only.
     */
    public function toDecimalString(): string
    {
        $sign = $this->cents < 0 ? '-' : '';
        $digits = str_pad(ltrim((string) $this->cents, '-'), 3, '0', STR_PAD_LEFT);
        return $sign . substr($digits, 0, -2) . '.' . substr($digits, -2);
    }
}
