<?php

declare(strict_types=1);

namespace GRCommerceSuite\Support;

use Automattic\WooCommerce\StoreApi\Exceptions\RouteException;
use RuntimeException;

final class CheckoutValidation
{
    /** Store API validation must reach Checkout Blocks as a 400 response. */
    public static function fail(string $code, string $message): never
    {
        if (class_exists(RouteException::class)) {
            throw new RouteException($code, $message, 400);
        }
        throw new RuntimeException($message);
    }
}
