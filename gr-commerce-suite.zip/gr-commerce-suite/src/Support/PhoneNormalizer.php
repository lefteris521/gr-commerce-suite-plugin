<?php

declare(strict_types=1);

namespace GRCommerceSuite\Support;

/**
 * Normalises Greek telephone numbers to E.164 (+30...) and 10-digit national formats,
 * preferring mobile numbers (69...) for courier SMS notifications (SPEC.md §8.2).
 */
final class PhoneNormalizer
{
    /**
     * Normalise raw phone input to E.164 format (+30XXXXXXXXXX).
     * When multiple phone numbers are separated by comma/slash/semicolon, prefers Greek mobile (69...).
     */
    public static function toE164(string $rawPhone, string $defaultCountryCode = '30'): string
    {
        $candidates = preg_split('/[,;\/|]+/', $rawPhone) ?: [$rawPhone];
        $normalisedList = [];

        foreach ($candidates as $candidate) {
            $cleaned = self::normaliseSingle($candidate, $defaultCountryCode);
            if ($cleaned !== '') {
                $normalisedList[] = $cleaned;
            }
        }

        if ($normalisedList === []) {
            return '';
        }

        // Prefer Greek mobile numbers starting with +3069 for courier SMS notifications.
        foreach ($normalisedList as $phone) {
            if (preg_match('/^\+3069\d{8}$/D', $phone) === 1) {
                return $phone;
            }
        }

        // Next prefer mobile/international numbers over Greek landlines (+302...).
        foreach ($normalisedList as $phone) {
            if (!str_starts_with($phone, '+302')) {
                return $phone;
            }
        }

        return $normalisedList[0];
    }

    /**
     * Validate a raw phone input (and optionally require mobile capability for Greek +30 numbers).
     */
    public static function isValid(string $rawPhone, bool $requireMobile = false): bool
    {
        $e164 = self::toE164($rawPhone);
        if ($e164 === '') {
            return false;
        }
        if ($requireMobile && str_starts_with($e164, '+30')) {
            return self::isGreekMobile($e164);
        }

        return true;
    }

    /**
     * Extract a 10-digit Greek national phone number (e.g. 6912345678 or 2101234567).
     */
    public static function toNationalDigits(string $rawPhone): string
    {
        $e164 = self::toE164($rawPhone);
        if (str_starts_with($e164, '+30') && strlen($e164) === 13) {
            return substr($e164, 3);
        }

        $digits = preg_replace('/\D+/', '', $rawPhone) ?? '';
        if (str_starts_with($digits, '0030') && strlen($digits) >= 14) {
            return substr($digits, 4, 10);
        }
        if (str_starts_with($digits, '30') && strlen($digits) === 12) {
            return substr($digits, 2);
        }

        return substr($digits, 0, 10);
    }

    public static function isGreekMobile(string $rawPhone): bool
    {
        $e164 = str_starts_with($rawPhone, '+30') && strlen($rawPhone) === 13 && ctype_digit(substr($rawPhone, 1))
            ? $rawPhone
            : self::toE164($rawPhone);

        return preg_match('/^\+3069\d{8}$/D', $e164) === 1;
    }

    /**
     * Normalise Greek postcode to 5 digits (strips spaces and non-digits).
     */
    public static function normalisePostcode(string $rawPostcode): string
    {
        $digits = preg_replace('/\D+/', '', $rawPostcode) ?? '';

        return substr($digits, 0, 5);
    }

    private static function normaliseSingle(string $input, string $defaultCountryCode): string
    {
        $trimmed = trim($input);
        if ($trimmed === '') {
            return '';
        }

        $cleaned = preg_replace('/[\s().-]+/u', '', $trimmed) ?? '';
        if (preg_match('/^\+?\d+$/D', $cleaned) !== 1) {
            return '';
        }

        $hasPlus = str_starts_with($cleaned, '+');
        $digits = $hasPlus ? substr($cleaned, 1) : $cleaned;

        if (!$hasPlus && str_starts_with($digits, '00')) {
            $digits = substr($digits, 2);
            $hasPlus = true;
        }

        if ($digits === '') {
            return '';
        }

        if ($hasPlus) {
            if (str_starts_with($digits, '30')) {
                return preg_match('/^30(?:69\d{8}|2\d{9})$/D', $digits) === 1 ? '+' . $digits : '';
            }

            return preg_match('/^[1-9]\d{7,14}$/D', $digits) === 1 ? '+' . $digits : '';
        }

        $country = preg_replace('/\D+/', '', $defaultCountryCode) ?? '30';
        if ($country === '' || $country === '30') {
            if (preg_match('/^(?:69\d{8}|2\d{9})$/D', $digits) === 1) {
                return '+30' . $digits;
            }
            if (preg_match('/^30(?:69\d{8}|2\d{9})$/D', $digits) === 1) {
                return '+' . $digits;
            }

            return '';
        }

        $national = str_starts_with($digits, '0') ? substr($digits, 1) : $digits;
        $combined = str_starts_with($digits, $country) && strlen($digits) >= 8 ? $digits : $country . $national;

        return preg_match('/^[1-9]\d{7,14}$/D', $combined) === 1 ? '+' . $combined : '';
    }
}
