<?php

declare(strict_types=1);

namespace GRCommerceSuite\Couriers;

use DateTimeImmutable;
use DateTimeZone;
use GRCommerceSuite\Contracts\CourierProviderInterface;
use GRCommerceSuite\Contracts\CredentialsValidatorInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Contracts\VoucherLookupInterface;
use GRCommerceSuite\Contracts\VoucherStateTrackerInterface;
use GRCommerceSuite\Domain\Cod\CodReconciliationResult;
use GRCommerceSuite\Domain\Cod\CodSettlementStatus;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Tracking\TrackingEvent;
use GRCommerceSuite\Domain\Tracking\TrackingResult;
use GRCommerceSuite\Domain\Tracking\TrackingStatus;
use GRCommerceSuite\Domain\Voucher\PrintFormat;
use GRCommerceSuite\Domain\Voucher\VoucherResult;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Exceptions\Courier\CourierAmbiguousResultException;
use GRCommerceSuite\Exceptions\Courier\CourierAuthenticationException;
use GRCommerceSuite\Exceptions\Courier\CourierRateLimitedException;
use GRCommerceSuite\Exceptions\Courier\CourierTransportException;
use GRCommerceSuite\Exceptions\Courier\CourierValidationException;
use GRCommerceSuite\Exceptions\Courier\UnsupportedPrintFormatException;
use GRCommerceSuite\Exceptions\Courier\VoucherNotFoundException;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Http\HttpRequest;
use GRCommerceSuite\Http\HttpResponse;
use GRCommerceSuite\Pdf\PdfMerger;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\ShippingOptions;
use GRCommerceSuite\Support\Logger;
use GRCommerceSuite\Support\Money;
use GRCommerceSuite\Support\PhoneNormalizer;
use GRCommerceSuite\Support\Redactor;
use GRCommerceSuite\Utils\GreekDataNormalizer;
use Throwable;
use WC_Order;
use WC_Order_Item_Product;

/**
 * ACS Courier REST API v2.0 Provider (`ACSAutoRest`) (SPEC.md §8).
 *
 * Endpoint: `https://webservices.acscourier.net/ACSRestServices/api/ACSAutoRest`
 * Authentication: `ACSApiKey` header + `Company_ID`, `Company_Password`, `User_ID`, `User_Password` in `ACSInputParameters`.
 * Supported operations:
 *  - `ACS_Create_Voucher`
 *  - `ACS_Print_Voucher_V2`
 *  - `ACS_Delete_Voucher`
 *  - `ACS_Trackingsummary`
 *  - `ACS_Issue_Pickup_List`
 */
final class AcsProvider implements CourierProviderInterface, CredentialsValidatorInterface, VoucherLookupInterface
{
    public const ENDPOINT_URL = 'https://webservices.acscourier.net/ACSRestServices/api/ACSAutoRest';

    public const ALIAS_CREATE_VOUCHER = 'ACS_Create_Voucher';
    public const ALIAS_PRINT_VOUCHER_V2 = 'ACS_Print_Voucher_V2';
    public const ALIAS_DELETE_VOUCHER = 'ACS_Delete_Voucher';
    public const ALIAS_TRACKING_SUMMARY = 'ACS_Trackingsummary';
    public const ALIAS_ISSUE_PICKUP_LIST = 'ACS_Issue_Pickup_List';

    private const DEFAULT_COD_CASH_LIMIT_CENTS = 50000; // EUR 500.00 Greek cash transaction cap (SPEC.md §8.2)

    /**
     * Tracks unknown courier status codes already logged once during this request.
     *
     * @var array<string, true>
     */
    private array $loggedUnknownStatusCodes = [];

    private readonly LoggerInterface $logger;

    private readonly PdfMerger $pdfMerger;

    /**
     * @param array{
     *     api_key?: string,
     *     company_id?: string,
     *     company_password?: string,
     *     user_id?: string,
     *     user_password?: string,
     *     billing_code?: string,
     *     sender_name?: string,
     *     language?: string,
     *     endpoint_url?: string,
     *     cod_cash_limit_cents?: int|string
     * } $credentials
     */
    public function __construct(
        private readonly HttpClientInterface $httpClient,
        private readonly array $credentials = [],
        ?LoggerInterface $logger = null,
        ?PdfMerger $pdfMerger = null,
        private readonly ?VoucherStateTrackerInterface $stateTracker = null,
    ) {
        $this->logger = $logger ?? new Logger('grcs-acs');
        $this->pdfMerger = $pdfMerger ?? new PdfMerger();
    }

    /**
     * Create one shipping voucher via `ACS_Create_Voucher` (SPEC.md §8.2).
     */
    public function createVoucher(WC_Order $order): VoucherResult
    {
        $orderId = (int) $order->get_id();
        $recipientName = GreekDataNormalizer::stripGreekAccentsUpper($this->resolveRecipientName($order));
        $recipientAddress = GreekDataNormalizer::stripGreekAccentsUpper($this->resolveAddressLine($order));
        $recipientCity = GreekDataNormalizer::stripGreekAccentsUpper($this->resolveCity($order));
        $rawPostcode = $this->resolvePostcode($order);
        $postcode = PhoneNormalizer::normalisePostcode($rawPostcode);
        if (strlen($postcode) !== 5 && preg_match('/\b(\d{3}\s?\d{2})\b/u', $recipientAddress, $pcMatch) === 1) {
            $postcode = PhoneNormalizer::normalisePostcode($pcMatch[1]);
        }
        $country = $this->resolveCountry($order);
        $rawPhone = $this->resolvePhone($order);
        $isSandbox = (new LicenseManager())->isSandboxEnabled();
        if ($rawPhone === '' && $isSandbox) {
            $rawPhone = '+306912345678';
        }
        $e164Phone = PhoneNormalizer::toE164($rawPhone);
        $nationalPhone = PhoneNormalizer::toNationalDigits($rawPhone);

        if ($recipientName === '') {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('ACS', 'validate_shipping', ['recipient_name' => $recipientName], $orderId);
            throw new CourierValidationException(
                __('ACS voucher creation failed: recipient name is required.', 'gr-commerce-suite'),
                CourierSlug::Acs
            );
        }

        if ($recipientAddress === '' || $recipientCity === '') {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('ACS', 'validate_shipping', ['recipient_address' => $recipientAddress, 'city' => $recipientCity], $orderId);
            throw new CourierValidationException(
                __('ACS voucher creation failed: recipient street address and city are required.', 'gr-commerce-suite'),
                CourierSlug::Acs
            );
        }

        if ($country === 'GR' && strlen($postcode) !== 5) {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('ACS', 'validate_shipping', ['postcode' => $rawPostcode], $orderId);
            throw new CourierValidationException(
                sprintf(__('ACS voucher creation failed: invalid 5-digit Greek postcode "%s".', 'gr-commerce-suite'), $rawPostcode),
                CourierSlug::Acs
            );
        }

        if ($e164Phone === '') {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('ACS', 'validate_shipping', ['recipient_phone' => $rawPhone], $orderId);
            throw new CourierValidationException(
                __('ACS voucher creation failed: a valid recipient telephone number is required.', 'gr-commerce-suite'),
                CourierSlug::Acs
            );
        }

        $codAmountCents = $this->resolveCodAmountCents($order);
        $cashLimitCents = (int) ($this->credentials['cod_cash_limit_cents'] ?? self::DEFAULT_COD_CASH_LIMIT_CENTS);
        if ($codAmountCents > $cashLimitCents) {
            $this->logger->warning(
                'ACS COD amount exceeds configured cash transaction warning threshold.',
                [
                    'order_id' => $orderId,
                    'cod_cents' => $codAmountCents,
                    'limit_cents' => $cashLimitCents,
                ]
            );
        }

        $idempotencyKey = (string) $order->get_meta('_grcs_active_idempotency_key', true);
        $referencePrefix = $idempotencyKey !== '' ? substr(
            $idempotencyKey,
            0,
            16
        ) : (string) $order->get_order_number();

        $customerNote = trim((string) $order->get_customer_note());
        $deliveryNotes = $customerNote !== ''
            ? mb_substr($customerNote . ' [REF:' . $referencePrefix . ']', 0, 120, 'UTF-8')
            : 'REF:' . $referencePrefix;

        $phones = $this->recipientPhones($order);
        if ($phones['mobile'] === '' && $phones['landline'] === '' && $isSandbox) {
            $phones['mobile'] = $nationalPhone;
        }
        $codDecimal = Money::fromCents($codAmountCents)->toDecimalString();

        $inputParameters = [
            'Pickup_Date' => gmdate('Y-m-d'),
            'Sender' => mb_substr($this->senderName(), 0, 50, 'UTF-8'),
            'Recipient_Name' => mb_substr($recipientName, 0, 60, 'UTF-8'),
            'Recipient_Address' => mb_substr($recipientAddress, 0, 80, 'UTF-8'),
            'Recipient_Region' => mb_substr($recipientCity, 0, 50, 'UTF-8'),
            'Recipient_Zipcode' => $postcode,
            'Recipient_Country' => $country,
            'Recipient_Phone' => $phones['landline'],
            'Recipient_Cell_Phone' => $phones['mobile'],
            'Recipient_Email' => mb_substr(trim((string) $order->get_billing_email()), 0, 80, 'UTF-8'),
            'Delivery_Notes' => $deliveryNotes,
            'Reference_Key1' => $referencePrefix,
            'Relevant_Code' => (string) $order->get_order_number(),
            'Item_Quantity' => ShippingOptions::parcelCount($order),
            'Weight' => $this->resolveOrderWeightKg($order),
            'Charge_Type' => 2,
            'Billing_Code' => $this->credential('billing_code', 'grcs_acs_billing_code'),
            'Cod_Amount' => $codAmountCents > 0 ? $codDecimal : '0.00',
            'Cod_Payment_Way' => $codAmountCents > 0 ? 0 : null,
            'Acs_Delivery_Products' => implode(',', ShippingOptions::acsProducts($order, $codAmountCents > 0)),
        ];

        $decoded = $this->executeJsonCall(
            alias: self::ALIAS_CREATE_VOUCHER,
            inputParameters: $inputParameters,
            timeoutSeconds: 15,
            isMutatingVoucherCall: true,
            orderId: $orderId,
            idempotencyKey: $idempotencyKey !== '' ? $idempotencyKey : null,
        );

        $voucherNo = $this->extractVoucherNumber($decoded);
        if ($voucherNo === '') {
            throw new CourierAmbiguousResultException(
                __('ACS_Create_Voucher returned HTTP 200 without a valid Voucher_No; ' .
                    'transitioning voucher state to unknown.', 'gr-commerce-suite'),
                CourierSlug::Acs,
                200,
                Redactor::redactArray($decoded),
                'Courier response was incomplete. Voucher marked as unknown for manual or automated verification.'
            );
        }

        return new VoucherResult(
            voucherNo: $voucherNo,
            courier: CourierSlug::Acs,
            codAmountCents: $codAmountCents,
            parcelCount: ShippingOptions::parcelCount($order),
            trackingUrl: \GRCommerceSuite\Services\TrackingService::publicUrl($voucherNo, CourierSlug::Acs),
            lockerId: null,
            rawResponse: Redactor::redactArray($decoded),
        );
    }

    /**
     * Cancel an unshipped voucher via `ACS_Delete_Voucher` (SPEC.md §8.2).
     */
    public function cancelVoucher(string $voucherNo): bool
    {
        $trimmed = trim($voucherNo);
        if ($trimmed === '') {
            throw new CourierValidationException(__('Voucher number cannot be empty.', 'gr-commerce-suite'), CourierSlug::Acs);
        }

        $decoded = $this->executeJsonCall(
            alias: self::ALIAS_DELETE_VOUCHER,
            inputParameters: [
                'Voucher_No' => $trimmed,
            ],
            timeoutSeconds: 15,
            isMutatingVoucherCall: true,
        );

        $errorMessage = $this->extractAcsErrorMessage($decoded);
        if ($errorMessage !== '') {
            $lower = mb_strtolower($errorMessage, 'UTF-8');

            if (
                str_contains(
                    $lower,
                    'not found'
                ) ||
                 str_contains(
                     $lower,
                     'δεν βρέθηκε'
                 ) ||
                 str_contains(
                     $lower,
                     'ανύπαρκτ'
                 )
            ) {
                throw new VoucherNotFoundException(
                    sprintf(__('ACS voucher "%s" was not found: %s', 'gr-commerce-suite'), $trimmed, $errorMessage),
                    CourierSlug::Acs
                );
            }

            // Already cancelled/deleted is idempotent -> true
            if (
                str_contains(
                    $lower,
                    'already deleted'
                ) ||
                 str_contains(
                     $lower,
                     'έχει ήδη διαγραφεί'
                 ) ||
                 str_contains(
                     $lower,
                     'άκυρο'
                 )
            ) {
                return true;
            }

            // Business refusal (e.g. already picked up / in transit) -> false
            if (
                str_contains($lower, 'picked up')
                || str_contains($lower, 'παραληφθ')
                || str_contains($lower, 'cannot be deleted')
                || str_contains($lower, 'δεν επιτρέπεται')
                || str_contains($lower, 'in transit')
            ) {
                return false;
            }

            throw new CourierValidationException(
                sprintf(__('ACS refused voucher deletion for "%s": %s', 'gr-commerce-suite'), $trimmed, $errorMessage),
                CourierSlug::Acs
            );
        }

        return true;
    }

    /**
     * Print up to 100 vouchers via `ACS_Print_Voucher_V2` and verify `%PDF-` magic header (SPEC.md §8.2).
     *
     * @param non-empty-list<non-empty-string> $voucherNos
     * @return non-empty-string
     */
    public function printVoucherPdf(array $voucherNos, string $format): string
    {
        if ($voucherNos === []) {
            throw new CourierValidationException(
                __('At least one voucher number is required for printing.', 'gr-commerce-suite'),
                CourierSlug::Acs
            );
        }

        if (count($voucherNos) > 100) {
            throw new CourierValidationException(
                __('Cannot print more than 100 vouchers in a single request.', 'gr-commerce-suite'),
                CourierSlug::Acs
            );
        }

        $printFormat = PrintFormat::tryFrom(strtolower(trim($format)));
        if ($printFormat === null) {
            throw new UnsupportedPrintFormatException(
                sprintf(__('Unsupported print format "%s" for ACS Courier.', 'gr-commerce-suite'), $format),
                CourierSlug::Acs
            );
        }

        // ACS Print_Type: 1 = Thermal (100x150mm), 2 = Laser A4 (up to 3/4 per page), 3 = A6
        $acsPrintType = match ($printFormat) {
            PrintFormat::Thermal => 1,
            PrintFormat::A4 => 2,
            PrintFormat::A6 => 3,
        };

        $pdfDocuments = [];

        foreach ($voucherNos as $voucherNo) {
            $trimmedVoucher = trim($voucherNo);
            if ($trimmedVoucher === '') {
                throw new CourierValidationException(__('Voucher number cannot be empty.', 'gr-commerce-suite'), CourierSlug::Acs);
            }

            $response = $this->sendAcsRequest(
                alias: self::ALIAS_PRINT_VOUCHER_V2,
                inputParameters: [
                    'Voucher_No' => $trimmedVoucher,
                    'Print_Type' => $acsPrintType,
                    'Start_Position' => 1,
                ],
                timeoutSeconds: 30,
                isMutatingVoucherCall: false,
            );

            $pdfBytes = $this->extractPdfBytesFromPrintResponse($response, $trimmedVoucher);
            $pdfDocuments[] = $pdfBytes;
        }

        return $this->pdfMerger->merge($pdfDocuments);
    }

    /**
     * Fetch current tracking status via `ACS_Trackingsummary` (SPEC.md §8.2, §11.1).
     */
    public function getTrackingStatus(string $voucherNo): TrackingResult
    {
        $trimmed = trim($voucherNo);
        if ($trimmed === '') {
            throw new CourierValidationException(__('Voucher number cannot be empty.', 'gr-commerce-suite'), CourierSlug::Acs);
        }

        $decoded = $this->executeJsonCall(
            alias: self::ALIAS_TRACKING_SUMMARY,
            inputParameters: [
                'Voucher_No' => $trimmed,
            ],
            timeoutSeconds: 15,
            isMutatingVoucherCall: false,
        );

        $rows = $this->extractTableOrValueRows($decoded);
        if ($rows === []) {
            throw new VoucherNotFoundException(
                sprintf(__('ACS tracking returned no records for voucher "%s".', 'gr-commerce-suite'), $trimmed),
                CourierSlug::Acs
            );
        }

        $events = [];
        $latestRow = $rows[count($rows) - 1];

        foreach ($rows as $row) {
            $code = (string) ($row['checkpoint_code'] ??
                 $row['status_code'] ??
                 $row['delivery_flag'] ??
                 $row['voucher_status'] ??
                 '0');
            $label = (string) ($row['checkpoint_description'] ??
                 $row['checkpoint_notes'] ??
                 $row['status'] ??
                 $row['description'] ??
                 'ACS status update');
            $location = isset($row['checkpoint_station']) ? (string) $row['checkpoint_station'] : null;
            $dateStr = (string) ($row['checkpoint_date_time'] ?? $row['datetime'] ?? $row['date'] ?? '');

            $occurredAt = $this->parseDateTime($dateStr) ?? new DateTimeImmutable('now', new DateTimeZone('UTC'));

            $events[] = new TrackingEvent(
                occurredAt: $occurredAt,
                courierCode: $code,
                label: $label,
                location: $location,
            );
        }

        $latestCode = (string) ($latestRow['checkpoint_code'] ??
             $latestRow['status_code'] ??
             $latestRow['delivery_flag'] ??
             $latestRow['voucher_status'] ??
             'UNKNOWN');
        $latestLabel = (string) ($latestRow['checkpoint_description'] ??
             $latestRow['checkpoint_notes'] ??
             $latestRow['status'] ??
             $latestRow['description'] ??
             'Unknown');
        $lastEventAt = $events[count($events) - 1]->occurredAt;

        $normalisedStatus = $this->mapStatusCode($latestCode, $latestLabel);

        return new TrackingResult(
            voucherNo: $trimmed,
            status: $normalisedStatus,
            courierStatusCode: $latestCode,
            courierStatusLabel: $latestLabel,
            lastEventAt: $lastEventAt,
            events: $events,
            rawResponse: Redactor::redactArray($decoded),
        );
    }

    /**
     * Issue a daily pickup list (manifest) via `ACS_Issue_Pickup_List`.
     *
     * @param list<string> $voucherNos Optional explicit voucher numbers to include.
     * @return array{pickup_list_no: string, pickup_date: string, unpicked_vouchers: list<string>, raw_response: array<string, mixed>}
     */
    public function issuePickupList(?string $pickupDate = null, array $voucherNos = []): array
    {
        $resolvedDate = $pickupDate !== null && trim($pickupDate) !== '' ? trim($pickupDate) : gmdate('Y-m-d');

        $params = [
            'Pickup_Date' => $resolvedDate,
            'MyData_Reference' => null,
        ];

        if ($voucherNos !== []) {
            $params['Vouchers_To_Include'] = implode(',', $voucherNos);
        }

        $decoded = $this->executeJsonCall(
            alias: self::ALIAS_ISSUE_PICKUP_LIST,
            inputParameters: $params,
            timeoutSeconds: 30,
            isMutatingVoucherCall: false,
        );

        $valueRows = $this->extractValueOutputRows($decoded);
        $first = $valueRows[0] ?? $decoded;

        $pickupListNo = (string) ($first['Mass_Number'] ?? $first['PickupList_No'] ?? $first['pickup_list_no'] ?? '');
        $unpickedRaw = $this->extractTableOrValueRows($decoded);
        $unpickedVouchers = [];

        foreach ($unpickedRaw as $row) {
            if (
                isset($row['Unpicked_Vouchers']) &&
                 is_string($row['Unpicked_Vouchers']) &&
                 $row['Unpicked_Vouchers'] !== ''
            ) {
                $unpickedVouchers[] = $row['Unpicked_Vouchers'];
            }
        }

        return [
            'pickup_list_no' => $pickupListNo,
            'pickup_date' => $resolvedDate,
            'unpicked_vouchers' => $unpickedVouchers,
            'raw_response' => Redactor::redactArray($decoded),
        ];
    }

    /**
     * Report COD collection/settlement facts for up to 100 ACS vouchers (SPEC.md §8.2, §10).
     *
     * @param non-empty-list<non-empty-string> $voucherNos
     * @return array<non-empty-string, CodReconciliationResult>
     */
    public function reconcileCodBatch(array $voucherNos): array
    {
        if (count($voucherNos) > 100) {
            throw new CourierValidationException(
                __('COD reconciliation batch cannot exceed 100 vouchers.', 'gr-commerce-suite'),
                CourierSlug::Acs
            );
        }

        $results = [];

        foreach ($voucherNos as $voucherNo) {
            try {
                $decoded = $this->executeJsonCall(
                    alias: self::ALIAS_TRACKING_SUMMARY,
                    inputParameters: ['Voucher_No' => $voucherNo],
                    timeoutSeconds: 30,
                    isMutatingVoucherCall: false,
                );

                $rows = $this->extractTableOrValueRows($decoded);
                if ($rows === []) {
                    $results[$voucherNo] = new CodReconciliationResult(
                        voucherNo: $voucherNo,
                        status: CodSettlementStatus::NotFound,
                        collectedAmountCents: null,
                        settlementRef: null,
                        settledAt: null,
                        rawResponse: Redactor::redactArray($decoded),
                    );
                    continue;
                }

                $latest = $rows[count($rows) - 1];
                $codCollectedRaw = (string) ($latest['cod_collected'] ??
                     $latest['cod_amount'] ??
                     $latest['Cod_Amount'] ??
                     '');
                $settlementRef = isset($latest['cod_settlement_ref']) || isset($latest['remittance_no'])
                    ? (string) ($latest['cod_settlement_ref'] ?? $latest['remittance_no'])
                    : null;
                $settledAtStr = (string) ($latest['settled_at'] ?? $latest['remittance_date'] ?? '');

                $code = (string) ($latest['checkpoint_code'] ??
                     $latest['status_code'] ??
                     $latest['delivery_flag'] ??
                     '');
                $label = (string) ($latest['checkpoint_description'] ?? $latest['status'] ?? '');
                $trackingStatus = $this->mapStatusCode($code, $label);

                $collectedCents = $codCollectedRaw !== '' ? Money::fromDecimalString($codCollectedRaw)->cents() : null;

                if ($settlementRef !== null && $settlementRef !== '') {
                    $status = CodSettlementStatus::Settled;
                } elseif (
                    $trackingStatus === TrackingStatus::Delivered &&
                     $collectedCents !== null &&
                     $collectedCents > 0
                ) {
                    $status = CodSettlementStatus::CollectedNotSettled;
                } else {
                    $status = CodSettlementStatus::NotCollected;
                }

                $results[$voucherNo] = new CodReconciliationResult(
                    voucherNo: $voucherNo,
                    status: $status,
                    collectedAmountCents: $collectedCents,
                    settlementRef: $settlementRef,
                    settledAt: $this->parseDateTime($settledAtStr),
                    rawResponse: Redactor::redactArray($decoded),
                );
            } catch (VoucherNotFoundException) {
                $results[$voucherNo] = new CodReconciliationResult(
                    voucherNo: $voucherNo,
                    status: CodSettlementStatus::NotFound,
                    collectedAmountCents: null,
                    settlementRef: null,
                    settledAt: null,
                    rawResponse: [],
                );
            }
        }

        return $results;
    }

    /**
     * Recover an `unknown` voucher by reference prefix if supported (SPEC.md §8.6).
     */
    public function findVoucherByReference(string $reference): ?VoucherResult
    {
        if (trim($reference) === '') {
            return null;
        }

        return null;
    }

    /**
     * Validate ACS credentials by calling `ACS_Trackingsummary` with a probe number (SPEC.md §8.6).
     */
    public function testConnection(): bool
    {
        try {
            $decoded = $this->executeJsonCall(
                alias: self::ALIAS_TRACKING_SUMMARY,
                inputParameters: ['Voucher_No' => '0000000000'],
                timeoutSeconds: 15,
                isMutatingVoucherCall: false,
            );

            $envelope = $decoded['ACSOutputResponce'] ?? $decoded['ACSOutputResponse'] ?? null;
            return is_array($envelope) && array_key_exists('ACSValueOutput', $envelope);
        } catch (VoucherNotFoundException) {
            // A missing probe voucher is expected after successful authentication.
            return true;
        } catch (CourierAuthenticationException) {
            return false;
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * Execute an ACS JSON call, enforcing timeout safety (`state = 'unknown'` on post-transmission timeout).
     *
     * @param array<string, mixed> $inputParameters
     * @return array<string, mixed>
     */
    private function executeJsonCall(
        string $alias,
        array $inputParameters,
        int $timeoutSeconds,
        bool $isMutatingVoucherCall,
        ?int $orderId = null,
        ?string $idempotencyKey = null,
    ): array {
        $response = $this->sendAcsRequest(
            alias: $alias,
            inputParameters: $inputParameters,
            timeoutSeconds: $timeoutSeconds,
            isMutatingVoucherCall: $isMutatingVoucherCall,
            orderId: $orderId,
            idempotencyKey: $idempotencyKey,
        );

        try {
            $decoded = json_decode($response->body, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable $e) {
            if ($isMutatingVoucherCall) {
                $this->transitionToUnknownOnTimeout(
                    orderId: $orderId,
                    idempotencyKey: $idempotencyKey,
                    errorMessage: 'ACS returned a malformed HTTP 2xx JSON response; voucher state set to unknown.',
                );

                throw new CourierAmbiguousResultException(
                    __('ACS returned a malformed JSON payload after request transmission; voucher state moved to unknown.', 'gr-commerce-suite'),
                    CourierSlug::Acs,
                    $response->statusCode,
                    ['alias' => $alias],
                    'Courier returned an unreadable response. Voucher marked as unknown to prevent duplicate creation.',
                    $e
                );
            }

            throw new CourierTransportException(
                sprintf(__('ACS returned invalid JSON for %s.', 'gr-commerce-suite'), $alias),
                CourierSlug::Acs,
                $response->statusCode,
                ['alias' => $alias],
                null,
                $e
            );
        }

        if (!is_array($decoded)) {
            if ($isMutatingVoucherCall) {
                $this->transitionToUnknownOnTimeout(
                    orderId: $orderId,
                    idempotencyKey: $idempotencyKey,
                    errorMessage: 'ACS returned a non-object JSON payload; voucher state set to unknown.',
                );

                throw new CourierAmbiguousResultException(
                    __('ACS returned an unexpected JSON structure; voucher state moved to unknown.', 'gr-commerce-suite'),
                    CourierSlug::Acs,
                    $response->statusCode,
                    ['alias' => $alias]
                );
            }

            throw new CourierTransportException(
                __('ACS returned non-array JSON payload.', 'gr-commerce-suite'),
                CourierSlug::Acs,
                $response->statusCode
            );
        }

        if ($alias !== self::ALIAS_DELETE_VOUCHER) {
            $errorMsg = $this->extractAcsErrorMessage($decoded);
            if ($errorMsg !== '') {
                $this->throwMappedAcsError($errorMsg, $response->statusCode, $decoded);
            }
        }

        return $decoded;
    }

    /**
     * Send a single HTTP POST request to `ACSAutoRest` with `ACSApiKey` header and `ACSInputParameters` JSON body.
     *
     * Timeout Safety (SPEC.md §6.3, §7, §8.4):
     * If the HTTP request times out after transmission, transitions the voucher row `state` to `'unknown'`
     * via `VoucherStateTrackerInterface` and throws `CourierAmbiguousResultException` rather than blindly retrying.
     *
     * @param array<string, mixed> $inputParameters
     */
    private function sendAcsRequest(
        string $alias,
        array $inputParameters,
        int $timeoutSeconds,
        bool $isMutatingVoucherCall,
        ?int $orderId = null,
        ?string $idempotencyKey = null,
    ): HttpResponse {
        $payload = [
            'ACSAlias' => $alias,
            'ACSInputParameters' => array_merge($this->baseCredentials(), $inputParameters),
        ];

        $jsonBody = function_exists('wp_json_encode')
            ? (string) wp_json_encode($payload)
            : json_encode($payload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);

        $request = new HttpRequest(
            method: 'POST',
            url: $this->endpointUrl(),
            headers: [
                'ACSApiKey' => $this->apiKey(),
                'Content-Type' => 'application/json; charset=utf-8',
                'Accept' => 'application/json',
            ],
            body: $jsonBody,
            timeoutSeconds: $timeoutSeconds,
            connectTimeoutSeconds: 5,
        );

        try {
            $response = (new \GRCommerceSuite\Services\DiagnosticLogger())->send($this->httpClient, $request, 'ACS', match ($alias) {
                self::ALIAS_CREATE_VOUCHER => 'create_voucher', self::ALIAS_TRACKING_SUMMARY => 'track_voucher',
                self::ALIAS_DELETE_VOUCHER => 'cancel_voucher', self::ALIAS_PRINT_VOUCHER_V2 => 'print_voucher',
                self::ALIAS_ISSUE_PICKUP_LIST => 'issue_pickup_list', default => 'courier_request',
            }, $orderId);
        } catch (Throwable $e) {
            $msg = $e->getMessage();
            if ($this->isTimeoutMessage($msg)) {
                $this->transitionToUnknownOnTimeout(
                    orderId: $orderId,
                    idempotencyKey: $idempotencyKey,
                    errorMessage: sprintf(
                        'ACS %s timed out after transmission (%s); state transitioned to unknown.',
                        $alias,
                        $msg
                    ),
                );

                throw new CourierAmbiguousResultException(
                    sprintf(
                        __('ACS %s timed out after transmission; voucher state moved to %s.', 'gr-commerce-suite'),
                        $alias,
                        VoucherState::Unknown->value
                    ),
                    CourierSlug::Acs,
                    null,
                    ['alias' => $alias, 'state' => VoucherState::Unknown->value],
                    'The courier did not respond in time. The voucher has been marked as unknown ' .
                        'to prevent duplicate creation.',
                    $e
                );
            }

            throw new CourierTransportException(
                sprintf(__('ACS transport failure during %s: %s', 'gr-commerce-suite'), $alias, $msg),
                CourierSlug::Acs,
                null,
                ['alias' => $alias],
                null,
                $e
            );
        }

        // 1. Post-transmission read/operation timeout -> transition row `state` to `'unknown'` (never blindly retry)
        if ($response->timedOutAfterTransmission) {
            $timeoutReason = $response->errorMessage ?? sprintf('HTTP %d timeout', $response->statusCode);
            $this->transitionToUnknownOnTimeout(
                orderId: $orderId,
                idempotencyKey: $idempotencyKey,
                errorMessage: sprintf(
                    'ACS %s timed out after transmission (%s); state transitioned to unknown.',
                    $alias,
                    $timeoutReason
                ),
            );

            throw new CourierAmbiguousResultException(
                sprintf(
                    __('ACS %s timed out after transmission (%s); voucher state moved to %s.', 'gr-commerce-suite'),
                    $alias,
                    $timeoutReason,
                    VoucherState::Unknown->value
                ),
                CourierSlug::Acs,
                $response->statusCode > 0 ? $response->statusCode : null,
                ['alias' => $alias, 'state' => VoucherState::Unknown->value],
                'The courier did not respond before the timeout elapsed. The voucher state ' .
                    'was set to unknown to avoid duplicate charges.'
            );
        }

        // 2. Pre-transmission transport failure (DNS, TCP connect refused) -> safe to retry
        if ($response->hasError() || $response->failedBeforeTransmission) {
            throw new CourierTransportException(
                sprintf(
                    __('ACS connection failed before processing %s: %s', 'gr-commerce-suite'),
                    $alias,
                    $response->errorMessage ??
                    'unknown error'
                ),
                CourierSlug::Acs,
                null,
                ['alias' => $alias, 'error_code' => $response->errorCode]
            );
        }

        // 3. HTTP status classification
        if ($response->statusCode === 401 || $response->statusCode === 403) {
            throw new CourierAuthenticationException(
                __('ACS authentication rejected (invalid ACSApiKey or company/user credentials).', 'gr-commerce-suite'),
                CourierSlug::Acs,
                $response->statusCode,
                ['alias' => $alias],
                'ACS Courier authentication failed. Please verify your API Key and credentials in settings.'
            );
        }

        if ($response->statusCode === 429) {
            $retryAfter = (int) ($response->header('retry-after') ?? 60);
            throw new CourierRateLimitedException(
                __('ACS API rate limit exceeded.', 'gr-commerce-suite'),
                CourierSlug::Acs,
                max(1, $retryAfter),
                429,
                ['alias' => $alias]
            );
        }

        if ($response->statusCode >= 500) {
            throw new CourierTransportException(
                sprintf(__('ACS server error (HTTP %d) on %s.', 'gr-commerce-suite'), $response->statusCode, $alias),
                CourierSlug::Acs,
                $response->statusCode,
                ['alias' => $alias]
            );
        }

        if ($response->statusCode < 200 || $response->statusCode >= 300) {
            throw new CourierValidationException(
                sprintf(__('ACS rejected %s with HTTP %d.', 'gr-commerce-suite'), $alias, $response->statusCode),
                CourierSlug::Acs,
                $response->statusCode,
                ['alias' => $alias]
            );
        }

        return $response;
    }

    /**
     * Transition voucher row `state` to `'unknown'` via the injected tracker when a timeout occurs after transmission.
     */
    private function transitionToUnknownOnTimeout(
        ?int $orderId,
        ?string $idempotencyKey,
        string $errorMessage,
    ): void {
        $this->logger->warning(
            $errorMessage,
            [
                'order_id' => $orderId,
                'state' => VoucherState::Unknown->value,
            ]
        );

        if ($this->stateTracker !== null && $orderId !== null && $orderId > 0) {
            $this->stateTracker->markUnknownOnTimeout(
                orderId: $orderId,
                courier: CourierSlug::Acs,
                errorMessage: $errorMessage,
                idempotencyKey: $idempotencyKey,
            );
        }
    }

    /**
     * Extract binary PDF bytes from `ACS_Print_Voucher_V2` response and verify `%PDF-` magic header.
     *
     * @return non-empty-string
     */
    private function extractPdfBytesFromPrintResponse(HttpResponse $response, string $voucherNo): string
    {
        if (PdfMerger::isValidPdf($response->body)) {
            /** @var non-empty-string $rawBody */
            $rawBody = $response->body;

            return $rawBody;
        }

        try {
            $decoded = json_decode($response->body, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable $e) {
            throw new CourierTransportException(
                sprintf(__('ACS print response for voucher "%s" is neither a valid PDF nor valid JSON.', 'gr-commerce-suite'), $voucherNo),
                CourierSlug::Acs,
                $response->statusCode,
                ['voucher_no' => $voucherNo],
                null,
                $e
            );
        }

        if (!is_array($decoded)) {
            throw new CourierTransportException(
                sprintf(__('ACS print response for voucher "%s" did not contain PDF data.', 'gr-commerce-suite'), $voucherNo),
                CourierSlug::Acs,
                $response->statusCode
            );
        }

        $errorMsg = $this->extractAcsErrorMessage($decoded);
        if ($errorMsg !== '') {
            $this->throwMappedAcsError($errorMsg, $response->statusCode, $decoded);
        }

        $valueRows = $this->extractValueOutputRows($decoded);
        $first = $valueRows[0] ?? $decoded;

        $base64Candidate = (string) (
            $first['PDF_Base64']
            ?? $first['Voucher_PDF']
            ?? $first['pdf_base64']
            ?? $first['pdf']
            ?? $first['Base64_String']
            ?? $decoded['PDF_Base64']
            ?? $decoded['pdf_base64']
            ?? ''
        );

        if ($base64Candidate !== '') {
            $binary = base64_decode($base64Candidate, true);
            if (is_string($binary) && $binary !== '' && PdfMerger::isValidPdf($binary)) {
                return $binary;
            }
        }

        throw new CourierTransportException(
            sprintf(__('ACS print payload for voucher "%s" did not start with %%PDF- magic bytes.', 'gr-commerce-suite'), $voucherNo),
            CourierSlug::Acs,
            $response->statusCode
        );
    }

    /**
     * @param array<string, mixed> $decoded
     */
    private function extractVoucherNumber(array $decoded): string
    {
        $valueRows = $this->extractValueOutputRows($decoded);
        if ($valueRows !== []) {
            $first = $valueRows[0];
            $candidate = (string) ($first['Voucher_No'] ?? $first['voucher_no'] ?? $first['Parcel_No'] ?? '');
            if (trim($candidate) !== '') {
                return trim($candidate);
            }
        }

        $topCandidate = (string) ($decoded['Voucher_No'] ?? $decoded['voucher_no'] ?? '');

        return trim($topCandidate);
    }

    /**
     * @param array<string, mixed> $decoded
     * @return list<array<string, mixed>>
     */
    private function extractValueOutputRows(array $decoded): array
    {
        $envelope = $decoded['ACSOutputResponce'] ?? $decoded['ACSOutputResponse'] ?? $decoded;
        if (!is_array($envelope)) {
            return [];
        }

        $valueOutput = $envelope['ACSValueOutput'] ?? null;
        if (!is_array($valueOutput)) {
            return [];
        }

        if (array_is_list($valueOutput)) {
            $rows = [];
            foreach ($valueOutput as $item) {
                if (is_array($item)) {
                    $rows[] = $item;
                }
            }

            return $rows;
        }

        return [$valueOutput];
    }

    /**
     * @param array<string, mixed> $decoded
     * @return list<array<string, mixed>>
     */
    private function extractTableOrValueRows(array $decoded): array
    {
        $envelope = $decoded['ACSOutputResponce'] ?? $decoded['ACSOutputResponse'] ?? $decoded;
        if (!is_array($envelope)) {
            return [];
        }

        $tableOutput = $envelope['ACSTableOutput'] ?? null;
        if (is_array($tableOutput)) {
            $tableData = $tableOutput['Table_Data'] ?? $tableOutput['Table_Data1'] ?? $tableOutput;
            if (is_array($tableData) && array_is_list($tableData)) {
                $rows = [];
                foreach ($tableData as $row) {
                    if (is_array($row)) {
                        $rows[] = $row;
                    }
                }
                if ($rows !== []) {
                    return $rows;
                }
            }
        }

        return $this->extractValueOutputRows($decoded);
    }

    /**
     * @param array<string, mixed> $decoded
     */
    private function extractAcsErrorMessage(array $decoded): string
    {
        $envelope = $decoded['ACSOutputResponce'] ?? $decoded['ACSOutputResponse'] ?? $decoded;
        if (!is_array($envelope)) {
            return '';
        }

        $errorOutput = $envelope['ACSErrorOutput'] ?? null;
        if (is_array($errorOutput)) {
            $msg = trim((string) ($errorOutput['Error_Message'] ?? $errorOutput['error_message'] ?? ''));
            if ($msg !== '') {
                return $msg;
            }
        }

        $valueRows = $this->extractValueOutputRows($decoded);
        foreach ($valueRows as $row) {
            $errMsg = trim((string) ($row['Error_Message'] ?? $row['error_message'] ?? ''));
            if ($errMsg !== '') {
                return $errMsg;
            }
        }

        return trim((string) ($decoded['Error_Message'] ?? $decoded['error_message'] ?? ''));
    }

    /**
     * @param array<string, mixed> $decoded
     */
    private function throwMappedAcsError(string $errorMessage, int $httpStatus, array $decoded): never
    {
        $lower = mb_strtolower($errorMessage, 'UTF-8');
        $redacted = Redactor::redactArray($decoded);

        if (
            str_contains($lower, 'api key')
            || str_contains($lower, 'unauthorized')
            || str_contains($lower, 'authentication')
            || str_contains($lower, 'password')
            || str_contains($lower, 'κωδικ')
            || str_contains($lower, 'πρόσβασ')
        ) {
            throw new CourierAuthenticationException(
                sprintf(__('ACS authentication error: %s', 'gr-commerce-suite'), $errorMessage),
                CourierSlug::Acs,
                $httpStatus,
                $redacted
            );
        }

        if (str_contains($lower, 'not found') || str_contains($lower, 'δεν βρέθηκε')) {
            throw new VoucherNotFoundException(
                sprintf(__('ACS voucher not found: %s', 'gr-commerce-suite'), $errorMessage),
                CourierSlug::Acs,
                $httpStatus,
                $redacted
            );
        }

        throw new CourierValidationException(
            sprintf(__('ACS validation error: %s', 'gr-commerce-suite'), $errorMessage),
            CourierSlug::Acs,
            $httpStatus,
            $redacted,
            $errorMessage
        );
    }

    /**
     * Map ACS checkpoint codes / descriptions to normalised `TrackingStatus` (SPEC.md §11.1).
     */
    private function mapStatusCode(string $code, string $label): TrackingStatus
    {
        $normalizedCode = strtoupper(trim($code));
        if (
            in_array(
                mb_strtolower(
                    trim($code),
                    'UTF-8'
                ),
                ['returned',
                 'refused',
                 'επιστροφή',
                 'άρνηση παραλαβής'],
                true
            )
            ||
                 in_array(
                     mb_strtolower(
                         trim($label),
                         'UTF-8'
                     ),
                     ['returned',
                     'refused',
                     'επιστροφή',
                     'άρνηση παραλαβής'],
                     true
                 )
        ) {
            return TrackingStatus::Returned;
        }
        $lowerLabel = mb_strtolower(trim($label), 'UTF-8');

        $directMap = [
            '1' => TrackingStatus::PickedUp,
            'PICKED_UP' => TrackingStatus::PickedUp,
            '2' => TrackingStatus::InTransit,
            'IN_TRANSIT' => TrackingStatus::InTransit,
            '3' => TrackingStatus::OutForDelivery,
            'OUT_FOR_DELIVERY' => TrackingStatus::OutForDelivery,
            '4' => TrackingStatus::Delivered,
            'DELIVERED' => TrackingStatus::Delivered,
            '5' => TrackingStatus::DeliveryFailed,
            'DELIVERY_FAILED' => TrackingStatus::DeliveryFailed,
            '6' => TrackingStatus::ReadyForPickup,
            'READY_FOR_PICKUP' => TrackingStatus::ReadyForPickup,
            '7' => TrackingStatus::Returning,
            'RETURNING' => TrackingStatus::Returning,
            '8' => TrackingStatus::Returned,
            'RETURNED' => TrackingStatus::Returned,
            '9' => TrackingStatus::Cancelled,
            'CANCELLED' => TrackingStatus::Cancelled,
            '0' => TrackingStatus::Pending,
            'PENDING' => TrackingStatus::Pending,
        ];

        if (isset($directMap[$normalizedCode])) {
            return $directMap[$normalizedCode];
        }

        if (str_contains($lowerLabel, 'επιστροφ') || str_contains($lowerLabel, 'return')) {
            return str_contains($lowerLabel, 'παραδόθηκε') || str_contains($lowerLabel, 'returned')
                ? TrackingStatus::Returned : TrackingStatus::Returning;
        }
        if (str_contains($lowerLabel, 'παραδόθηκε') || str_contains($lowerLabel, 'delivered')) {
            return TrackingStatus::Delivered;
        }
        if (str_contains($lowerLabel, 'προς παράδοση') || str_contains($lowerLabel, 'out for delivery')) {
            return TrackingStatus::OutForDelivery;
        }
        if (str_contains($lowerLabel, 'παραλαβή') || str_contains($lowerLabel, 'picked up')) {
            return TrackingStatus::PickedUp;
        }
        if (str_contains($lowerLabel, 'κατάστημα') || str_contains($lowerLabel, 'smartpoint')) {
            return TrackingStatus::ReadyForPickup;
        }
        if (str_contains($lowerLabel, 'αποτυχ') || str_contains($lowerLabel, 'αδυναμία')) {
            return TrackingStatus::DeliveryFailed;
        }
        if (
            str_contains(
                $lowerLabel,
                'διακίνηση'
            ) ||
             str_contains(
                 $lowerLabel,
                 'transit'
             ) ||
             str_contains(
                 $lowerLabel,
                 'hub'
             )
        ) {
            return TrackingStatus::InTransit;
        }

        if (!isset($this->loggedUnknownStatusCodes[$normalizedCode])) {
            $this->loggedUnknownStatusCodes[$normalizedCode] = true;
            $this->logger->warning(
                'Unmapped ACS tracking status code encountered; mapped to TrackingStatus::Unknown.',
                ['code' => $normalizedCode, 'label' => $label]
            );
        }

        return TrackingStatus::Unknown;
    }

    /**
     * @return array<string, string>
     */
    private function baseCredentials(): array
    {
        return [
            'Company_ID' => $this->credential('company_id', 'grcs_acs_company_id'),
            'Company_Password' => $this->credential('company_password', 'grcs_acs_company_password'),
            'User_ID' => $this->credential('user_id', 'grcs_acs_user_id'),
            'User_Password' => $this->credential('user_password', 'grcs_acs_user_password'),
            'Language' => (string) ($this->credentials['language'] ?? 'GR'),
        ];
    }

    private function apiKey(): string
    {
        return $this->credential('api_key', 'grcs_acs_api_key');
    }

    private function credential(string $key, string $optionName): string
    {
        $direct = trim((string) ($this->credentials[$key] ?? ''));
        if ($direct !== '') {
            return $direct;
        }

        if (function_exists('get_option')) {
            $opt = get_option($optionName, '');
            if (is_scalar($opt)) {
                return trim((string) $opt);
            }
        }

        return '';
    }

    private function endpointUrl(): string
    {
        $custom = trim((string) ($this->credentials['endpoint_url'] ?? ''));

        return $custom !== '' ? $custom : self::ENDPOINT_URL;
    }

    private function senderName(): string
    {
        $configured = trim((string) get_option(ShippingOptions::SENDER, $this->credentials['sender_name'] ?? ''));
        if ($configured !== '') {
            return $configured;
        }

        if (function_exists('get_bloginfo')) {
            $blogName = trim((string) get_bloginfo('name'));
            if ($blogName !== '') {
                return $blogName;
            }
        }

        return 'GR Commerce Store';
    }

    private function resolveRecipientName(WC_Order $order): string
    {
        $shippingName = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
        if ($shippingName !== '') {
            return $shippingName;
        }

        return trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
    }

    private function resolveAddressLine(WC_Order $order): string
    {
        $shippingAddr = trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2());
        if ($shippingAddr !== '') {
            return $shippingAddr;
        }

        return trim($order->get_billing_address_1() . ' ' . $order->get_billing_address_2());
    }

    private function resolveCity(WC_Order $order): string
    {
        $city = trim((string) $order->get_shipping_city());
        if ($city !== '') {
            return $city;
        }

        return trim((string) $order->get_billing_city());
    }

    private function resolvePostcode(WC_Order $order): string
    {
        $postcode = trim((string) $order->get_shipping_postcode());
        if ($postcode !== '') {
            return $postcode;
        }

        return trim((string) $order->get_billing_postcode());
    }

    private function resolveCountry(WC_Order $order): string
    {
        $country = strtoupper(trim((string) $order->get_shipping_country()));
        if ($country !== '') {
            return $country;
        }

        $billingCountry = strtoupper(trim((string) $order->get_billing_country()));

        return $billingCountry !== '' ? $billingCountry : 'GR';
    }

    private function resolvePhone(WC_Order $order): string
    {
        $shippingPhone = trim((string) $order->get_shipping_phone());
        $billingPhone = trim((string) $order->get_billing_phone());

        if ($shippingPhone !== '' && $billingPhone !== '' && $shippingPhone !== $billingPhone) {
            return $shippingPhone . ',' . $billingPhone;
        }

        return $shippingPhone !== '' ? $shippingPhone : $billingPhone;
    }

    /** @return array{landline: string, mobile: string} */
    private function recipientPhones(WC_Order $order): array
    {
        $phones = ['landline' => '', 'mobile' => ''];
        foreach ([$order->get_shipping_phone(), $order->get_billing_phone()] as $raw) {
            foreach (preg_split('/[,;\/|]+/', (string) $raw) ?: [] as $candidate) {
                $normalized = PhoneNormalizer::toE164($candidate);
                if ($normalized === '') {
                    continue;
                }
                $kind = PhoneNormalizer::isGreekMobile($candidate) ? 'mobile' : 'landline';
                if ($phones[$kind] === '') {
                    $phones[$kind] = str_starts_with($normalized, '+30') ? PhoneNormalizer::toNationalDigits($candidate) : $normalized;
                }
            }
        }
        return $phones;
    }

    private function resolveCodAmountCents(WC_Order $order): int
    {
        $override = $order->get_meta('_grcs_custom_cod_amount', true);
        if (is_string($override) && $override !== '') {
            return max(0, Money::fromDecimalString($override)->cents());
        }
        if (strtolower((string) $order->get_payment_method()) !== 'cod') {
            return 0;
        }

        return Money::fromDecimalString((string) $order->get_total())->cents();
    }

    private function resolveOrderWeightKg(WC_Order $order): string
    {
        return number_format(max(0.5, ShippingOptions::weightKg($order)), 2, '.', '');
    }

    private function parseDateTime(string $raw): ?DateTimeImmutable
    {
        $trimmed = trim($raw);
        if ($trimmed === '') {
            return null;
        }

        try {
            $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('Europe/Athens');

            return new DateTimeImmutable($trimmed, $tz);
        } catch (Throwable) {
            return null;
        }
    }

    private function isTimeoutMessage(string $message): bool
    {
        $lower = strtolower($message);

        return str_contains($lower, 'timed out')
            || str_contains($lower, 'timeout')
            || str_contains($lower, 'curl error 28');
    }
}
