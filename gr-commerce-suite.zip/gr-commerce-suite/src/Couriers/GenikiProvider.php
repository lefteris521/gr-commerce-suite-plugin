<?php

declare(strict_types=1);

namespace GRCommerceSuite\Couriers;

use DateTimeImmutable;
use DateTimeZone;
use GRCommerceSuite\Contracts\CourierProviderInterface;
use GRCommerceSuite\Contracts\CredentialsValidatorInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Contracts\VoucherLookupInterface;
use GRCommerceSuite\Contracts\VoucherStateTrackerInterface;
use GRCommerceSuite\Couriers\Geniki\GenikiStatusMap;
use GRCommerceSuite\Couriers\Geniki\SoapEnvelopeBuilder;
use GRCommerceSuite\Couriers\Geniki\SoapResponseParser;
use GRCommerceSuite\Domain\Cod\CodReconciliationResult;
use GRCommerceSuite\Domain\Cod\CodSettlementStatus;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Tracking\TrackingEvent;
use GRCommerceSuite\Domain\Tracking\TrackingResult;
use GRCommerceSuite\Domain\Tracking\TrackingStatus;
use GRCommerceSuite\Domain\Voucher\PrintFormat;
use GRCommerceSuite\Domain\Voucher\VoucherResult;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Exceptions\Courier\CourierAmbiguousResultException;
use GRCommerceSuite\Exceptions\Courier\CourierAuthenticationException;
use GRCommerceSuite\Exceptions\Courier\CourierRateLimitedException;
use GRCommerceSuite\Exceptions\Courier\CourierTransportException;
use GRCommerceSuite\Exceptions\Courier\CourierValidationException;
use GRCommerceSuite\Exceptions\Courier\UnsupportedPrintFormatException;
use GRCommerceSuite\Exceptions\Courier\VoucherNotFoundException;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Http\HttpRequest;
use GRCommerceSuite\Http\HttpResponse;
use GRCommerceSuite\Pdf\PdfMerger;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\ShippingOptions;
use GRCommerceSuite\Support\Logger;
use GRCommerceSuite\Support\Money;
use GRCommerceSuite\Support\PhoneNormalizer;
use GRCommerceSuite\Support\Redactor;
use GRCommerceSuite\Utils\GreekDataNormalizer;
use Throwable;
use WC_Order;
use WC_Order_Item_Product;
use WC_Product;

/**
 * Geniki Taxydromiki Web API V2 Provider (`JobServicesV2.asmx`) (SPEC.md §8, §8.5).
 *
 * Implements SOAP 1.1 communication manually over WordPress HTTP API without requiring ext-soap.
 *
 * Endpoints:
 *  - Production: `https://voucher.taxydromiki.gr/JobServicesV2.asmx`
 *  - Sandbox:    `https://testvoucher.taxydromiki.gr/JobServicesV2.asmx`
 *
 * Supported operations:
 *  - `Authenticate`
 *  - `CreateJob`
 *  - `CancelJob`
 *  - `TrackAndTrace`
 *  - `GetVouchersPdf` / `GetVoucherPdf`
 *  - `GetJobs`
 *  - `GetJobsFromOrderId`
 *  - `ClosePendingJobs`
 */
final class GenikiProvider implements CourierProviderInterface, CredentialsValidatorInterface, VoucherLookupInterface
{
    public const PRODUCTION_ENDPOINT = 'https://voucher.taxydromiki.gr/JobServicesV2.asmx';
    public const SANDBOX_ENDPOINT = 'https://testvoucher.taxydromiki.gr/JobServicesV2.asmx';

    public const DEFAULT_COD_SERVICE = 'αμ'; // Greek abbreviation for Antikatavoli Metrita (Cash on Delivery - Cash)
    public const DEFAULT_COD_CASH_LIMIT_CENTS = 50000; // EUR 500.00 cash transaction cap

    private const TRANSIENT_AUTH_KEY_PREFIX = 'grcs_geniki_auth_';
    private const AUTH_KEY_TTL_SECONDS = 7200; // 2 hours
    /**
     * C2: mutating calls refresh a key that is within this window of its TTL, so Result 11 (expired key)
     * should not reach CreateJob/CancelJob/ClosePendingJobs. 15 min covers the longest mutating timeout (30 s),
     * WP/Geniki clock skew and the fact that the 2 h TTL is our cache estimate, not a lifetime Geniki confirmed;
     * the cost is at most one extra Authenticate per 2 h.
     */
    private const AUTH_KEY_REFRESH_MARGIN_SECONDS = 900;

    private ?string $inMemoryAuthKey = null;
    private ?string $inMemoryAuthFingerprint = null;
    /** Issue time of the cached key; 0 = unknown (legacy transient), treated as stale for mutations. */
    private int $inMemoryIssuedAt = 0;

    /**
     * @var array<string, true>
     */
    private array $loggedUnknownStatusCodes = [];

    private readonly LoggerInterface $logger;
    private readonly PdfMerger $pdfMerger;

    /**
     * @param array{
     *     username?: string,
     *     password?: string,
     *     application_key?: string,
     *     environment?: string,
     *     endpoint_url?: string,
     *     default_service_code?: string,
     *     cod_service_code?: string,
     *     cod_cash_limit_cents?: int|string
     * } $credentials
     */
    public function __construct(
        private readonly HttpClientInterface $httpClient,
        private readonly array $credentials = [],
        ?LoggerInterface $logger = null,
        ?PdfMerger $pdfMerger = null,
        private readonly ?VoucherStateTrackerInterface $stateTracker = null,
    ) {
        $this->logger = $logger ?? new Logger('grcs-geniki');
        $this->pdfMerger = $pdfMerger ?? new PdfMerger();
    }

    /**
     * Authenticate with Geniki Taxydromiki and return active session auth key (`sAuthKey`).
     *
     * Caches the key in WordPress transients and in-memory to prevent redundant authentication round-trips.
     *
     * @throws CourierAuthenticationException
     * @throws CourierTransportException
     */
    public function authenticate(bool $forceRefresh = false): string
    {
        $username = $this->credential('username');
        $password = $this->credential('password');
        $appKey = $this->credential('application_key');

        if ($username === '' || $password === '' || $appKey === '') {
            throw new CourierAuthenticationException(
                __('Geniki Taxydromiki authentication failed: Username, Password, and Application Key are required.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $transientKey = $this->authCacheKey();
        $now = time();
        if (!$forceRefresh && $this->inMemoryAuthKey !== null && $this->inMemoryAuthFingerprint === $transientKey
            && $this->inMemoryIssuedAt + self::AUTH_KEY_TTL_SECONDS > $now) {
            return $this->inMemoryAuthKey;
        }

        if (!$forceRefresh && function_exists('get_transient')) {
            $cached = $this->decodeCachedAuthKey(get_transient($transientKey));
            if ($cached !== null) {
                $this->inMemoryAuthKey = $cached['key'];
                $this->inMemoryAuthFingerprint = $transientKey;
                $this->inMemoryIssuedAt = $cached['issued_at'];
                return $this->inMemoryAuthKey;
            }
        }

        $soapEnvelope = SoapEnvelopeBuilder::buildAuthenticate($username, $password, $appKey);
        $response = $this->sendSoapRequest(
            soapAction: 'Authenticate',
            soapBody: $soapEnvelope,
            timeoutSeconds: 15,
            isMutatingVoucherCall: false
        );

        $parsed = SoapResponseParser::parseAuthenticate($response->body);
        if (in_array($parsed['result'], [14, 15], true)) {
            $this->handleApiErrorCode('Authenticate', $parsed['result'], $response->statusCode, ['result' => $parsed['result']]);
        }
        if ($parsed['result'] !== 0 || $parsed['key'] === '') {
            throw new CourierAuthenticationException(
                sprintf(__('Geniki Taxydromiki authentication rejected with error code %d.', 'gr-commerce-suite'), $parsed['result']),
                CourierSlug::Geniki,
                $response->statusCode,
                ['result' => $parsed['result']]
            );
        }

        $authKey = $parsed['key'];
        $this->inMemoryAuthKey = $authKey;
        $this->inMemoryAuthFingerprint = $transientKey;
        $this->inMemoryIssuedAt = $now;

        if (function_exists('set_transient')) {
            // Session key stays plaintext (owner decision, memo 5); issued_at lets other requests judge its age.
            set_transient($transientKey, json_encode(['key' => $authKey, 'issued_at' => $now], JSON_THROW_ON_ERROR), self::AUTH_KEY_TTL_SECONDS);
        }

        return $authKey;
    }

    /**
     * Read a cached auth transient: JSON `{key, issued_at}`, or a bare key string from before C2 (issue time unknown).
     *
     * @return array{key: string, issued_at: int}|null
     */
    private function decodeCachedAuthKey(mixed $cached): ?array
    {
        if (!is_string($cached) || trim($cached) === '') {
            return null;
        }

        $decoded = json_decode($cached, true);
        if (is_array($decoded)) {
            $key = is_string($decoded['key'] ?? null) ? trim($decoded['key']) : '';
            $issuedAt = is_int($decoded['issued_at'] ?? null) ? $decoded['issued_at'] : 0;
            return $key !== '' ? ['key' => $key, 'issued_at' => $issuedAt] : null;
        }

        return ['key' => trim($cached), 'issued_at' => 0];
    }

    /**
     * C2: key for a mutating call, force-refreshed when it is within the safety margin of expiry or its age is unknown.
     */
    private function authenticateForMutation(): string
    {
        $authKey = $this->authenticate();
        if ($this->inMemoryIssuedAt + self::AUTH_KEY_TTL_SECONDS - self::AUTH_KEY_REFRESH_MARGIN_SECONDS <= time()) {
            $this->logger->info('Geniki Taxydromiki session key is near expiry; refreshing before a mutating call.');
            $authKey = $this->authenticate(forceRefresh: true);
        }

        return $authKey;
    }

    /**
     * Clear cached authentication key when expired or revoked.
     */
    public function invalidateAuthKey(): void
    {
        $this->inMemoryAuthKey = null;
        $this->inMemoryAuthFingerprint = null;
        $this->inMemoryIssuedAt = 0;

        if (function_exists('delete_transient')) {
            delete_transient($this->authCacheKey());
        }
    }

    /**
     * Compute a nonreversible, collision-resistant cache key bound to endpoint and full credentials (G9).
     */
    private function authCacheKey(): string
    {
        $endpoint = $this->resolveEndpoint();
        $username = $this->credential('username');
        $password = $this->credential('password');
        $appKey = $this->credential('application_key');

        $fingerprint = hash('sha256', (string) json_encode([$endpoint, $username, $password, $appKey], JSON_THROW_ON_ERROR));

        return self::TRANSIENT_AUTH_KEY_PREFIX . substr($fingerprint, 0, 24);
    }

    /**
     * Create one shipping voucher (AWB) for the order via `CreateJob` (SPEC.md §8.2, §8.5).
     */
    public function createVoucher(WC_Order $order): VoucherResult
    {
        $orderId = (int) $order->get_id();
        $recipientName = GreekDataNormalizer::stripGreekAccentsUpper($this->resolveRecipientName($order));
        $recipientAddress = GreekDataNormalizer::stripGreekAccentsUpper($this->resolveAddressLine($order));
        $recipientCity = GreekDataNormalizer::stripGreekAccentsUpper($this->resolveCity($order));
        $rawPostcode = $this->resolvePostcode($order);
        $postcode = PhoneNormalizer::normalisePostcode($rawPostcode);
        if (strlen($postcode) !== 5 && preg_match('/\b(\d{3}\s?\d{2})\b/u', $recipientAddress, $pcMatch) === 1) {
            $postcode = PhoneNormalizer::normalisePostcode($pcMatch[1]);
        }
        $country = $this->resolveCountry($order);
        $rawPhone = $this->resolvePhone($order);
        $nationalPhone = PhoneNormalizer::toNationalDigits($rawPhone);

        if ($recipientName === '') {
            throw new CourierValidationException(
                __('Geniki Taxydromiki voucher creation failed: recipient name is required.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        if ($recipientAddress === '' || $recipientCity === '') {
            throw new CourierValidationException(
                __('Geniki Taxydromiki voucher creation failed: recipient street address and city are required.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        if ($country === 'GR' && strlen($postcode) !== 5) {
            throw new CourierValidationException(
                sprintf(__('Geniki Taxydromiki voucher creation failed: invalid 5-digit Greek postcode "%s".', 'gr-commerce-suite'), $rawPostcode),
                CourierSlug::Geniki
            );
        }

        if ($nationalPhone === '') {
            throw new CourierValidationException(
                __('Geniki Taxydromiki voucher creation failed: a valid recipient telephone number is required.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $codAmountCents = $this->resolveCodAmountCents($order);
        $cashLimitCents = (int) ($this->credentials['cod_cash_limit_cents'] ?? self::DEFAULT_COD_CASH_LIMIT_CENTS);
        if ($codAmountCents > $cashLimitCents) {
            $this->logger->warning(
                'Geniki Taxydromiki COD amount exceeds configured cash transaction warning threshold.',
                [
                    'order_id' => $orderId,
                    'cod_cents' => $codAmountCents,
                    'limit_cents' => $cashLimitCents,
                ]
            );
        }

        $idempotencyKey = (string) $order->get_meta('_grcs_active_idempotency_key', true);
        $referencePrefix = $idempotencyKey !== ''
            ? substr($idempotencyKey, 0, 16)
            : (string) $order->get_order_number();

        $customerNote = trim((string) $order->get_customer_note());
        $voucherComments = $customerNote !== ''
            ? mb_substr($customerNote, 0, 40, 'UTF-8')
            : mb_substr('REF:' . $referencePrefix, 0, 40, 'UTF-8');

        $codServiceCode = trim((string) ($this->credentials['cod_service_code'] ?? self::DEFAULT_COD_SERVICE));
        if ($codServiceCode === '') {
            $codServiceCode = self::DEFAULT_COD_SERVICE;
        }

        $defaultService = trim((string) ($this->credentials['default_service_code'] ?? ''));
        $services = [];
        if ($defaultService !== '') {
            $services[] = $defaultService;
        }
        if ($codAmountCents > 0) {
            $services[] = $codServiceCode;
        }
        $servicesString = implode(',', array_unique($services));

        $weightKg = $this->resolveOrderWeightKg($order);
        $parcelCount = ShippingOptions::parcelCount($order);

        $payload = [
            'order_id' => $referencePrefix,
            'name' => mb_substr($recipientName, 0, 60, 'UTF-8'),
            'address' => mb_substr($recipientAddress, 0, 80, 'UTF-8'),
            'city' => mb_substr($recipientCity, 0, 50, 'UTF-8'),
            'zip' => $postcode,
            'telephone' => $nationalPhone,
            'email' => mb_substr(trim((string) $order->get_billing_email()), 0, 80, 'UTF-8'),
            'country' => $country === 'GR' ? 'Greece' : $country,
            'country_iso' => $country,
            'pieces' => $parcelCount,
            'weight' => $weightKg,
            'comments' => $voucherComments,
            'services' => $servicesString,
            'cod_amount' => $codAmountCents > 0 ? Money::fromCents($codAmountCents)->toDecimalString() : '0.00',
            'ins_amount' => '0.00',
        ];

        $response = $this->executeWithAuth(
            function (string $authKey) use ($payload, $orderId, $idempotencyKey): HttpResponse {
                $soapBody = SoapEnvelopeBuilder::buildCreateJob($authKey, $payload, 'Voucher');
                return $this->sendSoapRequest(
                    soapAction: 'CreateJob',
                    soapBody: $soapBody,
                    timeoutSeconds: 20,
                    isMutatingVoucherCall: true,
                    orderId: $orderId,
                    idempotencyKey: $idempotencyKey !== '' ? $idempotencyKey : null,
                );
            },
            orderId: $orderId,
            idempotencyKey: $idempotencyKey !== '' ? $idempotencyKey : null,
            mutating: true
        );

        try {
            $parsed = SoapResponseParser::parseCreateJob($response->body);
        } catch (Throwable $e) {
            $msg = sprintf(
                __('Geniki Taxydromiki CreateJob returned unparseable or empty response: %s', 'gr-commerce-suite'),
                $e->getMessage()
            );
            $this->transitionToUnknownOnTimeout($orderId, $idempotencyKey !== '' ? $idempotencyKey : null, $msg);
            throw new CourierAmbiguousResultException(
                $msg,
                CourierSlug::Geniki,
                $response->statusCode,
                ['error' => $e->getMessage()],
                'Courier returned an unreadable response after voucher creation. Voucher marked as unknown to prevent duplicate creation.',
                $e
            );
        }

        $resultCode = $parsed['result'];

        if ($resultCode === 8 || $resultCode === 12) {
            $msg = sprintf(
                __('Geniki Taxydromiki internal server/runtime error (Result %d) on CreateJob. Non-creation cannot be proven.', 'gr-commerce-suite'),
                $resultCode
            );
            $this->transitionToUnknownOnTimeout($orderId, $idempotencyKey !== '' ? $idempotencyKey : null, $msg);
            throw new CourierAmbiguousResultException(
                $msg,
                CourierSlug::Geniki,
                $response->statusCode,
                Redactor::redactArray($parsed),
                'Internal server error occurred on voucher creation. Marked as unknown to prevent duplicate voucher creation.'
            );
        }

        if ($resultCode !== 0) {
            $this->handleApiErrorCode('CreateJob', $resultCode, $response->statusCode, $parsed);
        }

        $voucherNo = $parsed['voucher'];
        if ($voucherNo === '') {
            $msg = __('Geniki Taxydromiki CreateJob returned success (Result 0) without a valid Voucher number.', 'gr-commerce-suite');
            $this->transitionToUnknownOnTimeout($orderId, $idempotencyKey !== '' ? $idempotencyKey : null, $msg);
            throw new CourierAmbiguousResultException(
                $msg,
                CourierSlug::Geniki,
                200,
                Redactor::redactArray($parsed),
                'Courier response was incomplete. Voucher marked as unknown for manual or automated verification.'
            );
        }

        return new VoucherResult(
            voucherNo: $voucherNo,
            courier: CourierSlug::Geniki,
            codAmountCents: $codAmountCents,
            parcelCount: $parcelCount,
            trackingUrl: \GRCommerceSuite\Services\TrackingService::publicUrl($voucherNo, CourierSlug::Geniki),
            lockerId: null,
            rawResponse: Redactor::redactArray($parsed + ['job_id' => $parsed['job_id']]),
        );
    }

    /**
     * Cancel (void) a voucher that has not yet been picked up via `CancelJob`.
     *
     * Idempotent: cancelling an already-cancelled voucher returns true.
     */
    public function cancelVoucher(string $voucherNo): bool
    {
        $trimmed = trim($voucherNo);
        if ($trimmed === '') {
            throw new CourierValidationException(
                __('Geniki Taxydromiki voucher number cannot be empty for cancellation.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        // Look up the Job ID associated with this voucher number
        $job = $this->findJobByVoucherNumber($trimmed);
        if ($job === null) {
            throw new VoucherNotFoundException(
                sprintf(__('Geniki Taxydromiki voucher "%s" was not found for cancellation.', 'gr-commerce-suite'), $trimmed),
                CourierSlug::Geniki
            );
        }

        // Idempotency: if already cancelled, return true immediately
        if ($job['is_canceled']) {
            return true;
        }

        $jobId = $job['id'];
        $response = $this->executeWithAuth(
            function (string $authKey) use ($jobId): HttpResponse {
                $soapBody = SoapEnvelopeBuilder::buildCancelJob($authKey, $jobId, true);
                return $this->sendSoapRequest(
                    soapAction: 'CancelJob',
                    soapBody: $soapBody,
                    timeoutSeconds: 15,
                    isMutatingVoucherCall: false
                );
            },
            mutating: true
        );

        $resultCode = SoapResponseParser::parseCancelJob($response->body);

        if ($resultCode === 0 || $resultCode === 13) {
            return true;
        }

        // Code 4: Invalid operation (job already closed / parcel picked up in carrier network)
        if ($resultCode === 4) {
            $this->logger->info(
                sprintf('Geniki Taxydromiki refused cancellation for voucher "%s" (job %d): parcel already closed/in-network (Result 4).', $trimmed, $jobId),
                ['voucher_no' => $trimmed, 'job_id' => $jobId]
            );
            return false;
        }

        // Map other error codes (auth, not found, etc.)
        $this->handleApiErrorCode('CancelJob', $resultCode, $response->statusCode, ['job_id' => $jobId]);
    }

    /**
     * Render labels for up to 100 vouchers of Geniki Taxydromiki as ONE PDF document.
     */
    public function printVoucherPdf(array $voucherNos, string $format): string
    {
        if ($voucherNos === []) {
            throw new CourierValidationException(
                __('At least one voucher number is required for printing.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        if (count($voucherNos) > 100) {
            throw new CourierValidationException(
                __('Cannot print more than 100 vouchers in a single request.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $printFormat = PrintFormat::tryFrom(strtolower(trim($format)));
        if ($printFormat === null) {
            throw new UnsupportedPrintFormatException(
                sprintf(__('Unsupported print format "%s" for Geniki Taxydromiki.', 'gr-commerce-suite'), $format),
                CourierSlug::Geniki
            );
        }

        // Map canonical format to Geniki MediaFormat
        $genikiFormat = match ($printFormat) {
            PrintFormat::A4 => 'Flyer',
            PrintFormat::A6, PrintFormat::Thermal => 'Sticker',
        };

        $cleanVouchers = [];
        foreach ($voucherNos as $v) {
            $tv = trim($v);
            if ($tv !== '') {
                $cleanVouchers[] = $tv;
            }
        }

        if ($cleanVouchers === []) {
            throw new CourierValidationException(
                __('No valid voucher numbers provided for printing.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $response = $this->executeWithAuth(
            function (string $authKey) use ($cleanVouchers, $genikiFormat): HttpResponse {
                $soapBody = SoapEnvelopeBuilder::buildGetVouchersPdf(
                    authKey: $authKey,
                    voucherNumbers: $cleanVouchers,
                    format: $genikiFormat,
                    extraInfoFormat: 'None'
                );
                return $this->sendSoapRequest(
                    soapAction: 'GetVouchersPdf',
                    soapBody: $soapBody,
                    timeoutSeconds: 30,
                    isMutatingVoucherCall: false
                );
            }
        );

        $pdf = $this->extractPdfBytes($response, $cleanVouchers);

        return $this->pdfMerger->merge([$pdf]);
    }

    /**
     * Fetch current tracking state of a single voucher via `TrackAndTrace`.
     */
    public function getTrackingStatus(string $voucherNo): TrackingResult
    {
        $trimmed = trim($voucherNo);
        if ($trimmed === '') {
            throw new CourierValidationException(
                __('Voucher number cannot be empty for tracking.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $response = $this->executeWithAuth(
            function (string $authKey) use ($trimmed): HttpResponse {
                $soapBody = SoapEnvelopeBuilder::buildTrackAndTrace($authKey, $trimmed, 'el');
                return $this->sendSoapRequest(
                    soapAction: 'TrackAndTrace',
                    soapBody: $soapBody,
                    timeoutSeconds: 15,
                    isMutatingVoucherCall: false
                );
            }
        );

        $parsed = SoapResponseParser::parseTrackAndTrace($response->body);
        $resultCode = $parsed['result'];

        if ($resultCode !== 0) {
            $this->handleApiErrorCode('TrackAndTrace', $resultCode, $response->statusCode, $parsed);
        }

        $rawCheckpoints = $parsed['checkpoints'];

        // Establish chronological ordering: do not assume array order is sorted
        $orderedCheckpoints = [];
        foreach ($rawCheckpoints as $origIdx => $cp) {
            $occurredAt = $this->parseDateTime($cp['status_date'] ?? '') ?? new DateTimeImmutable('1970-01-01 00:00:00', new DateTimeZone('UTC'));
            $orderedCheckpoints[] = [
                'orig_idx' => $origIdx,
                'occurred_at' => $occurredAt,
                'cp' => $cp,
            ];
        }

        usort($orderedCheckpoints, function (array $a, array $b): int {
            $cmp = $a['occurred_at'] <=> $b['occurred_at'];
            if ($cmp !== 0) {
                return $cmp;
            }
            return $a['orig_idx'] <=> $b['orig_idx'];
        });

        // Build chronological events list for complete audit trail
        $events = [];
        foreach ($orderedCheckpoints as $item) {
            $cp = $item['cp'];
            $code = trim((string) ($cp['status_code'] ?? ''));
            $label = trim((string) ($cp['status'] ?? ''));
            $location = !empty($cp['shop']) ? trim((string) $cp['shop']) : null;

            $events[] = new TrackingEvent(
                occurredAt: $item['occurred_at'],
                courierCode: $code,
                label: $label,
                location: $location
            );
        }

        // Evaluate reversals against checkpoint history to determine active state
        $activeCheckpoints = [];
        foreach ($orderedCheckpoints as $item) {
            $cp = $item['cp'];
            $code = strtoupper(trim((string) ($cp['status_code'] ?? '')));
            $label = trim((string) ($cp['status'] ?? ''));

            $targetReversedCode = GenikiStatusMap::getReversedCode($code, $label);
            if ($targetReversedCode !== null) {
                // Reversal checkpoint: find the latest preceding active checkpoint matching $targetReversedCode and cancel it
                for ($k = count($activeCheckpoints) - 1; $k >= 0; $k--) {
                    if ($activeCheckpoints[$k]['code'] === $targetReversedCode) {
                        array_splice($activeCheckpoints, $k, 1);
                        break;
                    }
                }
            } else {
                $activeCheckpoints[] = [
                    'code' => $code,
                    'label' => $label,
                    'occurred_at' => $item['occurred_at'],
                ];
            }
        }

        $latestCode = '';
        $latestLabel = $parsed['status'];

        if (!empty($activeCheckpoints)) {
            $lastActive = $activeCheckpoints[count($activeCheckpoints) - 1];
            $latestCode = $lastActive['code'];
            $latestLabel = $lastActive['label'];
        }

        $lastEventAt = !empty($events)
            ? $events[count($events) - 1]->occurredAt
            : ($this->parseDateTime($parsed['delivery_date'] ?? '') ?? new DateTimeImmutable('now', new DateTimeZone('UTC')));

        $deliveredAt = $parsed['delivered_at'] ?? null;
        $isReturnToSender = false;
        if ($deliveredAt !== null && trim($deliveredAt) !== '') {
            $lowerTarget = mb_strtolower(trim($deliveredAt), 'UTF-8');
            if (
                str_contains($lowerTarget, 'return to sender') ||
                str_contains($lowerTarget, 'return') ||
                str_contains($lowerTarget, 'sender') ||
                str_contains($lowerTarget, 'επιστροφ') ||
                str_contains($lowerTarget, 'αποστολε')
            ) {
                $isReturnToSender = true;
            }
        }

        // Map status using latest active checkpoint and deliveredAt target
        $normalisedStatus = GenikiStatusMap::map($latestCode, $latestLabel, $deliveredAt);

        // Fallback to top-level Status element if checkpoint was unmapped, ensuring summary does not override contradictory checkpoint evidence
        if ($normalisedStatus === TrackingStatus::Unknown && $parsed['status'] !== '') {
            $summaryStatus = GenikiStatusMap::map($parsed['status'], $parsed['status'], $deliveredAt);
            if ($summaryStatus === TrackingStatus::Delivered || $summaryStatus === TrackingStatus::Returned) {
                $hasContradiction = false;
                $contradictionStatus = null;

                $contradictoryStatuses = $summaryStatus === TrackingStatus::Delivered
                    ? [
                        TrackingStatus::DeliveryFailed,
                        TrackingStatus::Cancelled,
                        TrackingStatus::Returning,
                        TrackingStatus::Returned,
                        TrackingStatus::OutForDelivery,
                        TrackingStatus::InTransit,
                        TrackingStatus::ReadyForPickup,
                        TrackingStatus::PickedUp,
                        TrackingStatus::Pending,
                    ]
                    : [
                        TrackingStatus::DeliveryFailed,
                        TrackingStatus::Cancelled,
                        TrackingStatus::Returning,
                        TrackingStatus::Delivered,
                        TrackingStatus::OutForDelivery,
                        TrackingStatus::InTransit,
                        TrackingStatus::ReadyForPickup,
                        TrackingStatus::PickedUp,
                        TrackingStatus::Pending,
                    ];

                if (!empty($activeCheckpoints)) {
                    $deliveryDateTime = $this->parseDateTime($parsed['delivery_date'] ?? '');
                    if ($deliveryDateTime !== null && !empty($orderedCheckpoints)) {
                        $lastCpTime = $orderedCheckpoints[count($orderedCheckpoints) - 1]['occurred_at'];
                        if ($lastCpTime > $deliveryDateTime) {
                            $hasContradiction = true;
                        }
                    }

                    for ($i = count($activeCheckpoints) - 1; $i >= 0; $i--) {
                        $ac = $activeCheckpoints[$i];
                        $acStatus = GenikiStatusMap::map($ac['code'], $ac['label'], $deliveredAt);
                        if (in_array($acStatus, $contradictoryStatuses, true)) {
                            $hasContradiction = true;
                            $contradictionStatus = $acStatus;
                            break;
                        }
                    }
                }

                if ($hasContradiction) {
                    $normalisedStatus = $contradictionStatus ?? TrackingStatus::Unknown;
                } else {
                    $normalisedStatus = $summaryStatus;
                }
            } else {
                $normalisedStatus = $summaryStatus;
            }
        }

        // Check if delivered via DeliveryDate or latest checkpoint:
        // Contradictory status evidence strictly prevents delivery dates or return targets from asserting delivery/return
        $deliveryDate = $parsed['delivery_date'];
        if ($deliveryDate !== null && str_starts_with($deliveryDate, '0001-01-01')) {
            $deliveryDate = null;
        }

        $isContradictory = in_array($normalisedStatus, [
            TrackingStatus::DeliveryFailed,
            TrackingStatus::Cancelled,
            TrackingStatus::OutForDelivery,
            TrackingStatus::InTransit,
            TrackingStatus::ReadyForPickup,
            TrackingStatus::PickedUp,
            TrackingStatus::Pending,
            TrackingStatus::Returning,
        ], true);

        if (!$isContradictory) {
            if ($normalisedStatus === TrackingStatus::Delivered) {
                $normalisedStatus = $isReturnToSender ? TrackingStatus::Returned : TrackingStatus::Delivered;
            }
        }

        if ($normalisedStatus === TrackingStatus::Unknown && $latestCode !== '') {
            if (!isset($this->loggedUnknownStatusCodes[$latestCode])) {
                $this->loggedUnknownStatusCodes[$latestCode] = true;
                $this->logger->warning(
                    sprintf('Unmapped Geniki Taxydromiki tracking status code "%s" (%s).', $latestCode, $latestLabel),
                    ['courier' => CourierSlug::Geniki->value, 'code' => $latestCode, 'label' => $latestLabel]
                );
            }
        }

        // Redact consignee personal data from rawResponse (G8)
        $rawSafe = $parsed;
        if (isset($rawSafe['consignee'])) {
            $rawSafe['consignee'] = '[REDACTED]';
        }

        return new TrackingResult(
            voucherNo: $trimmed,
            status: $normalisedStatus,
            courierStatusCode: $latestCode !== '' ? $latestCode : ($parsed['status'] !== '' ? $parsed['status'] : 'UNKNOWN'),
            courierStatusLabel: $latestLabel !== '' ? $latestLabel : ($parsed['status'] !== '' ? $parsed['status'] : 'Unknown'),
            lastEventAt: $lastEventAt,
            events: $events,
            rawResponse: Redactor::redactArray($rawSafe)
        );
    }

    /**
     * Report COD collection/settlement facts for up to 100 vouchers.
     */
    public function reconcileCodBatch(array $voucherNos): array
    {
        if (count($voucherNos) > 100) {
            throw new CourierValidationException(
                __('COD reconciliation batch cannot exceed 100 vouchers.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $results = [];

        foreach ($voucherNos as $v) {
            $trimmed = trim($v);
            if ($trimmed === '') {
                continue;
            }

            try {
                $tracking = $this->getTrackingStatus($trimmed);

                // Geniki TrackAndTrace provides shipment delivery progress, not remittance accounting.
                // Never report CollectedNotSettled with null amount/reference, which would overwrite
                // previously imported partial CSV collection evidence or accepted shortfalls in shared storage.
                // Remain NotCollected until confirmed financial facts are imported via CSV (SPEC.md §10).
                $results[$trimmed] = new CodReconciliationResult(
                    voucherNo: $trimmed,
                    status: CodSettlementStatus::NotCollected,
                    collectedAmountCents: null,
                    settlementRef: null,
                    settledAt: null,
                    rawResponse: $tracking->rawResponse
                );
            } catch (VoucherNotFoundException) {
                $results[$trimmed] = new CodReconciliationResult(
                    voucherNo: $trimmed,
                    status: CodSettlementStatus::NotFound,
                    collectedAmountCents: null,
                    settlementRef: null,
                    settledAt: null,
                    rawResponse: []
                );
            } catch (Throwable) {
                $results[$trimmed] = new CodReconciliationResult(
                    voucherNo: $trimmed,
                    status: CodSettlementStatus::NotFound,
                    collectedAmountCents: null,
                    settlementRef: null,
                    settledAt: null,
                    rawResponse: []
                );
            }
        }

        return $results;
    }

    /**
     * Validate Geniki credentials via `Authenticate` call (SPEC.md §8.6).
     */
    public function testConnection(): bool
    {
        try {
            $key = $this->authenticate(forceRefresh: true);
            return $key !== '';
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * Auto-recover `unknown` vouchers by reference via `GetJobsFromOrderId` (SPEC.md §8.6).
     */
    public function findVoucherByReference(string $reference): ?VoucherResult
    {
        $trimmed = trim($reference);
        if ($trimmed === '') {
            return null;
        }

        try {
            $response = $this->executeWithAuth(
                function (string $authKey) use ($trimmed): HttpResponse {
                    $soapBody = SoapEnvelopeBuilder::buildGetJobsFromOrderId($authKey, $trimmed);
                    return $this->sendSoapRequest(
                        soapAction: 'GetJobsFromOrderId',
                        soapBody: $soapBody,
                        timeoutSeconds: 15,
                        isMutatingVoucherCall: false
                    );
                }
            );

            $parsed = SoapResponseParser::parseGetJobs($response->body);
            if ($parsed['result'] !== 0 || empty($parsed['jobs'])) {
                return null;
            }

            $matches = [];
            foreach ($parsed['jobs'] as $job) {
                if ($job['order_id'] === $trimmed && !$job['is_canceled']) {
                    $matches[] = $job;
                }
            }
            // A reference can legitimately return several jobs; never choose one arbitrarily.
            if (count($matches) !== 1) {
                return null;
            }
            $matchedJob = $matches[0];
            $voucherNo = $matchedJob['voucher_no'];
            $numbers = array_merge([$voucherNo], $matchedJob['sub_vouchers']);
            if ($matchedJob['id'] <= 0 || $matchedJob['parcel_count'] !== count($numbers)
                || count(array_unique($numbers)) !== count($numbers)) {
                return null;
            }
            foreach ($numbers as $number) {
                if (preg_match('/^[A-Za-z0-9_-]{1,100}$/D', $number) !== 1) {
                    return null;
                }
            }

            return new VoucherResult(
                voucherNo: $voucherNo,
                courier: CourierSlug::Geniki,
                codAmountCents: Money::fromDecimalString($matchedJob['cod_amount'])->cents(),
                parcelCount: $matchedJob['parcel_count'],
                trackingUrl: \GRCommerceSuite\Services\TrackingService::publicUrl($voucherNo, CourierSlug::Geniki),
                lockerId: null,
                rawResponse: Redactor::redactArray($matchedJob)
            );
        } catch (Throwable) {
            return null;
        }
    }

    /**
     * Finalize pending vouchers/manifests created on the current day via `ClosePendingJobs`.
     *
     * @return int Status code (0 = success).
     * @throws CourierAuthenticationException
     * @throws CourierValidationException
     * @throws CourierTransportException
     */
    public function closePendingJobs(): int
    {
        $response = $this->executeWithAuth(
            function (string $authKey): HttpResponse {
                $soapBody = SoapEnvelopeBuilder::buildClosePendingJobs($authKey);
                return $this->sendSoapRequest(
                    soapAction: 'ClosePendingJobs',
                    soapBody: $soapBody,
                    timeoutSeconds: 20,
                    isMutatingVoucherCall: false
                );
            },
            mutating: true
        );

        $result = SoapResponseParser::parseClosePendingJobs($response->body);
        if ($result !== 0) {
            $this->handleApiErrorCode('ClosePendingJobs', $result, $response->statusCode, []);
        }

        return $result;
    }

    /**
     * Finalize pending vouchers/manifests across a date range via `ClosePendingJobsByDate`.
     *
     * @return int Status code (0 = success).
     * @throws CourierAuthenticationException
     * @throws CourierValidationException
     * @throws CourierTransportException
     */
    public function closePendingJobsByDate(DateTimeImmutable $dateFrom, DateTimeImmutable $dateTo): int
    {
        if ($dateFrom > $dateTo) {
            throw new CourierValidationException(
                __('Start date cannot be after end date for Geniki finalization.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $response = $this->executeWithAuth(
            function (string $authKey) use ($dateFrom, $dateTo): HttpResponse {
                $soapBody = SoapEnvelopeBuilder::buildClosePendingJobsByDate($authKey, $dateFrom, $dateTo);
                return $this->sendSoapRequest(
                    soapAction: 'ClosePendingJobsByDate',
                    soapBody: $soapBody,
                    timeoutSeconds: 30,
                    isMutatingVoucherCall: false
                );
            },
            mutating: true
        );

        $result = SoapResponseParser::parseClosePendingJobsByDate($response->body);
        if ($result !== 0) {
            $this->handleApiErrorCode(
                'ClosePendingJobsByDate',
                $result,
                $response->statusCode,
                [
                    'date_from' => $dateFrom->format('Y-m-d\TH:i:s'),
                    'date_to' => $dateTo->format('Y-m-d\TH:i:s'),
                ]
            );
        }

        return $result;
    }

    /**
     * Look up a job by voucher number via `GetJobs`.
     *
     * @return array{id: int, is_canceled: bool, voucher_no: string, order_id: string, sub_vouchers: list<string>, parcel_count: int, cod_amount: string}|null
     */
    private function findJobByVoucherNumber(string $voucherNo): ?array
    {
        try {
            $response = $this->executeWithAuth(
                function (string $authKey) use ($voucherNo): HttpResponse {
                    $soapBody = SoapEnvelopeBuilder::buildGetJobs($authKey, [
                        'voucher_number' => $voucherNo,
                        'date_from' => '2020-01-01T00:00:00',
                        'date_to' => gmdate('Y-m-d\TH:i:s', time() + 86400),
                    ]);
                    return $this->sendSoapRequest(
                        soapAction: 'GetJobs',
                        soapBody: $soapBody,
                        timeoutSeconds: 15,
                        isMutatingVoucherCall: false
                    );
                }
            );

            $parsed = SoapResponseParser::parseGetJobs($response->body);
            if ($parsed['result'] !== 0 || empty($parsed['jobs'])) {
                return null;
            }

            $matchingJobs = [];
            $seenJobsById = [];

            foreach ($parsed['jobs'] as $j) {
                $jId = $j['id'] ?? 0;
                $vNo = $j['voucher_no'] ?? '';
                $seenJobsById[$jId][] = $vNo;

                if ($vNo === $voucherNo || in_array($voucherNo, $j['sub_vouchers'], true)) {
                    $matchingJobs[] = $j;
                }
            }

            if (empty($matchingJobs)) {
                return null;
            }

            // Reject invalid or zero job ID
            foreach ($matchingJobs as $j) {
                if ($j['id'] <= 0) {
                    return null;
                }
            }

            // Reject ambiguous matches: must resolve to exactly one unique positive job ID
            $uniqueMatchingIds = array_unique(array_column($matchingJobs, 'id'));
            if (count($uniqueMatchingIds) !== 1) {
                return null;
            }

            $targetJobId = $uniqueMatchingIds[0];

            // Reject contradictory identity: the resolved job ID must not be bound to other vouchers
            if (isset($seenJobsById[$targetJobId])) {
                $associatedVouchers = array_unique($seenJobsById[$targetJobId]);
                if (count($associatedVouchers) > 1) {
                    return null;
                }
            }

            return $matchingJobs[0];
        } catch (Throwable) {
            return null;
        }
    }

    /**
     * Execute an API action with automatic token retrieval.
     *
     * Reads retry once on token expiration (error 11). Mutating calls (C2) refresh a near-expiry key first and
     * never retry: Result 11 after a mutation was sent leaves the carrier outcome uncertain.
     *
     * @param callable(string): HttpResponse $action
     */
    private function executeWithAuth(
        callable $action,
        ?int $orderId = null,
        ?string $idempotencyKey = null,
        bool $mutating = false
    ): HttpResponse {
        $authKey = $mutating ? $this->authenticateForMutation() : $this->authenticate();

        try {
            $response = $action($authKey);
        } catch (CourierAmbiguousResultException $e) {
            throw $e;
        } catch (CourierTransportException $e) {
            throw $e;
        }

        // Check if response body indicates error code 11 (Invalid/expired key)
        if ($this->isExpiredKeyResponse($response->body)) {
            if ($mutating) {
                $this->invalidateAuthKey();
                $msg = __('Geniki Taxydromiki rejected the session key (Result 11) after a create/cancel/close request was sent. The outcome is uncertain and no automatic retry was made.', 'gr-commerce-suite');
                $this->transitionToUnknownOnTimeout($orderId, $idempotencyKey, $msg);
                throw new CourierAmbiguousResultException(
                    $msg,
                    CourierSlug::Geniki,
                    $response->statusCode,
                    ['result' => 11],
                    __('Geniki returned an expired-session error (Result 11) after the request was sent, so the result is uncertain. Look up the voucher/job at Geniki before trying again.', 'gr-commerce-suite')
                );
            }
            $this->logger->info('Geniki Taxydromiki session key expired (code 11). Refreshing token and retrying once.');
            $this->invalidateAuthKey();
            $newAuthKey = $this->authenticate(forceRefresh: true);
            $response = $action($newAuthKey);
        }

        return $response;
    }

    /**
     * Check if a response contains error code 11 (Invalid/expired key).
     * Recognises both XML Result elements and plain-text "11" returned by GetVouchersPdf (G10).
     */
    private function isExpiredKeyResponse(string $body): bool
    {
        $trimmed = trim($body);
        if ($trimmed === '11') {
            return true;
        }

        return preg_match('/<(?:[a-zA-Z0-9]+:)?Result[^>]*>\s*11\s*<\/(?:[a-zA-Z0-9]+:)?Result>/i', $body) === 1
            || preg_match('/<(?:[a-zA-Z0-9]+:)?CancelJobResult[^>]*>\s*11\s*<\/(?:[a-zA-Z0-9]+:)?CancelJobResult>/i', $body) === 1
            || preg_match('/<(?:[a-zA-Z0-9]+:)?GetVouchersPdfResult[^>]*>\s*11\s*<\/(?:[a-zA-Z0-9]+:)?GetVouchersPdfResult>/i', $body) === 1
            || preg_match('/<(?:[a-zA-Z0-9]+:)?GetVoucherPdfResult[^>]*>\s*11\s*<\/(?:[a-zA-Z0-9]+:)?GetVoucherPdfResult>/i', $body) === 1
            || preg_match('/<(?:[a-zA-Z0-9]+:)?ClosePendingJobsResult[^>]*>\s*11\s*<\/(?:[a-zA-Z0-9]+:)?ClosePendingJobsResult>/i', $body) === 1
            || preg_match('/<(?:[a-zA-Z0-9]+:)?ClosePendingJobsByDateResult[^>]*>\s*11\s*<\/(?:[a-zA-Z0-9]+:)?ClosePendingJobsByDateResult>/i', $body) === 1;
    }

    /**
     * Map Geniki API integer error code to specific GRCS exception.
     *
     * @param array<string, mixed> $context
     */
    private function handleApiErrorCode(string $operation, int $resultCode, int $httpStatus, array $context): never
    {
        $redacted = Redactor::redactArray($context);

        match ($resultCode) {
            14, 15 => throw new CourierRateLimitedException(
                sprintf(__('Geniki Taxydromiki rejected %s with error code %d.', 'gr-commerce-suite'), $operation, $resultCode),
                CourierSlug::Geniki,
                60,
                $httpStatus,
                $redacted
            ),
            1, 10, 11 => throw new CourierAuthenticationException(
                sprintf(__('Geniki Taxydromiki authentication/authorization error %d on %s.', 'gr-commerce-suite'), $resultCode, $operation),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            9 => throw new VoucherNotFoundException(
                sprintf(__('Geniki Taxydromiki voucher/job does not exist (Result 9) on %s.', 'gr-commerce-suite'), $operation),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            8, 12 => throw new CourierTransportException(
                sprintf(__('Geniki Taxydromiki internal server/runtime error (Result %d) on %s.', 'gr-commerce-suite'), $resultCode, $operation),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            700 => throw new CourierValidationException(
                __('Geniki Taxydromiki validation error: required fields (Name, Address, City) are missing (Result 700).', 'gr-commerce-suite'),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            701 => throw new CourierValidationException(
                __('Geniki Taxydromiki validation error: COD service is enabled but COD amount is missing (Result 701).', 'gr-commerce-suite'),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            702 => throw new CourierValidationException(
                __('Geniki Taxydromiki validation error: COD amount is provided but COD service is not selected (Result 702).', 'gr-commerce-suite'),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            703 => throw new CourierValidationException(
                __('Geniki Taxydromiki validation error: COD amount exceeds courier threshold (Result 703).', 'gr-commerce-suite'),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            3 => throw new CourierValidationException(
                __('Geniki Taxydromiki validation error: no data supplied for operation (Result 3).', 'gr-commerce-suite'),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            5, 6 => throw new CourierValidationException(
                sprintf(__('Geniki Taxydromiki max voucher limit reached (Result %d). Please contact courier support.', 'gr-commerce-suite'), $resultCode),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
            default => throw new CourierValidationException(
                sprintf(__('Geniki Taxydromiki rejected %s with error code %d.', 'gr-commerce-suite'), $operation, $resultCode),
                CourierSlug::Geniki,
                $httpStatus,
                $redacted
            ),
        };
    }

    /**
     * Send HTTP POST request with SOAP envelope and SOAPAction header.
     *
     * @throws CourierAmbiguousResultException
     * @throws CourierTransportException
     * @throws CourierRateLimitedException
     * @throws CourierAuthenticationException
     */
    private function sendSoapRequest(
        string $soapAction,
        string $soapBody,
        int $timeoutSeconds,
        bool $isMutatingVoucherCall,
        ?int $orderId = null,
        ?string $idempotencyKey = null
    ): HttpResponse {
        $endpoint = $this->resolveEndpoint();
        $headers = [
            'Content-Type' => 'text/xml; charset=utf-8',
            'SOAPAction' => sprintf('"%s/%s"', SoapEnvelopeBuilder::XMLNS_SERVICES, $soapAction),
        ];

        $request = new HttpRequest(
            method: 'POST',
            url: $endpoint,
            headers: $headers,
            body: $soapBody,
            timeoutSeconds: $timeoutSeconds,
            connectTimeoutSeconds: 5
        );

        $response = $this->httpClient->send($request);

        if ($response->timedOutAfterTransmission) {
            $msg = sprintf(
                __('Geniki Taxydromiki timed out after request transmission on %s (order ID %s). Marking voucher state as unknown.', 'gr-commerce-suite'),
                $soapAction,
                $orderId !== null ? (string) $orderId : 'N/A'
            );

            if ($isMutatingVoucherCall) {
                $this->transitionToUnknownOnTimeout($orderId, $idempotencyKey, $msg);
            }

            throw new CourierAmbiguousResultException(
                $msg,
                CourierSlug::Geniki,
                $response->statusCode,
                ['soap_action' => $soapAction],
                'Request timed out while waiting for courier confirmation. State preserved as unknown.'
            );
        }

        if ($response->failedBeforeTransmission) {
            // Typed: the HTTP client proved the payload never reached Geniki, so this is safe to retry
            // even when the transport message contains "timed out" (e.g. a TCP connect timeout).
            throw new CourierTransportException(
                sprintf(__('Connection failed before reaching Geniki Taxydromiki on %s: %s', 'gr-commerce-suite'), $soapAction, $response->errorMessage ?? 'unknown error'),
                CourierSlug::Geniki,
                $response->statusCode,
                ['soap_action' => $soapAction],
                null,
                null,
                true
            );
        }

        if ($response->statusCode === 429) {
            $retryAfter = (int) ($response->header('retry-after') ?? 60);
            throw new CourierRateLimitedException(
                sprintf(__('Geniki Taxydromiki rate limit reached on %s. Retry after %d seconds.', 'gr-commerce-suite'), $soapAction, $retryAfter),
                CourierSlug::Geniki,
                $retryAfter
            );
        }

        if ($response->statusCode === 401 || $response->statusCode === 403) {
            throw new CourierAuthenticationException(
                sprintf(__('Geniki Taxydromiki returned HTTP %d on %s.', 'gr-commerce-suite'), $response->statusCode, $soapAction),
                CourierSlug::Geniki,
                $response->statusCode
            );
        }

        if ($response->statusCode >= 500) {
            $msg = sprintf(__('Geniki Taxydromiki server error (HTTP %d) on %s.', 'gr-commerce-suite'), $response->statusCode, $soapAction);
            if ($isMutatingVoucherCall) {
                $this->transitionToUnknownOnTimeout($orderId, $idempotencyKey, $msg);
                throw new CourierAmbiguousResultException(
                    $msg,
                    CourierSlug::Geniki,
                    $response->statusCode,
                    ['soap_action' => $soapAction],
                    'Server error after mutating request transmission. State preserved as unknown to prevent duplicate voucher creation.'
                );
            }
            throw new CourierTransportException(
                $msg,
                CourierSlug::Geniki,
                $response->statusCode
            );
        }

        return $response;
    }

    /**
     * Transition voucher row to `'unknown'` on post-transmission timeout.
     */
    private function transitionToUnknownOnTimeout(
        ?int $orderId,
        ?string $idempotencyKey,
        string $errorMessage
    ): void {
        $this->logger->warning(
            $errorMessage,
            [
                'order_id' => $orderId,
                'state' => VoucherState::Unknown->value,
            ]
        );

        if ($this->stateTracker !== null && $orderId !== null && $orderId > 0) {
            $this->stateTracker->markUnknownOnTimeout(
                orderId: $orderId,
                courier: CourierSlug::Geniki,
                errorMessage: $errorMessage,
                idempotencyKey: $idempotencyKey
            );
        }
    }

    /**
     * Extract PDF binary string from response and verify `%PDF-` magic header.
     *
     * @param list<string> $voucherNos
     * @return non-empty-string
     */
    private function extractPdfBytes(HttpResponse $response, array $voucherNos): string
    {
        $body = $response->body;

        if (PdfMerger::isValidPdf($body)) {
            /** @var non-empty-string $body */
            return $body;
        }

        // Check if PDF is base64-encoded inside an XML response
        if (preg_match('/<GetVouchersPdfResult>([^<]+)<\/GetVouchersPdfResult>/i', $body, $matches) === 1
            || preg_match('/<GetVoucherPdfResult>([^<]+)<\/GetVoucherPdfResult>/i', $body, $matches) === 1) {
            $base64 = trim($matches[1]);
            $decoded = base64_decode($base64, true);
            if (is_string($decoded) && PdfMerger::isValidPdf($decoded)) {
                /** @var non-empty-string $decoded */
                return $decoded;
            }
        }

        // If body is text/plain error code
        $trimmedBody = trim($body);
        if (is_numeric($trimmedBody)) {
            $code = (int) $trimmedBody;
            $this->handleApiErrorCode('GetVouchersPdf', $code, $response->statusCode, ['vouchers' => $voucherNos]);
        }

        throw new CourierTransportException(
            sprintf(__('Geniki Taxydromiki print response for vouchers "%s" did not start with %%PDF- magic bytes.', 'gr-commerce-suite'), implode(', ', $voucherNos)),
            CourierSlug::Geniki,
            $response->statusCode
        );
    }

    /**
     * Resolve production vs sandbox endpoint URL.
     */
    private function resolveEndpoint(): string
    {
        if (isset($this->credentials['endpoint_url']) && trim($this->credentials['endpoint_url']) !== '') {
            return trim($this->credentials['endpoint_url']);
        }

        $env = strtolower(trim((string) ($this->credentials['environment'] ?? '')));
        $isSandbox = $env === 'sandbox' || $env === 'test' || (new LicenseManager())->isSandboxEnabled();

        return $isSandbox ? self::SANDBOX_ENDPOINT : self::PRODUCTION_ENDPOINT;
    }

    /**
     * Read a credential from the injected (vault-resolved) array only; CredentialVault owns legacy-option upgrades.
     */
    private function credential(string $key): string
    {
        if (isset($this->credentials[$key]) && is_scalar($this->credentials[$key])) {
            return trim((string) $this->credentials[$key]);
        }

        return '';
    }

    private function resolveRecipientName(WC_Order $order): string
    {
        $shipping = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
        if ($shipping !== '') {
            return $shipping;
        }

        $shippingCompany = trim((string) $order->get_shipping_company());
        if ($shippingCompany !== '') {
            return $shippingCompany;
        }

        $billing = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        if ($billing !== '') {
            return $billing;
        }

        return trim((string) $order->get_billing_company());
    }

    private function resolveAddressLine(WC_Order $order): string
    {
        $address1 = trim((string) $order->get_shipping_address_1());
        $address2 = trim((string) $order->get_shipping_address_2());
        $combined = trim($address1 . ' ' . $address2);
        if ($combined !== '') {
            return $combined;
        }

        $bill1 = trim((string) $order->get_billing_address_1());
        $bill2 = trim((string) $order->get_billing_address_2());

        return trim($bill1 . ' ' . $bill2);
    }

    private function resolveCity(WC_Order $order): string
    {
        $city = trim((string) $order->get_shipping_city());
        if ($city !== '') {
            return $city;
        }

        return trim((string) $order->get_billing_city());
    }

    private function resolvePostcode(WC_Order $order): string
    {
        $pc = trim((string) $order->get_shipping_postcode());
        if ($pc !== '') {
            return $pc;
        }

        return trim((string) $order->get_billing_postcode());
    }

    private function resolveCountry(WC_Order $order): string
    {
        $country = strtoupper(trim((string) $order->get_shipping_country()));
        if ($country !== '') {
            return $country;
        }

        $billing = strtoupper(trim((string) $order->get_billing_country()));

        return $billing !== '' ? $billing : 'GR';
    }

    private function resolvePhone(WC_Order $order): string
    {
        $phone = trim((string) $order->get_billing_phone());
        if ($phone !== '') {
            return $phone;
        }

        $shippingPhone = trim((string) $order->get_meta('_shipping_phone', true));
        if ($shippingPhone !== '') {
            return $shippingPhone;
        }

        return (string) $order->get_meta('shipping_phone', true);
    }

    private function resolveCodAmountCents(WC_Order $order): int
    {
        $override = $order->get_meta('_grcs_custom_cod_amount', true);
        if (is_string($override) && trim($override) !== '') {
            return max(0, Money::fromDecimalString(trim($override))->cents());
        }

        $paymentMethod = strtolower(trim((string) $order->get_payment_method()));
        if ($paymentMethod !== 'cod') {
            return 0;
        }

        $total = (string) $order->get_total();

        return Money::fromDecimalString($total)->cents();
    }

    private function resolveOrderWeightKg(WC_Order $order): float
    {
        $weight = ShippingOptions::weightKg($order);

        return $weight > 0.0 ? round($weight, 3) : 1.0;
    }

    private function parseDateTime(string $dateStr): ?DateTimeImmutable
    {
        $trimmed = trim($dateStr);
        if ($trimmed === '') {
            return null;
        }

        try {
            return new DateTimeImmutable($trimmed, new DateTimeZone('Europe/Athens'));
        } catch (Throwable) {
            try {
                return new DateTimeImmutable($trimmed, new DateTimeZone('UTC'));
            } catch (Throwable) {
                return null;
            }
        }
    }
}
