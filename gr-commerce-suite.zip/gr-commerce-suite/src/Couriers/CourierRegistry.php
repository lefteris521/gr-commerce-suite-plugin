<?php

declare(strict_types=1);

namespace GRCommerceSuite\Couriers;

use GRCommerceSuite\Contracts\CourierProviderInterface;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use InvalidArgumentException;

/**
 * Registry of courier provider factories keyed by `CourierSlug` (SPEC.md §4.1, §8.6).
 *
 * Credentials are decrypted lazily only when a provider is requested via `get()`.
 */
final class CourierRegistry
{
    /**
     * @var array<string, callable(): CourierProviderInterface>
     */
    private array $factories = [];

    /**
     * @var array<string, CourierProviderInterface>
     */
    private array $instances = [];

    /**
     * @param callable(): CourierProviderInterface $factory
     */
    public function register(CourierSlug $slug, callable $factory): void
    {
        $this->factories[$slug->value] = $factory;
        foreach (array_keys($this->instances) as $key) {
            if (str_starts_with($key, $slug->value . ':')) {
                unset($this->instances[$key]);
            }
        }
    }

    public function has(CourierSlug $slug): bool
    {
        return isset($this->factories[$slug->value]);
    }

    public function get(CourierSlug $slug): CourierProviderInterface
    {
        $instanceKey = $slug->value . ':' . (function_exists('get_current_blog_id') ? get_current_blog_id() : 0);
        if (isset($this->instances[$instanceKey])) {
            return $this->instances[$instanceKey];
        }

        if (!isset($this->factories[$slug->value])) {
            throw new InvalidArgumentException(sprintf(__('Courier provider "%s" is not registered.', 'gr-commerce-suite'), $slug->value));
        }

        $factory = $this->factories[$slug->value];
        $provider = $factory();

        if (!$provider instanceof CourierProviderInterface) {
            throw new InvalidArgumentException(
                sprintf(__('Factory for courier "%s" did not return a CourierProviderInterface instance.', 'gr-commerce-suite'), $slug->value)
            );
        }

        $this->instances[$instanceKey] = $provider;

        return $provider;
    }

    /**
     * @return list<CourierSlug>
     */
    public function registeredSlugs(): array
    {
        $slugs = [];
        foreach (array_keys($this->factories) as $rawSlug) {
            $slug = CourierSlug::tryFrom($rawSlug);
            if ($slug !== null) {
                $slugs[] = $slug;
            }
        }

        return $slugs;
    }
}
