<?php

declare(strict_types=1);

namespace GRCommerceSuite\Couriers;

use DateTimeImmutable;
use DateTimeZone;
use GRCommerceSuite\Contracts\CourierProviderInterface;
use GRCommerceSuite\Contracts\CredentialsValidatorInterface;
use GRCommerceSuite\Contracts\LoggerInterface;
use GRCommerceSuite\Contracts\PickupLocationProviderInterface;
use GRCommerceSuite\Contracts\VoucherStateTrackerInterface;
use GRCommerceSuite\Contracts\WebhookReceiverInterface;
use GRCommerceSuite\Domain\Cod\CodReconciliationResult;
use GRCommerceSuite\Domain\Cod\CodSettlementStatus;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Domain\Shared\PickupPoint;
use GRCommerceSuite\Domain\Tracking\TrackingEvent;
use GRCommerceSuite\Domain\Tracking\TrackingResult;
use GRCommerceSuite\Domain\Tracking\TrackingStatus;
use GRCommerceSuite\Domain\Voucher\PrintFormat;
use GRCommerceSuite\Domain\Voucher\VoucherResult;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Exceptions\Courier\CourierAmbiguousResultException;
use GRCommerceSuite\Exceptions\Courier\CourierAuthenticationException;
use GRCommerceSuite\Exceptions\Courier\CourierRateLimitedException;
use GRCommerceSuite\Exceptions\Courier\CourierTransportException;
use GRCommerceSuite\Exceptions\Courier\CourierValidationException;
use GRCommerceSuite\Exceptions\Courier\UnsupportedPrintFormatException;
use GRCommerceSuite\Exceptions\Courier\VoucherNotFoundException;
use GRCommerceSuite\Http\HttpClientInterface;
use GRCommerceSuite\Http\HttpRequest;
use GRCommerceSuite\Http\HttpResponse;
use GRCommerceSuite\Pdf\PdfMerger;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Services\ShippingOptions;
use GRCommerceSuite\Support\Logger;
use GRCommerceSuite\Support\Money;
use GRCommerceSuite\Support\PhoneNormalizer;
use GRCommerceSuite\Support\Redactor;
use GRCommerceSuite\Utils\GreekDataNormalizer;
use Throwable;
use WC_Order;
use WC_Order_Item_Product;
use WP_REST_Request;

/**
 * BOX NOW Partner API Provider (SPEC.md §8, §14).
 *
 * Endpoints:
 *  - OAuth2 Bearer authentication: `POST /api/v1/auth-sessions`
 *  - APM locker lookup:            `GET  /api/v1/destinations`
 *  - Parcel creation:              `POST /api/v1/delivery-requests`
 *  - PDF label retrieval:          `GET  /api/v1/parcels/{parcelId}/label.pdf`
 *  - Parcel details / tracking:    `GET  /api/v1/parcels/{parcelId}`
 *  - Parcel cancellation:          `POST /api/v1/parcels/{parcelId}:cancel`
 */
final class BoxNowProvider implements
    CourierProviderInterface,
    PickupLocationProviderInterface,
    CredentialsValidatorInterface,
    WebhookReceiverInterface
{
    public const PRODUCTION_BASE_URL = 'https://api-production.boxnow.gr';
    public const STAGING_BASE_URL = 'https://api-stage.boxnow.gr';

    public const PATH_AUTH_SESSIONS = '/api/v1/auth-sessions';
    public const PATH_DESTINATIONS = '/api/v1/destinations';
    public const PATH_DELIVERY_REQUESTS = '/api/v1/delivery-requests';

    private const DEFAULT_COD_CASH_LIMIT_CENTS = 50000;

    private ?string $inMemoryAccessToken = null;

    private int $inMemoryTokenExpiresAt = 0;

    /**
     * @var array<string, true>
     */
    private array $loggedUnknownStatusCodes = [];

    private readonly LoggerInterface $logger;

    private ?PdfMerger $pdfMerger;

    /**
     * @param array{
     *     client_id?: string,
     *     client_secret?: string,
     *     partner_id?: string,
     *     origin_location_id?: string,
     *     origin_contact_name?: string,
     *     origin_contact_phone?: string,
     *     origin_contact_email?: string,
     *     webhook_secret?: string,
     *     environment?: string,
     *     base_url?: string,
     *     cod_cash_limit_cents?: int|string
     * } $credentials
     */
    public function __construct(
        private readonly HttpClientInterface $httpClient,
        private readonly array $credentials = [],
        ?LoggerInterface $logger = null,
        ?PdfMerger $pdfMerger = null,
        private readonly ?VoucherStateTrackerInterface $stateTracker = null,
    ) {
        $this->logger = $logger ?? new Logger('grcs-boxnow');
        $this->pdfMerger = $pdfMerger;
    }

    /**
     * Authenticate with BOX NOW via `POST /api/v1/auth-sessions` and return OAuth2 Bearer token.
     */
    public function authenticate(bool $forceRefresh = false): string
    {
        $now = time();
        if (!$forceRefresh && $this->inMemoryAccessToken !== null && $this->inMemoryTokenExpiresAt > $now) {
            return $this->inMemoryAccessToken;
        }

        $transientKey = $this->tokenTransientKey();
        if (!$forceRefresh && function_exists('get_transient')) {
            $cached = get_transient($transientKey);
            if (is_string($cached) && $cached !== '') {
                $this->inMemoryAccessToken = $cached;
                $this->inMemoryTokenExpiresAt = $now + 300;

                return $cached;
            }
        }

        $clientId = $this->credential('client_id', 'grcs_boxnow_client_id');
        $clientSecret = $this->credential('client_secret', 'grcs_boxnow_client_secret');

        $bodyPayload = [
            'grant_type' => 'client_credentials',
            'client_id' => $clientId,
            'client_secret' => $clientSecret,
        ];

        $jsonBody = function_exists('wp_json_encode')
            ? (string) wp_json_encode($bodyPayload)
            : json_encode($bodyPayload, JSON_THROW_ON_ERROR);

        $request = new HttpRequest(
            method: 'POST',
            url: $this->baseUrl() . self::PATH_AUTH_SESSIONS,
            headers: [
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
            body: $jsonBody,
            timeoutSeconds: 15,
            connectTimeoutSeconds: 5,
        );

        try {
            $response = (new \GRCommerceSuite\Services\DiagnosticLogger())->send($this->httpClient, $request, 'BOXNOW', 'authenticate');
        } catch (Throwable $e) {
            throw new CourierTransportException(
                sprintf(__('BOX NOW OAuth2 token request failed: %s', 'gr-commerce-suite'), $e->getMessage()),
                CourierSlug::BoxNow,
                null,
                [],
                null,
                $e
            );
        }

        if ($response->hasError()) {
            throw new CourierTransportException(
                sprintf(__('BOX NOW OAuth2 transport error: %s', 'gr-commerce-suite'), $response->errorMessage ?? 'unknown'),
                CourierSlug::BoxNow
            );
        }

        if ($response->statusCode === 401 || $response->statusCode === 403 || $response->statusCode === 400) {
            throw new CourierAuthenticationException(
                __('BOX NOW OAuth2 authentication failed (invalid client_id or client_secret).', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                $response->statusCode,
                [],
                'BOX NOW authentication failed. Please verify your Client ID and Client Secret in settings.'
            );
        }

        if ($response->statusCode === 429) {
            throw new CourierRateLimitedException(
                __('BOX NOW OAuth2 rate limit exceeded.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                (int) ($response->header('retry-after') ?? 60),
                429
            );
        }

        if ($response->statusCode < 200 || $response->statusCode >= 300) {
            throw new CourierTransportException(
                sprintf(__('BOX NOW OAuth2 endpoint returned HTTP %d.', 'gr-commerce-suite'), $response->statusCode),
                CourierSlug::BoxNow,
                $response->statusCode
            );
        }

        try {
            $decoded = json_decode($response->body, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable $e) {
            throw new CourierTransportException(
                __('BOX NOW OAuth2 response contained invalid JSON.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                $response->statusCode,
                [],
                null,
                $e
            );
        }

        if (
            !is_array($decoded) ||
             !isset($decoded['access_token']) ||
             !is_string($decoded['access_token']) ||
             trim($decoded['access_token']) === ''
        ) {
            throw new CourierAuthenticationException(
                __('BOX NOW OAuth2 response did not contain a valid access_token.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                $response->statusCode
            );
        }

        $token = trim($decoded['access_token']);
        $expiresIn = max(120, (int) ($decoded['expires_in'] ?? 3600));
        $ttl = max(60, $expiresIn - 60);

        $this->inMemoryAccessToken = $token;
        $this->inMemoryTokenExpiresAt = $now + $ttl;

        if (function_exists('set_transient')) {
            set_transient($transientKey, $token, $ttl);
        }

        return $token;
    }

    /**
     * Look up BOX NOW APM lockers via `GET /api/v1/destinations` (SPEC.md §8.6, §14).
     *
     * @return list<PickupPoint>
     */
    public function listPickupPoints(string $postcode = '', bool $fresh = false): array
    {
        $normalisedPostcode = PhoneNormalizer::normalisePostcode($postcode);
        $cacheKey = 'grcs_boxnow_lockers_' .
             substr(
                 hash(
                     'sha256',
                     $this->tokenTransientKey() .
                     '|' .
                     $normalisedPostcode
                 ),
                 0,
                 24
             );
        $cached = get_transient($cacheKey);
        if (!$fresh && is_array($cached)) {
            return array_values(array_filter($cached, static fn(mixed $point): bool => $point instanceof PickupPoint));
        }

        $response = $this->sendAuthenticatedRequest(
            method: 'GET',
            path: self::PATH_DESTINATIONS,
            bodyPayload: null,
            timeoutSeconds: 15,
            isMutatingVoucherCall: false,
        );

        try {
            $decoded = json_decode($response->body, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable $e) {
            throw new CourierTransportException(
                __('BOX NOW destinations response is not valid JSON.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                $response->statusCode,
                [],
                null,
                $e
            );
        }

        if (!is_array($decoded)) {
            return [];
        }

        $items = isset($decoded['data']) && is_array($decoded['data']) ? $decoded['data'] : $decoded;
        $points = [];

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $id = trim((string) ($item['id'] ?? $item['lockerId'] ?? ''));
            if ($id === '') {
                continue;
            }

            $itemPostcode = PhoneNormalizer::normalisePostcode((string) ($item['postalCode'] ??
                 $item['postcode'] ??
                 $item['zip'] ??
                 ''));
            if (
                $normalisedPostcode !== '' &&
                 $itemPostcode !== '' &&
                 !str_starts_with(
                     $itemPostcode,
                     $normalisedPostcode
                 )
            ) {
                continue;
            }

            $lat = isset($item['lat']) && (is_float($item['lat']) || is_int($item['lat'])) ? $item['lat'] * 1.0 : null;
            $lng = isset($item['lng']) && (is_float($item['lng']) || is_int($item['lng'])) ? $item['lng'] * 1.0 : null;

            $points[] = new PickupPoint(
                id: $id,
                courier: CourierSlug::BoxNow,
                name: (string) ($item['name'] ?? $item['title'] ?? ('BOX NOW Locker #' . $id)),
                address: (string) ($item['addressLine1'] ?? $item['address'] ?? ''),
                postcode: $itemPostcode,
                city: (string) ($item['city'] ?? $item['region'] ?? ''),
                latitude: $lat,
                longitude: $lng,
                rawResponse: Redactor::redactArray($item),
            );
        }

        if (function_exists('set_transient') && $points !== []) {
            set_transient($cacheKey, $points, 12 * 3600);
        }

        return $points;
    }

    /**
     * Create a BOX NOW parcel voucher via `POST /api/v1/delivery-requests` (SPEC.md §8.2, §14).
     */
    public function createVoucher(WC_Order $order): VoucherResult
    {
        $orderId = (int) $order->get_id();
        $lockerId = trim((string) $order->get_meta('_grcs_boxnow_locker_id', true));
        if ($lockerId === '') {
            $lockerId = trim((string) $order->get_meta('_boxnow_locker_id', true));
        }

        $isSandbox = (new LicenseManager())->isSandboxEnabled();

        if ($lockerId === '' && $isSandbox) {
            $lockerId = '1001';
        }

        if ($lockerId === '') {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('BOXNOW', 'validate_shipping', ['locker_id' => $lockerId], $orderId);
            throw new CourierValidationException(
                __('BOX NOW voucher creation failed: missing target APM locker ID (_grcs_boxnow_locker_id).', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                null,
                ['order_id' => $orderId],
                'A BOX NOW locker ID is required to create a voucher for this order.'
            );
        }

        $recipientName = GreekDataNormalizer::stripGreekAccentsUpper($this->resolveRecipientName($order));
        $rawPhone = $this->resolvePhone($order);
        if ($rawPhone === '' && $isSandbox) {
            $rawPhone = '+306912345678';
        }
        $e164Phone = PhoneNormalizer::toE164($rawPhone);
        $recipientEmail = trim((string) $order->get_billing_email());

        if ($recipientName === '' || !PhoneNormalizer::isValid($rawPhone, true)) {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('BOXNOW', 'validate_shipping', ['recipient_name' => $recipientName, 'recipient_phone' => $rawPhone], $orderId);
            throw new CourierValidationException(
                __('BOX NOW voucher creation failed: recipient name and mobile telephone number (+30...) are required.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                null,
                ['order_id' => $orderId]
            );
        }

        $codAmountCents = $this->resolveCodAmountCents($order);
        if ($codAmountCents > 0 && get_option(\GRCommerceSuite\Shipping\CheckoutShippingValidation::BOXNOW_ALLOW_COD, 'no') !== 'yes') {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('BOXNOW', 'validate_cod', ['cod_cents' => (string) $codAmountCents], $orderId);
            throw new CourierValidationException(
                __('BOX NOW voucher creation failed: BOX NOW cannot collect cash. Enable "Allow BOX NOW Pay on the Go" (payment link), set the order COD amount to 0, or change the payment method.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                null,
                ['order_id' => $orderId]
            );
        }
        $cashLimitCents = (int) ($this->credentials['cod_cash_limit_cents'] ?? self::DEFAULT_COD_CASH_LIMIT_CENTS);
        if ($codAmountCents > $cashLimitCents) {
            $this->logger->warning(
                'BOX NOW COD amount exceeds configured cash transaction warning threshold.',
                [
                    'order_id' => $orderId,
                    'cod_cents' => $codAmountCents,
                    'limit_cents' => $cashLimitCents,
                ]
            );
        }

        $orderTotalDecimal = Money::fromDecimalString((string) $order->get_total())->toDecimalString();
        $codDecimal = Money::fromCents($codAmountCents)->toDecimalString();

        $idempotencyKey = (string) $order->get_meta('_grcs_active_idempotency_key', true);
        $referencePrefix = $idempotencyKey !== '' ? substr($idempotencyKey, 0, 16) : '';
        $orderNumberRef = $referencePrefix !== ''
            ? sprintf('%s-%s', (string) $order->get_order_number(), $referencePrefix)
            : (string) $order->get_order_number();

        $payload = [
            'orderNumber' => $orderNumberRef,
            'invoiceValue' => $orderTotalDecimal,
            'paymentMode' => $codAmountCents > 0 ? 'cod' : 'prepaid',
            'amountToBeCollected' => $codDecimal,
            'notifyOnAccepted' => true,
            'origin' => [
                'contactName' => ShippingOptions::senderName(),
                'contactNumber' => PhoneNormalizer::toE164((string) ($this->credentials['origin_contact_phone'] ??
                     '+302100000000')),

                'contactEmail' => (string) ($this->credentials['origin_contact_email'] ?? 'store@example.com'),
                'locationId' => $this->credential('origin_location_id', 'grcs_boxnow_origin_location_id', '1'),
            ],
            'destination' => [
                'contactNumber' => $e164Phone,
                'contactEmail' => $recipientEmail !== '' ? $recipientEmail : 'customer@example.com',
                'contactName' => mb_substr($recipientName, 0, 80, 'UTF-8'),
                'locationId' => $lockerId,
            ],
            'items' => array_map(static fn(int $piece): array => [
                'id' => (string) $orderId . '-' . $piece,
                'name' => sprintf('Order #%s / %d', (string) $order->get_order_number(), $piece),
                'value' => Money::fromCents(intdiv(Money::fromDecimalString($orderTotalDecimal)->cents(), ShippingOptions::parcelCount($order))
                    + ($piece === 1 ? Money::fromDecimalString($orderTotalDecimal)->cents() % ShippingOptions::parcelCount($order) : 0))->toDecimalString(),
                'weight' => max(0.5, ShippingOptions::weightKg($order) / ShippingOptions::parcelCount($order)),
                'compartmentSize' => 2,
            ], range(1, ShippingOptions::parcelCount($order))),
        ];

        $response = $this->sendAuthenticatedRequest(
            method: 'POST',
            path: self::PATH_DELIVERY_REQUESTS,
            bodyPayload: $payload,
            timeoutSeconds: 15,
            isMutatingVoucherCall: true,
            orderId: $orderId,
            idempotencyKey: $idempotencyKey !== '' ? $idempotencyKey : null,
        );

        try {
            $decoded = json_decode($response->body, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable $e) {
            $this->transitionToUnknownOnTimeout(
                orderId: $orderId,
                idempotencyKey: $idempotencyKey !== '' ? $idempotencyKey : null,
                errorMessage: 'BOX NOW returned a malformed HTTP 2xx JSON payload; voucher state ' .
                    'transitioned to unknown.',
            );

            throw new CourierAmbiguousResultException(
                __('BOX NOW delivery-requests returned invalid JSON on HTTP 2xx; voucher state set to unknown.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                $response->statusCode,
                ['order_id' => $orderId],
                null,
                $e
            );
        }

        if (!is_array($decoded)) {
            $this->transitionToUnknownOnTimeout(
                orderId: $orderId,
                idempotencyKey: $idempotencyKey !== '' ? $idempotencyKey : null,
                errorMessage: 'BOX NOW returned a non-object JSON payload; voucher state transitioned to unknown.',
            );

            throw new CourierAmbiguousResultException(
                __('BOX NOW delivery-requests returned an unexpected payload; voucher state set to unknown.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                $response->statusCode
            );
        }

        $parcelId = $this->extractParcelId($decoded);
        if ($parcelId === '') {
            $this->transitionToUnknownOnTimeout(
                orderId: $orderId,
                idempotencyKey: $idempotencyKey !== '' ? $idempotencyKey : null,
                errorMessage: 'BOX NOW HTTP 2xx response lacked parcel ID; voucher state transitioned to unknown.',
            );

            throw new CourierAmbiguousResultException(
                __('BOX NOW delivery-requests response did not include a parcel ID; voucher state set to unknown.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                $response->statusCode,
                Redactor::redactArray($decoded)
            );
        }

        $parcelCount = isset($decoded['parcels']) && is_array($decoded['parcels'])
            ? max(1, count($decoded['parcels']))
            : 1;

        return new VoucherResult(
            voucherNo: $parcelId,
            courier: CourierSlug::BoxNow,
            codAmountCents: $codAmountCents,
            parcelCount: $parcelCount,
            trackingUrl: \GRCommerceSuite\Services\TrackingService::publicUrl($parcelId, CourierSlug::BoxNow),
            lockerId: $lockerId,
            rawResponse: Redactor::redactArray($decoded),
        );
    }

    /**
     * Cancel a BOX NOW parcel via `POST /api/v1/parcels/{parcelId}:cancel` (SPEC.md §8.2).
     */
    public function cancelVoucher(string $voucherNo): bool
    {
        $trimmed = trim($voucherNo);
        if ($trimmed === '') {
            throw new CourierValidationException(__('Parcel ID cannot be empty.', 'gr-commerce-suite'), CourierSlug::BoxNow);
        }

        $path = sprintf('/api/v1/parcels/%s:cancel', rawurlencode($trimmed));

        try {
            $response = $this->sendAuthenticatedRequest(
                method: 'POST',
                path: $path,
                bodyPayload: [],
                timeoutSeconds: 15,
                isMutatingVoucherCall: true,
            );

            return $response->statusCode >= 200 && $response->statusCode < 300;
        } catch (CourierValidationException $e) {
            $lower = strtolower($e->getMessage());
            if (str_contains($lower, 'already cancelled') || str_contains($lower, 'cancelled')) {
                return true;
            }
            if (
                str_contains(
                    $lower,
                    'in-transit'
                ) ||
                 str_contains(
                     $lower,
                     'delivered'
                 ) ||
                 str_contains(
                     $lower,
                     'cannot cancel'
                 )
            ) {
                return false;
            }

            throw $e;
        }
    }

    /**
     * Retrieve PDF labels for up to 100 BOX NOW parcels via `GET /api/v1/parcels/{parcelId}/label.pdf` (SPEC.md §8.2).
     *
     * @param non-empty-list<non-empty-string> $voucherNos
     * @return non-empty-string
     */
    public function printVoucherPdf(array $voucherNos, string $format): string
    {
        if ($voucherNos === []) {
            throw new CourierValidationException(
                __('At least one parcel ID is required for printing.', 'gr-commerce-suite'),
                CourierSlug::BoxNow
            );
        }

        if (count($voucherNos) > 100) {
            throw new CourierValidationException(
                __('Cannot print more than 100 BOX NOW labels at once.', 'gr-commerce-suite'),
                CourierSlug::BoxNow
            );
        }

        $printFormat = PrintFormat::tryFrom(strtolower(trim($format)));
        if ($printFormat === null) {
            throw new UnsupportedPrintFormatException(
                sprintf(__('Unsupported print format "%s" for BOX NOW.', 'gr-commerce-suite'), $format),
                CourierSlug::BoxNow
            );
        }

        $pdfDocuments = [];

        foreach ($voucherNos as $voucherNo) {
            $trimmed = trim($voucherNo);
            if ($trimmed === '') {
                throw new CourierValidationException(__('Parcel ID cannot be empty.', 'gr-commerce-suite'), CourierSlug::BoxNow);
            }

            $path = sprintf('/api/v1/parcels/%s/label.pdf', rawurlencode($trimmed));
            if ((new LicenseManager())->isSandboxEnabled()) {
                $path .= '?format=' . $printFormat->value;
            }
            $response = $this->sendAuthenticatedRequest(
                method: 'GET',
                path: $path,
                bodyPayload: null,
                timeoutSeconds: 30,
                isMutatingVoucherCall: false,
                acceptHeader: 'application/pdf',
            );

            $pdfBytes = $this->extractPdfBytes($response, $trimmed);
            $pdfDocuments[] = $pdfBytes;
        }

        return ($this->pdfMerger ??= new PdfMerger())->merge($pdfDocuments);
    }

    /**
     * Fetch current tracking status of a BOX NOW parcel via `GET /api/v1/parcels/{parcelId}` (SPEC.md §8.2, §11.1).
     */
    public function getTrackingStatus(string $voucherNo): TrackingResult
    {
        $trimmed = trim($voucherNo);
        if ($trimmed === '') {
            throw new CourierValidationException(__('Parcel ID cannot be empty.', 'gr-commerce-suite'), CourierSlug::BoxNow);
        }

        $path = sprintf('/api/v1/parcels/%s', rawurlencode($trimmed));
        $response = $this->sendAuthenticatedRequest(
            method: 'GET',
            path: $path,
            bodyPayload: null,
            timeoutSeconds: 15,
            isMutatingVoucherCall: false,
        );

        try {
            $decoded = json_decode($response->body, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable $e) {
            throw new CourierTransportException(
                sprintf(__('BOX NOW tracking response for "%s" is not valid JSON.', 'gr-commerce-suite'), $trimmed),
                CourierSlug::BoxNow,
                $response->statusCode,
                [],
                null,
                $e
            );
        }

        if (!is_array($decoded)) {
            throw new VoucherNotFoundException(
                sprintf(__('BOX NOW parcel "%s" was not found.', 'gr-commerce-suite'), $trimmed),
                CourierSlug::BoxNow,
                $response->statusCode
            );
        }

        $stateCode = (string) ($decoded['state'] ?? $decoded['status'] ?? 'unknown');
        $stateLabel = (string) ($decoded['stateLabel'] ?? $decoded['statusDescription'] ?? $stateCode);

        $events = [];
        $rawEvents = isset($decoded['events']) && is_array($decoded['events']) ? $decoded['events'] : [];
        foreach ($rawEvents as $ev) {
            if (!is_array($ev)) {
                continue;
            }
            $evCode = (string) ($ev['type'] ?? $ev['state'] ?? $stateCode);
            $evLabel = (string) ($ev['description'] ?? $ev['label'] ?? $evCode);
            $evLoc = isset($ev['locationId']) || isset($ev['location'])
                ? (string) ($ev['location'] ?? $ev['locationId'])
                : null;
            $evTime = $this->parseDateTime((string) ($ev['time'] ?? $ev['createdAt'] ?? ''))
                ?? new DateTimeImmutable('now', new DateTimeZone('UTC'));

            $events[] = new TrackingEvent(
                occurredAt: $evTime,
                courierCode: $evCode,
                label: $evLabel,
                location: $evLoc,
            );
        }

        $lastEventAt = $events !== []
            ? $events[count($events) - 1]->occurredAt
            : $this->parseDateTime((string) ($decoded['updatedAt'] ?? ''));

        $normalisedStatus = $this->mapBoxNowState($stateCode);

        return new TrackingResult(
            voucherNo: $trimmed,
            status: $normalisedStatus,
            courierStatusCode: $stateCode,
            courierStatusLabel: $stateLabel,
            lastEventAt: $lastEventAt,
            events: $events,
            rawResponse: Redactor::redactArray($decoded),
        );
    }

    /**
     * Report COD collection/settlement facts for up to 100 BOX NOW parcels (SPEC.md §8.2, §10).
     *
     * @param non-empty-list<non-empty-string> $voucherNos
     * @return array<non-empty-string, CodReconciliationResult>
     */
    public function reconcileCodBatch(array $voucherNos): array
    {
        if (count($voucherNos) > 100) {
            throw new CourierValidationException(
                __('COD reconciliation batch cannot exceed 100 parcels.', 'gr-commerce-suite'),
                CourierSlug::BoxNow
            );
        }

        $results = [];

        foreach ($voucherNos as $voucherNo) {
            try {
                $path = sprintf('/api/v1/parcels/%s', rawurlencode($voucherNo));
                $response = $this->sendAuthenticatedRequest(
                    method: 'GET',
                    path: $path,
                    bodyPayload: null,
                    timeoutSeconds: 30,
                    isMutatingVoucherCall: false,
                );

                $decoded = json_decode($response->body, true, 512, JSON_THROW_ON_ERROR);
                if (!is_array($decoded)) {
                    $results[$voucherNo] = new CodReconciliationResult(
                        voucherNo: $voucherNo,
                        status: CodSettlementStatus::NotFound,
                        collectedAmountCents: null,
                        settlementRef: null,
                        settledAt: null,
                        rawResponse: [],
                    );
                    continue;
                }

                $stateCode = (string) ($decoded['state'] ?? $decoded['status'] ?? '');
                $trackingStatus = $this->mapBoxNowState($stateCode);

                $collectedRaw = (string) ($decoded['amountCollected'] ??
                     $decoded['codCollected'] ??
                     $decoded['amountToBeCollected'] ??
                     '');
                $collectedCents = $collectedRaw !== '' ? Money::fromDecimalString($collectedRaw)->cents() : null;
                $settlementRef = isset($decoded['settlementReference']) || isset($decoded['codSettlementRef'])
                    ? (string) ($decoded['settlementReference'] ?? $decoded['codSettlementRef'])
                    : null;
                $settledAt = $this->parseDateTime((string) ($decoded['settledAt'] ?? ''));

                if ($settlementRef !== null && $settlementRef !== '') {
                    $codStatus = CodSettlementStatus::Settled;
                } elseif (
                    $trackingStatus === TrackingStatus::Delivered &&
                     $collectedCents !== null &&
                     $collectedCents > 0
                ) {
                    $codStatus = CodSettlementStatus::CollectedNotSettled;
                } else {
                    $codStatus = CodSettlementStatus::NotCollected;
                }

                $results[$voucherNo] = new CodReconciliationResult(
                    voucherNo: $voucherNo,
                    status: $codStatus,
                    collectedAmountCents: $collectedCents,
                    settlementRef: $settlementRef,
                    settledAt: $settledAt,
                    rawResponse: Redactor::redactArray($decoded),
                );
            } catch (VoucherNotFoundException) {
                $results[$voucherNo] = new CodReconciliationResult(
                    voucherNo: $voucherNo,
                    status: CodSettlementStatus::NotFound,
                    collectedAmountCents: null,
                    settlementRef: null,
                    settledAt: null,
                    rawResponse: [],
                );
            } catch (Throwable) {
                $results[$voucherNo] = new CodReconciliationResult(
                    voucherNo: $voucherNo,
                    status: CodSettlementStatus::NotFound,
                    collectedAmountCents: null,
                    settlementRef: null,
                    settledAt: null,
                    rawResponse: [],
                );
            }
        }

        return $results;
    }

    /**
     * Parse incoming BOX NOW webhook request (SPEC.md §8.6, §15.3).
     *
     * @return list<TrackingResult>
     */
    public function parseWebhook(WP_REST_Request $request): array
    {
        $rawBody = (string) $request->get_body();
        if (trim($rawBody) === '') {
            return [];
        }

        try {
            $decoded = json_decode($rawBody, true, 512, JSON_THROW_ON_ERROR);
        } catch (Throwable) {
            return [];
        }

        if (!is_array($decoded)) {
            return [];
        }

        $parcelId = trim((string) ($decoded['parcelId'] ?? $decoded['id'] ?? ''));
        if ($parcelId === '') {
            return [];
        }

        $stateCode = (string) ($decoded['state'] ?? $decoded['status'] ?? 'unknown');
        $status = $this->mapBoxNowState($stateCode);
        $occurredAt = $this->parseDateTime((string) ($decoded['timestamp'] ?? $decoded['updatedAt'] ?? ''))
            ?? new DateTimeImmutable('now', new DateTimeZone('UTC'));

        return [
            new TrackingResult(
                voucherNo: $parcelId,
                status: $status,
                courierStatusCode: $stateCode,
                courierStatusLabel: $stateCode,
                lastEventAt: $occurredAt,
                events: [
                    new TrackingEvent(
                        occurredAt: $occurredAt,
                        courierCode: $stateCode,
                        label: $stateCode,
                        location: isset($decoded['locationId']) ? (string) $decoded['locationId'] : null,
                    ),
                ],
                rawResponse: Redactor::redactArray($decoded),
            ),
        ];
    }

    /**
     * Validate BOX NOW OAuth2 credentials (SPEC.md §8.6).
     */
    public function testConnection(): bool
    {
        try {
            return $this->authenticate(true) !== '';
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * Send an authenticated request to BOX NOW Partner API with Bearer token and timeout safety.
     *
     * @param array<string, mixed>|null $bodyPayload
     */
    private function sendAuthenticatedRequest(
        string $method,
        string $path,
        ?array $bodyPayload,
        int $timeoutSeconds,
        bool $isMutatingVoucherCall,
        ?int $orderId = null,
        ?string $idempotencyKey = null,
        string $acceptHeader = 'application/json',
    ): HttpResponse {
        $accessToken = $this->authenticate();

        $headers = [
            'Authorization' => 'Bearer ' . $accessToken,
            'Accept' => $acceptHeader,
        ];

        $body = null;
        if ($bodyPayload !== null) {
            $headers['Content-Type'] = 'application/json';
            $body = function_exists('wp_json_encode')
                ? (string) wp_json_encode($bodyPayload)
                : json_encode($bodyPayload, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
        }

        $request = new HttpRequest(
            method: $method,
            url: $this->baseUrl() . $path,
            headers: $headers,
            body: $body,
            timeoutSeconds: $timeoutSeconds,
            connectTimeoutSeconds: 5,
        );

        try {
            $response = (new \GRCommerceSuite\Services\DiagnosticLogger())->send($this->httpClient, $request, 'BOXNOW', match (true) {
                $method === 'POST' && $path === self::PATH_DELIVERY_REQUESTS => 'create_voucher',
                str_contains($path, 'cancel') || $method === 'DELETE' => 'cancel_voucher',
                str_contains($path, 'label') => 'print_voucher',
                $path === self::PATH_DESTINATIONS => 'list_pickup_points', default => 'track_voucher',
            }, $orderId);
        } catch (Throwable $e) {
            $msg = $e->getMessage();
            if ($this->isTimeoutMessage($msg)) {
                $this->transitionToUnknownOnTimeout(
                    orderId: $orderId,
                    idempotencyKey: $idempotencyKey,
                    errorMessage: sprintf(
                        'BOX NOW %s timed out after transmission (%s); state transitioned to unknown.',
                        $path,
                        $msg
                    ),
                );

                throw new CourierAmbiguousResultException(
                    sprintf(
                        __('BOX NOW request %s timed out after transmission; voucher state moved to %s.', 'gr-commerce-suite'),
                        $path,
                        VoucherState::Unknown->value
                    ),
                    CourierSlug::BoxNow,
                    null,
                    ['path' => $path, 'state' => VoucherState::Unknown->value],
                    'BOX NOW did not respond in time. Voucher marked as unknown to prevent duplicate creation.',
                    $e
                );
            }

            throw new CourierTransportException(
                sprintf(__('BOX NOW transport error on %s: %s', 'gr-commerce-suite'), $path, $msg),
                CourierSlug::BoxNow,
                null,
                ['path' => $path],
                null,
                $e
            );
        }

        // 1. Post-transmission read/operation timeout -> transition row `state` to `'unknown'`
        if ($response->timedOutAfterTransmission) {
            $timeoutReason = $response->errorMessage ?? sprintf('HTTP %d timeout', $response->statusCode);
            $this->transitionToUnknownOnTimeout(
                orderId: $orderId,
                idempotencyKey: $idempotencyKey,
                errorMessage: sprintf(
                    'BOX NOW %s timed out after transmission (%s); state transitioned to unknown.',
                    $path,
                    $timeoutReason
                ),
            );

            throw new CourierAmbiguousResultException(
                sprintf(
                    __('BOX NOW %s timed out after transmission (%s); voucher state moved to %s.', 'gr-commerce-suite'),
                    $path,
                    $timeoutReason,
                    VoucherState::Unknown->value
                ),
                CourierSlug::BoxNow,
                $response->statusCode > 0 ? $response->statusCode : null,
                ['path' => $path, 'state' => VoucherState::Unknown->value],
                'BOX NOW did not respond before the timeout elapsed. Voucher state was set to ' .
                    'unknown to prevent duplicate creation.'
            );
        }

        // 2. Pre-transmission transport failure -> retryable
        if ($response->hasError() || $response->failedBeforeTransmission) {
            throw new CourierTransportException(
                sprintf(
                    __('BOX NOW connection failed before processing %s: %s', 'gr-commerce-suite'),
                    $path,
                    $response->errorMessage ??
                    'unknown'
                ),
                CourierSlug::BoxNow,
                null,
                ['path' => $path, 'error_code' => $response->errorCode]
            );
        }

        // 3. Status codes
        if ($response->statusCode === 401 || $response->statusCode === 403) {
            throw new CourierAuthenticationException(
                sprintf(__('BOX NOW Bearer token rejected (HTTP %d).', 'gr-commerce-suite'), $response->statusCode),
                CourierSlug::BoxNow,
                $response->statusCode,
                ['path' => $path]
            );
        }

        if ($response->statusCode === 404) {
            throw new VoucherNotFoundException(
                sprintf(__('BOX NOW resource not found at %s.', 'gr-commerce-suite'), $path),
                CourierSlug::BoxNow,
                404,
                ['path' => $path]
            );
        }

        if ($response->statusCode === 429) {
            throw new CourierRateLimitedException(
                __('BOX NOW rate limit exceeded.', 'gr-commerce-suite'),
                CourierSlug::BoxNow,
                (int) ($response->header('retry-after') ?? 60),
                429,
                ['path' => $path]
            );
        }

        if ($response->statusCode >= 500) {
            throw new CourierTransportException(
                sprintf(__('BOX NOW server error (HTTP %d) on %s.', 'gr-commerce-suite'), $response->statusCode, $path),
                CourierSlug::BoxNow,
                $response->statusCode,
                ['path' => $path]
            );
        }

        if ($response->statusCode < 200 || $response->statusCode >= 300) {
            $errMsg = $this->extractBoxNowError($response->body) ?: sprintf(
                'HTTP %d validation error on %s',
                $response->statusCode,
                $path
            );
            throw new CourierValidationException(
                sprintf(__('BOX NOW rejected request: %s', 'gr-commerce-suite'), $errMsg),
                CourierSlug::BoxNow,
                $response->statusCode,
                ['path' => $path],
                $errMsg
            );
        }

        return $response;
    }

    private function transitionToUnknownOnTimeout(
        ?int $orderId,
        ?string $idempotencyKey,
        string $errorMessage,
    ): void {
        $this->logger->warning(
            $errorMessage,
            [
                'order_id' => $orderId,
                'state' => VoucherState::Unknown->value,
            ]
        );

        if ($this->stateTracker !== null && $orderId !== null && $orderId > 0) {
            $this->stateTracker->markUnknownOnTimeout(
                orderId: $orderId,
                courier: CourierSlug::BoxNow,
                errorMessage: $errorMessage,
                idempotencyKey: $idempotencyKey,
            );
        }
    }

    /**
     * @param array<string, mixed> $decoded
     */
    private function extractParcelId(array $decoded): string
    {
        if (
            isset($decoded['parcels']) &&
             is_array($decoded['parcels']) &&
             isset($decoded['parcels'][0]) &&
             is_array($decoded['parcels'][0])
        ) {
            $id = trim((string) ($decoded['parcels'][0]['id'] ?? ''));
            if ($id !== '') {
                return $id;
            }
        }

        return trim((string) ($decoded['parcelId'] ?? $decoded['id'] ?? ''));
    }

    /**
     * @return non-empty-string
     */
    private function extractPdfBytes(HttpResponse $response, string $voucherNo): string
    {
        if (PdfMerger::isValidPdf($response->body)) {
            /** @var non-empty-string $rawBody */
            $rawBody = $response->body;

            return $rawBody;
        }

        try {
            $decoded = json_decode($response->body, true, 512, JSON_THROW_ON_ERROR);
            if (is_array($decoded)) {
                $b64 = (string) ($decoded['pdf_base64'] ?? $decoded['label'] ?? $decoded['data'] ?? '');
                if ($b64 !== '') {
                    $bin = base64_decode($b64, true);
                    if (is_string($bin) && $bin !== '' && PdfMerger::isValidPdf($bin)) {
                        return $bin;
                    }
                }
            }
        } catch (Throwable) {
            // Fall through to exception below
        }

        throw new CourierTransportException(
            sprintf(__('BOX NOW label response for parcel "%s" did not start with %%PDF- magic bytes.', 'gr-commerce-suite'), $voucherNo),
            CourierSlug::BoxNow,
            $response->statusCode
        );
    }

    private function extractBoxNowError(string $body): string
    {
        try {
            $decoded = json_decode($body, true, 64, JSON_THROW_ON_ERROR);
            if (is_array($decoded)) {
                return trim((string) ($decoded['message'] ?? $decoded['error'] ?? $decoded['code'] ?? ''));
            }
        } catch (Throwable) {
            return '';
        }

        return '';
    }

    private function mapBoxNowState(string $stateCode): TrackingStatus
    {
        $normalized = mb_strtolower(trim($stateCode), 'UTF-8');

        $map = [
            'new' => TrackingStatus::Pending,
            'accepted' => TrackingStatus::PickedUp,
            'in-depot' => TrackingStatus::InTransit,
            'in-transit' => TrackingStatus::InTransit,
            'out-for-delivery' => TrackingStatus::OutForDelivery,
            'in-final-destination' => TrackingStatus::ReadyForPickup,
            'wait-for-load' => TrackingStatus::InTransit,
            'delivered' => TrackingStatus::Delivered,
            'expired' => TrackingStatus::DeliveryFailed,
            'returning' => TrackingStatus::Returning,
            'returned' => TrackingStatus::Returned,
            'refused' => TrackingStatus::Returned,
            'επιστροφή' => TrackingStatus::Returned,
            'άρνηση παραλαβής' => TrackingStatus::Returned,
            'cancelled' => TrackingStatus::Cancelled,
            'canceled' => TrackingStatus::Cancelled,
            'lost' => TrackingStatus::Exception,
            'damaged' => TrackingStatus::Exception,
        ];

        if (isset($map[$normalized])) {
            return $map[$normalized];
        }

        if (!isset($this->loggedUnknownStatusCodes[$normalized])) {
            $this->loggedUnknownStatusCodes[$normalized] = true;
            $this->logger->warning(
                'Unmapped BOX NOW tracking state encountered; mapped to TrackingStatus::Unknown.',
                ['state' => $stateCode]
            );
        }

        return TrackingStatus::Unknown;
    }

    /** Live checkout must never validate destinations against a stale staging/custom endpoint. */
    public function usesProductionEndpoint(): bool
    {
        return $this->baseUrl() === self::PRODUCTION_BASE_URL;
    }

    private function baseUrl(): string
    {
        $custom = rtrim(trim((string) ($this->credentials['base_url'] ?? '')), '/');
        if ($custom !== '') {
            return $custom;
        }

        $env = strtolower(trim((string) ($this->credentials['environment'] ?? 'production')));

        return $env === 'staging' || $env === 'stage' || $env === 'sandbox'
            ? self::STAGING_BASE_URL
            : self::PRODUCTION_BASE_URL;
    }

    private function tokenTransientKey(): string
    {
        $clientId = $this->credential('client_id', 'grcs_boxnow_client_id', 'default');

        $secret = $this->credential('client_secret', 'grcs_boxnow_client_secret');
        $mode = (new LicenseManager())->isSandboxEnabled() ? 'sandbox' : 'live';
        return 'grcs_boxnow_tok_' .
             substr(
                 hash(
                     'sha256',
                     $this->baseUrl() .
                     '|' .
                     $clientId .
                     '|' .
                     $secret .
                     '|' .
                     $mode
                 ),
                 0,
                 24
             );
    }

    private function credential(string $key, string $optionName, string $default = ''): string
    {
        $direct = trim((string) ($this->credentials[$key] ?? ''));
        if ($direct !== '') {
            return $direct;
        }

        if (function_exists('get_option')) {
            $opt = get_option($optionName, '');
            if (is_scalar($opt) && trim((string) $opt) !== '') {
                return trim((string) $opt);
            }
        }

        return $default;
    }

    private function resolveRecipientName(WC_Order $order): string
    {
        $shippingName = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
        if ($shippingName !== '') {
            return $shippingName;
        }

        return trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
    }

    private function resolvePhone(WC_Order $order): string
    {
        $shippingPhone = trim((string) $order->get_shipping_phone());
        $billingPhone = trim((string) $order->get_billing_phone());

        if ($shippingPhone !== '' && $billingPhone !== '' && $shippingPhone !== $billingPhone) {
            return $shippingPhone . ',' . $billingPhone;
        }

        return $shippingPhone !== '' ? $shippingPhone : $billingPhone;
    }

    private function resolveCodAmountCents(WC_Order $order): int
    {
        $override = $order->get_meta('_grcs_custom_cod_amount', true);
        if (is_string($override) && $override !== '') {
            return max(0, Money::fromDecimalString($override)->cents());
        }
        if (strtolower((string) $order->get_payment_method()) !== 'cod') {
            return 0;
        }

        return Money::fromDecimalString((string) $order->get_total())->cents();
    }

    private function parseDateTime(string $raw): ?DateTimeImmutable
    {
        $trimmed = trim($raw);
        if ($trimmed === '') {
            return null;
        }

        try {
            $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('Europe/Athens');

            return new DateTimeImmutable($trimmed, $tz);
        } catch (Throwable) {
            return null;
        }
    }

    private function isTimeoutMessage(string $message): bool
    {
        $lower = strtolower($message);

        return str_contains($lower, 'timed out')
            || str_contains($lower, 'timeout')
            || str_contains($lower, 'curl error 28');
    }
}
