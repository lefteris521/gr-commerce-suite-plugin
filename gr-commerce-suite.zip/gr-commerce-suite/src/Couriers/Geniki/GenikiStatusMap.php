<?php

declare(strict_types=1);

namespace GRCommerceSuite\Couriers\Geniki;

use GRCommerceSuite\Domain\Tracking\TrackingStatus;

/**
 * Normalises Geniki Taxydromiki checkpoint status codes and textual descriptions
 * to the canonical GRCS `TrackingStatus` enum (SPEC.md §11.1).
 */
final class GenikiStatusMap
{
    /**
     * Official checkpoint reversal map (Official Web API V2 guide, p. 14).
     * Reversal codes cancel the preceding active checkpoint matching the mapped target code.
     *
     * @var array<string, string>
     */
    public const REVERSAL_MAP = [
        'C_E2' => 'C_E1', // Cancel previous checkpoint: C_E1 (Return to sender)
        'C_L2' => 'C_L1', // Cancel previous checkpoint: C_L1 (Routing to other service point)
        'C_K9' => 'C_K8', // Cancel previous checkpoint: C_K8 (Departure from Service Point)
    ];

    /**
     * Determines whether a checkpoint code or status description is a reversal of a prior checkpoint.
     * Returns the target checkpoint code that is reversed (e.g. 'C_E1'), or null if not a reversal.
     */
    public static function getReversedCode(string $code, string $description = ''): ?string
    {
        $normalizedCode = strtoupper(trim($code));
        if (isset(self::REVERSAL_MAP[$normalizedCode])) {
            return self::REVERSAL_MAP[$normalizedCode];
        }

        if ($description !== '') {
            if (preg_match('/cancel\s+previous\s+checkpoint:\s*([A-Za-z0-9_]+)/i', $description, $matches)) {
                return strtoupper(trim($matches[1]));
            }
        }

        return null;
    }

    /**
     * Map a Geniki checkpoint code, description, and optional delivery target to a normalised TrackingStatus.
     */
    public static function map(string $code, string $description, ?string $deliveredAt = null): TrackingStatus
    {
        $normalizedCode = strtoupper(trim($code));
        $lowerDesc = mb_strtolower(trim($description), 'UTF-8');

        // Checkpoint reversals cannot be resolved in isolation without history
        if (self::getReversedCode($normalizedCode, $lowerDesc) !== null) {
            return TrackingStatus::Unknown;
        }

        $isReturnTarget = false;
        if ($deliveredAt !== null && trim($deliveredAt) !== '') {
            $lowerTarget = mb_strtolower(trim($deliveredAt), 'UTF-8');
            if (
                str_contains($lowerTarget, 'return to sender') ||
                str_contains($lowerTarget, 'return') ||
                str_contains($lowerTarget, 'sender') ||
                str_contains($lowerTarget, 'επιστροφ') ||
                str_contains($lowerTarget, 'αποστολε')
            ) {
                $isReturnTarget = true;
            }
        }

        // Check for direct status code matches against official immutable C_* and standard codes (Official Web API V2 guide, p. 14)
        $direct = match ($normalizedCode) {
            'DELIVERED', 'PARADOSI', 'PARADOTHIKE', 'C_DELIVERED', 'C_DELIVERY', 'C_DEL', 'C_PARADOSI', 'C_PARADOTHIKE', 'C_W2', 'C_S2', '4' => TrackingStatus::Delivered,
            'OUT_FOR_DELIVERY', 'DIANOMI', 'C_OUT_FOR_DELIVERY', 'C_OUT', 'C_DIANOMI', 'C_A3', 'C_S0', '3' => TrackingStatus::OutForDelivery,
            'IN_TRANSIT', 'METAFORA', 'DIALOGI', 'C_IN_TRANSIT', 'C_TRANSIT', 'C_METAFORA', 'C_DIALOGI', 'C_A1', 'C_H1', 'C_H2', 'C_K8', 'C_L1', 'C_S1', 'C_S7', 'C_SD', '2' => TrackingStatus::InTransit,
            'READY_FOR_PICKUP', 'PARALAVI_KATASTIMA', 'C_READY_FOR_PICKUP', 'C_PARALAVI_KATASTIMA', 'C_PICKUP_STORE', 'C_D2', 'C_S4', 'C_S9', '6' => TrackingStatus::ReadyForPickup,
            'PICKED_UP', 'PARALAVI_APOSTOLEA', 'EISAGOGI', 'C_PICKED_UP', 'C_PICKUP', 'C_PARALAVI_APOSTOLEA', 'C_EISAGOGI', 'C_W3', '1' => TrackingStatus::PickedUp,
            'RETURNED', 'EPISTROFI', 'C_RETURNED', 'C_RETURN', 'C_EPISTROFI', 'C_S3', '8' => TrackingStatus::Returned,
            'RETURNING', 'C_RETURNING', 'C_E1', '7' => TrackingStatus::Returning,
            'DELIVERY_FAILED', 'APOTYXIA', 'C_DELIVERY_FAILED', 'C_FAILED', 'C_APOTYXIA', 'C_UNDELIVERED', 'C_EA_AS', 'C_S6', 'C_SA', 'C_SB', 'C_SE', 'C_SF', '5' => TrackingStatus::DeliveryFailed,
            'CANCELLED', 'CANCELED', 'AKYROSI', 'C_CANCELLED', 'C_CANCELED', 'C_AKYROSI', 'C_P4', 'C_S5', 'C_S8', '9' => TrackingStatus::Cancelled,
            'PENDING', 'DHMIOYRGIA', 'C_PENDING', 'C_DHMIOYRGIA', 'C_NW', 'C_KK', 'C_SC', '0' => TrackingStatus::Pending,
            default => null,
        };

        if ($direct !== null) {
            if ($isReturnTarget && $direct === TrackingStatus::Delivered) {
                return TrackingStatus::Returned;
            }
            return $direct;
        }

        // Geniki exception codes start with C_EA_ (e.g. C_EA_DD, C_EA_AS)
        if (str_starts_with($normalizedCode, 'C_EA_')) {
            return TrackingStatus::DeliveryFailed;
        }

        // Semantic analysis of Greek and English checkpoint text.
        // Negative / failure / undelivered matches take precedence over partial substring hits.
        if (
            str_contains($lowerDesc, 'αδυναμία παράδοσης') ||
            str_contains($lowerDesc, 'αποτυχία') ||
            str_contains($lowerDesc, 'απών') ||
            str_contains($lowerDesc, 'λάθος διεύθυνση') ||
            str_contains($lowerDesc, 'μη παράδοση') ||
            str_contains($lowerDesc, 'failed') ||
            str_contains($lowerDesc, 'undelivered') ||
            str_contains($lowerDesc, 'not delivered') ||
            str_contains($lowerDesc, 'attempted') ||
            str_contains($lowerDesc, 'damaged') ||
            str_contains($lowerDesc, 'destroyed') ||
            str_contains($lowerDesc, 'damage') ||
            str_contains($lowerDesc, 'destruction') ||
            str_contains($lowerDesc, 'ζημιά') ||
            str_contains($lowerDesc, 'καταστροφή')
        ) {
            return TrackingStatus::DeliveryFailed;
        }

        if (
            str_contains($lowerDesc, 'επιστροφή') ||
            str_contains($lowerDesc, 'επιστράφηκε') ||
            str_contains($lowerDesc, 'άρνηση παραλαβής') ||
            str_contains($lowerDesc, 'return to sender') ||
            str_contains($lowerDesc, 'returned') ||
            str_contains($lowerDesc, 'returning') ||
            str_contains($lowerDesc, 'refused')
        ) {
            return (str_contains($lowerDesc, 'ολοκληρώθηκε') || str_contains($lowerDesc, 'παραδόθηκε') || str_contains($lowerDesc, 'delivered'))
                ? TrackingStatus::Returned
                : TrackingStatus::Returning;
        }

        // Out for delivery must precede delivery check
        if (
            str_contains($lowerDesc, 'προς παράδοση') ||
            str_contains($lowerDesc, 'διανομή') ||
            str_contains($lowerDesc, 'out for delivery') ||
            str_contains($lowerDesc, 'on courier') ||
            str_contains($lowerDesc, 'με διανομέα')
        ) {
            return TrackingStatus::OutForDelivery;
        }

        if (
            str_contains($lowerDesc, 'παραλαβή από κατάστημα') ||
            str_contains($lowerDesc, 'προς παραλαβή') ||
            str_contains($lowerDesc, 'διαθέσιμο στο κατάστημα') ||
            str_contains($lowerDesc, 'ready for pickup') ||
            str_contains($lowerDesc, 'available for pickup') ||
            str_contains($lowerDesc, 'store pickup')
        ) {
            return TrackingStatus::ReadyForPickup;
        }

        if (
            str_contains($lowerDesc, 'παραλαβή από αποστολέα') ||
            str_contains($lowerDesc, 'παραλήφθηκε') ||
            str_contains($lowerDesc, 'εισαγωγή') ||
            str_contains($lowerDesc, 'picked up') ||
            str_contains($lowerDesc, 'collection from sender') ||
            str_contains($lowerDesc, 'collected')
        ) {
            return TrackingStatus::PickedUp;
        }

        if (
            str_contains($lowerDesc, 'μεταφορά') ||
            str_contains($lowerDesc, 'διαλογή') ||
            str_contains($lowerDesc, 'κέντρο διαλογής') ||
            str_contains($lowerDesc, 'άφιξη σε') ||
            str_contains($lowerDesc, 'αναχώρηση από') ||
            str_contains($lowerDesc, 'in transit') ||
            str_contains($lowerDesc, 'transit') ||
            str_contains($lowerDesc, 'hub') ||
            str_contains($lowerDesc, 'sorting')
        ) {
            return TrackingStatus::InTransit;
        }

        // Specific delivery matches only: never match bare 'παράδοση' without delivered confirmation
        if (
            str_contains($lowerDesc, 'παραδόθηκε') ||
            str_contains($lowerDesc, 'επιτυχής παράδοση') ||
            str_contains($lowerDesc, 'ολοκλήρωση παράδοσης') ||
            str_contains($lowerDesc, 'delivered')
        ) {
            return $isReturnTarget ? TrackingStatus::Returned : TrackingStatus::Delivered;
        }

        if (
            str_contains($lowerDesc, 'ακυρώθηκε') ||
            str_contains($lowerDesc, 'ακύρωση') ||
            str_contains($lowerDesc, 'cancelled') ||
            str_contains($lowerDesc, 'canceled')
        ) {
            return TrackingStatus::Cancelled;
        }

        if (
            str_contains($lowerDesc, 'δημιουργία') ||
            str_contains($lowerDesc, 'καταχώρηση') ||
            str_contains($lowerDesc, 'pending') ||
            str_contains($lowerDesc, 'registered') ||
            str_contains($lowerDesc, 'customs') ||
            str_contains($lowerDesc, 'τελωνείο')
        ) {
            return TrackingStatus::Pending;
        }

        return TrackingStatus::Unknown;
    }
}
