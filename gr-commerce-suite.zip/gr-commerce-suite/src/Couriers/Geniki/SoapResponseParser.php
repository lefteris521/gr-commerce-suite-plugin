<?php

declare(strict_types=1);

namespace GRCommerceSuite\Couriers\Geniki;

use GRCommerceSuite\Exceptions\Courier\CourierTransportException;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use SimpleXMLElement;
use Throwable;

/**
 * Parses SOAP 1.1 XML responses from Geniki Taxydromiki Web API V2 (`JobServicesV2.asmx`).
 *
 * Implemented using PHP's built-in SimpleXMLElement with network entity loading disabled (LIBXML_NONET).
 */
final class SoapResponseParser
{
    /**
     * Parse SOAP response and return the inner response XML element or detect SOAP Faults.
     *
     * @throws CourierTransportException When XML is invalid or a SOAP Fault is present.
     */
    public static function parseEnvelope(string $xml): SimpleXMLElement
    {
        $trimmed = trim($xml);
        if ($trimmed === '') {
            throw new CourierTransportException(
                __('Geniki Taxydromiki returned an empty response body.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        // Disable external entities and load XML cleanly
        $internalErrors = libxml_use_internal_errors(true);
        try {
            $element = simplexml_load_string($trimmed, 'SimpleXMLElement', LIBXML_NONET);
        } catch (Throwable $e) {
            libxml_clear_errors();
            libxml_use_internal_errors($internalErrors);
            throw new CourierTransportException(
                sprintf(__('Failed to parse Geniki Taxydromiki XML response: %s', 'gr-commerce-suite'), $e->getMessage()),
                CourierSlug::Geniki,
                null,
                [],
                null,
                $e
            );
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($internalErrors);
        }

        if ($element === false) {
            throw new CourierTransportException(
                __('Geniki Taxydromiki returned malformed XML.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        // Register SOAP namespaces
        $element->registerXPathNamespace('soap', SoapEnvelopeBuilder::XMLNS_SOAP);
        $element->registerXPathNamespace('tns', SoapEnvelopeBuilder::XMLNS_SERVICES);

        // Check for SOAP Fault
        $faults = $element->xpath('//soap:Fault | //Fault');
        if (!empty($faults)) {
            $fault = $faults[0];
            $faultCode = (string) ($fault->faultcode ?? $fault->faultCode ?? $fault->Code->Value ?? 'SOAP-FAULT');
            $faultString = (string) ($fault->faultstring ?? $fault->faultString ?? $fault->Reason->Text ?? 'Unknown SOAP fault');

            throw new CourierTransportException(
                sprintf(__('Geniki SOAP Fault [%s]: %s', 'gr-commerce-suite'), $faultCode, $faultString),
                CourierSlug::Geniki,
                null,
                ['fault_code' => $faultCode, 'fault_string' => $faultString]
            );
        }

        return $element;
    }

    /**
     * Parse AuthenticateResponse.
     *
     * @return array{result: int, key: string}
     */
    public static function parseAuthenticate(string $xml): array
    {
        $element = self::parseEnvelope($xml);
        $element->registerXPathNamespace('tns', SoapEnvelopeBuilder::XMLNS_SERVICES);

        $results = $element->xpath('//tns:AuthenticateResult | //AuthenticateResult');
        if (empty($results)) {
            throw new CourierTransportException(
                __('AuthenticateResult missing from Geniki response.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $res = $results[0];
        $code = isset($res->Result) ? (int) $res->Result : -1;
        $key = isset($res->Key) ? trim((string) $res->Key) : '';

        return [
            'result' => $code,
            'key' => $key,
        ];
    }

    /**
     * Parse CreateJobResponse.
     *
     * @return array{result: int, job_id: int, voucher: string, sub_vouchers: list<string>}
     */
    public static function parseCreateJob(string $xml): array
    {
        $element = self::parseEnvelope($xml);
        $element->registerXPathNamespace('tns', SoapEnvelopeBuilder::XMLNS_SERVICES);

        $results = $element->xpath('//tns:CreateJobResult | //CreateJobResult');
        if (empty($results)) {
            throw new CourierTransportException(
                __('CreateJobResult missing from Geniki response.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $res = $results[0];
        $code = isset($res->Result) ? (int) $res->Result : -1;
        $jobId = isset($res->JobId) ? (int) $res->JobId : 0;
        $voucher = isset($res->Voucher) ? trim((string) $res->Voucher) : '';

        $subVouchers = [];
        if (isset($res->SubVouchers->Record)) {
            foreach ($res->SubVouchers->Record as $subRec) {
                $subNo = isset($subRec->VoucherNo) ? trim((string) $subRec->VoucherNo) : '';
                if ($subNo !== '') {
                    $subVouchers[] = $subNo;
                }
            }
        }

        return [
            'result' => $code,
            'job_id' => $jobId,
            'voucher' => $voucher,
            'sub_vouchers' => $subVouchers,
        ];
    }

    /**
     * Parse CancelJobResponse.
     *
     * @return int CancelJobResult code (0 = success, 4 = closed/picked up, 9 = doesn't exist).
     */
    public static function parseCancelJob(string $xml): int
    {
        $element = self::parseEnvelope($xml);
        $element->registerXPathNamespace('tns', SoapEnvelopeBuilder::XMLNS_SERVICES);

        $results = $element->xpath('//tns:CancelJobResult | //CancelJobResult');
        if (empty($results)) {
            throw new CourierTransportException(
                __('CancelJobResult missing from Geniki response.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        return (int) $results[0];
    }

    /**
     * Parse TrackAndTraceResponse.
     *
     * @return array{
     *     result: int,
     *     status: string,
     *     delivery_date: ?string,
     *     delivered_at: ?string,
     *     consignee: ?string,
     *     checkpoints: list<array{status: string, status_code: string, status_date: string, shop: string}>
     * }
     */
    public static function parseTrackAndTrace(string $xml): array
    {
        $element = self::parseEnvelope($xml);
        $element->registerXPathNamespace('tns', SoapEnvelopeBuilder::XMLNS_SERVICES);

        $results = $element->xpath('//tns:TrackAndTraceResult | //TrackAndTraceResult');
        if (empty($results)) {
            throw new CourierTransportException(
                __('TrackAndTraceResult missing from Geniki response.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $res = $results[0];
        $code = isset($res->Result) ? (int) $res->Result : -1;
        $status = isset($res->Status) ? trim((string) $res->Status) : '';
        $rawDeliveryDate = isset($res->DeliveryDate) ? trim((string) $res->DeliveryDate) : '';
        $deliveryDate = ($rawDeliveryDate !== '' && !str_starts_with($rawDeliveryDate, '0001-01-01'))
            ? $rawDeliveryDate : null;
        $deliveredAt = isset($res->DeliveredAt) && trim((string) $res->DeliveredAt) !== ''
            ? trim((string) $res->DeliveredAt) : null;
        $consignee = isset($res->Consignee) && trim((string) $res->Consignee) !== ''
            ? trim((string) $res->Consignee) : null;

        $checkpoints = [];
        if (isset($res->Checkpoints->Checkpoint)) {
            foreach ($res->Checkpoints->Checkpoint as $cp) {
                $checkpoints[] = [
                    'status' => isset($cp->Status) ? trim((string) $cp->Status) : '',
                    'status_code' => isset($cp->StatusCode) ? trim((string) $cp->StatusCode) : '',
                    'status_date' => isset($cp->StatusDate) ? trim((string) $cp->StatusDate) : '',
                    'shop' => isset($cp->Shop) ? trim((string) $cp->Shop) : '',
                ];
            }
        }

        return [
            'result' => $code,
            'status' => $status,
            'delivery_date' => $deliveryDate,
            'delivered_at' => $deliveredAt,
            'consignee' => $consignee,
            'checkpoints' => $checkpoints,
        ];
    }

    /**
     * Parse GetJobsResponse / GetJobsFromOrderIdResponse.
     *
     * @return array{result: int, count: int, jobs: list<array{id: int, is_canceled: bool, voucher_no: string, order_id: string, sub_vouchers: list<string>, parcel_count: int, cod_amount: string}>}
     */
    public static function parseGetJobs(string $xml): array
    {
        $element = self::parseEnvelope($xml);
        $element->registerXPathNamespace('tns', SoapEnvelopeBuilder::XMLNS_SERVICES);

        $results = $element->xpath('//tns:GetJobsResult | //GetJobsResult | //tns:GetJobsFromOrderIdResult | //GetJobsFromOrderIdResult');
        if (empty($results)) {
            throw new CourierTransportException(
                __('GetJobsResult missing from Geniki response.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        $res = $results[0];
        $code = isset($res->Result) ? (int) $res->Result : -1;
        $count = isset($res->Count) ? (int) $res->Count : 0;

        $jobs = [];
        if (isset($res->Jobs->VoucherJob)) {
            foreach ($res->Jobs->VoucherJob as $vJob) {
                $id = isset($vJob->Id) ? (int) $vJob->Id : 0;
                $isCanceled = isset($vJob->IsCanceled) && strtolower(trim((string) $vJob->IsCanceled)) === 'true';
                $orderId = isset($vJob->OrderId) ? trim((string) $vJob->OrderId) : '';
                $voucherNo = '';
                if (isset($vJob->Voucher->VoucherNo)) {
                    $voucherNo = trim((string) $vJob->Voucher->VoucherNo);
                }

                $children = [];
                foreach ($vJob->SubVouchers->Record ?? [] as $child) {
                    $children[] = trim((string) ($child->VoucherNo ?? ''));
                }

                $jobs[] = [
                    'id' => $id,
                    'is_canceled' => $isCanceled,
                    'voucher_no' => $voucherNo,
                    'order_id' => $orderId,
                    'sub_vouchers' => $children,
                    'parcel_count' => isset($vJob->Voucher->Pieces)
                        ? (int) $vJob->Voucher->Pieces : 1 + count($children),
                    'cod_amount' => isset($vJob->Voucher->CodAmount)
                        ? trim((string) $vJob->Voucher->CodAmount) : '0.00',
                ];
            }
        }

        return [
            'result' => $code,
            'count' => $count,
            'jobs' => $jobs,
        ];
    }

    /**
     * Parse ClosePendingJobsResponse.
     */
    public static function parseClosePendingJobs(string $xml): int
    {
        $element = self::parseEnvelope($xml);
        $element->registerXPathNamespace('tns', SoapEnvelopeBuilder::XMLNS_SERVICES);

        $results = $element->xpath('//tns:ClosePendingJobsResult | //ClosePendingJobsResult');
        if (empty($results)) {
            throw new CourierTransportException(
                __('ClosePendingJobsResult missing from Geniki response.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        return (int) $results[0];
    }

    /**
     * Parse ClosePendingJobsByDateResponse.
     */
    public static function parseClosePendingJobsByDate(string $xml): int
    {
        $element = self::parseEnvelope($xml);
        $element->registerXPathNamespace('tns', SoapEnvelopeBuilder::XMLNS_SERVICES);

        $results = $element->xpath('//tns:ClosePendingJobsByDateResult | //ClosePendingJobsByDateResult');
        if (empty($results)) {
            throw new CourierTransportException(
                __('ClosePendingJobsByDateResult missing from Geniki response.', 'gr-commerce-suite'),
                CourierSlug::Geniki
            );
        }

        return (int) $results[0];
    }
}
