<?php

declare(strict_types=1);

namespace GRCommerceSuite\Couriers\Geniki;

use DateTimeImmutable;

/**
 * Builds standard SOAP 1.1 XML request envelopes for Geniki Taxydromiki Web API V2 (`JobServicesV2.asmx`).
 *
 * Generated envelopes avoid ext-soap dependencies to support shared-hosting environments
 * without PHP SOAP extension (SPEC.md §8.5, composer.json).
 */
final class SoapEnvelopeBuilder
{
    public const XMLNS_SOAP = 'http://schemas.xmlsoap.org/soap/envelope/';
    public const XMLNS_XSI = 'http://www.w3.org/2001/XMLSchema-instance';
    public const XMLNS_XSD = 'http://www.w3.org/2001/XMLSchema';
    public const XMLNS_SERVICES = 'http://voucher.taxydromiki.gr/JobServicesV2.asmx';

    /**
     * Build SOAP envelope for Authenticate operation.
     */
    public static function buildAuthenticate(string $username, string $password, string $applicationKey): string
    {
        $body = sprintf(
            '    <Authenticate xmlns="%s">' . "\n" .
            '      <sUsrName>%s</sUsrName>' . "\n" .
            '      <sUsrPwd>%s</sUsrPwd>' . "\n" .
            '      <applicationKey>%s</applicationKey>' . "\n" .
            '    </Authenticate>',
            self::XMLNS_SERVICES,
            self::escapeXml($username),
            self::escapeXml($password),
            self::escapeXml($applicationKey)
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for CreateJob operation.
     *
     * @param array{
     *     order_id?: string,
     *     name: string,
     *     address: string,
     *     city: string,
     *     zip?: string,
     *     telephone?: string,
     *     email?: string,
     *     country?: string,
     *     country_iso?: string,
     *     pieces?: int,
     *     weight?: float|string,
     *     comments?: string,
     *     services?: string,
     *     cod_amount?: float|string,
     *     ins_amount?: float|string
     * } $data
     */
    public static function buildCreateJob(string $authKey, array $data, string $jobType = 'Voucher'): string
    {
        $orderId = self::escapeXml($data['order_id'] ?? '');
        $name = self::escapeXml($data['name']);
        $address = self::escapeXml($data['address']);
        $city = self::escapeXml($data['city']);
        $zip = self::escapeXml($data['zip'] ?? '');
        $telephone = self::escapeXml($data['telephone'] ?? '');
        $email = self::escapeXml($data['email'] ?? '');
        $country = self::escapeXml($data['country'] ?? 'Greece');
        $countryIso = self::escapeXml($data['country_iso'] ?? 'GR');
        $pieces = max(1, (int) ($data['pieces'] ?? 1));
        $weight = is_numeric($data['weight'] ?? null) ? number_format((float) $data['weight'], 3, '.', '') : '1.000';
        $comments = self::escapeXml($data['comments'] ?? '');
        $services = self::escapeXml($data['services'] ?? '');
        $codAmount = is_numeric($data['cod_amount'] ?? null) ? number_format((float) $data['cod_amount'], 2, '.', '') : '0.00';
        $insAmount = is_numeric($data['ins_amount'] ?? null) ? number_format((float) $data['ins_amount'], 2, '.', '') : '0.00';

        $body = sprintf(
            '    <CreateJob xmlns="%s">' . "\n" .
            '      <sAuthKey>%s</sAuthKey>' . "\n" .
            '      <oVoucher>' . "\n" .
            '        <OrderId>%s</OrderId>' . "\n" .
            '        <Name>%s</Name>' . "\n" .
            '        <Address>%s</Address>' . "\n" .
            '        <Email>%s</Email>' . "\n" .
            '        <Country>%s</Country>' . "\n" .
            '        <CountryIso>%s</CountryIso>' . "\n" .
            '        <City>%s</City>' . "\n" .
            '        <Telephone>%s</Telephone>' . "\n" .
            '        <Zip>%s</Zip>' . "\n" .
            '        <Pieces>%d</Pieces>' . "\n" .
            '        <Weight>%s</Weight>' . "\n" .
            '        <Comments>%s</Comments>' . "\n" .
            '        <Services>%s</Services>' . "\n" .
            '        <CodAmount>%s</CodAmount>' . "\n" .
            '        <InsAmount>%s</InsAmount>' . "\n" .
            '      </oVoucher>' . "\n" .
            '      <eType>%s</eType>' . "\n" .
            '    </CreateJob>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey),
            $orderId,
            $name,
            $address,
            $email,
            $country,
            $countryIso,
            $city,
            $telephone,
            $zip,
            $pieces,
            $weight,
            $comments,
            $services,
            $codAmount,
            $insAmount,
            self::escapeXml($jobType)
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for CancelJob operation.
     */
    public static function buildCancelJob(string $authKey, int $jobId, bool $cancel = true): string
    {
        $body = sprintf(
            '    <CancelJob xmlns="%s">' . "\n" .
            '      <sAuthKey>%s</sAuthKey>' . "\n" .
            '      <nJobId>%d</nJobId>' . "\n" .
            '      <bCancel>%s</bCancel>' . "\n" .
            '    </CancelJob>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey),
            $jobId,
            $cancel ? 'true' : 'false'
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for TrackAndTrace operation.
     */
    public static function buildTrackAndTrace(string $authKey, string $voucherNo, string $language = 'el'): string
    {
        $body = sprintf(
            '    <TrackAndTrace xmlns="%s">' . "\n" .
            '      <authKey>%s</authKey>' . "\n" .
            '      <voucherNo>%s</voucherNo>' . "\n" .
            '      <language>%s</language>' . "\n" .
            '    </TrackAndTrace>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey),
            self::escapeXml($voucherNo),
            self::escapeXml($language)
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for GetVouchersPdf operation.
     *
     * @param non-empty-list<string> $voucherNumbers
     */
    public static function buildGetVouchersPdf(
        string $authKey,
        array $voucherNumbers,
        string $format = 'Flyer',
        string $extraInfoFormat = 'None'
    ): string {
        $vouchersXml = '';
        foreach ($voucherNumbers as $v) {
            $trimmed = trim($v);
            if ($trimmed !== '') {
                $vouchersXml .= sprintf('        <string>%s</string>' . "\n", self::escapeXml($trimmed));
            }
        }

        $body = sprintf(
            '    <GetVouchersPdf xmlns="%s">' . "\n" .
            '      <authKey>%s</authKey>' . "\n" .
            '      <voucherNumbers>' . "\n" .
            '%s' .
            '      </voucherNumbers>' . "\n" .
            '      <format>%s</format>' . "\n" .
            '      <extraInfoFormat>%s</extraInfoFormat>' . "\n" .
            '    </GetVouchersPdf>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey),
            $vouchersXml,
            self::escapeXml($format),
            self::escapeXml($extraInfoFormat)
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for GetVoucherPdf operation.
     */
    public static function buildGetVoucherPdf(
        string $authKey,
        string $voucherNo,
        string $format = 'Flyer',
        string $extraInfoFormat = 'None'
    ): string {
        $body = sprintf(
            '    <GetVoucherPdf xmlns="%s">' . "\n" .
            '      <authKey>%s</authKey>' . "\n" .
            '      <voucherNo>%s</voucherNo>' . "\n" .
            '      <format>%s</format>' . "\n" .
            '      <extraInfoFormat>%s</extraInfoFormat>' . "\n" .
            '    </GetVoucherPdf>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey),
            self::escapeXml($voucherNo),
            self::escapeXml($format),
            self::escapeXml($extraInfoFormat)
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for GetJobs operation (query jobs by voucher number or date range).
     *
     * @param array{
     *     date_from?: string,
     *     date_to?: string,
     *     voucher_number?: string,
     *     order_id?: string,
     *     state?: string,
     *     count_type?: string,
     *     search_type?: string
     * } $params
     */
    public static function buildGetJobs(string $authKey, array $params = []): string
    {
        $dateFrom = self::escapeXml($params['date_from'] ?? '2020-01-01T00:00:00');
        $dateTo = self::escapeXml($params['date_to'] ?? gmdate('Y-m-d\TH:i:s', time() + 86400));
        $voucherNumber = self::escapeXml($params['voucher_number'] ?? '');
        $orderId = self::escapeXml($params['order_id'] ?? '');
        $state = self::escapeXml($params['state'] ?? 'All');
        $countType = self::escapeXml($params['count_type'] ?? 'All');
        $searchType = self::escapeXml($params['search_type'] ?? 'Vouchers');

        $body = sprintf(
            '    <GetJobs xmlns="%s">' . "\n" .
            '      <sAuthKey>%s</sAuthKey>' . "\n" .
            '      <oParams>' . "\n" .
            '        <DateFrom>%s</DateFrom>' . "\n" .
            '        <DateTo>%s</DateTo>' . "\n" .
            '        <VoucherNumber>%s</VoucherNumber>' . "\n" .
            '        <OrderId>%s</OrderId>' . "\n" .
            '        <State>%s</State>' . "\n" .
            '        <CounType>%s</CounType>' . "\n" .
            '        <SearchType>%s</SearchType>' . "\n" .
            '      </oParams>' . "\n" .
            '    </GetJobs>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey),
            $dateFrom,
            $dateTo,
            $voucherNumber,
            $orderId,
            $state,
            $countType,
            $searchType
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for GetJobsFromOrderId operation.
     */
    public static function buildGetJobsFromOrderId(string $authKey, string $orderId): string
    {
        $body = sprintf(
            '    <GetJobsFromOrderId xmlns="%s">' . "\n" .
            '      <sAuthKey>%s</sAuthKey>' . "\n" .
            '      <sOrderId>%s</sOrderId>' . "\n" .
            '    </GetJobsFromOrderId>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey),
            self::escapeXml($orderId)
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for ClosePendingJobs operation.
     */
    public static function buildClosePendingJobs(string $authKey): string
    {
        $body = sprintf(
            '    <ClosePendingJobs xmlns="%s">' . "\n" .
            '      <sAuthKey>%s</sAuthKey>' . "\n" .
            '    </ClosePendingJobs>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey)
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Build SOAP envelope for ClosePendingJobsByDate operation.
     */
    public static function buildClosePendingJobsByDate(string $authKey, DateTimeImmutable $dateFrom, DateTimeImmutable $dateTo): string
    {
        $body = sprintf(
            '    <ClosePendingJobsByDate xmlns="%s">' . "\n" .
            '      <sAuthKey>%s</sAuthKey>' . "\n" .
            '      <dFr>%s</dFr>' . "\n" .
            '      <dTo>%s</dTo>' . "\n" .
            '    </ClosePendingJobsByDate>',
            self::XMLNS_SERVICES,
            self::escapeXml($authKey),
            self::escapeXml($dateFrom->format('Y-m-d\TH:i:s')),
            self::escapeXml($dateTo->format('Y-m-d\TH:i:s'))
        );

        return self::wrapEnvelope($body);
    }

    /**
     * Escape special XML characters for safe inclusion in SOAP elements.
     */
    public static function escapeXml(string $value): string
    {
        return htmlspecialchars($value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
    }

    /**
     * Wrap body in standard SOAP 1.1 Envelope and Body tags.
     */
    private static function wrapEnvelope(string $bodyXml): string
    {
        return '<?xml version="1.0" encoding="utf-8"?>' . "\n" .
            sprintf(
                '<soap:Envelope xmlns:xsi="%s" xmlns:xsd="%s" xmlns:soap="%s">' . "\n",
                self::XMLNS_XSI,
                self::XMLNS_XSD,
                self::XMLNS_SOAP
            ) .
            '  <soap:Body>' . "\n" .
            $bodyXml . "\n" .
            '  </soap:Body>' . "\n" .
            '</soap:Envelope>';
    }
}
