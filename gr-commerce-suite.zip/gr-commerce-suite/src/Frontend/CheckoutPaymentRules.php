<?php

declare(strict_types=1);

namespace GRCommerceSuite\Frontend;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Modules\ModuleRegistry;
use GRCommerceSuite\Shipping\CourierSelection;
use GRCommerceSuite\Shipping\ShippingContext;
use GRCommerceSuite\Support\CheckoutValidation;
use WC_Order;

/** Courier-aware COD labelling and the invoice (Τιμολόγιο) payment restriction. */
final class CheckoutPaymentRules implements HookSubscriberInterface
{
    public const OPTION_INVOICE_DISABLE_COD = 'grcs_invoice_disable_cod';
    public const META_PAYMENT_MODE = '_grcs_payment_mode';

    private static bool $registered = false;
    private static bool $instructionHooksRegistered = false;
    private ?object $codGateway = null;

    public function register(): void
    {
        $this->registerInstructionHooks();
        // Checkout and full runtime can both initialise on one request; filters must not stack.
        if (self::$registered) {
            return;
        }
        self::$registered = true;
        add_filter('woocommerce_gateway_title', [$this, 'title'], 20, 2);
        add_filter('woocommerce_gateway_description', [$this, 'description'], 20, 2);
        add_filter('woocommerce_available_payment_gateways', [$this, 'gateways'], 120);
        add_action('woocommerce_checkout_process', [$this, 'validateCheckout']);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'validateStoreApi'], 20, 2);
        add_action('woocommerce_checkout_create_order', [$this, 'savePaymentMode'], 95, 2);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'savePaymentMode'], 95, 2);
    }

    /** Also register for deferred/admin emails, independently of the checkout runtime. */
    public function registerInstructionHooks(): void
    {
        if (self::$instructionHooksRegistered) {
            return;
        }
        self::$instructionHooksRegistered = true;
        add_action('wc_payment_gateways_initialized', [$this, 'bindCodInstructions']);
        if (function_exists('did_action') && did_action('wc_payment_gateways_initialized') > 0) {
            $this->bindCodInstructions(WC()->payment_gateways());
        }
    }

    public function bindCodInstructions(object $gateways): void
    {
        if (!method_exists($gateways, 'payment_gateways')) {
            return;
        }
        $cod = $gateways->payment_gateways()['cod'] ?? null;
        if (!$cod instanceof \WC_Gateway_COD) {
            return;
        }
        $this->codGateway = $cod;
        remove_action('woocommerce_thankyou_cod', [$cod, 'thankyou_page']);
        remove_action('woocommerce_email_before_order_table', [$cod, 'email_instructions'], 10);
        add_action('woocommerce_thankyou_cod', [$this, 'renderThankYou']);
        add_action('woocommerce_email_before_order_table', [$this, 'renderEmail'], 10, 3);
    }

    public static function isBoxNowPayment(WC_Order $order): bool
    {
        if ($order->get_payment_method() !== 'cod') {
            return false;
        }
        $mode = (string) $order->get_meta(self::META_PAYMENT_MODE, true);
        return $mode !== '' ? $mode === 'boxnow_pay_on_the_go'
            : self::usesBoxNow(CourierSelection::orderRates($order));
    }

    public function savePaymentMode(WC_Order $order, mixed $request = null): void
    {
        if (is_object($request) && method_exists($request, 'get_method')
            && in_array($request->get_method(), ['PUT', 'PATCH'], true)) {
            return;
        }
        if ($order->get_payment_method() !== 'cod') {
            $order->delete_meta_data(self::META_PAYMENT_MODE);
            return;
        }
        $rates = CourierSelection::orderRates($order);
        $boxNow = self::usesEnabledBoxNow($rates !== [] ? $rates : $this->chosenRates());
        $order->update_meta_data(self::META_PAYMENT_MODE, $boxNow ? 'boxnow_pay_on_the_go' : 'cod');
        if ($boxNow) {
            $order->set_payment_method_title(self::codLabels(true)['title']);
        }
        // Keep gateway ID `cod`: provider collection amounts and reconciliation depend on it.
    }

    public function renderThankYou(int $orderId): void
    {
        $order = wc_get_order($orderId);
        if ($order instanceof WC_Order && self::isBoxNowPayment($order)) {
            echo '<p>' . esc_html(self::codLabels(true)['description']) . '</p>';
        } elseif ($this->codGateway !== null && method_exists($this->codGateway, 'thankyou_page')) {
            $this->codGateway->thankyou_page();
        }
    }

    public function renderEmail(WC_Order $order, bool $sentToAdmin = false, bool $plainText = false): void
    {
        if (!self::isBoxNowPayment($order)) {
            if ($this->codGateway !== null && method_exists($this->codGateway, 'email_instructions')) {
                $this->codGateway->email_instructions($order, $sentToAdmin, $plainText);
            }
            return;
        }
        if (!$sentToAdmin) {
            $text = self::codLabels(true)['description'];
            if ($plainText) {
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text email.
                echo $text . "\n";
            } else {
                echo '<p>' . esc_html($text) . '</p>';
            }
        }
    }

    public static function invoiceDisablesCod(): bool
    {
        return get_option(self::OPTION_INVOICE_DISABLE_COD, 'yes') === 'yes'
            && get_option(GreekInvoiceCheckout::OPTION_ENABLED, 'yes') === 'yes';
    }

    /** @param array<int|string, mixed> $rates */
    public static function usesBoxNow(array $rates): bool
    {
        foreach ($rates as $rate) {
            if (is_string($rate) && CourierSelection::fromRate($rate) === CourierSlug::BoxNow) {
                return true;
            }
        }
        return false;
    }

    /** New checkout behaviour only; historical order/email classification deliberately uses usesBoxNow().
     * @param array<int|string, mixed> $rates
     */
    public static function usesEnabledBoxNow(array $rates): bool
    {
        return ModuleRegistry::courierCanCreate(CourierSlug::BoxNow) && self::usesBoxNow($rates);
    }

    /** @return array{title: string, description: string} */
    public static function codLabels(bool $boxNow): array
    {
        return $boxNow ? [
            'title' => __('BOX NOW Pay on the Go (Πληρωμή online πριν την παραλαβή)', 'gr-commerce-suite'),
            // The plugin only tells BOX NOW the amount; BOX NOW chooses how it sends the link, so name no channel or wallet.
            'description' => __('Η BOX NOW θα σας στείλει ασφαλή σύνδεσμο πληρωμής στα στοιχεία επικοινωνίας της παραγγελίας. Πληρώνετε ηλεκτρονικά με τους τρόπους που εμφανίζει ο σύνδεσμος, πριν ανοίξετε τη θυρίδα. Δεν γίνονται δεκτά μετρητά και δεν υπάρχει POS στη θυρίδα.', 'gr-commerce-suite'),
        ] : [
            'title' => __('Αντικαταβολή (Πληρωμή με μετρητά στον courier)', 'gr-commerce-suite'),
            'description' => __('Πληρωμή με μετρητά στον διανομέα κατά την παράδοση της παραγγελίας σας.', 'gr-commerce-suite'),
        ];
    }

    /**
     * Document type for the current request: the submitted checkout form, the update_order_review
     * post_data snapshot, then the value captured in the session.
     */
    public static function documentType(): string
    {
        // Block checkout never writes the classic session, so a stale classic choice must not leak into it.
        if (self::isStoreApiRequest()) {
            return self::storeApiDocumentType() === 'invoice' ? 'invoice' : 'receipt';
        }
        $type = null;
        if (isset($_POST['grcs_document_type'])) {
            $type = $_POST['grcs_document_type'];
        } elseif (isset($_POST['post_data']) && is_string($_POST['post_data'])) {
            wp_parse_str(wp_unslash($_POST['post_data']), $posted);
            $type = $posted['grcs_document_type'] ?? null;
        }
        if ($type === null && function_exists('WC') && WC()->session) {
            $saved = WC()->session->get('grcs_invoice_checkout', []);
            $type = is_array($saved) ? ($saved['document_type'] ?? null) : null;
        }
        return $type === 'invoice' ? 'invoice' : 'receipt';
    }

    private static function isStoreApiRequest(): bool
    {
        if (!defined('REST_REQUEST') || !REST_REQUEST) {
            return false;
        }
        $route = $GLOBALS['wp']->query_vars['rest_route'] ?? $_GET['rest_route'] ?? $_SERVER['REQUEST_URI'] ?? '';
        return is_string($route) && preg_match('#/wc/store/#', $route) === 1;
    }

    /** Block checkout's document-type field: request body first, then the stored value on the draft order. */
    private static function storeApiDocumentType(): ?string
    {
        $raw = (string) apply_filters(
            'grcs_store_api_request_body',
            function_exists('rest_get_server') ? rest_get_server()->get_raw_data() : ''
        );
        $body = $raw !== '' ? json_decode($raw, true) : null;
        $fields = is_array($body) ? ($body['additional_fields'] ?? null) : null;
        if (is_array($fields) && isset($fields['grcs/document-type'])) {
            return is_string($fields['grcs/document-type']) ? $fields['grcs/document-type'] : null;
        }
        $draftId = function_exists('WC') && WC()->session ? WC()->session->get('store_api_draft_order') : null;
        $order = is_numeric($draftId) && function_exists('wc_get_order') ? wc_get_order((int) $draftId) : null;
        if ($order instanceof WC_Order) {
            $value = $order->get_meta('_wc_other/grcs/document-type', true);
            return is_string($value) && $value !== '' ? $value : null;
        }
        return null;
    }

    /** @return array<int|string, string> */
    private function chosenRates(): array
    {
        $chosen = function_exists('WC') && WC()->session ? WC()->session->get('chosen_shipping_methods', []) : [];
        return is_array($chosen) ? array_filter($chosen, 'is_string') : [];
    }

    private function relabel(mixed $id): bool
    {
        return $id === 'cod' && BoxNowCheckoutPicker::isCheckoutRequest() && !is_admin()
            && !(function_exists('is_wc_endpoint_url')
                && (is_wc_endpoint_url('order-pay') || is_wc_endpoint_url('order-received')));
    }

    public function title(mixed $title, mixed $id = null): mixed
    {
        // The order stores this title at checkout, so admin screens and emails keep the courier-specific label.
        return $this->relabel($id) ? self::codLabels(self::usesEnabledBoxNow($this->chosenRates()))['title'] : $title;
    }

    public function description(mixed $description, mixed $id = null): mixed
    {
        if (!$this->relabel($id)) {
            return $description;
        }
        $rates = $this->chosenRates();
        $boxNow = self::usesEnabledBoxNow($rates);
        // Name the handling charge before COD is chosen; it otherwise appears only after the total refreshes.
        $cents = function_exists('WC') && WC()->cart ? ShippingContext::codHandlingCents($rates) : [];
        $sum = array_sum($cents);
        if ($sum <= 0) {
            return self::codLabels($boxNow)['description'];
        }
        $amount = html_entity_decode(wp_strip_all_tags(wc_price($sum / 100)), ENT_QUOTES, 'UTF-8')
            . (isset($cents['taxable']) && wc_tax_enabled() ? ' + ' . __('ΦΠΑ', 'gr-commerce-suite') : '');
        return self::codLabels($boxNow)['description'] . ' ' . sprintf($boxNow
            ? __('Χρέωση Pay on the Go: %s, προστίθεται στο σύνολο.', 'gr-commerce-suite')
            : __('Χρέωση αντικαταβολής: %s, προστίθεται στο σύνολο.', 'gr-commerce-suite'), $amount);
    }

    /** @param array<string, mixed> $gateways
     * @return array<string, mixed>
     */
    public function gateways(array $gateways): array
    {
        if (
            isset($gateways['cod']) && !is_admin() && BoxNowCheckoutPicker::isCheckoutRequest()
            && self::invoiceDisablesCod() && self::documentType() === 'invoice'
        ) {
            unset($gateways['cod']);
        }
        return $gateways;
    }

    /** Names no specific method: bank transfer or card may well be unavailable on this store. */
    public static function invoiceCodMessage(): string
    {
        return __('Η αντικαταβολή δεν είναι διαθέσιμη για παραγγελίες με τιμολόγιο. Επιλέξτε άλλον τρόπο πληρωμής.', 'gr-commerce-suite');
    }

    /** Invoice removed cash on delivery and nothing else is offered: say so and give a real next step. */
    public static function invoiceNoPaymentMessage(): string
    {
        return __('Για παραγγελίες με τιμολόγιο το κατάστημα δεν προσφέρει αυτή τη στιγμή άλλον τρόπο πληρωμής εκτός από την αντικαταβολή. Επιλέξτε «Απόδειξη» για να πληρώσετε με αντικαταβολή, ή επικοινωνήστε με το κατάστημα για να εκδοθεί τιμολόγιο.', 'gr-commerce-suite');
    }

    /**
     * Whether an invoice customer is left any way to pay once cash on delivery is removed: an enabled
     * gateway other than COD, counting bank transfer only when it has account details to show.
     * Reads saved settings, so it also works on admin screens where no cart exists.
     */
    public static function invoiceHasPaymentMethod(): bool
    {
        $wc = function_exists('WC') ? WC() : null;
        $gateways = $wc && method_exists($wc, 'payment_gateways') ? $wc->payment_gateways()->payment_gateways() : [];
        foreach ($gateways as $id => $gateway) {
            if ($id === 'cod' || !is_object($gateway) || !property_exists($gateway, 'enabled') || $gateway->enabled !== 'yes') {
                continue;
            }
            if ($id === 'bacs' && BankTransferAccounts::setupState()['state'] === 'missing') {
                continue;
            }
            return true;
        }
        return false;
    }

    public function validateCheckout(): void
    {
        $payment = $_POST['payment_method'] ?? '';
        if ($payment === 'cod' && self::invoiceDisablesCod() && self::documentType() === 'invoice') {
            wc_add_notice(self::invoiceCodMessage(), 'error');
        }
    }

    public function validateStoreApi(WC_Order $order, mixed $request): void
    {
        if (
            !self::invoiceDisablesCod()
            || (is_object($request) && method_exists($request, 'get_method')
                && in_array($request->get_method(), ['PUT', 'PATCH'], true))
        ) {
            return;
        }
        $fields = is_object($request) && method_exists($request, 'get_param') ? $request->get_param('additional_fields') : [];
        $payment = is_object($request) && method_exists($request, 'get_param') ? $request->get_param('payment_method') : null;
        $payment = is_string($payment) ? $payment : $order->get_payment_method();
        if (is_array($fields) && ($fields['grcs/document-type'] ?? '') === 'invoice' && $payment === 'cod') {
            CheckoutValidation::fail('grcs_invoice_cod', self::invoiceCodMessage());
        }
    }
}
