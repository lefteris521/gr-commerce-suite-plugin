<?php

declare(strict_types=1);

namespace GRCommerceSuite\Frontend;

/** Presentation only: no validation, POST filters, persistence or courier hooks. */
final class CheckoutCharacterWarnings
{
    public function enqueueAssets(): void
    {
        if (!is_checkout() || is_order_received_page() || is_checkout_pay_page() || has_block('woocommerce/checkout')) {
            return;
        }
        wp_enqueue_script('grcs-character-warnings', plugins_url('assets/js/checkout-character-warnings.js', GRCS_PLUGIN_FILE),
            ['jquery', 'wc-checkout'], GRCS_VERSION, true);
        wp_enqueue_style('grcs-character-warnings', plugins_url('assets/css/checkout-character-warnings.css', GRCS_PLUGIN_FILE),
            [], GRCS_VERSION);
        // Native storefront gettext; never use the private GRCS administrator locale.
        wp_localize_script('grcs-character-warnings', 'grcsCharacterWarnings', [
            'message' => __('Please check this field: it appears to mix different alphabets within the same word. If the spelling is correct, you can continue.', 'gr-commerce-suite'),
        ]);
    }
}
