<?php

declare(strict_types=1);

namespace GRCommerceSuite\Frontend;

use GRCommerceSuite\I18n\AdminLocale;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Services\LicenseManager;
use WC_Admin_Settings;
use WC_Order;

/** Greek bank selector for WooCommerce Direct Bank Transfer (bacs), with an OUR-charges acknowledgement. */
final class BankTransferAccounts implements HookSubscriberInterface
{
    public const OPTION_ACCOUNTS = 'grcs_bank_accounts';
    public const OPTION_CUSTOMER_FEES = 'grcs_bank_transfer_customer_fees';
    public const OPTION_FEE_WARNING = 'grcs_bank_transfer_fee_warning';
    public const FIELD_TYPE = 'grcs_bank_accounts';
    public const META_NAME = '_grcs_bank_name';
    public const META_IBAN = '_grcs_bank_iban';
    public const META_SWIFT = '_grcs_bank_swift';
    public const META_BENEFICIARY = '_grcs_bank_beneficiary';
    public const META_FEE_NOTICE = '_grcs_bank_fee_notice';
    public const META_SIMULATED = '_grcs_bank_simulated';
    public const FIELD_ACCOUNT = 'grcs/bank-account';
    public const FIELD_FEE_ACK = 'grcs/bank-fee-ack';

    /** Pre-built rows; the merchant supplies IBAN and beneficiary for each bank they use. */
    private const PRESETS = [
        'piraeus' => ['bank_name' => 'Τράπεζα Πειραιώς', 'swift' => 'PIRBGRAA'],
        'eurobank' => ['bank_name' => 'Eurobank', 'swift' => 'ERBKGRAA'],
        'alpha' => ['bank_name' => 'Alpha Bank', 'swift' => 'CRBAGRAA'],
        'nbg' => ['bank_name' => 'Εθνική Τράπεζα', 'swift' => 'ETHNGRAA'],
        'viva' => ['bank_name' => 'Viva.com', 'swift' => 'VPAYGRAA'],
    ];

    /** Sandbox-only checkout data until the merchant saves real accounts; never persisted. */
    private const DEMO_ACCOUNTS = [
        'piraeus' => ['iban' => 'GR9701701230000001234567890', 'swift' => 'PIRBGRAA'],
        'eurobank' => ['iban' => 'GR2702600450000009876543210', 'swift' => 'ERBKGRAA'],
        'nbg' => ['iban' => 'GR2301100800000004567890123', 'swift' => 'ETHNGRAA'],
    ];
    private const DEMO_BENEFICIARY = 'ΕΛΛΗΝΙΚΟ ΗΛΕΚΤΡΟΝΙΚΟ ΚΑΤΑΣΤΗΜΑ ΙΚΕ';

    private static bool $registered = false;
    private static bool $emailHooksRegistered = false;
    private static bool $blockFieldsRegistered = false;

    public function register(): void
    {
        // Checkout and full runtime can both initialise on one request; the description filter must not stack.
        if (self::$registered) {
            return;
        }
        self::$registered = true;
        add_filter('woocommerce_gateway_description', [$this, 'description'], 30, 2);
        add_filter('woocommerce_available_payment_gateways', [$this, 'gateways'], 130);
        add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('woocommerce_checkout_process', [$this, 'validateCheckout']);
        add_action('woocommerce_checkout_create_order', [$this, 'saveClassic'], 20, 2);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'saveStoreApi'], 20, 2);
        add_action('wp', [$this, 'registerBlockFields']);
        // Register before Store API builds the checkout route's additional_fields schema.
        add_action('rest_api_init', [$this, 'registerBlockFields'], 1);
        add_action('woocommerce_admin_order_data_after_billing_address', [$this, 'renderAdminDetails'], 20);
        add_action('woocommerce_thankyou_bacs', [$this, 'renderThankYou'], 5);
        $this->registerEmailHooks();
    }

    /** Email hooks must also be available outside checkout, including deferred sends. */
    public function registerEmailHooks(): void
    {
        if (self::$emailHooksRegistered) {
            return;
        }
        self::$emailHooksRegistered = true;
        add_action('woocommerce_email_before_order_table', [$this, 'renderEmail'], 15, 4);
        add_filter('woocommerce_bacs_accounts', [$this, 'nativeAccounts'], 10, 2);
    }

    public static function defaultWarning(): string
    {
        return __('⚠️ Τα έξοδα εμβάσματος από διαφορετική τράπεζα επιβαρύνουν εξ ολοκλήρου τον πελάτη. Η παραγγελία εκτελείται μετά την εμφάνιση του πλήρους ποσού στον λογαριασμό μας.', 'gr-commerce-suite');
    }

    /**
     * The settings form used to pre-fill and save the default text, freezing it in one language.
     * A stored copy of the default (source or current translation) therefore still means "use the default".
     */
    public static function isDefaultWarning(string $text): bool
    {
        $text = trim($text);
        return $text === '' || $text === self::defaultWarning()
            || $text === '⚠️ Τα έξοδα εμβάσματος από διαφορετική τράπεζα επιβαρύνουν εξ ολοκλήρου τον πελάτη. Η παραγγελία εκτελείται μετά την εμφάνιση του πλήρους ποσού στον λογαριασμό μας.';
    }

    public static function warning(): string
    {
        $text = trim((string) get_option(self::OPTION_FEE_WARNING, ''));
        return self::isDefaultWarning($text) ? self::defaultWarning() : $text;
    }

    /** Settings API filter (after WooCommerce's own textarea sanitising): store the default as empty so it keeps following the storefront language. */
    public static function sanitizeWarning(mixed $value): string
    {
        $text = is_string($value) ? trim($value) : '';
        return self::isDefaultWarning($text) ? '' : $text;
    }

    public static function customerFees(): bool
    {
        return get_option(self::OPTION_CUSTOMER_FEES, 'yes') === 'yes';
    }

    public static function normalizeIban(string $iban): string
    {
        return strtoupper((string) preg_replace('/[^A-Za-z0-9]/', '', $iban));
    }

    /** ISO 13616 structure and mod-97 checksum; Greek IBANs are exactly 27 characters. */
    public static function validIban(string $iban): bool
    {
        $iban = self::normalizeIban($iban);
        if (preg_match('/^[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}$/D', $iban) !== 1 || (str_starts_with($iban, 'GR') && strlen($iban) !== 27)) {
            return false;
        }
        $digits = '';
        foreach (str_split(substr($iban, 4) . substr($iban, 0, 4)) as $char) {
            $digits .= ctype_alpha($char) ? (string) (ord($char) - 55) : $char;
        }
        $mod = 0;
        foreach (str_split($digits, 7) as $chunk) {
            $mod = (int) ((string) $mod . $chunk) % 97;
        }
        return $mod === 1;
    }

    public static function validSwift(string $swift): bool
    {
        return preg_match('/^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/D', $swift) === 1;
    }

    public static function formatIban(string $iban): string
    {
        return trim(chunk_split(self::normalizeIban($iban), 4, ' '));
    }

    /** Saved rows merged over the pre-built banks, for the settings table.
     * @return array<string, array{enabled: string, bank_name: string, iban: string, swift: string, beneficiary: string}>
     */
    public static function storedRows(): array
    {
        $saved = get_option(self::OPTION_ACCOUNTS, []);
        $saved = is_array($saved) ? $saved : [];
        $rows = [];
        foreach (self::PRESETS as $key => $preset) {
            $row = is_array($saved[$key] ?? null) ? $saved[$key] : [];
            $text = static fn(string $field, string $default = ''): string => is_string($row[$field] ?? null) ? $row[$field] : $default;
            $rows[$key] = ['enabled' => $text('enabled', 'no') === 'yes' ? 'yes' : 'no',
                'bank_name' => $text('bank_name', $preset['bank_name']), 'iban' => $text('iban'),
                'swift' => $text('swift', $preset['swift']), 'beneficiary' => $text('beneficiary')];
        }
        return $rows;
    }

    public static function usesDemoAccounts(): bool
    {
        return get_option(self::OPTION_ACCOUNTS, null) === null && (new LicenseManager())->isSandboxEnabled();
    }

    /** Enabled, complete accounts offered at checkout.
     * @return array<string, array{bank_name: string, iban: string, swift: string, beneficiary: string, simulated: bool}>
     */
    public static function accounts(): array
    {
        if (self::usesDemoAccounts()) {
            $accounts = [];
            foreach (self::DEMO_ACCOUNTS as $key => $demo) {
                $accounts[$key] = ['bank_name' => self::PRESETS[$key]['bank_name'], 'iban' => $demo['iban'],
                    'swift' => $demo['swift'], 'beneficiary' => self::DEMO_BENEFICIARY, 'simulated' => true];
            }
            return $accounts;
        }
        $accounts = [];
        foreach (self::storedRows() as $key => $row) {
            if (
                $row['enabled'] === 'yes' && $row['bank_name'] !== '' && $row['beneficiary'] !== ''
                && self::validIban($row['iban']) && self::validSwift($row['swift'])
            ) {
                $accounts[$key] = ['bank_name' => $row['bank_name'], 'iban' => self::normalizeIban($row['iban']),
                    'swift' => $row['swift'], 'beneficiary' => $row['beneficiary'], 'simulated' => false];
            }
        }
        return $accounts;
    }

    /**
     * Whether customers choosing bank transfer get somewhere to pay: our accounts, WooCommerce's own
     * BACS accounts, or an IBAN the merchant wrote into the gateway description or instructions.
     *
     * @return array{state: 'off'|'demo'|'ready'|'missing', source: ''|'grcs'|'woocommerce'|'instructions', count: int}
     */
    public static function setupState(): array
    {
        $gateway = get_option('woocommerce_bacs_settings', []);
        $gateway = is_array($gateway) ? $gateway : [];
        if (($gateway['enabled'] ?? 'no') !== 'yes') {
            return ['state' => 'off', 'source' => '', 'count' => 0];
        }
        if (self::usesDemoAccounts()) {
            return ['state' => 'demo', 'source' => 'grcs', 'count' => count(self::DEMO_ACCOUNTS)];
        }
        $count = count(self::accounts());
        if ($count > 0) {
            return ['state' => 'ready', 'source' => 'grcs', 'count' => $count];
        }
        $native = get_option('woocommerce_bacs_accounts', []);
        $native = array_filter(is_array($native) ? $native : [], static fn(mixed $row): bool => is_array($row)
            && (trim((string) ($row['iban'] ?? '')) !== '' || trim((string) ($row['account_number'] ?? '')) !== ''));
        if ($native !== []) {
            return ['state' => 'ready', 'source' => 'woocommerce', 'count' => count($native)];
        }
        $text = strtoupper((string) preg_replace('/\s+/', '', ($gateway['description'] ?? '') . ' ' . ($gateway['instructions'] ?? '')));
        if (preg_match_all('/[A-Z]{2}[0-9]{2}[A-Z0-9]{11,30}/', $text, $matches) > 0) {
            foreach ($matches[0] as $candidate) {
                // The pattern is greedy; try every length so trailing text does not hide a valid IBAN.
                for ($length = strlen($candidate); $length >= 15; $length--) {
                    if (self::validIban(substr($candidate, 0, $length))) {
                        return ['state' => 'ready', 'source' => 'instructions', 'count' => 1];
                    }
                }
            }
        }
        return ['state' => 'missing', 'source' => '', 'count' => 0];
    }

    /** WooCommerce settings API renderer for the `grcs_bank_accounts` field type.
     * @param array<string, mixed> $field
     */
    public static function renderSettingsField(array $field): void
    {
        $id = self::OPTION_ACCOUNTS;
        $labels = [
            'enabled' => AdminLocale::__('Ενεργός', 'gr-commerce-suite'),
            'bank_name' => AdminLocale::__('Τράπεζα', 'gr-commerce-suite'),
            'iban' => AdminLocale::__('IBAN', 'gr-commerce-suite'),
            'swift' => AdminLocale::__('SWIFT / BIC', 'gr-commerce-suite'),
            'beneficiary' => AdminLocale::__('Δικαιούχος Λογαριασμού', 'gr-commerce-suite'),
        ];
        // One full-width cell: beside a label column the table left a 27-character IBAN about 70px.
        echo '<tr valign="top" class="grcs-bank-accounts-row"><td colspan="2" class="forminp"><p class="grcs-bank-accounts-label">'
            . esc_html((string) ($field['title'] ?? '')) . '</p>';
        self::renderSetupMessage();
        echo '<div class="grcs-bank-accounts-wrap"><table class="widefat striped grcs-bank-accounts-table"><thead><tr>';
        foreach ($labels as $label) {
            echo '<th scope="col">' . esc_html($label) . '</th>';
        }
        echo '</tr></thead><tbody>';
        foreach (self::storedRows() as $key => $row) {
            $name = static fn(string $column): string => $id . '[' . $key . '][' . $column . ']';
            $cell = static fn(string $column): string => '<td data-label="' . esc_attr($labels[$column]) . '">';
            $label = static fn(string $column): string => ' aria-label="' . esc_attr($labels[$column] . ' — ' . $row['bank_name']) . '"';
            echo '<tr>' . $cell('enabled') . '<input type="checkbox" name="' . esc_attr($name('enabled')) . '" value="yes"' . checked($row['enabled'], 'yes', false)
                . ' aria-label="' . esc_attr(sprintf(AdminLocale::__('Ενεργοποίηση %s', 'gr-commerce-suite'), $row['bank_name'])) . '" /></td>'
                . $cell('bank_name') . '<input type="text" class="regular-text" name="' . esc_attr($name('bank_name')) . '"' . $label('bank_name') . ' value="' . esc_attr($row['bank_name']) . '" maxlength="80" /></td>'
                . $cell('iban') . '<input type="text" class="regular-text" name="' . esc_attr($name('iban')) . '"' . $label('iban') . ' value="' . esc_attr(self::formatIban($row['iban'])) . '" placeholder="GR16 0110 1250 0000 0001 2300 695" maxlength="42" /></td>'
                . $cell('swift') . '<input type="text" name="' . esc_attr($name('swift')) . '"' . $label('swift') . ' value="' . esc_attr($row['swift']) . '" maxlength="11" /></td>'
                . $cell('beneficiary') . '<input type="text" class="regular-text" name="' . esc_attr($name('beneficiary')) . '"' . $label('beneficiary') . ' value="' . esc_attr($row['beneficiary']) . '" placeholder="' . esc_attr($labels['beneficiary']) . '" maxlength="140" /></td></tr>';
        }
        echo '</tbody></table></div><p class="description">' . esc_html((string) ($field['desc'] ?? '')) . '</p>';
        if (self::usesDemoAccounts()) {
            echo '<p class="description"><strong>' . AdminLocale::esc_html__('[SANDBOX] Μέχρι να αποθηκεύσετε λογαριασμούς εδώ, το checkout εμφανίζει 3 δοκιμαστικούς λογαριασμούς (Πειραιώς, Eurobank, Εθνική).', 'gr-commerce-suite') . '</strong></p>';
        }
        echo '</td></tr>';
    }

    /** What customers currently get when they choose bank transfer, with a link to where it is fixed. */
    public static function renderSetupMessage(): void
    {
        $setup = self::setupState();
        $gatewayUrl = admin_url('admin.php?page=wc-settings&tab=checkout&section=bacs');
        [$tone, $message, $link] = match (true) {
            $setup['state'] === 'off' => ['info', AdminLocale::__('Direct bank transfer is turned off in WooCommerce payments, so customers do not see these accounts.', 'gr-commerce-suite'),
                AdminLocale::__('Turn on bank transfer', 'gr-commerce-suite')],
            $setup['state'] === 'missing' => ['warning', AdminLocale::__('Bank transfer is switched on but has no account details, so it is hidden at checkout. Enable at least one account below, or add your details to WooCommerce\'s own bank transfer settings, and it will appear again.', 'gr-commerce-suite'),
                AdminLocale::__('WooCommerce bank transfer settings', 'gr-commerce-suite')],
            $setup['source'] === 'woocommerce' => ['info', AdminLocale::__('Customers currently see the accounts saved in WooCommerce\'s own bank transfer settings. Accounts enabled here replace them at checkout.', 'gr-commerce-suite'),
                AdminLocale::__('WooCommerce bank transfer settings', 'gr-commerce-suite')],
            $setup['source'] === 'instructions' => ['info', AdminLocale::__('Customers currently see the IBAN written in the bank transfer description or instructions. Accounts enabled here add a bank selector with copyable details.', 'gr-commerce-suite'),
                AdminLocale::__('WooCommerce bank transfer settings', 'gr-commerce-suite')],
            default => ['', '', ''],
        };
        if ($message === '') {
            return;
        }
        echo '<div class="notice notice-' . esc_attr($tone) . ' inline grcs-bank-setup" data-grcs-bank-setup="' . esc_attr($setup['state']) . '"><p>'
            . esc_html($message) . ' <a href="' . esc_url($gatewayUrl) . '">' . esc_html($link) . '</a></p></div>';
    }

    /** @param array<string, mixed> $option
     * @return array<string, array<string, string>>
     */
    public static function sanitizeSettingsField(mixed $value, array $option = [], mixed $raw = null): array
    {
        $raw = is_array($raw) ? $raw : [];
        $clean = [];
        foreach (self::PRESETS as $key => $preset) {
            $row = is_array($raw[$key] ?? null) ? $raw[$key] : [];
            $text = static fn(string $field, int $length): string => is_string($row[$field] ?? null)
                ? mb_substr(sanitize_text_field($row[$field]), 0, $length) : '';
            $entry = ['enabled' => ($row['enabled'] ?? '') === 'yes' ? 'yes' : 'no',
                'bank_name' => $text('bank_name', 80) !== '' ? $text('bank_name', 80) : $preset['bank_name'],
                'iban' => self::normalizeIban($text('iban', 42)),
                'swift' => strtoupper((string) preg_replace('/\s+/', '', $text('swift', 11))),
                'beneficiary' => $text('beneficiary', 140)];
            if ($entry['enabled'] === 'yes') {
                $problem = match (true) {
                    !self::validIban($entry['iban']) => AdminLocale::__('μη έγκυρο IBAN', 'gr-commerce-suite'),
                    !self::validSwift($entry['swift']) => AdminLocale::__('μη έγκυρο SWIFT/BIC', 'gr-commerce-suite'),
                    $entry['beneficiary'] === '' => AdminLocale::__('λείπει ο δικαιούχος', 'gr-commerce-suite'),
                    default => null,
                };
                if ($problem !== null) {
                    // An incomplete account must never be shown to customers as a payment destination.
                    $entry['enabled'] = 'no';
                    if (class_exists(WC_Admin_Settings::class)) {
                        WC_Admin_Settings::add_error(sprintf(AdminLocale::__('%1$s: %2$s — ο λογαριασμός απενεργοποιήθηκε.', 'gr-commerce-suite'), $entry['bank_name'], $problem));
                    }
                }
            }
            $clean[$key] = $entry;
        }
        return $clean;
    }

    /** @return array<string, string> */
    private static function postedSelection(): array
    {
        $posted = [];
        if (isset($_POST['post_data']) && is_string($_POST['post_data'])) {
            wp_parse_str(wp_unslash($_POST['post_data']), $posted);
        } else {
            $posted = wp_unslash($_POST);
        }
        $account = $posted['grcs_bank_account'] ?? '';
        $ack = $posted['grcs_bank_fee_ack'] ?? '';
        return ['account' => is_string($account) ? sanitize_key($account) : '', 'ack' => $ack === 'yes' ? 'yes' : ''];
    }

    private static function onCheckoutForm(): bool
    {
        return BoxNowCheckoutPicker::isCheckoutRequest() && !is_admin()
            && !(function_exists('is_wc_endpoint_url') && (is_wc_endpoint_url('order-pay') || is_wc_endpoint_url('order-received')));
    }

    public function description(mixed $description, mixed $id = null): mixed
    {
        if ($id !== 'bacs' || !self::onCheckoutForm()) {
            return $description;
        }
        $accounts = self::accounts();
        if ($accounts === []) {
            return $description;
        }
        $selected = self::postedSelection();
        // With a single account there is nothing to choose: show its details straight away.
        $current = isset($accounts[$selected['account']]) ? $selected['account'] : (count($accounts) === 1 ? (string) array_key_first($accounts) : '');
        // Kept on one line: WooCommerce runs gateway descriptions through wpautop().
        $html = '<div class="grcs-bank-transfer" data-grcs-bank-transfer>';
        if (reset($accounts)['simulated']) {
            $html .= '<p class="grcs-bank-sandbox">' . esc_html__('[SANDBOX] Δοκιμαστικοί λογαριασμοί — μην πραγματοποιήσετε πραγματική κατάθεση.', 'gr-commerce-suite') . '</p>';
        }
        $html .= '<p class="grcs-bank-transfer__intro"><strong>' . esc_html__('Επιλέξτε την τράπεζα στην οποία θα κάνετε την κατάθεση:', 'gr-commerce-suite') . '</strong></p>'
            . '<div class="grcs-bank-options" id="grcs_bank_account_options" tabindex="-1" role="radiogroup" aria-label="' . esc_attr__('Τράπεζα κατάθεσης', 'gr-commerce-suite') . '">';
        foreach ($accounts as $key => $account) {
            $html .= '<label class="grcs-bank-option' . ($key === $current ? ' is-selected' : '') . '"><input type="radio" name="grcs_bank_account" value="'
                . esc_attr($key) . '"' . checked($key, $current, false) . ' /><span>' . esc_html($account['bank_name']) . '</span></label>';
        }
        $html .= '</div>';
        foreach ($accounts as $key => $account) {
            $html .= '<div class="grcs-bank-details" data-bank="' . esc_attr($key) . '"' . ($key === $current ? '' : ' hidden') . '>'
                . '<div class="grcs-bank-row"><span class="grcs-bank-label">' . esc_html__('Δικαιούχος', 'gr-commerce-suite') . '</span><span class="grcs-bank-value">' . esc_html($account['beneficiary']) . '</span></div>'
                . '<div class="grcs-bank-row"><span class="grcs-bank-label">IBAN</span><span class="grcs-bank-value"><code class="grcs-bank-iban">' . esc_html(self::formatIban($account['iban'])) . '</code>'
                . '<button type="button" class="button grcs-copy-iban" data-iban="' . esc_attr($account['iban']) . '" data-copied="' . esc_attr__('Ο IBAN αντιγράφηκε.', 'gr-commerce-suite') . '">' . esc_html__('📋 Αντιγραφή IBAN', 'gr-commerce-suite') . '</button></span></div>'
                . '<div class="grcs-bank-row"><span class="grcs-bank-label">' . esc_html__('SWIFT / BIC', 'gr-commerce-suite') . '</span><span class="grcs-bank-value"><code>' . esc_html($account['swift']) . '</code></span></div>'
                . '</div>';
        }
        if (self::customerFees()) {
            $html .= '<div class="grcs-bank-warning" role="note">' . esc_html(self::warning()) . '</div>'
                . '<label class="grcs-bank-ack"><input type="checkbox" id="grcs_bank_fee_ack" name="grcs_bank_fee_ack" value="yes"' . checked($selected['ack'], 'yes', false) . ' /> '
                . esc_html__('Έχω ενημερωθεί ότι τυχόν έξοδα εμβάσματος από άλλη τράπεζα βαρύνουν εμένα (εντολή OUR).', 'gr-commerce-suite') . ' <abbr class="required" title="' . esc_attr__('required', 'woocommerce') . '">*</abbr></label>';
        }
        return (is_string($description) ? $description : '') . $html . '</div>';
    }

    /**
     * A bank transfer with no account anywhere (ours, WooCommerce's, or an IBAN in its texts)
     * leaves the customer nothing to pay into, so it is not offered until the merchant adds one.
     *
     * @param array<string, mixed> $gateways
     * @return array<string, mixed>
     */
    public function gateways(array $gateways): array
    {
        if (!isset($gateways['bacs']) || (function_exists('is_admin') && is_admin() && !(function_exists('wp_doing_ajax') && wp_doing_ajax()))) {
            return $gateways;
        }
        if (self::setupState()['state'] === 'missing') {
            unset($gateways['bacs']);
        }
        return $gateways;
    }

    public function enqueueAssets(): void
    {
        if (!BoxNowCheckoutPicker::isCheckoutRequest()) {
            return;
        }
        $url = plugins_url('', GRCS_PLUGIN_FILE);
        wp_enqueue_style('grcs-bank-transfer', $url . '/assets/css/bank-transfer-checkout.css', [], GRCS_VERSION);
        wp_enqueue_script('grcs-bank-transfer', $url . '/assets/js/bank-transfer-checkout.js', ['jquery'], GRCS_VERSION, true);
        wp_localize_script('grcs-bank-transfer', 'grcsBankTransfer', [
            'copied' => __('✓ Αντιγράφηκε', 'gr-commerce-suite'),
            'copyFailed' => __('Η αντιγραφή δεν έγινε — επιλέχθηκε το κείμενο για να το αντιγράψετε.', 'gr-commerce-suite'),
            'selected' => __('Επιλέχθηκε', 'gr-commerce-suite'),
        ]);
    }

    public function validateCheckout(): void
    {
        if (($_POST['payment_method'] ?? '') !== 'bacs') {
            return;
        }
        $accounts = self::accounts();
        if ($accounts === []) {
            return;
        }
        $selected = self::postedSelection();
        // The id turns WooCommerce's top notice into a link to the control, which sits far below near the payment box.
        if (!isset($accounts[$selected['account']])) {
            wc_add_notice(__('Παρακαλώ επιλέξτε την τράπεζα στην οποία θα πραγματοποιήσετε την κατάθεση.', 'gr-commerce-suite'), 'error', ['id' => 'grcs_bank_account_options']);
        }
        if (self::customerFees() && $selected['ack'] !== 'yes') {
            wc_add_notice(__('Παρακαλώ επιβεβαιώστε ότι τα έξοδα εμβάσματος από διαφορετική τράπεζα επιβαρύνουν εσάς.', 'gr-commerce-suite'), 'error', ['id' => 'grcs_bank_fee_ack']);
        }
    }

    /** @param array<string, mixed> $data */
    public function saveClassic(WC_Order $order, array $data = []): void
    {
        $payment = is_string($data['payment_method'] ?? null) ? $data['payment_method'] : $order->get_payment_method();
        $this->snapshot($order, $payment === 'bacs' ? self::accounts() : [], self::postedSelection()['account']);
    }

    /**
     * Block checkout: the bank and the OUR-charges acknowledgement arrive as native Additional Checkout Fields.
     * The schema conditions below only drive the UI; this is the authoritative check.
     */
    public function saveStoreApi(WC_Order $order, mixed $request): void
    {
        // Draft updates occur while the shopper is still choosing a payment method.
        if (is_object($request) && method_exists($request, 'get_method') && in_array($request->get_method(), ['PUT', 'PATCH'], true)) {
            return;
        }
        $fields = is_object($request) && method_exists($request, 'get_param') ? $request->get_param('additional_fields') : [];
        $fields = is_array($fields) ? $fields : [];
        $accounts = $order->get_payment_method() === 'bacs' ? self::accounts() : [];
        $account = is_string($fields[self::FIELD_ACCOUNT] ?? null) ? sanitize_key($fields[self::FIELD_ACCOUNT]) : '';
        if (count($accounts) === 1 && !isset($accounts[$account])) {
            // Same as the classic form, which shows a single account's details without asking.
            $account = (string) array_key_first($accounts);
        }
        if ($accounts !== []) {
            if (!isset($accounts[$account])) {
                \GRCommerceSuite\Support\CheckoutValidation::fail('grcs_bank_account_required', __('Παρακαλώ επιλέξτε την τράπεζα στην οποία θα πραγματοποιήσετε την κατάθεση.', 'gr-commerce-suite'));
            }
            if (self::customerFees() && !in_array($fields[self::FIELD_FEE_ACK] ?? null, [true, 1, '1', 'true', 'yes'], true)) {
                \GRCommerceSuite\Support\CheckoutValidation::fail('grcs_bank_fee_ack_required', __('Παρακαλώ επιβεβαιώστε ότι τα έξοδα εμβάσματος από διαφορετική τράπεζα επιβαρύνουν εσάς.', 'gr-commerce-suite'));
            }
        }
        $this->snapshot($order, $accounts, $account);
    }

    public function registerBlockFields(): void
    {
        if (
            self::$blockFieldsRegistered || !BoxNowCheckoutPicker::isCheckoutRequest()
            || !function_exists('woocommerce_register_additional_checkout_field')
        ) {
            return;
        }
        $accounts = self::accounts();
        if ($accounts === []) {
            return;
        }
        self::$blockFieldsRegistered = true;
        // Conditional required/hidden need WooCommerce 9.9+; older versions rely on saveStoreApi() alone.
        $conditions = static fn(): array => defined('WC_VERSION') && version_compare(WC_VERSION, '9.9', '>=')
            ? ['required' => self::paymentCondition(true), 'hidden' => self::paymentCondition(false)] : [];
        $options = [];
        foreach ($accounts as $key => $account) {
            $options[] = ['value' => (string) $key, 'label' => $account['bank_name']];
        }
        woocommerce_register_additional_checkout_field([
            'id' => self::FIELD_ACCOUNT, 'location' => 'order', 'type' => 'select',
            'label' => __('Τράπεζα κατάθεσης', 'gr-commerce-suite'), 'options' => $options,
        ] + $conditions());
        if (self::customerFees()) {
            woocommerce_register_additional_checkout_field([
                'id' => self::FIELD_FEE_ACK, 'location' => 'order', 'type' => 'checkbox',
                'label' => __('Έχω ενημερωθεί ότι τυχόν έξοδα εμβάσματος από άλλη τράπεζα βαρύνουν εμένα (εντολή OUR).', 'gr-commerce-suite'),
            ] + $conditions());
        }
    }

    /** @return array<string, mixed> JSON-schema condition on the chosen payment method. */
    private static function paymentCondition(bool $isBacs): array
    {
        if ($isBacs) {
            return ['checkout' => ['properties' => ['payment_method' => ['const' => 'bacs']], 'required' => ['payment_method']]];
        }
        return ['checkout' => ['properties' => ['payment_method' => ['not' => ['const' => 'bacs']]]]];
    }

    /**
     * @param array<string, array{bank_name: string, iban: string, swift: string, beneficiary: string, simulated: bool}> $accounts
     */
    private function snapshot(WC_Order $order, array $accounts, string $key): void
    {
        if (!isset($accounts[$key])) {
            foreach ([self::META_NAME, self::META_IBAN, self::META_SWIFT, self::META_BENEFICIARY, self::META_FEE_NOTICE, self::META_SIMULATED] as $meta) {
                $order->delete_meta_data($meta);
            }
            return;
        }
        // Snapshot the account so later settings changes never alter what the customer was told.
        $account = $accounts[$key];
        $order->update_meta_data(self::META_NAME, $account['bank_name']);
        $order->update_meta_data(self::META_IBAN, $account['iban']);
        $order->update_meta_data(self::META_SWIFT, $account['swift']);
        $order->update_meta_data(self::META_BENEFICIARY, $account['beneficiary']);
        if (self::customerFees()) {
            $order->update_meta_data(self::META_FEE_NOTICE, self::warning());
        } else {
            $order->delete_meta_data(self::META_FEE_NOTICE);
        }
        if ($account['simulated']) {
            $order->update_meta_data(self::META_SIMULATED, 'yes');
        } else {
            $order->delete_meta_data(self::META_SIMULATED);
        }
        // WooCommerce saves this WC_Order immediately after the create-order / update-order hook.
    }

    /** @return array{bank_name: string, iban: string, swift: string, beneficiary: string, fee_notice: string, simulated: bool}|null */
    public static function orderAccount(WC_Order $order): ?array
    {
        $iban = (string) $order->get_meta(self::META_IBAN, true);
        if ($iban === '') {
            return null;
        }
        return ['bank_name' => (string) $order->get_meta(self::META_NAME, true), 'iban' => $iban,
            'swift' => (string) $order->get_meta(self::META_SWIFT, true),
            'beneficiary' => (string) $order->get_meta(self::META_BENEFICIARY, true),
            'fee_notice' => (string) $order->get_meta(self::META_FEE_NOTICE, true),
            'simulated' => $order->get_meta(self::META_SIMULATED, true) === 'yes'];
    }

    /** @param array{bank_name: string, iban: string, swift: string, beneficiary: string, fee_notice: string, simulated: bool} $account
     * @return array<string, string>
     */
    private static function lines(array $account, WC_Order $order, bool $admin = false): array
    {
        $translate = $admin ? [AdminLocale::class, '__'] : '__';
        $lines = [
            $translate('Τράπεζα', 'gr-commerce-suite') => ($account['simulated'] ? '[SANDBOX] ' : '') . $account['bank_name'],
            $translate('Δικαιούχος', 'gr-commerce-suite') => $account['beneficiary'],
            'IBAN' => self::formatIban($account['iban']),
            $translate('SWIFT / BIC', 'gr-commerce-suite') => $account['swift'],
        ];
        if (!$admin) {
            // The customer needs the amount beside the account, not only in the order summary above it.
            $lines[__('Ποσό', 'gr-commerce-suite')] = self::amount($order);
        }
        $lines[$translate('Αιτιολογία κατάθεσης', 'gr-commerce-suite')] = self::reference($order, $admin);
        return $lines;
    }

    /** Also shown in Customer 360°, so staff can match a customer's "I paid" call against the bank statement. */
    public static function reference(WC_Order $order, bool $admin = false): string
    {
        $translate = $admin ? [AdminLocale::class, '__'] : '__';
        return sprintf($translate('Παραγγελία #%s', 'gr-commerce-suite'), $order->get_order_number());
    }

    private static function amount(WC_Order $order): string
    {
        return html_entity_decode(wp_strip_all_tags(wc_price((float) $order->get_total(), ['currency' => $order->get_currency()])), ENT_QUOTES, 'UTF-8');
    }

    public function renderAdminDetails(WC_Order $order): void
    {
        $account = self::orderAccount($order);
        if ($account === null) {
            return;
        }
        echo '<div class="grcs-bank-admin"><h4>' . AdminLocale::esc_html__('Τραπεζική Κατάθεση', 'gr-commerce-suite') . '</h4>';
        foreach (self::lines($account, $order, true) as $label => $value) {
            echo '<p><strong>' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
        }
        echo '</div>';
    }

    public function renderThankYou(mixed $orderId): void
    {
        $order = wc_get_order(is_numeric($orderId) ? (int) $orderId : 0);
        $account = $order instanceof WC_Order ? self::orderAccount($order) : null;
        if ($account === null) {
            return;
        }
        echo '<section class="grcs-bank-thankyou"><h2>' . esc_html__('Στοιχεία Τραπεζικής Κατάθεσης', 'gr-commerce-suite') . '</h2>';
        $reference = self::reference($order);
        if ($order->has_status(['on-hold', 'pending'])) {
            // Once the merchant marks the order paid, the details stay as a record without asking for payment again.
            echo '<p class="grcs-bank-thankyou__lead">' . esc_html(sprintf(
                __('Για να ολοκληρωθεί η παραγγελία σας, μεταφέρετε %1$s στον παρακάτω λογαριασμό με αιτιολογία «%2$s».', 'gr-commerce-suite'),
                self::amount($order),
                $reference
            )) . '</p>';
        }
        $copy = [
            'IBAN' => [$account['iban'], __('Αντιγραφή IBAN', 'gr-commerce-suite'), __('Ο IBAN αντιγράφηκε.', 'gr-commerce-suite')],
            $reference => [$reference, __('Αντιγραφή αιτιολογίας', 'gr-commerce-suite'), __('Η αιτιολογία αντιγράφηκε.', 'gr-commerce-suite')],
        ];
        echo '<table class="shop_table grcs-bank-thankyou__table"><tbody>';
        foreach (self::lines($account, $order) as $label => $value) {
            $button = $copy[$label] ?? $copy[$value] ?? null;
            echo '<tr><th scope="row">' . esc_html($label) . '</th><td><span class="grcs-bank-value"><span class="grcs-copy-source">' . esc_html($value) . '</span>';
            if ($button !== null) {
                echo '<button type="button" class="button grcs-copy" data-copy="' . esc_attr($button[0]) . '" data-copied="' . esc_attr($button[2]) . '">'
                    . esc_html($button[1]) . '</button>';
            }
            echo '</span></td></tr>';
        }
        echo '</tbody></table>';
        if ($account['fee_notice'] !== '') {
            echo '<div class="grcs-bank-warning" role="note">' . esc_html($account['fee_notice']) . '</div>';
        }
        echo '</section>';
    }

    public function renderEmail(mixed $order, bool $sentToAdmin = false, bool $plainText = false, mixed $email = null): void
    {
        if (!$order instanceof WC_Order || $sentToAdmin || !$order->has_status(['on-hold', 'pending'])) {
            return;
        }
        $account = self::orderAccount($order);
        if ($account === null) {
            return;
        }
        $title = __('Στοιχεία Τραπεζικής Κατάθεσης', 'gr-commerce-suite');
        if ($plainText) {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text email, not HTML.
            echo "\n" . $title . "\n";
            foreach (self::lines($account, $order) as $label => $value) {
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text email, not HTML.
                echo $label . ': ' . $value . "\n";
            }
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text email, not HTML.
            echo ($account['fee_notice'] !== '' ? "\n" . $account['fee_notice'] . "\n" : '') . "\n";
            return;
        }
        echo '<div class="grcs-email-bank" style="margin:0 0 24px;padding:16px;border:1px solid #dbe3ec;border-radius:8px;background:#f8fafc;">'
            . '<h2 style="margin:0 0 12px;">' . esc_html($title) . '</h2>';
        foreach (self::lines($account, $order) as $label => $value) {
            echo '<p style="margin:0 0 8px;"><strong>' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
        }
        if ($account['fee_notice'] !== '') {
            echo '<p style="margin:12px 0 0;padding:12px;border:1px solid #f5c26b;border-radius:6px;background:#fff8e6;color:#7a4a00;">'
                . esc_html($account['fee_notice']) . '</p>';
        }
        echo '</div>';
    }

    /** Hide WooCommerce's own account list when the customer already chose one of ours.
     * @return mixed
     */
    public function nativeAccounts(mixed $accounts, mixed $orderId = null): mixed
    {
        $order = is_numeric($orderId) && (int) $orderId > 0 ? wc_get_order((int) $orderId) : null;
        return $order instanceof WC_Order && self::orderAccount($order) !== null ? [] : $accounts;
    }
}
