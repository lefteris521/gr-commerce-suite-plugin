<?php

declare(strict_types=1);

namespace GRCommerceSuite\Frontend;

use GRCommerceSuite\I18n\AdminLocale;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Database\Repositories\VoucherRepository;
use GRCommerceSuite\Domain\Voucher\VoucherState;
use GRCommerceSuite\Services\AadeRegistryLookup;
use GRCommerceSuite\Services\CodBlacklistService;
use GRCommerceSuite\Http\WpHttpClient;
use GRCommerceSuite\Security\CredentialVault;
use GRCommerceSuite\Support\Lock;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Services\TrackingService;
use RuntimeException;
use WC_Order;
use WP_Error;

/** Receipt/invoice capture using WooCommerce CRUD and native Additional Checkout Fields. */
final class GreekInvoiceCheckout implements HookSubscriberInterface
{
    public const OPTION_ENABLED = 'grcs_invoice_enabled';
    public const OPTION_USERNAME = 'grcs_aade_username';
    public const OPTION_PASSWORD = 'grcs_aade_password';
    public const OPTION_STORE_AFM = 'grcs_aade_store_afm';
    public const NONCE_ACTION = 'grcs_invoice_lookup';
    private bool $blockFieldsRegistered = false;
    private bool $emailHooksRegistered = false;
    /** The instance that owns the checkout hooks; both bootstrap paths may call register(). */
    private static ?self $registeredBy = null;

    public function __construct(
        private readonly ?AadeRegistryLookup $lookup = null,
        private readonly ?VoucherRepository $vouchers = null,
    ) {
    }

    public function register(): void
    {
        // The runtime subscriber and the lightweight checkout bootstrap can both reach here with
        // separate instances. Keep the WordPress hook table as the shared guard.
        if (
            self::$registeredBy !== null
            && has_action('woocommerce_after_checkout_validation', [self::$registeredBy, 'validateClassic']) !== false
        ) {
            return;
        }
        self::$registeredBy = $this;
        add_action('woocommerce_review_order_before_payment', [$this, 'render'], 10);
        // Classic process_checkout() converts these WP_Error entries to notices, including
        // their field IDs. Also emitting at checkout_process would duplicate every error.
        add_action('woocommerce_after_checkout_validation', [$this, 'validateClassic'], 10, 2);
        add_action('woocommerce_checkout_update_order_review', [$this, 'captureClassic']);
        // No order-review fragment: the fieldset renders outside #payment, so WooCommerce never wipes it, and
        // replacing it on every update_checkout discarded text typed while the request was in flight.
        add_action('woocommerce_checkout_create_order', [$this, 'saveClassic'], 15, 2);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'saveStoreApi'], 15, 2);
        add_action('wp', [$this, 'registerBlockFields']);
        add_action('rest_api_init', [$this, 'registerBlockFields'], 1);
        add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('wp_ajax_grcs_invoice_lookup', [$this, 'handleLookup']);
        add_action('wp_ajax_nopriv_grcs_invoice_lookup', [$this, 'handleLookup']);
        add_action('wp_ajax_grcs_lookup_afm', [$this, 'handleLookup']);
        add_action('wp_ajax_nopriv_grcs_lookup_afm', [$this, 'handleLookup']);
        add_action('woocommerce_admin_order_data_after_billing_address', [$this, 'renderAdminDetails']);
        add_action('woocommerce_order_details_after_order_table', [$this, 'renderDocumentDetails']);
    }

    public function enabled(): bool
    {
        return get_option(self::OPTION_ENABLED, 'yes') === 'yes';
    }

    /** Email hooks must also be available outside checkout, including deferred sends. */
    public function registerEmailHooks(): void
    {
        if ($this->emailHooksRegistered) {
            return;
        }
        $this->emailHooksRegistered = true;
        add_action('woocommerce_email_order_meta', [$this, 'renderEmailInvoice'], 10, 4);
        add_action('woocommerce_email_after_order_table', [$this, 'renderEmailTracking'], 20, 4);
    }

    public function renderEmailInvoice(WC_Order $order, bool $sentToAdmin = false, bool $plainText = false, mixed $email = null): void
    {
        if ($order->get_meta('_grcs_document_type', true) !== 'invoice') {
            return;
        }
        $company = (string) $order->get_meta('_grcs_company_name', true);
        $lines = [
            __('Τύπος Παραστατικού', 'gr-commerce-suite') => __('Τιμολόγιο Πώλησης', 'gr-commerce-suite'),
            __('ΑΦΜ', 'gr-commerce-suite') => (string) $order->get_meta('_grcs_vat_number', true),
            __('ΔΟΥ', 'gr-commerce-suite') => (string) $order->get_meta('_grcs_doy', true),
            __('Επωνυμία', 'gr-commerce-suite') => $company !== '' ? $company : $order->get_billing_company(),
            __('Δραστηριότητα', 'gr-commerce-suite') => (string) $order->get_meta('_grcs_profession', true),
        ];
        if ($plainText) {
            echo "\n";
            foreach ($lines as $label => $value) {
                // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text email, not HTML.
                echo $label . ': ' . $value . "\n";
            }
            echo "\n";
            return;
        }
        echo '<div class="grcs-email-invoice" style="margin:20px 0;padding:16px;border:1px solid #dbe3ec;border-radius:8px;background:#f8fafc;">';
        foreach ($lines as $label => $value) {
            echo '<p style="margin:0 0 8px;"><strong>' . esc_html($label) . ':</strong> ' . esc_html($value) . '</p>';
        }
        echo '</div>';
    }

    public function renderEmailTracking(WC_Order $order, bool $sentToAdmin = false, bool $plainText = false, mixed $email = null): void
    {
        // Support both the public metadata names and the existing voucher service snapshot.
        $voucher = (string) $order->get_meta('_grcs_voucher_no', true);
        $courier = (string) $order->get_meta('_grcs_courier', true);
        if ($voucher === '') {
            $voucher = (string) $order->get_meta('_grcs_last_voucher_no', true);
            $courier = (string) $order->get_meta('_grcs_last_courier', true);
        }
        if (trim($courier) === '') {
            // VoucherLockService writes `_grcs_voucher_no` with `_grcs_last_courier`; `_grcs_courier` is never saved.
            $courier = (string) $order->get_meta('_grcs_last_courier', true);
        }
        $courier = strtolower(trim($courier));
        if (
            $voucher === '' || !in_array($courier, ['acs', 'boxnow'], true)
            || $this->voucherCancelled(CourierSlug::from($courier), $voucher)
        ) {
            return;
        }
        $url = TrackingService::publicUrl($voucher, CourierSlug::from($courier));
        $message = sprintf(
            __('Αποστολή με %1$s — Αριθμός Αποστολής (Voucher): %2$s', 'gr-commerce-suite'),
            $courier === 'acs' ? 'ACS' : 'BOX NOW',
            $voucher
        );
        if ($plainText) {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text email, not HTML.
            echo "\n" . $message . ($url !== '' ? "\n" . $url : '') . "\n\n";
            return;
        }
        echo '<div class="grcs-email-tracking" style="margin:20px 0;padding:16px;border:1px solid #bfdbfe;border-radius:8px;background:#eff6ff;">'
            . '<p style="margin:0 0 8px;">' . esc_html($message) . '</p>';
        if ($url !== '') {
            echo '<a href="' . esc_url($url) . '">' . esc_html__('Παρακολούθηση αποστολής', 'gr-commerce-suite') . '</a>';
        }
        echo '</div>';
    }

    /** Cancellation clears the order snapshot; the table also guards snapshots that outlived their voucher. */
    private function voucherCancelled(CourierSlug $courier, string $voucher): bool
    {
        try {
            $row = ($this->vouchers ?? VoucherRepository::fromGlobals())->findByVoucherNo($courier, $voucher);
        } catch (RuntimeException) {
            return false;
        }
        return is_array($row) && ($row['state'] ?? '') === VoucherState::Cancelled->value;
    }

    /** Official checksum: weights 256..2, remainder modulo 11 then modulo 10. */
    public static function validVat(string $vat): bool
    {
        if (preg_match('/^[0-9]{9}$/D', $vat) !== 1 || $vat === '000000000') {
            return false;
        }
        $sum = 0;
        for ($i = 0; $i < 8; ++$i) {
            $sum += (int) $vat[$i] * (2 ** (8 - $i));
        }
        return ($sum % 11) % 10 === (int) $vat[8];
    }

    /** @return array<string, string> */
    public static function labels(): array
    {
        return ['vat_number' => __('ΑΦΜ (Greek VAT Number)', 'gr-commerce-suite'),
            'company_name' => __('Επωνυμία Εταιρείας (Company Name)', 'gr-commerce-suite'),
            'doy' => __('ΔΟΥ (Tax Office)', 'gr-commerce-suite'),
            'profession' => __('Επάγγελμα / Δραστηριότητα (Business Activity)', 'gr-commerce-suite')];
    }

    public function render(mixed $checkout = null): void
    {
        if (!BoxNowCheckoutPicker::isCheckoutRequest() || !$this->enabled()) {
            return;
        }
        if ($checkout === null && is_callable([WC(), 'checkout'])) {
            $checkout = WC()->checkout();
        }
        $saved = WC()->session ? WC()->session->get('grcs_invoice_checkout', []) : [];
        $value = static fn(string $key): string => is_array($saved) && is_string($saved[$key] ?? null)
            ? $saved[$key] : (is_object($checkout) && method_exists($checkout, 'get_value')
                ? (string) $checkout->get_value('grcs_' . $key) : '');
        $invoice = $value('document_type') === 'invoice';
        echo '<fieldset id="grcs-invoice-checkout" class="grcs-checkout-wrap grcs-invoice"><legend>' . esc_html__('Απόδειξη ή Τιμολόγιο', 'gr-commerce-suite') . '</legend><div class="grcs-document-toggle">';
        foreach (['receipt' => __('Απόδειξη Λιανικής', 'gr-commerce-suite'), 'invoice' => __('Τιμολόγιο', 'gr-commerce-suite')] as $type => $label) {
            echo '<label><input type="radio" name="grcs_document_type" value="' . esc_attr($type) . '"'
                . (($invoice ? 'invoice' : 'receipt') === $type ? ' checked' : '') . ' required /> ' . esc_html($label) . '</label>';
        }
        echo '</div><div class="grcs-invoice-fields">';
        foreach (self::labels() as $key => $label) {
            echo '<p id="grcs_' . esc_attr($key) . '_field" class="form-row form-row-wide' . ($invoice ? ' validate-required' : '') . '"><label for="grcs_' . esc_attr($key) . '">' . esc_html($label)
                . '</label><input class="input-text" id="grcs_' . esc_attr($key) . '" name="grcs_' . esc_attr($key)
                . '" value="' . esc_attr($value($key)) . '" aria-required="' . ($invoice ? 'true' : 'false') . '"' . ($invoice ? ' required' : '')
                . ($key === 'vat_number' ? ' inputmode="numeric" maxlength="9" pattern="[0-9]{9}"' : ' maxlength="200"') . ' /></p>';
        }
        echo '</div></fieldset>';
    }

    public function registerBlockFields(): void
    {
        if (
            $this->blockFieldsRegistered || !BoxNowCheckoutPicker::isCheckoutRequest()
            || !$this->enabled() || !function_exists('woocommerce_register_additional_checkout_field')
        ) {
            return;
        }
        $this->blockFieldsRegistered = true;
        woocommerce_register_additional_checkout_field([
            'id' => 'grcs/document-type', 'location' => 'order', 'type' => 'select',
            'label' => __('Απόδειξη ή Τιμολόγιο', 'gr-commerce-suite'),
            'required' => true,
            'options' => [['value' => 'receipt', 'label' => __('Απόδειξη Λιανικής', 'gr-commerce-suite')],
                ['value' => 'invoice', 'label' => __('Τιμολόγιο', 'gr-commerce-suite')]],
        ]);
        foreach (self::labels() as $key => $label) {
            $field = ['id' => 'grcs/' . str_replace('_', '-', $key), 'location' => 'order', 'type' => 'text', 'label' => $label];
            if (defined('WC_VERSION') && version_compare(WC_VERSION, '9.9', '>=')) {
                $field['required'] = self::invoiceCondition('invoice');
                $field['hidden'] = self::invoiceCondition('receipt', true);
            }
            if ($key === 'vat_number') {
                $field['attributes'] = ['maxLength' => 9, 'pattern' => '[0-9]{9}'];
            }
            woocommerce_register_additional_checkout_field($field);
        }
    }

    /** @return array<string, mixed> */
    private static function invoiceCondition(string $value, bool $includeMissing = false): array
    {
        $properties = ['properties' => ['grcs/document-type' => ['const' => $value]]];
        if (!$includeMissing) {
            $properties['required'] = ['grcs/document-type'];
        }
        return ['checkout' => ['properties' => ['additional_fields' => $properties]]];
    }

    /** @param array<array-key, mixed> $data
     * @return array<string, string>
     */
    public static function clean(array $data): array
    {
        $clean = [];
        foreach (array_merge(['document_type'], array_keys(self::labels())) as $key) {
            $value = $data['grcs_' . $key] ?? '';
            $clean[$key] = is_string($value) ? mb_substr(sanitize_text_field($value), 0, 200) : '';
        }
        if (isset($data['grcs_document_type']) && !is_string($data['grcs_document_type'])) {
            $clean['document_type'] = 'invalid';
        }
        return $clean;
    }

    /** @param array<string, string> $data
     * @return list<string>
     */
    public static function errors(array $data): array
    {
        return array_values(self::fieldErrors($data));
    }

    /** @param array<string, string> $data
     * @return array<string, string> Field IDs => messages, shared by both classic validation hooks.
     */
    private static function fieldErrors(array $data): array
    {
        if (!in_array($data['document_type'], ['receipt', 'invoice'], true)) {
            return ['grcs_document_type' => __('Choose Απόδειξη Λιανικής or Τιμολόγιο.', 'gr-commerce-suite')];
        }
        if ($data['document_type'] !== 'invoice') {
            return [];
        }
        $errors = [];
        if (!self::validVat($data['vat_number'])) {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure(
                'INVOICE',
                'validate_afm',
                ['vat_number' => $data['vat_number']],
                null,
                false
            );
            $errors['grcs_vat_number'] = __('Enter a valid nine-digit Greek ΑΦΜ.', 'gr-commerce-suite');
        }
        foreach (self::labels() as $key => $label) {
            if ($key !== 'vat_number' && $data[$key] === '') {
                (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('INVOICE', 'validate_invoice', [$key => $data[$key]]);
                $errors['grcs_' . $key] = sprintf(__('Required invoice field: %s', 'gr-commerce-suite'), $label);
            }
        }
        return $errors;
    }

    public function captureClassic(string $posted): void
    {
        if ($this->enabled() && WC()->session) {
            wp_parse_str($posted, $data);
            WC()->session->set('grcs_invoice_checkout', self::clean($data));
        }
    }

    /** @param array<string, string> $fragments
     * @return array<string, string>
     */
    public function fragments(array $fragments): array
    {
        if ($this->enabled()) {
            ob_start();
            $this->render();
            $fragments['#grcs-invoice-checkout'] = (string) ob_get_clean();
        }
        return $fragments;
    }

    public function validateCheckout(): void
    {
        if ($this->enabled()) {
            foreach (self::fieldErrors(self::clean(wp_unslash($_POST))) as $id => $message) {
                wc_add_notice($message, 'error', ['id' => $id]);
            }
        }
    }

    /** @param array<string, mixed> $data */
    public function validateClassic(array $data, WP_Error $errors): void
    {
        if (!$this->enabled()) {
            return;
        }
        // Custom classic inputs are not necessarily in WooCommerce's filtered posted-data array.
        $clean = self::clean(array_merge($data, wp_unslash($_POST)));
        foreach (self::fieldErrors($clean) as $id => $message) {
            $errors->add($id . '_validation', $message, ['id' => $id]);
        }
    }

    /** @param array<string, mixed> $data */
    public function saveClassic(WC_Order $order, array $data = []): void
    {
        if ($this->enabled()) {
            $this->persist($order, self::clean(array_merge($data, wp_unslash($_POST))));
        }
    }

    public function saveStoreApi(WC_Order $order, mixed $request): void
    {
        if (!$this->enabled()) {
            return;
        }
        // Draft updates occur while the shopper is still entering company information.
        if (
            is_object($request) && method_exists($request, 'get_method')
            && in_array($request->get_method(), ['PUT', 'PATCH'], true)
        ) {
            return;
        }
        $fields = is_object($request) && method_exists($request, 'get_param') ? $request->get_param('additional_fields') : [];
        $data = [];
        foreach (array_merge(['document_type'], array_keys(self::labels())) as $key) {
            $data['grcs_' . $key] = is_array($fields) ? ($fields['grcs/' . str_replace('_', '-', $key)] ?? '') : '';
        }
        if (!is_array($fields) || !in_array($fields['grcs/document-type'] ?? null, ['receipt', 'invoice'], true)) {
            \GRCommerceSuite\Support\CheckoutValidation::fail('grcs_document_required', __('Choose Retail Receipt or Invoice before placing your order.', 'gr-commerce-suite'));
        }
        $this->persist($order, self::clean($data));
    }

    public function renderDocumentDetails(WC_Order $order): void
    {
        $type = $order->get_meta('_grcs_document_type', true);
        if (!in_array($type, ['receipt', 'invoice'], true)) {
            return;
        }
        echo '<p><strong>' . esc_html__('Document type', 'gr-commerce-suite') . ':</strong> '
            . esc_html($type === 'invoice' ? __('Invoice', 'gr-commerce-suite') : __('Retail Receipt', 'gr-commerce-suite')) . '</p>';
        if ($type === 'invoice') {
            $this->renderAdminDetails($order, false);
        }
    }

    /** @param array<string, string> $data */
    private function persist(WC_Order $order, array $data): void
    {
        $errors = self::errors($data);
        if ($errors !== []) {
            \GRCommerceSuite\Support\CheckoutValidation::fail('grcs_invoice_invalid', implode(' ', $errors));
        }
        $order->update_meta_data('_grcs_document_type', $data['document_type']);
        foreach (self::labels() as $key => $label) {
            if ($data['document_type'] === 'invoice') {
                $order->update_meta_data('_grcs_' . $key, $data[$key]);
            } else {
                $order->delete_meta_data('_grcs_' . $key);
            }
        }
        if ($data['document_type'] === 'invoice' && $order->get_billing_company() === '') {
            $order->set_billing_company($data['company_name']);
        }
        // Both checkout pipelines save the WC_Order after these hooks.
    }

    public function renderAdminDetails(WC_Order $order, bool $admin = true): void
    {
        if ($order->get_meta('_grcs_document_type', true) !== 'invoice') {
            return;
        }
        $translate = $admin ? [AdminLocale::class, '__'] : '__';
        echo '<div class="grcs-invoice-admin"><h4>' . esc_html($translate('Τιμολόγιο', 'gr-commerce-suite')) . '</h4>';
        foreach ([
            'vat_number' => $translate('AFM (Greek VAT Number)', 'gr-commerce-suite'),
            'company_name' => $translate('Company Name', 'gr-commerce-suite'),
            'doy' => $translate('Tax Office', 'gr-commerce-suite'),
            'profession' => $translate('Business Activity', 'gr-commerce-suite'),
        ] as $key => $label) {
            echo '<p><strong>' . esc_html($label) . ':</strong> ' . esc_html((string) $order->get_meta('_grcs_' . $key, true)) . '</p>';
        }
        echo '</div>';
    }

    public function enqueueAssets(): void
    {
        if (!BoxNowCheckoutPicker::isCheckoutRequest() || !$this->enabled()) {
            return;
        }
        $url = plugins_url('', GRCS_PLUGIN_FILE);
        wp_enqueue_script('grcs-invoice-checkout', $url . '/assets/js/invoice-checkout.js', ['jquery'], GRCS_VERSION, true);
        wp_enqueue_style('grcs-invoice-checkout', $url . '/assets/css/invoice-checkout.css', [], GRCS_VERSION);
        wp_localize_script('grcs-invoice-checkout', 'grcsInvoice', [
            'ajaxUrl' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce(self::NONCE_ACTION),
            'lookup' => __('🔍 Αναζήτηση ΑΑΔΕ', 'gr-commerce-suite'),
            'loading' => __('Έλεγχος ΑΑΔΕ...', 'gr-commerce-suite'),
            'fallback' => __('Η αυτόματη συμπλήρωση δεν είναι διαθέσιμη. Συμπληρώστε τα στοιχεία σας.', 'gr-commerce-suite'),
            'success' => __('✓ Τα στοιχεία επιβεβαιώθηκαν από την ΑΑΔΕ', 'gr-commerce-suite'),
            'simulation' => __('✓ Προσομοίωση ΑΑΔΕ — συμπληρώθηκαν δοκιμαστικά στοιχεία', 'gr-commerce-suite'),
        ]);
    }

    public function handleLookup(): void
    {
        if (!check_ajax_referer(self::NONCE_ACTION, 'security', false)) {
            wp_send_json_error(['message' => __('Security check failed.', 'gr-commerce-suite')], 403);
        }
        if (!$this->enabled() || !function_exists('WC') || WC()->cart === null || WC()->cart->is_empty()) {
            wp_send_json_error(['message' => __('Lookup requires an active checkout.', 'gr-commerce-suite')], 403);
        }
        $input = $_POST['afm'] ?? $_POST['vat'] ?? null;
        $vat = is_string($input) ? trim(wp_unslash($input)) : '';
        if (!self::validVat($vat)) {
            (new \GRCommerceSuite\Services\DiagnosticLogger())->validationFailure('INVOICE', 'validate_afm', ['vat_number' => $vat], null, false);
            wp_send_json_error(['message' => __('Μη έγκυρο ΑΦΜ (Invalid VAT number).', 'gr-commerce-suite')], 422);
        }
        $key = 'grcs_aade_rate_' . hash_hmac('sha256', CodBlacklistService::clientIp(), wp_salt('auth'));
        if (!Lock::acquire($key, 15)) {
            wp_send_json_error(['message' => __('Please try again shortly.', 'gr-commerce-suite')], 429);
        }
        try {
            $count = (int) get_transient($key);
            $limited = $count >= 5;
            $result = null;
            if (!$limited) {
                set_transient($key, $count + 1, 300);
                $lookup = $this->lookup ?? new AadeRegistryLookup(new WpHttpClient(), new CredentialVault());
                $result = $lookup->lookup($vat);
            }
        } finally {
            Lock::release($key);
        }
        if ($limited) {
            wp_send_json_error(['message' => __('Please try again later or enter the details manually.', 'gr-commerce-suite')], 429);
        }
        wp_send_json_success(['valid' => true, 'details' => $result, 'simulated' => isset($lookup) && $lookup->isSimulation(),
            'message' => $result === null ? __('Enter invoice details manually.', 'gr-commerce-suite') : '']);
    }
}
