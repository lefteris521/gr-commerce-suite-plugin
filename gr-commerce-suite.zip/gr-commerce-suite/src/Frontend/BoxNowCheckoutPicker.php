<?php

declare(strict_types=1);

namespace GRCommerceSuite\Frontend;

use GRCommerceSuite\Contracts\HookSubscriberInterface;
use GRCommerceSuite\Contracts\PickupLocationProviderInterface;
use GRCommerceSuite\Couriers\CourierRegistry;
use GRCommerceSuite\Domain\Shared\CourierSlug;
use GRCommerceSuite\Services\LicenseManager;
use GRCommerceSuite\Shipping\CourierSelection;
use Throwable;
use WC_Order;

/** Classic and native Blocks locker selection; WooCommerce remains responsible for shipping rates. */
final class BoxNowCheckoutPicker implements HookSubscriberInterface
{
    public const FIELD_ID = 'grcs/boxnow-locker-id';
    public const META_KEY = '_grcs_boxnow_locker_id';
    public const OPTION_SHIPPING_METHODS = 'grcs_boxnow_shipping_methods';
    public const OPTION_PARTNER_ID = 'grcs_boxnow_widget_partner_id';
    public const DETAILS_KEY = '_grcs_boxnow_locker_details';

    /** @var array<int|string, string>|null */
    private ?array $locationCache = null;

    /** @var array<int|string, array<string, mixed>> */
    private array $locationDetails = [];

    private bool $blockFieldRegistered = false;

    public static function isCheckoutRequest(): bool
    {
        if (
            (function_exists('is_checkout') && is_checkout())
            || (function_exists('is_wc_endpoint_url') && is_wc_endpoint_url())
        ) {
            return true;
        }
        // WooCommerce's checkout AJAX and Store API requests have no queried checkout page.
        if (($_POST['action'] ?? '') === 'grcs_boxnow_validate_locker') {
            return true;
        }
        $ajax = $_GET['wc-ajax'] ?? '';
        if (is_string($ajax) && in_array($ajax, ['update_order_review', 'checkout'], true)) {
            return true;
        }
        if (defined('REST_REQUEST') && REST_REQUEST) {
            $route = $GLOBALS['wp']->query_vars['rest_route'] ?? $_GET['rest_route'] ?? $_SERVER['REQUEST_URI'] ?? '';
            return is_string($route) &&
                 preg_match(
                     '#/wc/store/v[0-9]+/(?:checkout|cart|batch)(?:[/?]|$)#',
                     $route
                 ) === 1;
        }
        return false;
    }

    public function __construct(private readonly CourierRegistry $registry)
    {
    }

    public function register(): void
    {
        if (!\GRCommerceSuite\Modules\ModuleRegistry::courierCanCreate(CourierSlug::BoxNow)) {
            return;
        }
        add_action('woocommerce_review_order_before_payment', [$this, 'render'], 5);
        add_filter('woocommerce_update_order_review_fragments', [$this, 'fragments']);
        add_action('woocommerce_checkout_process', [$this, 'validateCheckout']);
        add_action('woocommerce_after_checkout_validation', [$this, 'validateClassic'], 10, 2);
        add_action('woocommerce_checkout_create_order', [$this, 'saveClassic'], 10, 2);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'saveStoreApi'], 100, 2);
        add_action('wp', [$this, 'registerBlockField']);
        // Register before Store API builds the checkout route's additional_fields schema.
        add_action('rest_api_init', [$this, 'registerBlockField'], 1);
        add_action('wp_enqueue_scripts', [$this, 'enqueue']);
        add_action('wp_ajax_grcs_boxnow_validate_locker', [$this, 'validateSelection']);
        add_action('wp_ajax_nopriv_grcs_boxnow_validate_locker', [$this, 'validateSelection']);
    }

    /** Saved locker details remain available even when new BOX NOW checkouts are disabled. No provider requests. */
    public function registerOrderHooks(): void
    {
        add_action('woocommerce_order_details_after_order_table', [$this, 'renderOrderDetails']);
        add_action('woocommerce_email_order_meta', [$this, 'renderOrderDetails'], 20, 4);
    }

    /** @return array<int|string, string> */
    public function locations(): array
    {
        if (!self::isCheckoutRequest()) {
            return [];
        }
        if ($this->locationCache !== null) {
            return $this->locationCache;
        }
        if ((new LicenseManager())->isSandboxEnabled()) {
            $this->locationDetails = [
                '1001' => ['id' => '1001', 'name' => '[SANDBOX] Ερμού', 'address' => 'Ερμού 10', 'postcode' => '10563', 'city' => 'Αθήνα', 'simulated' => true],
                '1002' => ['id' => '1002', 'name' => '[SANDBOX] Σύνταγμα', 'address' => 'Πλατεία Συντάγματος 1', 'postcode' => '10557', 'city' => 'Αθήνα', 'simulated' => true],
                '2001' => ['id' => '2001', 'name' => '[SANDBOX] Τσιμισκή', 'address' => 'Τσιμισκή 45', 'postcode' => '54623', 'city' => 'Θεσσαλονίκη', 'simulated' => true],
            ];
            $locations = [
                '1001' => '[SANDBOX] BOX NOW Ερμού — Ερμού 10, 10563 Αθήνα',
                '1002' => '[SANDBOX] BOX NOW Σύνταγμα — Πλατεία Συντάγματος 1, 10557 Αθήνα',
                '2001' => '[SANDBOX] BOX NOW Τσιμισκή — Τσιμισκή 45, 54623 Θεσσαλονίκη',
            ];
            // A locker picked on the real map widget is accepted for this sandbox session only.
            $widget = function_exists('WC') && WC()->session ? WC()->session->get(self::DETAILS_KEY) : null;
            if (
                is_array($widget) && !empty($widget['widget']) && is_string($widget['id'] ?? null)
                && $this->sanitizeLockerId($widget['id']) === $widget['id'] && !isset($locations[$widget['id']])
            ) {
                $this->locationDetails[$widget['id']] = $widget;
                $locations[$widget['id']] = (string) ($widget['name'] ?? '') . ' — ' . (string) ($widget['address'] ?? '');
            }
            return $this->locationCache = $locations;
        }
        try {
            $provider = $this->registry->get(CourierSlug::BoxNow);
            if ($provider instanceof \GRCommerceSuite\Couriers\BoxNowProvider && !$provider->usesProductionEndpoint()) {
                return $this->locationCache = [];
            }
            $locations = [];
            if ($provider instanceof PickupLocationProviderInterface) {
                $points = $provider instanceof \GRCommerceSuite\Couriers\BoxNowProvider
                    ? $provider->listPickupPoints('', true) : $provider->listPickupPoints('');
                foreach ($points as $point) {
                    if (
                        ($point->rawResponse['type'] ?? 'apm') !== 'apm'
                        || ($point->rawResponse['country'] ?? 'GR') !== 'GR'
                    ) {
                        continue;
                    }
                    $locations[$point->id] = $point->name . ' — ' . $point->address . ', ' . $point->postcode;
                    $this->locationDetails[$point->id] = ['id' => $point->id, 'name' => $point->name,
                        'address' => $point->address, 'postcode' => $point->postcode, 'city' => $point->city,
                        'simulated' => false];
                }
            }
            return $this->locationCache = $locations;
        } catch (Throwable) {
            // A courier outage must not break checkout for other shipping methods.
            return $this->locationCache = [];
        }
    }

    /** @param array<mixed> $methods */
    public function usesBoxNow(array $methods): bool
    {
        foreach ($methods as $method) {
            if (is_string($method) && CourierSelection::fromRate($method) === CourierSlug::BoxNow) {
                return true;
            }
        }
        return false;
    }

    public function render(): void
    {
        if (!self::isCheckoutRequest()) {
            return;
        }
        $methods = function_exists('WC') && WC()->session ? WC()->session->get('chosen_shipping_methods', []) : [];
        echo '<div id="grcs-boxnow-locker-checkout-field" class="grcs-checkout-wrap grcs-boxnow-picker">';
        if ($this->usesBoxNow(is_array($methods) ? $methods : [])) {
            $posted = [];
            if (isset($_POST['post_data']) && is_string($_POST['post_data'])) {
                wp_parse_str(wp_unslash($_POST['post_data']), $posted);
            }
            $selected = is_string($posted['grcs_boxnow_locker_id'] ?? null) ? $posted['grcs_boxnow_locker_id']
                : \GRCommerceSuite\Shipping\ShippingContext::locker();
            echo '<input type="hidden" name="grcs_boxnow_locker_id" id="grcs_boxnow_locker_id" value="'
                . esc_attr($selected) . '" /><div class="grcs-boxnow-control"></div>';
            echo '<noscript>' . esc_html__('Enable JavaScript to select a BOX NOW locker, or choose another shipping method.', 'gr-commerce-suite') . '</noscript>';
        }
        echo '</div>';
    }

    /**
     * @param array<string, string> $fragments
     * @return array<string, string>
     */
    public function fragments(array $fragments): array
    {
        if (!self::isCheckoutRequest()) {
            return $fragments;
        }
        ob_start();
        $this->render();
        $fragments['#grcs-boxnow-locker-checkout-field'] = (string) ob_get_clean();
        return $fragments;
    }

    public function registerBlockField(): void
    {
        if (
            $this->blockFieldRegistered || !self::isCheckoutRequest()
            || !function_exists('woocommerce_register_additional_checkout_field')
        ) {
            return;
        }
        // Native additional fields work in Blocks without a compiled JavaScript bundle.
        $field = [
            'id' => self::FIELD_ID,
            'label' => __('Selected BOX NOW locker', 'gr-commerce-suite'),
            'optionalLabel' => __('Selected BOX NOW locker', 'gr-commerce-suite'),
            'attributes' => ['readOnly' => true],
            'location' => 'order',
            'type' => 'text',
            'required' => false,
            'sanitize_callback' => [$this, 'sanitizeLockerId'],
        ];
        if (defined('WC_VERSION') && version_compare(WC_VERSION, '9.9', '>=')) {
            $mapped = array_values(array_filter(
                CourierSelection::mappings(CourierSlug::BoxNow),
                static fn(string $rate): bool => CourierSelection::fromRate($rate) === CourierSlug::BoxNow
            ));
            $patterns = ['^grcs_boxnow(:[0-9]+)?$'];
            foreach (array_merge(['boxnow', 'box_now', 'box-now'], $mapped) as $method) {
                if (!str_contains($method, ':') && CourierSelection::fromRate($method) === CourierSlug::BoxNow) {
                    $patterns[] = '^' . preg_quote($method, '/') . '(:[0-9]+)?$';
                }
            }
            $rateSchema = ['anyOf' => [['type' => 'string', 'pattern' => implode('|', $patterns)]]];
            if ($mapped !== []) {
                array_unshift($rateSchema['anyOf'], ['enum' => $mapped]);
            }
            // Exclude conflicting mappings, while native BOX NOW always keeps precedence.
            $excluded = ['^grcs_acs(:[0-9]+)?$'];
            foreach (CourierSelection::mappings(CourierSlug::Acs) as $method) {
                if (explode(':', $method, 2)[0] !== 'grcs_boxnow') {
                    $excluded[] = '^' . preg_quote($method, '/') . (str_contains($method, ':') ? '$' : '(:[0-9]+)?$');
                }
            }
            $rateSchema['not'] = ['type' => 'string', 'pattern' => implode('|', $excluded)];
            $selected = ['cart' => ['properties' => [
                'shipping_rates' => ['type' => 'array', 'contains' => $rateSchema],
            ]]];
            $field['hidden'] = ['cart' => ['properties' => [
                'shipping_rates' => ['not' => ['contains' => $rateSchema]],
            ]]];
            $field['required'] = $selected;
        }
        woocommerce_register_additional_checkout_field($field);
        $this->blockFieldRegistered = true;
    }

    public function sanitizeLockerId(mixed $value): string
    {
        return is_string($value) && preg_match('/^[a-zA-Z0-9_-]{1,64}$/D', trim($value)) ? trim($value) : '';
    }

    public function enqueue(): void
    {
        if (!function_exists('is_checkout') || !is_checkout()) {
            return;
        }
        $sandbox = (new LicenseManager())->isSandboxEnabled();
        $dependencies = ['jquery', 'wp-data'];
        if (function_exists('has_block') && has_block('woocommerce/checkout')) {
            $dependencies[] = 'wc-blocks-checkout';
            $dependencies[] = 'wc-blocks-data-store';
        }
        wp_enqueue_script(
            'grcs-boxnow-checkout',
            plugins_url('assets/js/boxnow-checkout.js', GRCS_PLUGIN_FILE),
            $dependencies,
            GRCS_VERSION,
            true
        );
        wp_enqueue_style('grcs-boxnow-checkout', plugins_url('assets/css/boxnow-checkout.css', GRCS_PLUGIN_FILE), [], GRCS_VERSION);
        wp_localize_script('grcs-boxnow-checkout', 'grcsBoxNowCheckout', [
            'methods' => CourierSelection::mappings(CourierSlug::BoxNow),
            'acsMethods' => CourierSelection::mappings(CourierSlug::Acs),
            'sandbox' => $sandbox,
            'partnerId' => sanitize_text_field((string) get_option(self::OPTION_PARTNER_ID, '')),
            'mockLockers' => $sandbox ? $this->locations() : [],
            'ajaxUrl' => admin_url('admin-ajax.php'), 'nonce' => wp_create_nonce('grcs_boxnow_picker'),
            'select' => __('📍 Επιλογή Θυρίδας BOX NOW', 'gr-commerce-suite'),
            'required' => __('Παρακαλώ επιλέξτε θυρίδα BOX NOW για να ολοκληρώσετε την παραγγελία.', 'gr-commerce-suite'),
            'unavailable' => __('BOX NOW locker selection is unavailable. Retry the map or choose another shipping method.', 'gr-commerce-suite'),
            'loading' => __('Checking locker availability…', 'gr-commerce-suite'),
            'simulation' => __('[SANDBOX] — Δοκιμαστικές θυρίδες BOX NOW.', 'gr-commerce-suite'),
            'fallback' => __('Χειροκίνητη επιλογή δοκιμαστικής θυρίδας (Offline Sandbox)', 'gr-commerce-suite'),
        ]);
    }

    /** Verify widget output without accepting any browser-supplied address or name. */
    public function validateSelection(): void
    {
        check_ajax_referer('grcs_boxnow_picker', 'security');
        try {
            $locker = isset($_POST['locker']) ? wp_unslash($_POST['locker']) : '';
            if ((new LicenseManager())->isSandboxEnabled()) {
                $this->rememberSandboxWidgetLocker($locker);
            }
            $id = $this->validatedLockerId($locker);
            if (WC()->session) {
                WC()->session->set(\GRCommerceSuite\Shipping\ShippingContext::LOCKER, $id);
                WC()->session->set(self::DETAILS_KEY, $this->locationDetails[$id]);
            }
            wp_send_json_success($this->locationDetails[$id]);
        } catch (Throwable) {
            wp_send_json_error(['message' => __('This locker cannot be verified. Please retry or choose another shipping method.', 'gr-commerce-suite')], 422);
        }
    }

    /** Sandbox has no verifiable locker API, so the real widget's own details are stored as simulated test data. */
    private function rememberSandboxWidgetLocker(mixed $locker): void
    {
        $id = $this->sanitizeLockerId($locker);
        $this->locationCache = null;
        if ($id === '' || !WC()->session || array_key_exists($id, $this->locations())) {
            return;
        }
        $text = static fn(string $key): string => isset($_POST[$key]) && is_string($_POST[$key])
            ? mb_substr(sanitize_text_field(wp_unslash($_POST[$key])), 0, 120) : '';
        WC()->session->set(self::DETAILS_KEY, ['id' => $id, 'name' => '[SANDBOX] ' . ($text('name') !== '' ? $text('name') : 'BOX NOW ' . $id),
            'address' => $text('address'), 'postcode' => $text('postcode'), 'city' => '', 'simulated' => true, 'widget' => true]);
        $this->locationCache = null;
    }

    public function renderOrderDetails(WC_Order $order, bool $sentToAdmin = false, bool $plainText = false, mixed $email = null): void
    {
        $details = $order->get_meta(self::DETAILS_KEY, true);
        if (!is_array($details) || !$this->usesBoxNow(CourierSelection::orderRates($order))) {
            return;
        }
        $text = __('BOX NOW locker', 'gr-commerce-suite') . ': ' . implode(', ', array_filter([
            $details['id'] ?? '', $details['name'] ?? '', $details['address'] ?? '', $details['postcode'] ?? '', $details['city'] ?? '',
        ]));
        if ($plainText) {
            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text email, not HTML.
            echo "\n" . $text . "\n";
        } else {
            echo '<p class="grcs-locker-details">' . esc_html($text) . '</p>';
        }
    }

    /**
     * Validate before Classic Checkout creates an order or attempts payment.
     */
    public function validateCheckout(): void
    {
        $methods = $_POST['shipping_method'] ?? [];
        if (!$this->usesBoxNow(is_array($methods) ? $methods : [])) {
            return;
        }
        try {
            $value = $_POST['grcs_boxnow_locker_id'] ?? '';
            $this->validatedLockerId(is_string($value) ? wp_unslash($value) : '');
        } catch (Throwable $error) {
            wc_add_notice($error->getMessage(), 'error');
        }
    }

    /** @param array<string, mixed> $data */
    public function validateClassic(array $data, \WP_Error $errors): void
    {
        $methods = $data['shipping_method'] ?? [];
        if (!$this->usesBoxNow(is_array($methods) ? $methods : [])) {
            return;
        }
        $value = $_POST['grcs_boxnow_locker_id'] ?? $data['grcs_boxnow_locker_id'] ?? '';
        try {
            $this->validatedLockerId(is_string($value) ? wp_unslash($value) : '');
        } catch (Throwable $error) {
            $errors->add('grcs_locker_invalid', $error->getMessage());
        }
    }

    /** @param array<string, mixed> $data */
    public function saveClassic(WC_Order $order, array $data = []): void
    {
        $value = $_POST['grcs_boxnow_locker_id'] ?? $data['grcs_boxnow_locker_id'] ?? '';
        $this->save($order, is_string($value) ? wp_unslash($value) : '');
    }

    public function saveStoreApi(WC_Order $order, mixed $request): void
    {
        $additional = is_object($request) && is_callable([$request, 'get_param']) ? $request->get_param('additional_fields') : [];
        $extensions = is_object($request) && is_callable([$request, 'get_param']) ? $request->get_param('extensions') : [];
        $additional = is_array($additional) ? $additional : [];
        $extensions = is_array($extensions) ? $extensions : [];
        $value = $additional[self::FIELD_ID] ?? $extensions['gr-commerce-suite']['boxnow_locker_id'] ?? null;
        if ($value === null && is_object($request) && method_exists($request, 'get_param')) {
            $value = $request->get_param('grcs_boxnow_locker_id');
        }
        // Blocks also updates draft orders before a locker has been selected.
        $partial = is_object($request) && method_exists($request, 'get_method')
            && in_array($request->get_method(), ['PUT', 'PATCH'], true);
        $this->save($order, $value, !$partial);
    }

    private function save(WC_Order $order, mixed $value, bool $required = true): void
    {
        $methods = CourierSelection::orderRates($order);
        if (!$this->usesBoxNow($methods)) {
            $order->delete_meta_data(self::META_KEY);
            $order->delete_meta_data(self::DETAILS_KEY);
            $order->delete_meta_data('_boxnow_locker_id');
            $order->delete_meta_data('_boxnow_locker_name');
            $order->delete_meta_data('_boxnow_locker_address');
            $order->delete_meta_data('_wc_other/' . self::FIELD_ID);
            $courier = CourierSelection::fromOrder($order);
            if ($courier !== null) {
                $order->update_meta_data('_grcs_preferred_courier', $courier->value);
            } else {
                $order->delete_meta_data('_grcs_preferred_courier');
            }
            return;
        }
        if (!$required && $this->sanitizeLockerId($value) === '') {
            $order->delete_meta_data(self::META_KEY);
            $order->delete_meta_data(self::DETAILS_KEY);
            $order->delete_meta_data('_boxnow_locker_id');
            $order->delete_meta_data('_boxnow_locker_name');
            $order->delete_meta_data('_boxnow_locker_address');
            $order->delete_meta_data('_wc_other/' . self::FIELD_ID);
            $order->delete_meta_data('_grcs_preferred_courier');
            return;
        }
        $id = $this->validatedLockerId($value);
        $order->update_meta_data(self::META_KEY, $id);
        $order->update_meta_data(self::DETAILS_KEY, $this->locationDetails[$id]);
        $order->update_meta_data('_boxnow_locker_id', $id);
        $order->update_meta_data('_boxnow_locker_name', $this->locationDetails[$id]['name']);
        $order->update_meta_data('_boxnow_locker_address', $this->locationDetails[$id]['address']);
        // WooCommerce saves this WC_Order immediately after the create/update-order hook.
        $courier = CourierSelection::fromOrder($order);
        if ($courier !== null) {
            $order->update_meta_data('_grcs_preferred_courier', $courier->value);
        } else {
            $order->delete_meta_data('_grcs_preferred_courier');
        }
    }

    private function validatedLockerId(mixed $value): string
    {
        $id = $this->sanitizeLockerId($value);
        if ($id === '') {
            \GRCommerceSuite\Support\CheckoutValidation::fail('grcs_locker_required', __(
                'Παρακαλώ επιλέξτε θυρίδα BOX NOW για να ολοκληρώσετε την παραγγελία.',
                'gr-commerce-suite'
            ));
        }
        $locations = $this->locations();
        if (!array_key_exists($id, $locations)) {
            \GRCommerceSuite\Support\CheckoutValidation::fail('grcs_locker_unavailable', __(
                'This BOX NOW locker is unavailable. Please choose another locker.',
                'gr-commerce-suite'
            ));
        }
        // The widget selects a location; merchant parcel/rating rules still apply.
        if (WC()->cart && WC()->cart->needs_shipping() && WC()->session) {
            $chosen = WC()->session->get('chosen_shipping_methods', []);
            foreach (WC()->shipping()->get_packages() as $key => $package) {
                $rate = is_array($chosen) ? ($chosen[$key] ?? '') : '';
                if (!is_string($rate) || !str_starts_with($rate, 'grcs_boxnow:')) {
                    continue;
                }
                $method = \WC_Shipping_Zones::get_shipping_method((int) substr($rate, strlen('grcs_boxnow:')));
                if ($method instanceof \WC_Shipping_Method && $method->get_option('pricing_mode', 'fixed') === 'dynamic') {
                    try {
                        (new \GRCommerceSuite\Shipping\Pricing\BoxNowRuleCalculator())->calculate($package, $method->instance_settings, $id, false);
                    } catch (Throwable) {
                        \GRCommerceSuite\Support\CheckoutValidation::fail('grcs_locker_ineligible', __(
                            'This BOX NOW locker cannot accept this delivery package. Choose another locker or shipping method.',
                            'gr-commerce-suite'
                        ));
                    }
                }
            }
        }
        return $id;
    }
}
