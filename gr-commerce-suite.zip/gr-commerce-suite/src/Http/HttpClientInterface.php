<?php

declare(strict_types=1);

namespace GRCommerceSuite\Http;

/**
 * Transport contract abstracting WordPress HTTP API (`wp_remote_request`) (SPEC.md §3 C-6, §8).
 */
interface HttpClientInterface
{
    public function send(HttpRequest $request): HttpResponse;
}
