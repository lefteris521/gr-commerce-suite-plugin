<?php

declare(strict_types=1);

namespace GRCommerceSuite\Http;

use WP_Error;

/**
 * WordPress HTTP API (`wp_remote_request`) implementation of `HttpClientInterface` (SPEC.md §3 C-6, §8.2).
 *
 * Classifies transport failures into pre-transmission (safe to retry) vs post-transmission read timeouts
 * (ambiguous result -> voucher row MUST transition to `state = 'unknown'`).
 */
final class WpHttpClient implements HttpClientInterface
{
    public function send(HttpRequest $request): HttpResponse
    {
        $args = [
            'method' => strtoupper($request->method),
            'headers' => $request->headers,
            'timeout' => max(1, $request->timeoutSeconds),
            'redirection' => 0,
            'reject_unsafe_urls' => true,
            'httpversion' => '1.1',
            'blocking' => true,
            'sslverify' => true,
        ];

        if ($request->body !== null) {
            $args['body'] = $request->body;
        }

        $rawResponse = wp_remote_request($request->url, $args);

        if ($rawResponse instanceof WP_Error) {
            /** @var WP_Error $rawResponse */
            $errorCode = (string) $rawResponse->get_error_code();
            $errorMessage = (string) $rawResponse->get_error_message();

            $isPreConnect = self::isPreTransmissionFailure($errorCode, $errorMessage);
            $isPostTimeout = !$isPreConnect && self::isTimeoutError($errorCode, $errorMessage);

            return new HttpResponse(
                statusCode: 0,
                body: '',
                headers: [],
                errorCode: $errorCode !== '' ? $errorCode : 'http_request_failed',
                errorMessage: $errorMessage,
                timedOutAfterTransmission: !$isPreConnect,
                failedBeforeTransmission: $isPreConnect,
            );
        }

        $statusCode = (int) wp_remote_retrieve_response_code($rawResponse);
        $body = (string) wp_remote_retrieve_body($rawResponse);
        $rawHeaders = wp_remote_retrieve_headers($rawResponse);

        $headers = [];
        if (is_iterable($rawHeaders)) {
            foreach ($rawHeaders as $k => $v) {
                if (is_array($v)) {
                    $headers[strtolower((string) $k)] = implode(', ', array_map('strval', $v));
                } elseif (is_scalar($v)) {
                    $headers[strtolower((string) $k)] = (string) $v;
                }
            }
        }

        $timedOutHeader = ($headers['x-grcs-timeout'] ?? '') === '1';
        $isGatewayOrRequestTimeout = in_array($statusCode, [408, 504], true) || $timedOutHeader;

        return new HttpResponse(
            statusCode: $statusCode,
            body: $body,
            headers: $headers,
            errorCode: null,
            errorMessage: null,
            timedOutAfterTransmission: $isGatewayOrRequestTimeout,
            failedBeforeTransmission: false,
        );
    }

    /**
     * Detect failures proven to have occurred before the HTTP payload reached the remote server.
     */
    private static function isPreTransmissionFailure(string $code, string $message): bool
    {
        $lowerCode = strtolower($code);
        $lowerMsg = strtolower($message);

        if (in_array($lowerCode, ['connect_timeout', 'dns_resolution_failed', 'tls_handshake_failed'], true)) {
            return true;
        }

        $preConnectPatterns = [
            'could not resolve host',
            'resolving timed out',
            'failed to connect to',
            'connection refused',
            'connection timed out',
            'ssl connection timeout',
            'unable to connect',
            'name or service not known',
        ];

        foreach ($preConnectPatterns as $pattern) {
            if (str_contains($lowerMsg, $pattern)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Detect read/operation timeouts after the request was transmitted.
     */
    private static function isTimeoutError(string $code, string $message): bool
    {
        $lowerCode = strtolower($code);
        $lowerMsg = strtolower($message);

        if (
            str_contains($lowerCode, 'timeout')
            || str_contains($lowerCode, 'timed_out')
            || $lowerCode === 'grcs_read_timeout'
        ) {
            return true;
        }

        $timeoutPatterns = [
            'operation timed out',
            'read timed out',
            'request timed out',
            'timed out',
            'curl error 28',
        ];

        foreach ($timeoutPatterns as $pattern) {
            if (str_contains($lowerMsg, $pattern)) {
                return true;
            }
        }

        return false;
    }
}
