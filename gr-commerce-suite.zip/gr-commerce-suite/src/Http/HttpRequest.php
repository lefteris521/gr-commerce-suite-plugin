<?php

declare(strict_types=1);

namespace GRCommerceSuite\Http;

/**
 * Immutable HTTP request value object for `HttpClientInterface` (SPEC.md §4, §8.2).
 */
final readonly class HttpRequest
{
    /**
     * @param array<string, string> $headers
     */
    public function __construct(
        public string $method,
        public string $url,
        public array $headers = [],
        public ?string $body = null,
        public int $timeoutSeconds = 15,
        public int $connectTimeoutSeconds = 5,
    ) {
    }
}
