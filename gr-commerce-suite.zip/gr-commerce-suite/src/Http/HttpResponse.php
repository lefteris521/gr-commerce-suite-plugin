<?php

declare(strict_types=1);

namespace GRCommerceSuite\Http;

/**
 * Immutable HTTP response value object returned by `HttpClientInterface` (SPEC.md §4, §8.2).
 */
final readonly class HttpResponse
{
    /**
     * @param array<string, string> $headers Lowercased header names.
     */
    public function __construct(
        public int $statusCode,
        public string $body,
        public array $headers = [],
        public ?string $errorCode = null,
        public ?string $errorMessage = null,
        public bool $timedOutAfterTransmission = false,
        public bool $failedBeforeTransmission = false,
    ) {
    }

    public function isSuccess(): bool
    {
        return $this->errorCode === null && $this->statusCode >= 200 && $this->statusCode < 300;
    }

    public function hasError(): bool
    {
        return $this->errorCode !== null;
    }

    public function header(string $name): ?string
    {
        $lower = strtolower($name);
        foreach ($this->headers as $key => $value) {
            if (strtolower($key) === $lower) {
                return $value;
            }
        }

        return null;
    }
}
