<?php

declare(strict_types=1);

namespace GRCommerceSuite\Security;

use GRCommerceSuite\Domain\Shared\CourierSlug;
use RuntimeException;
use Throwable;

/**
 * Encrypts and decrypts courier credentials at rest using `sodium_crypto_secretbox` (SPEC.md §15.2).
 */
final class CredentialVault
{
    public const ENCRYPTION_UNAVAILABLE = 'Credential encryption is unavailable. Enable PHP Sodium or a compatible sodium_compat implementation before saving credentials.';

    public static function encryptionAvailable(): bool
    {
        return function_exists('sodium_crypto_secretbox')
            && function_exists('sodium_crypto_secretbox_open')
            && function_exists('sodium_crypto_generichash')
            && defined('SODIUM_CRYPTO_SECRETBOX_NONCEBYTES')
            && defined('SODIUM_CRYPTO_SECRETBOX_KEYBYTES');
    }

    /** @return array{username: string, password: string} */
    public function getAade(): array
    {
        $stored = get_option('grcs_aade_credentials', '');
        $plain = is_string($stored) && $stored !== '' ? $this->decrypt($stored) : null;
        $decoded = $plain !== null ? json_decode($plain, true) : null;
        return ['username' => is_array($decoded) && is_string($decoded['username'] ?? null) ? $decoded['username'] : '',
            'password' => is_array($decoded) && is_string($decoded['password'] ?? null) ? $decoded['password'] : ''];
    }

    public function saveAade(string $username, string $password): void
    {
        $existing = $this->getAade();
        $payload = wp_json_encode(['username' => $username, 'password' => $password !== '' ? $password : $existing['password']]);
        update_option('grcs_aade_credentials', $this->encrypt((string) $payload), false);
    }

    /** @var array<string, list<string>> */
    public const SECRET_FIELDS = [
        'acs' => ['api_key', 'company_password', 'user_password'],
        'boxnow' => ['client_secret'],
        'geniki' => ['password', 'application_key'],
    ];

    /** Move legacy plaintext secrets into the encrypted vault before removing their duplicate options. */
    public function migrateLegacySecrets(): void
    {
        foreach ([CourierSlug::Acs, CourierSlug::BoxNow, CourierSlug::Geniki] as $courier) {
            $plaintext = is_array(get_option($this->optionName($courier), ''));
            foreach (self::SECRET_FIELDS[$courier->value] as $field) {
                $value = get_option('grcs_' . $courier->value . '_' . $field, '');
                $plaintext = $plaintext || (is_string($value) && $value !== '');
            }
            if ($plaintext) {
                if (!$this->saveForCourier($courier, $this->getForCourier($courier))) {
                    throw new RuntimeException(__('Could not encrypt the saved courier credentials.', 'gr-commerce-suite'));
                }
                $this->removePlaintextSecrets($courier);
            }
        }
    }

    public function removePlaintextSecrets(CourierSlug $courier): void
    {
        foreach (self::SECRET_FIELDS[$courier->value] ?? [] as $field) {
            delete_option('grcs_' . $courier->value . '_' . $field);
        }
    }
    /**
     * Retrieve decrypted credentials array for a courier.
     *
     * @return array<string, string>
     */
    public function getForCourier(CourierSlug $courier): array
    {
        if (!function_exists('get_option')) {
            return [];
        }

        $optionName = $this->optionName($courier);
        $stored = get_option($optionName, '');
        $credentials = [];

        if (is_array($stored)) {
            foreach ($stored as $k => $v) {
                if (is_scalar($v)) {
                    $credentials[(string) $k] = (string) $v;
                }
            }
        } elseif (is_string($stored) && trim($stored) !== '') {
            $decrypted = $this->decrypt($stored);
            if ($decrypted !== null) {
                try {
                    $decoded = json_decode($decrypted, true, 16, JSON_THROW_ON_ERROR);
                    if (is_array($decoded)) {
                        foreach ($decoded as $key => $value) {
                            if (is_scalar($value)) {
                                $credentials[(string) $key] = (string) $value;
                            }
                        }
                    }
                } catch (Throwable) {
                    // Fall through to individual WooCommerce option fallbacks
                }
            }
        }

        return $this->mergeIndividualOptionFallbacks($courier, $credentials);
    }

    /**
     * Merge standalone WooCommerce settings options (`grcs_acs_*`, `grcs_boxnow_*`) when vault keys are empty.
     *
     * @param array<string, string> $credentials
     * @return array<string, string>
     */
    private function mergeIndividualOptionFallbacks(CourierSlug $courier, array $credentials): array
    {
        if (!function_exists('get_option')) {
            return $credentials;
        }

        $optionMap = match ($courier) {
            CourierSlug::Acs => [
                'api_key' => 'grcs_acs_api_key',
                'company_id' => 'grcs_acs_company_id',
                'company_password' => 'grcs_acs_company_password',
                'user_id' => 'grcs_acs_user_id',
                'user_password' => 'grcs_acs_user_password',
                'billing_code' => 'grcs_acs_billing_code',
            ],
            CourierSlug::BoxNow => [
                'client_id' => 'grcs_boxnow_client_id',
                'client_secret' => 'grcs_boxnow_client_secret',
                'origin_location_id' => 'grcs_boxnow_origin_location_id',
            ],
            CourierSlug::Geniki => \GRCommerceSuite\Modules\Geniki\GenikiSettings::vaultOptionMap(),
        };

        foreach ($optionMap as $credKey => $optionName) {
            if (!array_key_exists($credKey, $credentials) || ($courier !== CourierSlug::Geniki && trim($credentials[$credKey]) === '')) {
                $optVal = get_option($optionName, '');
                if (is_scalar($optVal) && trim((string) $optVal) !== '') {
                    $credentials[$credKey] = trim((string) $optVal);
                }
            }
        }

        return $credentials;
    }

    /**
     * Encrypt and store credentials for a courier in a non-autoloaded option.
     *
     * @param array<string, string> $credentials
     */
    public function saveForCourier(CourierSlug $courier, array $credentials): bool
    {
        if (!function_exists('update_option')) {
            return false;
        }

        $json = function_exists('wp_json_encode')
            ? (string) wp_json_encode($credentials)
            : json_encode($credentials, JSON_THROW_ON_ERROR);

        $encrypted = $this->encrypt($json);
        $optionName = $this->optionName($courier);

        return (bool) update_option($optionName, $encrypted, false);
    }

    public function encrypt(string $plaintext): string
    {
        if (!self::encryptionAvailable()) {
            throw new RuntimeException(self::ENCRYPTION_UNAVAILABLE);
        }
        $key = $this->deriveKey();
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $cipher = sodium_crypto_secretbox($plaintext, $nonce, $key);

        return base64_encode($nonce . $cipher);
    }

    public function decrypt(string $encodedPayload): ?string
    {
        if (!self::encryptionAvailable()) {
            return null;
        }
        $raw = base64_decode($encodedPayload, true);
        if (!is_string($raw)) {
            return null;
        }

        $nonceLength = SODIUM_CRYPTO_SECRETBOX_NONCEBYTES;
        if (strlen($raw) <= $nonceLength) {
            return null;
        }

        $nonce = substr($raw, 0, $nonceLength);
        $cipher = substr($raw, $nonceLength);

        try {
            $plaintext = sodium_crypto_secretbox_open($cipher, $nonce, $this->deriveKey());
        } catch (Throwable) {
            return null;
        }

        return is_string($plaintext) ? $plaintext : null;
    }

    private function optionName(CourierSlug $courier): string
    {
        return 'grcs_credentials_' . $courier->value;
    }

    /**
     * @return non-empty-string
     */
    private function deriveKey(): string
    {
        $rawSecret = defined('GRCS_ENCRYPTION_KEY') && is_string(constant('GRCS_ENCRYPTION_KEY'))
            ? (string) constant('GRCS_ENCRYPTION_KEY')
            : (function_exists('wp_salt') ? wp_salt('secure_auth') : 'grcs-default-fallback-key-material');

        /** @var non-empty-string $key */
        $key = sodium_crypto_generichash($rawSecret, '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES);

        return $key;
    }
}
