<?php

declare(strict_types=1);

namespace GRCommerceSuite\Security;

/** Preserve provider option names while sealing their password fields in the suite vault format. */
final class IntegrationSecrets
{
    private const PREFIX = 'grcs-secret-v1:';
    private const OPTIONS = [
        'courier_center' => ['cc_wc_credential_value', 'cc_wc_api_key'],
    ];
    /** @var array<string, bool> */
    private static array $registered = [];

    public static function register(string $key, bool $migrate): bool
    {
        if (!CredentialVault::encryptionAvailable()) {
            return false;
        }
        foreach (self::OPTIONS[$key] ?? [] as $option) {
            if (!isset(self::$registered[$option])) {
                self::$registered[$option] = true;
                add_filter('option_' . $option, static fn(mixed $value): mixed => self::transform($option, $value, false));
                add_filter('pre_update_option_' . $option, static fn(mixed $value): mixed => self::transform($option, $value, true));
            }
        }
        $flag = 'grcs_embedded_secrets_' . $key;
        if ($migrate && get_option($flag, 'no') !== 'yes') {
            foreach (self::OPTIONS[$key] ?? [] as $option) {
                $value = get_option($option, null);
                if ($value !== null && $value !== '' && $value !== []) {
                    update_option($option, $value);
                }
            }
            update_option($flag, 'yes', false);
        }
        return true;
    }

    public static function transform(string $option, mixed $value, bool $seal): mixed
    {
        return in_array($option, ['cc_wc_credential_value', 'cc_wc_api_key'], true)
            ? self::secret($value, $seal) : $value;
    }

    private static function secret(mixed $value, bool $seal): mixed
    {
        if (!is_string($value) || $value === '') {
            return $value;
        }
        $vault = new CredentialVault();
        if (str_starts_with($value, self::PREFIX)) {
            return $seal ? $value : ($vault->decrypt(substr($value, strlen(self::PREFIX))) ?? '');
        }
        return $seal ? self::PREFIX . $vault->encrypt($value) : $value;
    }
}
