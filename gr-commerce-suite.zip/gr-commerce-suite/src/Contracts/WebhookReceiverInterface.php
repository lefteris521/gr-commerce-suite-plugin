<?php

declare(strict_types=1);

namespace GRCommerceSuite\Contracts;

use GRCommerceSuite\Domain\Tracking\TrackingResult;
use WP_REST_Request;

/**
 * Optional courier capability for push tracking webhooks (SPEC.md §8.6).
 */
interface WebhookReceiverInterface
{
    /**
     * @return list<TrackingResult>
     */
    public function parseWebhook(WP_REST_Request $request): array;
}
