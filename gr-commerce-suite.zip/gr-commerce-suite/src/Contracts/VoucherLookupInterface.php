<?php

declare(strict_types=1);

namespace GRCommerceSuite\Contracts;

use GRCommerceSuite\Domain\Voucher\VoucherResult;

/**
 * Optional courier capability for recovering `unknown` vouchers by reference (SPEC.md §8.6).
 */
interface VoucherLookupInterface
{
    public function findVoucherByReference(string $reference): ?VoucherResult;
}
