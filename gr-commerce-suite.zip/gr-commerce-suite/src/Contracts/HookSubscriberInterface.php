<?php

declare(strict_types=1);

namespace GRCommerceSuite\Contracts;

/**
 * Contract for services that register WordPress / WooCommerce hooks on kernel boot (SPEC.md §5.2).
 */
interface HookSubscriberInterface
{
    public function register(): void;
}
