<?php

declare(strict_types=1);

namespace GRCommerceSuite\Contracts;

use GRCommerceSuite\Domain\Shared\CourierSlug;

/**
 * Contract for recording post-transmission timeout state transitions (`state = 'unknown'`)
 * without coupling courier adapters to the database layer (SPEC.md §4.1, §6.3, §7).
 */
interface VoucherStateTrackerInterface
{
    /**
     * Transition a reserved or in-flight voucher row to `state = 'unknown'` when an HTTP request
     * times out after transmission so it is never blindly retried.
     */
    public function markUnknownOnTimeout(
        int $orderId,
        CourierSlug $courier,
        string $errorMessage,
        ?string $idempotencyKey = null,
    ): void;
}
