<?php

declare(strict_types=1);

namespace GRCommerceSuite\Contracts;

use GRCommerceSuite\Domain\Shared\PickupPoint;

/**
 * Optional courier capability for listing APM lockers or pickup stores (SPEC.md §8.6).
 */
interface PickupLocationProviderInterface
{
    /**
     * @return list<PickupPoint>
     */
    public function listPickupPoints(string $postcode): array;
}
