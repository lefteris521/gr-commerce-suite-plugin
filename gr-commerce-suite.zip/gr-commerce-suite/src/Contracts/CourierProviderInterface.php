<?php

declare(strict_types=1);

namespace GRCommerceSuite\Contracts;

use GRCommerceSuite\Domain\Cod\CodReconciliationResult;
use GRCommerceSuite\Domain\Tracking\TrackingResult;
use GRCommerceSuite\Domain\Voucher\PrintFormat;
use GRCommerceSuite\Domain\Voucher\VoucherResult;
use GRCommerceSuite\Exceptions\Courier\CourierAmbiguousResultException;
use GRCommerceSuite\Exceptions\Courier\CourierAuthenticationException;
use GRCommerceSuite\Exceptions\Courier\CourierRateLimitedException;
use GRCommerceSuite\Exceptions\Courier\CourierTransportException;
use GRCommerceSuite\Exceptions\Courier\CourierValidationException;
use GRCommerceSuite\Exceptions\Courier\UnsupportedOperationException;
use GRCommerceSuite\Exceptions\Courier\VoucherNotFoundException;
use WC_Order;

/**
 * Contract every courier adapter (ACS, BOX NOW, Geniki Taxydromiki, future couriers) MUST implement.
 * Normative behaviour is defined in SPEC.md §8; this docblock is a summary of it.
 *
 * Adapter purity rules (enforced in code review and by architecture tests):
 *  1. Adapters are stateless API translators. They MUST NOT write to the database, MUST NOT call
 *     $order->save() / update_meta_data(), MUST NOT schedule Action Scheduler jobs and MUST NOT add
 *     order notes. Persistence, idempotency and retries belong to the Services layer.
 *  2. Adapters read orders exclusively through the WC_Order CRUD API (getters / get_meta()).
 *     get_post_meta(), WP_Query on shop_order and direct SQL are forbidden (HPOS, SPEC.md §3 C-2).
 *  3. All HTTP goes through GRCommerceSuite\Http\HttpClientInterface (wp_remote_request() underneath).
 *     No Guzzle/cURL, no ext-soap. Adapters perform NO inline retries: one call = one attempt.
 *  4. Money crosses this boundary as integer euro cents. Floats are forbidden for money.
 *  5. Every DTO's `rawResponse` MUST be redacted (credentials, tokens, recipient PII) before it is returned.
 *  6. Errors are signalled ONLY with the exception types declared below; anything else is treated
 *     as a bug, logged as critical, and is never retried automatically.
 *
 * Exception semantics (drives the voucher state machine in SPEC.md §6.3 and the retry policy in §9.5):
 *  - CourierValidationException     Courier rejected the data (address, phone, weight...). Permanent. Not retried.
 *  - CourierAuthenticationException Credentials invalid/expired. Permanent until settings change. Not retried.
 *  - CourierRateLimitedException    Throttled. Retryable; honour getRetryAfterSeconds().
 *  - CourierTransportException      Failure proven to have happened BEFORE the courier processed the
 *                                   request (DNS, connect timeout, TLS, HTTP 502/503/504 without body). Retryable.
 *  - CourierAmbiguousResultException Request may have been processed (read timeout after send, malformed
 *                                   2xx body). NEVER blindly retried: the voucher row moves to `unknown`.
 *  - VoucherNotFoundException       The courier does not know the voucher number.
 *  - UnsupportedOperationException  The courier API has no equivalent operation.
 *
 * Optional capabilities are expressed with separate interfaces in this namespace (SPEC.md §8.6),
 * e.g. VoucherLookupInterface for recovering `unknown` vouchers, so this contract stays exact.
 */
interface CourierProviderInterface
{
    /**
     * Create one shipping voucher (AWB) for the order.
     *
     * Inputs read from the order (all via WC_Order getters / get_meta()):
     *  - Shipping address (falls back to billing when shipping is empty), normalised to Greek format:
     *    5-digit postcode, E.164 phone (+30...), Greek or Latin text truncated with mb_* to courier limits.
     *  - COD: when payment method is `cod`, codAmountCents = order total in cents; otherwise 0.
     *  - BOX NOW: the locker id from order meta `_grcs_boxnow_locker_id` (required for that courier).
     *  - Idempotency: order meta `_grcs_active_idempotency_key` (written by VoucherService before the call).
     *    Adapters MUST place its first 16 characters in the courier's free-text reference field when the
     *    API offers one, so an `unknown` voucher can later be matched (SPEC.md §7).
     *
     * @throws CourierValidationException
     * @throws CourierAuthenticationException
     * @throws CourierRateLimitedException
     * @throws CourierTransportException
     * @throws CourierAmbiguousResultException
     */
    public function createVoucher(WC_Order $order): VoucherResult;

    /**
     * Cancel (void) a voucher that has not yet been picked up.
     *
     * Idempotent: cancelling an already-cancelled voucher returns true.
     *
     * @param non-empty-string $voucherNo
     *
     * @return bool True if the voucher is cancelled at the courier; false if the courier refuses as a
     *              business rule (e.g. parcel already picked up / in network). Transport and auth problems
     *              are exceptions, never `false`.
     *
     * @throws VoucherNotFoundException
     * @throws CourierAuthenticationException
     * @throws CourierRateLimitedException
     * @throws CourierTransportException
     * @throws CourierAmbiguousResultException
     * @throws UnsupportedOperationException
     */
    public function cancelVoucher(string $voucherNo): bool;

    /**
     * Render labels for up to 100 vouchers of THIS courier as ONE PDF document.
     *
     * If the courier returns one PDF per voucher, the adapter merges them via GRCommerceSuite\Pdf\PdfMerger.
     * The adapter MUST verify the payload starts with the "%PDF-" magic bytes; an HTML/JSON error page
     * delivered with HTTP 200 MUST raise CourierTransportException (or CourierValidationException when the
     * body states a permanent reason).
     *
     * @param non-empty-list<non-empty-string> $voucherNos Max 100 items (SPEC.md §9.2).
     * @param value-of<PrintFormat>            $format     'a4' | 'a6' | 'thermal' (100x150mm label).
     *
     * @return non-empty-string Raw PDF bytes (binary string, not base64).
     *
     * @throws CourierValidationException     Includes an unsupported $format for this courier.
     * @throws VoucherNotFoundException
     * @throws CourierAuthenticationException
     * @throws CourierRateLimitedException
     * @throws CourierTransportException
     */
    public function printVoucherPdf(array $voucherNos, string $format): string;

    /**
     * Fetch the current tracking state of a single voucher.
     *
     * The courier-specific status code is mapped to the normalised TrackingStatus enum by the adapter's
     * status map; unmapped codes MUST map to TrackingStatus::Unknown (never throw) and are logged once
     * per code at warning level so the map can be extended.
     *
     * @param non-empty-string $voucherNo
     *
     * @throws VoucherNotFoundException
     * @throws CourierAuthenticationException
     * @throws CourierRateLimitedException
     * @throws CourierTransportException
     */
    public function getTrackingStatus(string $voucherNo): TrackingResult;

    /**
     * Report COD collection/settlement facts for up to 100 vouchers of THIS courier.
     *
     * The adapter only reports what the courier says; it does not compare amounts and does not decide
     * whether a voucher is reconciled (CodReconciliationService does, SPEC.md §10).
     *
     * Completeness rule: the returned array MUST contain exactly one entry for EVERY input voucher number.
     * Vouchers the courier does not return MUST be present with CodSettlementStatus::NotFound.
     *
     * @param non-empty-list<non-empty-string> $voucherNos Max 100 items.
     *
     * @return array<non-empty-string, CodReconciliationResult> Keyed by voucher number.
     *
     * @throws CourierAuthenticationException
     * @throws CourierRateLimitedException
     * @throws CourierTransportException
     * @throws UnsupportedOperationException
     */
    public function reconcileCodBatch(array $voucherNos): array;
}
