<?php

declare(strict_types=1);

namespace GRCommerceSuite\Contracts;

/**
 * Optional courier capability for validating credentials in admin settings (SPEC.md §8.6).
 */
interface CredentialsValidatorInterface
{
    public function testConnection(): bool;
}
